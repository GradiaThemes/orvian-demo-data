<?php
/**
 * Icon Box Widget
 *
 * @package OrvianAddons
 */

namespace OrvianAddons\Elementor\Widgets;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Icons_Manager;
use Elementor\Group_Control_Typography;
use OrvianAddons\Elementor\Elementor as OrvianAddons_Elementor;

/**
 * Icon Box Widget Class
 */
class Icon_Box extends Widget_Base {

	use Base\Text_Class;

	/**
	 * Get widget name
	 *
	 * @return string
	 */
	public function get_name() {
		return 'orvian-icon-box';
	}

	/**
	 * Get widget title
	 *
	 * @return string
	 */
	public function get_title() {
		return esc_html__( 'Icon Box', 'orvian-addons' );
	}

	/**
	 * Get widget icon
	 *
	 * @return string
	 */
	public function get_icon() {
		return 'eicon-icon-box ' . OrvianAddons_Elementor::CLASS_WIDGET;
	}

	/**
	 * Get widget categories
	 *
	 * @return array
	 */
	public function get_categories() {
		return [ OrvianAddons_Elementor::CATEGORY ];
	}

	/**
	 * Get widget keywords
	 *
	 * @return array
	 */
	public function get_keywords() {
		return [ 'orvian', 'icon', 'box', 'svg' ];
	}

	/**
	 * Register widget controls
	 */
	protected function register_controls() {
		// Section content.
		$this->start_controls_section(
			'content_section',
			[
				'label' => esc_html__( 'Icon Box', 'orvian-addons' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'icon',
			[
				'label'   => esc_html__( 'Icon', 'orvian-addons' ),
				'type'    => Controls_Manager::ICONS,
				'default' => [
					'value'   => 'fas fa-star',
					'library' => 'fa-solid',
				],
			]
		);

		$this->add_control(
			'title',
			[
				'label'       => esc_html__( 'Title', 'orvian-addons' ),
				'type'        => Controls_Manager::TEXT,
				'dynamic'     => [ 'active' => true ],
				'default'     => esc_html__( 'Icon Box', 'orvian-addons' ),
				'placeholder' => esc_html__( 'Type icon box title', 'orvian-addons' ),
			]
		);

		$this->add_control(
			'description',
			[
				'label' => esc_html__( 'Description', 'orvian-addons' ),
				'type'  => Controls_Manager::TEXTAREA,
			]
		);

		$this->add_control(
			'title_size',
			[
				'label'   => esc_html__( 'Title HTML Tag', 'orvian-addons' ),
				'type'    => Controls_Manager::SELECT,
				'options' => $this->get_text_class_options_with_tags(),
				'default' => 'h3',
			]
		);

		$this->add_control(
			'title_link',
			[
				'label'       => esc_html__( 'Title Link', 'orvian-addons' ),
				'type'        => Controls_Manager::URL,
				'placeholder' => esc_html__( 'https://your-link.com', 'orvian-addons' ),
			]
		);

		$this->end_controls_section();

		// Section style.
		$this->start_controls_section(
			'style_section',
			[
				'label' => esc_html__( 'Style', 'orvian-addons' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_responsive_control(
			'icon_position',
			[
				'label'          => esc_html__( 'Icon Position', 'orvian-addons' ),
				'type'           => Controls_Manager::CHOOSE,
				'default'        => 'row',
				'mobile_default' => 'column',
				'options'        => [
					'row'            => [
						'title' => esc_html__( 'Left', 'orvian-addons' ),
						'icon'  => 'eicon-h-align-left',
					],
					'column'         => [
						'title' => esc_html__( 'Top', 'orvian-addons' ),
						'icon'  => 'eicon-v-align-top',
					],
					'row-reverse'    => [
						'title' => esc_html__( 'Right', 'orvian-addons' ),
						'icon'  => 'eicon-h-align-right',
					],
					'column-reverse' => [
						'title' => esc_html__( 'Bottom', 'orvian-addons' ),
						'icon'  => 'eicon-v-align-bottom',
					],
				],
				'selectors'      => [
					'{{WRAPPER}}' => '--icon-position: {{VALUE}};',
				],
				'condition'      => [
					'icon[value]!' => '',
				],
			]
		);

		$this->add_responsive_control(
			'content_vertical_alignment',
			[
				'label'                => esc_html__( 'Vertical Alignment', 'orvian-addons' ),
				'type'                 => Controls_Manager::CHOOSE,
				'options'              => [
					'top'    => [
						'title' => esc_html__( 'Top', 'orvian-addons' ),
						'icon'  => 'eicon-v-align-top',
					],
					'middle' => [
						'title' => esc_html__( 'Middle', 'orvian-addons' ),
						'icon'  => 'eicon-v-align-middle',
					],
					'bottom' => [
						'title' => esc_html__( 'Bottom', 'orvian-addons' ),
						'icon'  => 'eicon-v-align-bottom',
					],
				],
				'default'              => 'middle',
				'selectors_dictionary' => [
					'top'    => 'start',
					'middle' => 'center',
					'bottom' => 'end',
				],
				'selectors'            => [
					'{{WRAPPER}}' => '--content-vertical-alignment: {{VALUE}};',
				],
				'condition'            => [
					'icon[value]!' => '',
				],
			]
		);

		$this->add_responsive_control(
			'icon_vertical_position',
			[
				'label'      => esc_html__( 'Adjust Vertical Position', 'orvian-addons' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%', 'em', 'rem', 'vw', 'custom' ],
				'selectors'  => [
					'{{WRAPPER}}' => '--icon-vertical-position: {{SIZE}}{{UNIT}};',
				],
				'condition'  => [
					'icon[value]!'  => '',
					'icon_position' => [ 'row', 'row-reverse' ],
				],
			]
		);

		$this->add_responsive_control(
			'alignment',
			[
				'label'     => esc_html__( 'Alignment', 'orvian-addons' ),
				'type'      => Controls_Manager::CHOOSE,
				'options'   => [
					'left'   => [
						'title' => esc_html__( 'Left', 'orvian-addons' ),
						'icon'  => 'eicon-text-align-left',
					],
					'center' => [
						'title' => esc_html__( 'Center', 'orvian-addons' ),
						'icon'  => 'eicon-text-align-center',
					],
					'right'  => [
						'title' => esc_html__( 'Right', 'orvian-addons' ),
						'icon'  => 'eicon-text-align-right',
					],
				],
				'default'   => 'center',
				'selectors' => [
					'{{WRAPPER}}' => '--text-align: {{VALUE}}',
				],
			]
		);

		$this->add_responsive_control(
			'icon_space',
			[
				'label'      => esc_html__( 'Icon Spacing', 'orvian-addons' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%', 'em', 'rem', 'vw', 'custom' ],
				'default'    => [
					'size' => 12,
				],
				'selectors'  => [
					'{{WRAPPER}} .orvian-icon-box' => 'gap: {{SIZE}}{{UNIT}}',
				],
				'condition'  => [
					'icon[value]!' => '',
				],
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'style_icon_section',
			[
				'label' => esc_html__( 'Icon', 'orvian-addons' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'color',
			[
				'label'     => esc_html__( 'Color', 'orvian-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .orvian-icon-box .orvian-svg-icon' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_responsive_control(
			'size',
			[
				'label'      => esc_html__( 'Size', 'orvian-addons' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px' ],
				'range'      => [
					'px' => [
						'min' => 0,
						'max' => 500,
					],
				],
				'default'    => [],
				'selectors'  => [
					'{{WRAPPER}} .orvian-icon-box .orvian-svg-icon' => 'font-size: {{SIZE}}{{UNIT}}',
				],
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'style_content_section',
			[
				'label' => esc_html__( 'Content', 'orvian-addons' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'heading_title',
			[
				'label' => esc_html__( 'Title', 'orvian-addons' ),
				'type'  => Controls_Manager::HEADING,
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'typography_title',
				'selector' => '{{WRAPPER}} .orvian-icon-box__title',
			]
		);

		$this->add_control(
			'title_color',
			[
				'label'     => esc_html__( 'Color', 'orvian-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .orvian-icon-box__title' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_control(
			'title_spacing',
			[
				'label'      => esc_html__( 'Spacing', 'orvian-addons' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px' ],
				'range'      => [
					'px' => [
						'min' => 0,
						'max' => 500,
					],
				],
				'selectors'  => [
					'{{WRAPPER}} .orvian-icon-box__title' => 'margin-bottom: {{SIZE}}{{UNIT}}',
				],
			]
		);

		$this->add_control(
			'heading_description',
			[
				'label'     => esc_html__( 'Description', 'orvian-addons' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'typography_description',
				'selector' => '{{WRAPPER}} .orvian-icon-box__description',
			]
		);

		$this->add_control(
			'description_color',
			[
				'label'     => esc_html__( 'Color', 'orvian-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .orvian-icon-box__description' => 'color: {{VALUE}}',
				],
			]
		);

		$this->end_controls_section();
	}

	/**
	 * Render widget output
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();

		if ( empty( $settings['icon'] ) ) {
			return;
		}

		$this->add_render_attribute( 'icon', 'class', [ 'orvian-icon-box', 'flex', 'gap-2', 'items-center' ] );
		$this->add_render_attribute( 'title', 'class', [ 'orvian-icon-box__title', 'font-lg', 'font-medium', 'm-0', 'text-white' ] );
		$this->add_render_attribute( 'description', 'class', [ 'orvian-icon-box__description', 'm-0' ] );

		$title_tag = $this->resolve_text_tag( $settings['title_size'], 'title' );
		$has_link  = ! empty( $settings['title_link']['url'] );

		if ( $has_link ) {
			$this->add_link_attributes( 'title_link', $settings['title_link'] );
		}

		$this->add_inline_editing_attributes( 'title' );
		$this->add_inline_editing_attributes( 'description' );
		?>
		<div <?php $this->print_render_attribute_string( 'icon' ); ?>>
			<span class="orvian-svg-icon text-white">
				<?php Icons_Manager::render_icon( $settings['icon'], [ 'aria-hidden' => 'true' ] ); ?>
			</span>

			<div class="orvian-icon-box__content">
				<?php if ( ! empty( $settings['title'] ) ) : ?>
					<<?php echo esc_attr( $title_tag ); ?> <?php $this->print_render_attribute_string( 'title' ); ?>>
						<?php if ( $has_link ) : ?>
							<a <?php $this->print_render_attribute_string( 'title_link' ); ?>>
								<?php echo wp_kses_post( nl2br( $settings['title'] ) ); ?>
							</a>
						<?php else : ?>
							<?php echo wp_kses_post( nl2br( $settings['title'] ) ); ?>
						<?php endif; ?>
					</<?php echo esc_attr( $title_tag ); ?>>
				<?php endif; ?>

				<?php if ( ! empty( $settings['description'] ) ) : ?>
					<p <?php $this->print_render_attribute_string( 'description' ); ?>><?php echo wp_kses_post( nl2br( $settings['description'] ) ); ?></p>
				<?php endif; ?>
			</div>
		</div>
		<?php
	}
}
