<?php
/**
 * Elementor Builder Header Section
 *
 * @package OrvianAddons
 */

namespace OrvianAddons\Elementor\Builder;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

use OrvianAddons\Elementor\Builder\Helper;

/**
 * Main class of plugin for admin
 */
class Header_Section {

	/**
	 * Instance
	 *
	 * @var $instance
	 */
	private static $instance;

	/**
	 * Initiator
	 *
	 * @return object
	 */
	public static function instance() {
		if ( ! isset( self::$instance ) ) {
			self::$instance = new self();
		}

		return self::$instance;
	}

	/**
	 * Template id
	 *
	 * @var $template_id
	 */
	private static $template_id = 0;

	/**
	 * Instantiate the object.
	 *
	 * @return void
	 */
	public function __construct() {
		add_action( 'wp_enqueue_scripts', [ $this, 'enqueue_scripts' ] );
		add_action( 'orvian_before_site_content', [ $this, 'content_builder' ], 20 );

		add_filter( 'orvian_header_section_default', [ $this, 'header_section_default' ] );
	}

	/**
	 * Enqueue scripts
	 *
	 * @return void
	 */
	public function enqueue_scripts() {
		if ( ! apply_filters( 'orvian_header_section_builder', true ) ) {
			return;
		}

		self::$template_id = $this->get_template_id();

		if ( empty( self::$template_id ) || ! is_numeric( self::$template_id ) ) {
			return;
		}

		$template_id = intval( self::$template_id );
		if ( $template_id <= 0 ) {
			return;
		}

		if ( class_exists( '\Elementor\Core\Files\CSS\Post' ) ) {
			$css_file = new \Elementor\Core\Files\CSS\Post( $template_id );
			if ( $css_file ) {
				$css_file->enqueue();
			}
		}
	}

	/**
	 * Content builder
	 *
	 * @return void
	 */
	public function content_builder() {
		if ( ! apply_filters( 'orvian_header_section_builder', true ) ) {
			return;
		}

		self::$template_id = $this->get_template_id();

		if ( empty( self::$template_id ) || ! is_numeric( self::$template_id ) ) {
			return;
		}

		$template_id = intval( self::$template_id );
		if ( $template_id <= 0 ) {
			return;
		}

		$document = \Elementor\Plugin::instance()->documents->get( $template_id );
		if ( ! empty( $document ) ) {
			?><div class="orvian-header-section orvian-header-section--elementor">
			<?php
			echo \Elementor\Plugin::instance()->frontend->get_builder_content_for_display( $template_id ); // phpcs:ignore
			?>
			</div>
			<?php
		}
	}

	/**
	 * Get Template id
	 *
	 * @return int
	 */
	public function get_template_id() {
		if ( ! empty( self::$template_id ) ) {
			return self::$template_id;
		}

		$template_id = 0;

		if ( is_page() || is_archive() || is_home() || is_404() ) {
			$template_id = Helper::get_query( 'header_section' );

			if ( empty( $template_id ) ) {
				$template_id = Helper::get_query( 'header_section', false, true );
			}
		}

		self::$template_id = $template_id;

		return self::$template_id;
	}

	/**
	 * Header Section default
	 *
	 * @return bool
	 */
	public function header_section_default() {
		self::$template_id = $this->get_template_id();
		if ( empty( self::$template_id ) ) {
			return true;
		}

		return false;
	}
}
