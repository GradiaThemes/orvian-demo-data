<?php
/**
 * Hooks for importer
 *
 * @package OrvianAddons
 */

namespace OrvianAddons\Admin;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Class Importer
 */
class Importer {

	/**
	 * Instance
	 *
	 * @var $instance
	 */
	private static $instance;

	/**
	 * Returns the instance.
	 *
	 * @return object instance of class
	 */
	public static function instance() {
		if ( ! isset( self::$instance ) ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	/**
	 * Class constructor.
	 */
	public function __construct() {
		if ( ! did_action( 'elementor/loaded' ) ) {
			return;
		}

		add_action( 'ocdi/before_import', [ $this,'enable_svg_upload' ] );
		add_filter( 'ocdi/import_files', [ $this, 'import_files' ] );
		add_action( 'ocdi/after_import', [ $this, 'after_import_setup' ] );
	}

	/**
	 * Define demo import files.
	 *
	 * @return array
	 */
	public function import_files() {
		$base_path = 'https://github.com/GradiaThemes/orvian-demo-data/raw/refs/heads/main/data/';

		return [
			[
				'import_file_name'           => esc_html__( 'Personal (Default)', 'orvian-addons' ),
				'import_preview_image_url'   => $base_path . 'personal/preview.jpg',
				'import_file_url'            => $base_path . 'personal/content.xml',
				'import_customizer_file_url' => $base_path . 'personal/customizer.dat',
				'preview_url'                => 'https://orvian.gradiathemes.com/personal-default/',
				'page_slugs'                 => [
					'home'      => 'personal-default',
					'blog'      => 'blog',
					'portfolio' => 'my-work',
				],
				'menu_slugs'                 => [
					'primary'        => 'Primary Menu',
					'primary-mobile' => 'Primary Menu Mobile',
				],
			],
			[
				'import_file_name'           => esc_html__( 'Agency (Dark)', 'orvian-addons' ),
				'import_preview_image_url'   => $base_path . 'agency-dark/preview.jpg',
				'import_file_url'            => $base_path . 'agency-dark/content.xml',
				'import_customizer_file_url' => $base_path . 'agency-dark/customizer.dat',
				'preview_url'                => 'https://orvian.gradiathemes.com/home-agency-dark/',
				'page_slugs'                 => [
					'home'      => 'home-agency-dark',
					'blog'      => 'blog',
					'portfolio' => 'my-work',
				],
				'menu_slugs'                 => [
					'primary'        => 'Primary Menu',
					'primary-mobile' => 'Primary Menu Mobile',
				],
			],
			[
				'import_file_name'           => esc_html__( 'Agency (Light)', 'orvian-addons' ),
				'import_preview_image_url'   => $base_path . 'agency-light/preview.jpg',
				'import_file_url'            => $base_path . 'agency-light/content.xml',
				'import_customizer_file_url' => $base_path . 'agency-light/customizer.dat',
				'preview_url'                => 'https://orvian.gradiathemes.com/home-agency-light/',
				'page_slugs'                 => [
					'home'      => 'home-agency-light',
					'blog'      => 'blog',
					'portfolio' => 'my-work',
				],
				'menu_slugs'                 => [
					'primary'        => 'Primary Menu',
					'primary-mobile' => 'Primary Menu Mobile',
				],
			],
		];
	}

	/**
	 * Enable svg upload
	 */
	public function enable_svg_upload() {
		add_filter( 'upload_mimes', [ $this, 'svg_upload_types' ] );
	}

	/**
	 * Enable svg upload
	 *
	 * @param array $file_types File types.
	 * @return array
	 */
	public function svg_upload_types( $file_types ) {
		$new_filetypes         = [];
		$new_filetypes['svg']  = 'image/svg+xml';
		$new_filetypes['webp'] = 'image/webp';
		$file_types            = array_merge( $file_types, $new_filetypes );
		return $file_types;
	}

	/**
	 * Setup after import.
	 *
	 * @param array $selected_import Selected import data.
	 * @return void
	 */
	public function after_import_setup( $selected_import ) {
		$pages = ! empty( $selected_import['page_slugs'] ) ? $selected_import['page_slugs'] : [];
		$menus = ! empty( $selected_import['menu_slugs'] ) ? $selected_import['menu_slugs'] : [];

		if ( ! empty( $pages['home'] ) ) {
			$page = get_page_by_path( $pages['home'] );
			if ( $page ) {
				update_option( 'show_on_front', 'page' );
				update_option( 'page_on_front', $page->ID );
			}
		}

		if ( ! empty( $pages['blog'] ) ) {
			$page = get_page_by_path( $pages['blog'] );
			if ( $page ) {
				update_option( 'page_for_posts', $page->ID );
			}
		}

		if ( ! empty( $pages['portfolio'] ) ) {
			$page = get_page_by_path( $pages['portfolio'] );
			if ( $page ) {
				update_option( 'orvian_portfolio_page_id', $page->ID );
			}
		}

		if ( ! empty( $menus ) ) {
			$locations = [];
			foreach ( $menus as $location => $menu_name ) {
				$menu = get_term_by( 'name', $menu_name, 'nav_menu' );
				if ( $menu ) {
					$locations[ $location ] = $menu->term_id;
				}
			}
			if ( ! empty( $locations ) ) {
				set_theme_mod( 'nav_menu_locations', $locations );
			}
		}

		update_option( 'elementor_disable_color_schemes', 'yes' );
		update_option( 'elementor_disable_typography_schemes', 'yes' );

		flush_rewrite_rules();
	}
}
