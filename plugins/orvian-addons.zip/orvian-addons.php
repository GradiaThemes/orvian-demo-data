<?php
/**
 * Plugin Name: Orvian Addons
 * Plugin URI: https://orvian.gradiathemes.com
 * Description: A companion plugin for the Orvian theme that adds custom Elementor widgets and theme-specific functionality.
 * Version: 1.0.0
 * Author: GradiaThemes
 * Author URI: https://gradiathemes.com
 * Text Domain: orvian-addons
 * Domain Path: /languages
 * License: GPLv2
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Requires at least: 6.5
 *
 * @package Orvian Addons
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Define plugin constants.
define( 'ORVIAN_ADDONS_VERSION', '1.0.0' );
define( 'ORVIAN_ADDONS_FILE', __FILE__ );
define( 'ORVIAN_ADDONS_PATH', plugin_dir_path( __FILE__ ) );
define( 'ORVIAN_ADDONS_URL', plugin_dir_url( __FILE__ ) );
define( 'ORVIAN_ADDONS_ASSETS_URL', plugins_url( 'assets/', __FILE__ ) );

// Load the autoloader.
require_once ORVIAN_ADDONS_PATH . 'autoload.php';

// Load the plugin.
require_once ORVIAN_ADDONS_PATH . 'inc/plugin.php';

\OrvianAddons\Plugin::instance();
