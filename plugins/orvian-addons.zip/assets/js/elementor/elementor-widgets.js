class OrvianHeadingWidgetHandler extends elementorModules.frontend.handlers.Base {
	getDefaultSettings() {
		return {
			selectors: {
				heading: '.orvian-heading',
				span: '.orvian-heading span',
			},
		};
	}

	getDefaultElements() {
		const selectors = this.getSettings( 'selectors' );
		const widget = this.$element[ 0 ];

		return {
			heading: widget.querySelector( selectors.heading ),
			span: widget.querySelector( selectors.span ),
		};
	}

	animation() {
		const settings = this.getElementSettings();
		const heading = this.elements.heading;
		const span = this.elements.span;

		if ( settings.animation === 'yes' && heading && span ) {
			const widthHeading = heading.offsetWidth;
			const widthSpan = span.offsetWidth;

			if ( widthSpan > widthHeading ) {
				heading.style.setProperty(
					'--transform-width',
					widthSpan - widthHeading + 'px'
				);
			}
		}
	}

	onInit( ...args ) {
		super.onInit( ...args );

		this.animation();
	}
}

class OrvianMarqueeWidgetHandler extends elementorModules.frontend.handlers.Base {
	getDefaultSettings() {
		return {
			selectors: {
				...super.getDefaultSettings().selectors,
				container: '.orvian-elementor--marquee',
				inner: '.orvian-marquee--inner',
				items: '.orvian-marquee--original',
				primary: '.orvian-marquee__primary',
				secondary: '.orvian-marquee__secondary',
			},
		};
	}

	getDefaultElements() {
		const selectors = this.getSettings( 'selectors' );

		return {
			...super.getDefaultElements(),
			$container: this.$element.find( selectors.container ),
			$inner: this.$element.find( selectors.inner ),
			$items: this.$element.find( selectors.items ),
			$primary: this.$element.find( selectors.primary ),
			$secondary: this.$element.find( selectors.secondary ),
		};
	}

	duplicateItems() {
		const settings = this.getElementSettings(),
			  $inner = this.elements.$inner;

		if ( $inner.find( '.orvian-marquee--duplicate').length ) {
			$inner.find( '.orvian-marquee--duplicate').remove();
		}

		if( $inner.length > 1 ) {
			$inner.each( function( i, element ) {
				const $items = jQuery(element).find( '.orvian-marquee--original' );

				let item, amount = ( parseInt( Math.ceil( jQuery( window ).width() / $items.outerWidth( true ) ) ) || 0 ) + 1,
					speed = 1 / parseFloat( settings.speed ?? 0.3 ) * ( $items.outerWidth( true ) / 350 );

				jQuery(element).css( '--orvian-marquee-speed', speed + 's' );

				for ( let i = 1; i <= amount; i++ ) {
					item = $items.clone();
					item.addClass( 'orvian-marquee--duplicate' );
					item.removeClass( 'orvian-marquee--original' );
					item.css( '--orvian-marquee-index', String(i) );

					item.appendTo( jQuery(element) );
				}
			});
		} else {
			const $items = $inner.find( '.orvian-marquee--original' );

			let item, amount = ( parseInt( Math.ceil( jQuery( window ).width() / $items.outerWidth( true ) ) ) || 0 ) + 1,
				speed = 1 / parseFloat( settings.speed ?? 0.3 ) * ( $items.outerWidth( true ) / 350 );

			$inner.css( '--orvian-marquee-speed', speed + 's' );

			for ( let i = 1; i <= amount; i++ ) {
				item = $items.clone();
				item.addClass( 'orvian-marquee--duplicate' );
				item.removeClass( 'orvian-marquee--original' );
				item.css( '--orvian-marquee-index', String(i) );

				item.appendTo( $inner );
			}
		}
	}

	hoverItem() {
		const $primary = this.elements.$primary,
			  $secondary = this.elements.$secondary;

		$primary.on( 'mouseenter', function() {
			$primary.closest('.orvian-marquees').addClass( 'hover-primary' );
		});

		$primary.on( 'mouseleave', function() {
			$primary.closest('.orvian-marquees').removeClass( 'hover-primary' );
		});

		$secondary.on( 'mouseenter', function() {
			$secondary.closest('.orvian-marquees').addClass( 'hover-secondary' );
		});

		$secondary.on( 'mouseleave', function() {
			$secondary.closest('.orvian-marquees').removeClass( 'hover-secondary' );
		});
	}

	onInit( ...args ) {
		super.onInit( ...args );

		this.duplicateItems();

		jQuery( window ).on( 'resize', () => {
			this.duplicateItems();
		});

		this.hoverItem();
	}
}

class OrvianAccordionWidgetHandler extends elementorModules.frontend.handlers.Base {
	onInit( ...args ) {
		super.onInit( ...args );

		const $item = this.$element.find('.orvian-accordion__item'),
			  $title = this.$element.find('.orvian-accordion__title'),
			  $toggle = this.$element.find('.orvian-accordion__toggle');

		$item.on('click', (e) => {
			e.preventDefault();

			jQuery(e.target).find( '.orvian-accordion__title' ).trigger('click');
		});

		$toggle.on('click', (e) => {
			e.preventDefault();

			jQuery(e.target).closest('.orvian-accordion__item').find( '.orvian-accordion__title' ).trigger('click');
		});

		$title.on('click', (e) => {
			e.preventDefault();

			jQuery(e.target).closest('.orvian-accordion__item').siblings().removeClass('open');
			jQuery(e.target).closest('.orvian-accordion__item').siblings().find('.orvian-accordion__content').slideUp();

			if( jQuery(e.target).closest('.orvian-accordion__item').hasClass('open') ) {
				jQuery(e.target).closest('.orvian-accordion__item').removeClass('open');
				jQuery(e.target).closest('.orvian-accordion__item').find('.orvian-accordion__content').slideUp();
			} else {
				jQuery(e.target).closest('.orvian-accordion__item').addClass('open');
				jQuery(e.target).closest('.orvian-accordion__item').find('.orvian-accordion__content').slideDown();
			}
		});
	}
}

class OrvianImageAccordionWidgetHandler extends elementorModules.frontend.handlers.Base {
	getDefaultSettings() {
		return {
			selectors: {
				wrapper: '.orvian-image-accordion',
				thumbnails: '.orvian-image-accordion__thumbnails',
				thumbnailsItem: '.orvian-image-accordion__thumbnails span',
				items: '.orvian-image-accordion__items',
				item: '.orvian-image-accordion__item',
				header: '.orvian-image-accordion__header',
			},
		};
	}

	getDefaultElements() {
		const selectors = this.getSettings( 'selectors' );
		const widget = this.$element[ 0 ];

		return {
			wrapper: widget.querySelector( selectors.wrapper ),
			thumbnails: widget.querySelector( selectors.thumbnails ),
			thumbnailsItems: widget.querySelectorAll( selectors.thumbnailsItem ),
			items: widget.querySelector( selectors.items ),
			itemsList: widget.querySelectorAll( selectors.item ),
		};
	}

	initThumbnails() {
		const { thumbnailsItems } = this.elements;

		if ( ! thumbnailsItems || thumbnailsItems.length === 0 ) {
			return;
		}

		thumbnailsItems.forEach( ( container ) => {
			gsap.set( container, {
				scale: 0,
				transformOrigin: 'center center',
			} );
		} );

		if ( thumbnailsItems[ 0 ] ) {
			gsap.set( thumbnailsItems[ 0 ], { scale: 1 } );
		}
	}

	scaleThumbnails( index ) {
		const { thumbnailsItems } = this.elements;

		if ( ! thumbnailsItems || thumbnailsItems.length === 0 ) {
			return;
		}

		thumbnailsItems.forEach( ( container, i ) => {
			const img = container.querySelector( 'img' );

			if ( i === index ) {
				gsap.set( container, { zIndex: 2 } );
				gsap.fromTo(
					container,
					{ scale: 0 },
					{
						scale: 1,
						duration: 0.8,
						ease: 'power3.out',
						overwrite: 'auto',
					}
				);
				if ( img ) {
					gsap.fromTo(
						img,
						{ scale: 2, zIndex: 2 },
						{
							scale: 1,
							duration: 1.6,
							ease: 'power3.out',
							overwrite: 'auto',
						}
					);
				}
			} else {
				gsap.set( container, { zIndex: 1 } );
			}
		} );
	}

	animateThumbnails( index ) {
		const { thumbnails, items, itemsList } = this.elements;

		if ( ! thumbnails || ! items ) {
			return;
		}

		const thumbnailsHeight = thumbnails.offsetHeight;
		const itemsHeight = items.offsetHeight;

		if ( thumbnailsHeight === 0 || itemsHeight === 0 ) {
			return;
		}

		const safeIndex = index === -1 ? 0 : index;
		const totalItems = itemsList.length;

		if ( totalItems <= 1 ) {
			return;
		}

		const itemGap = ( itemsHeight - thumbnailsHeight ) / ( totalItems - 1 );
		const offsetY = safeIndex * itemGap;

		gsap.to( thumbnails, {
			y: offsetY,
			duration: 0.6,
			ease: 'power3.out',
			overwrite: 'auto',
		} );

		this.scaleThumbnails( safeIndex );
	}

	resetThumbnails() {
		const { thumbnails, itemsList } = this.elements;

		if ( ! thumbnails ) {
			return;
		}

		const openIndex = Array.from( itemsList ).findIndex(
			( item ) => item.classList.contains( 'open' )
		);

		this.animateThumbnails( openIndex );
	}

	onInit( ...args ) {
		super.onInit( ...args );

		const selectors = this.getSettings( 'selectors' );
		const widget = this.$element[ 0 ];

		const $item = this.$element.find( selectors.item );
		const $header = this.$element.find( selectors.header );
		const $toggle = this.$element.find( '.orvian-image-accordion__toggle' );
		const $thumbnails = this.$element.find( selectors.thumbnails );
		const $wrapper = this.$element.find( selectors.wrapper );

		const isTwoColumn =
			$wrapper.hasClass( 'orvian-image-accordion--two-column-left' ) ||
			$wrapper.hasClass( 'orvian-image-accordion--two-column-right' );

		if ( isTwoColumn && typeof gsap !== 'undefined' ) {
			this.initThumbnails();
		}

		$item.on( 'mouseenter', ( e ) => {
			e.preventDefault();

			if ( ! jQuery( e.target ).hasClass( 'open' ) ) {
				jQuery( e.target )
					.find( selectors.header )
					.trigger( 'click' );
			}
		} );

		$toggle.on( 'mouseenter', ( e ) => {
			e.preventDefault();

			if ( ! jQuery( e.target ).hasClass( 'open' ) ) {
				jQuery( e.target )
					.closest( selectors.item )
					.find( '.orvian-image-accordion__title' )
					.trigger( 'click' );
			}
		} );

		$header.on( 'mouseenter', ( e ) => {
			e.preventDefault();

			const $currentItem = jQuery( e.target ).closest( selectors.item );
			const currentIndex = $currentItem.data( 'index' );
			const isOpen = $currentItem.hasClass( 'open' );

			if ( ! isOpen ) {
				$currentItem
					.siblings( '.open' )
					.find( '.orvian-image-accordion__content' )
					.slideUp();
				$currentItem.siblings( '.open' ).removeClass( 'open' );
				$currentItem.addClass( 'open' );
				$currentItem.find( '.orvian-image-accordion__content' ).slideDown( () => {
					if ( isTwoColumn && typeof gsap !== 'undefined' ) {
						this.animateThumbnails( currentIndex );
					}
				} );

				if (
					$thumbnails.find(
						'[data-index="' + currentIndex + '"]'
					).length
				) {
					$thumbnails.find( '.open' ).removeClass( 'open' );
					$thumbnails
						.find( '[data-index="' + currentIndex + '"]' )
						.addClass( 'open' );
				}
			}
		} );
	}
}

class OrvianTestimonialsWidgetHandler extends elementorModules.frontend.handlers.Base {
	renderCircularText() {
		const el = this.$element[ 0 ]?.querySelector(
			'.orvian-circular__text'
		);
		if ( ! el ) {
			return;
		}

		const text = el.dataset.text || el.textContent.trim();
		if ( ! text ) {
			return;
		}

		el.innerHTML = '';

		const size = el.offsetWidth;
		const radius = size / 2;

		const MAX_FONT = 14;
		const MIN_FONT = 8;

		const canvas = document.createElement( 'canvas' );
		const ctx = canvas.getContext( '2d' );

		let fontSize = MAX_FONT;

		while ( fontSize > MIN_FONT ) {
			ctx.font = `${ fontSize }px`;
			const textWidth = ctx.measureText( text ).width;
			const circumference = 2 * Math.PI * radius;

			if ( textWidth <= circumference ) {
				break;
			}

			fontSize--;
		}

		ctx.font = `${ fontSize }px`;
		const baseWidth = ctx.measureText( text ).width;
		const circumference = 2 * Math.PI * radius;

		const spacing =
			text.length > 1 ? ( circumference - baseWidth ) / text.length : 0;

		let angle = -10;
		const anglePerPx = 360 / circumference;

		for ( const char of text ) {
			const span = document.createElement( 'span' );

			span.textContent = char;
			if ( fontSize !== MAX_FONT ) {
				span.style.fontSize = fontSize + 'px';
			}

			const charWidth = ctx.measureText( char ).width + spacing;

			span.style.transform = `rotate(${ angle }deg) translate(${ radius }px) rotate(90deg)`;

			el.appendChild( span );

			angle += charWidth * anglePerPx;
		}
	}

	animation() {
		const container = this.$element[0]?.querySelector('.orvian-testimonials');
		const items = this.$element[0]?.querySelectorAll('.orvian-testimonials__item');

		if ( !container || items.length <= 1 ) {
			return;
		}

		const customOrder = [0, 3, 2, 5, 1, 4].filter(i => items[i]);
		const orderedItems = customOrder.map(i => items[i]);
		const total = orderedItems.length;

		const mm = gsap.matchMedia();

		mm.add( "(min-width: 1200px)", () => {
			const spacing = Math.min( window.innerHeight * 0.5, 500 );

			gsap.set( container, { perspective: 1000 } );

			const applyItem = ( item, i, cursorVal ) => {
				const progress = ( cursorVal - i * spacing ) / spacing;

				let opacityVal;
				if ( progress < -1 || progress > 2 ) {
					opacityVal = 0;
				} else if ( progress < 0 ) {
					opacityVal = ( progress + 1 ) / 1;
				} else if ( progress < 1 ) {
					opacityVal = 1 - 0.7 * progress;
				} else {
					opacityVal = 0.3 * ( 2 - progress );
				}
				opacityVal = opacityVal * opacityVal * ( 3 - 2 * opacityVal );

				let scaleVal;
				if ( progress < -1 ) {
					scaleVal = 0.5;
				} else if ( progress < 0 ) {
					scaleVal = 0.5 + ( progress + 1 ) * 0.5;
				} else if ( progress < 2 ) {
					scaleVal = 1 + progress * 0.4;
				} else {
					scaleVal = 1.8;
				}

				gsap.set( item, {
					z: progress * spacing * 0.3,
					opacity: opacityVal,
					scale: scaleVal,
					filter: `blur(${ ( 1 - opacityVal ) * 15 }px)`,
				} );
			};

			orderedItems.forEach( ( item, i ) => applyItem( item, i, 0 ) );

			const scrollDistance = ( total - 1 ) * spacing + window.innerHeight * 0.3;
			const cursor = { value: 0 };

			const tl = gsap.timeline( {
				scrollTrigger: {
					trigger: container,
					start: "top top",
					end: `+=${ scrollDistance }`,
					pin: true,
					scrub: 1.5,
					invalidateOnRefresh: true,
				}
			} );

			tl.to( cursor, {
				value: ( total - 1 ) * spacing,
				ease: "none",
				duration: 1,
				onUpdate: () => {
					orderedItems.forEach( ( item, i ) => applyItem( item, i, cursor.value ) );
				}
			} );

			return () => {
				ScrollTrigger.getAll().forEach( st => st.kill() );
				gsap.set( items, { clearProps: "all" } );
			};
		} );
	}

	onInit( ...args ) {
		const self = this;
		super.onInit( ...args );

		self.renderCircularText();

		window.Orvian.onAnimationsReady( function() {
			self.animation();
		} );
	}

	onElementChange() {
		this.renderCircularText();
	}
}

class OrvianCounterWidgetHandler extends elementorModules.frontend.handlers.Base {
	getDefaultSettings() {
		return {
			selectors: {
				counter: '.orvian-counter__number',
				counterWrapper: '.orvian-counter__counter',
			},
		};
	}

	getDefaultElements() {
		const selectors = this.getSettings( 'selectors' );
		const widget = this.$element[ 0 ];

		return {
			counter: widget.querySelector( selectors.counter ),
			counterWrapper: widget.querySelector( selectors.counterWrapper ),
		};
	}

	animateCounter() {
		const counter = this.elements.counter;
		const wrapper = this.elements.counterWrapper;

		if ( ! counter || ! wrapper ) {
			return;
		}

		const targetValue = parseFloat( wrapper.dataset.counterValue ) || 0;
		const duration = parseFloat( wrapper.dataset.counterDuration ) || 2;

		if ( targetValue === 0 ) {
			counter.textContent = '0';
			return;
		}

		const obj = { val: 0 };

		gsap.to( obj, {
			val: targetValue,
			duration: duration,
			ease: 'power2.out',
			scrollTrigger: {
				trigger: counter,
				start: 'top 80%',
				once: true,
			},
			onUpdate: () => {
				counter.textContent = Math.floor( obj.val );
			},
		} );
	}

	onInit( ...args ) {
		super.onInit( ...args );

		if ( typeof window.Orvian !== 'undefined' ) {
			window.Orvian.onAnimationsReady( () => {
				this.animateCounter();
			} );
		} else {
			this.animateCounter();
		}
	}
}

class OrvianCounterCardWidgetHandler extends elementorModules.frontend.handlers.Base {
	getDefaultSettings() {
		return {
			selectors: {
				counter: '.orvian-counter-card__number',
				counterWrapper: '.orvian-counter-card__counter',
			},
		};
	}

	getDefaultElements() {
		const selectors = this.getSettings( 'selectors' );
		const widget = this.$element[ 0 ];

		return {
			counter: widget.querySelector( selectors.counter ),
			counterWrapper: widget.querySelector( selectors.counterWrapper ),
		};
	}

	animateCounter() {
		const counter = this.elements.counter;
		const wrapper = this.elements.counterWrapper;

		if ( ! counter || ! wrapper ) {
			return;
		}

		const targetValue = parseFloat( wrapper.dataset.counterValue ) || 0;
		const duration = parseFloat( wrapper.dataset.counterDuration ) || 2;

		if ( targetValue === 0 ) {
			counter.textContent = '0';
			return;
		}

		const obj = { val: 0 };

		gsap.to( obj, {
			val: targetValue,
			duration: duration,
			ease: 'power2.out',
			scrollTrigger: {
				trigger: counter,
				start: 'top 80%',
				once: true,
			},
			onUpdate: () => {
				counter.textContent = Math.floor( obj.val );
			},
		} );
	}

	onInit( ...args ) {
		super.onInit( ...args );

		if ( typeof window.Orvian !== 'undefined' ) {
			window.Orvian.onAnimationsReady( () => {
				this.animateCounter();
			} );
		} else {
			this.animateCounter();
		}
	}
}

class OrvianPricingPlansWidgetHandler extends elementorModules.frontend.handlers.Base {
	onInit( ...args ) {
		super.onInit( ...args );

		const widget = this.$element[ 0 ];

		widget.addEventListener( 'click', ( e ) => {
			const tab = e.target.closest( '.orvian-pricing-plans__tab' ),
				  bg = e.target.closest( '.orvian-pricing-plans__tabs-header' ).querySelector( '.orvian-pricing-plans__tab-bg' );

			if ( ! tab ) {
				return;
			}

			if ( tab.classList.contains( 'active' ) ) {
				return;
			}

			widget
				.querySelectorAll( '.orvian-pricing-plans__tab' )
				.forEach( ( t ) => {
					t.classList.remove( 'active' );
				} );
			widget
				.querySelectorAll( '.orvian-pricing-plans__tabs' )
				.forEach( ( t ) => {
					t.classList.remove( 'active' );
				} );

			if ( bg ) {
				bg.classList.remove( 'animated' );

				if ( bg.classList.contains( 'active' ) ) {
					bg.classList.remove( 'active' );
				} else {
					bg.classList.add( 'active' );
				}

				setTimeout( () => {
					bg.classList.add( 'animated' );
				}, 400 );
			}

			setTimeout( () => {
				tab.classList.add( 'active' );
			}, 200);

			const tabName = tab.dataset.tab;
			const targetTab = widget.querySelector(
				`.orvian-pricing-plans__tabs[data-tab="${ tabName }"]`
			);

			if ( targetTab ) {
				targetTab.classList.add( 'active' );
			}
		} );
	}
}

class OrvianServicesWidgetHandler extends elementorModules.frontend.handlers.Base {
	onInit( ...args ) {
		super.onInit( ...args );

		const self = this;

		window.Orvian.onAnimationsReady( function() {
			self.initServicesAnimation();
		} );
	}

	initServicesAnimation() {
		const $element = this.$element;
		const $imagesCol = $element.find( '.orvian-services__images-col' );
		const $contentCol = $element.find( '.orvian-services__content-col' );
		const $items = $imagesCol.find( '.orvian-services__item' );
		const $contents = $contentCol.find( '.orvian-services__content' );

		if ( $items.length === 0 || $contents.length === 0 ) {
			return;
		}

		const mm = gsap.matchMedia();

		mm.add( '(min-width: 1024px)', () => {
			const triggers = [];
			let initialIndex = 0;

			$items.each( ( i, item ) => {
				const rect = item.getBoundingClientRect();
				if ( rect.top < window.innerHeight * 0.6 ) {
					initialIndex = i;
				}
			} );

			gsap.set( $contents, { opacity: 0 } );
			gsap.set( $contents.eq( initialIndex ), { opacity: 1 } );

			ScrollTrigger.create( {
				trigger: $imagesCol[ 0 ],
				start: 'top top',
				end: () => '+=' + ( $imagesCol[ 0 ].scrollHeight - window.innerHeight * 0.8 ),
				pin: $contentCol[ 0 ],
				invalidateOnRefresh: true,
			} );

			$items.each( ( i, item ) => {
				const st = ScrollTrigger.create( {
					trigger: item,
					start: 'top 60%',
					end: 'bottom 40%',
					onEnter: () => {
						$contents.each( ( j, content ) => {
							gsap.to( content, {
								opacity: j === i ? 1 : 0,
								duration: 0.4,
								ease: 'power2.out',
								overwrite: 'auto',
							} );
						} );
					},
					onEnterBack: () => {
						$contents.each( ( j, content ) => {
							gsap.to( content, {
								opacity: j === i ? 1 : 0,
								duration: 0.4,
								ease: 'power2.out',
								overwrite: 'auto',
							} );
						} );
					},
				} );

				triggers.push( st );
			} );

			return () => {
				triggers.forEach( ( st ) => st.kill() );
			};
		} );
	}
}

window.addEventListener( 'elementor/frontend/init', () => {
	elementorFrontend.hooks.addAction(
		'frontend/element_ready/orvian-heading.default',
		( $element ) => {
			elementorFrontend.elementsHandler.addHandler(
				OrvianHeadingWidgetHandler,
				{ $element }
			);
		}
	);
	elementorFrontend.hooks.addAction(
		'frontend/element_ready/orvian-video.default',
		function ( $element ) {
			if ( $element.data( 'orvian-video-init' ) ) {
				return;
			}
			$element.data( 'orvian-video-init', true );

			$element.attr( 'data-widget_type', 'video.default' );

			elementorFrontend.hooks.doAction(
				'frontend/element_ready/video.default',
				$element
			);
		}
	);
	elementorFrontend.hooks.addAction(
		'frontend/element_ready/orvian-marquee.default',
		( $element ) => {
			elementorFrontend.elementsHandler.addHandler(
				OrvianMarqueeWidgetHandler,
				{ $element }
			);
		}
	);
	elementorFrontend.hooks.addAction(
		'frontend/element_ready/orvian-accordion.default',
		( $element ) => {
			elementorFrontend.elementsHandler.addHandler(
				OrvianAccordionWidgetHandler,
				{ $element }
			);
		}
	);
	elementorFrontend.hooks.addAction(
		'frontend/element_ready/orvian-image-accordion.default',
		( $element ) => {
			elementorFrontend.elementsHandler.addHandler(
				OrvianImageAccordionWidgetHandler,
				{ $element }
			);
		}
	);
	elementorFrontend.hooks.addAction(
		'frontend/element_ready/orvian-services.default',
		( $element ) => {
			elementorFrontend.elementsHandler.addHandler(
				OrvianMarqueeWidgetHandler,
				{ $element }
			);
			elementorFrontend.elementsHandler.addHandler(
				OrvianServicesWidgetHandler,
				{ $element }
			);
		}
	);
	elementorFrontend.hooks.addAction(
		'frontend/element_ready/orvian-testimonials.default',
		( $element ) => {
			elementorFrontend.elementsHandler.addHandler(
				OrvianTestimonialsWidgetHandler,
				{ $element }
			);
		}
	);
	elementorFrontend.hooks.addAction(
		'frontend/element_ready/orvian-pricing-plans.default',
		( $element ) => {
			elementorFrontend.elementsHandler.addHandler(
				OrvianPricingPlansWidgetHandler,
				{ $element }
			);
		}
	);
	elementorFrontend.hooks.addAction(
		'frontend/element_ready/orvian-counter.default',
		( $element ) => {
			elementorFrontend.elementsHandler.addHandler(
				OrvianCounterWidgetHandler,
				{ $element }
			);
		}
	);
	elementorFrontend.hooks.addAction(
		'frontend/element_ready/orvian-counter-card.default',
		( $element ) => {
			elementorFrontend.elementsHandler.addHandler(
				OrvianCounterCardWidgetHandler,
				{ $element }
			);
		}
	);
} );
