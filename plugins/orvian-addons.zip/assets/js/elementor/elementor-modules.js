function OrvianReloadPreviewModule() {

	this.init = function () {
		if (
			typeof elementor === 'undefined' ||
			! elementor.settings
		) {
			return;
		}

		const self = this;

		elementor.settings.page.model.on(
			'change:orvian_color_scheme',
			self.onChange.bind(this)
		);

	};

	this.onChange = function () {

		const model = elementor.settings.page.model;
		const scheme = model.get('orvian_color_scheme');

		const iframe = document.querySelector('#elementor-preview-iframe');
		if (!iframe || !iframe.contentDocument) return;

		const doc = iframe.contentDocument;

		// Elementor wrapper trong preview iframe
		const wrapper = doc.querySelector(
			'.elementor[data-elementor-id="' + elementor.config.document.id + '"]'
		);

		if (!wrapper) return;

		// remove old scheme classes
		wrapper.classList.remove(
			'orvian-color-scheme',
			'theme-light',
			'theme-dark'
		);

		// add new scheme
		if (typeof scheme === 'string' && scheme.length) {
			wrapper.classList.add( 'orvian-color-scheme', scheme);
		}
	};

	this.init();
}

function OrvianCustomCssModule() {
	this.init = function () {
		if ( typeof elementor !== 'undefined' && elementor.hooks ) {
			elementor.hooks.addFilter(
				'editor/style/styleText',
				this.addCustomCss.bind( this )
			);
		}
	};

	this.addCustomCss = function ( css, view ) {
		if ( ! view || typeof view.getEditModel === 'undefined' ) {
			return css;
		}

		const model = view.getEditModel();
		const settings = model.get( 'settings' );
		const customCSS = settings ? settings.get( 'custom_css' ) : '';

		let selector =
			'.elementor-element.elementor-element-' + model.get( 'id' );

		if (
			model.get( 'elType' ) === 'document' &&
			elementor.config &&
			elementor.config.document &&
			elementor.config.document.settings
		) {
			selector = elementor.config.document.settings.cssWrapperSelector;
		}

		if ( customCSS ) {
			css += customCSS.replace( /selector/g, selector );
		}

		return css;
	};

	this.init();
}

if ( typeof window !== 'undefined' ) {
	window.addEventListener( 'elementor:init', function () {
		if ( typeof ElementorProConfig === 'undefined' ) {
			new OrvianCustomCssModule();
		}

		new OrvianReloadPreviewModule();
	} );
}
