document.addEventListener( 'DOMContentLoaded', function () {
	function toggleSizeFieldset( panel ) {
		const hasIcon = panel.querySelector(
			'input[data-tag-option="has_icon"]'
		);
		const sizeFieldset = panel.querySelector( '.orvian-size-fieldset' );

		if ( ! hasIcon || ! sizeFieldset ) {
			return;
		}

		if ( hasIcon.checked ) {
			sizeFieldset.style.display = 'block';
		} else {
			sizeFieldset.style.display = 'none';
			const select = sizeFieldset.querySelector( 'select' );
			if ( select ) {
				select.value = 'default';
			}
		}
	}

	function updateInsertTag( panel ) {
		const insertInput = panel
			.closest( 'form' )
			.querySelector( 'input[data-tag-part="tag"]' );

		if ( ! insertInput ) {
			return;
		}

		let currentTag = insertInput.value;

		const bracketStart = currentTag.indexOf( '[' );
		const bracketEnd = currentTag.indexOf( ']' );

		let prefix = '';
		let optionsStr = '';

		if ( bracketStart !== -1 && bracketEnd !== -1 ) {
			prefix = currentTag.substring( 0, bracketStart );
			optionsStr = currentTag.substring( bracketStart, bracketEnd + 1 );
		} else {
			optionsStr = currentTag;
		}

		const hasIcon = panel
			.querySelector( 'input[data-tag-option="has_icon"]' )
			?.checked;
		const sizeSelect = panel.querySelector(
			'.orvian-size-fieldset select'
		);

		optionsStr = optionsStr.replace( /\s+has_icon/g, '' );
		optionsStr = optionsStr.replace( /\s+size:\w+/g, '' );

		if ( hasIcon ) {
			optionsStr = optionsStr.replace( ']', ' has_icon]' );
		}

		if ( sizeSelect && sizeSelect.value && sizeSelect.value !== 'default' ) {
			optionsStr = optionsStr.replace(
				']',
				' size:' + sizeSelect.value + ']'
			);
		}

		insertInput.value = prefix + optionsStr;
	}

	function initOrvianOptions( panel ) {
		const insertInput = panel
			.closest( 'form' )
			.querySelector( 'input[data-tag-part="tag"]' );

		if ( ! insertInput ) {
			return;
		}

		const currentTag = insertInput.value;
		const hasIconMatch = currentTag.match( /\s+has_icon\b/ );
		const sizeMatch = currentTag.match( /\bsize:(\w+)/ );

		const hasIconInput = panel.querySelector(
			'input[data-tag-option="has_icon"]'
		);
		const sizeSelect = panel.querySelector(
			'.orvian-size-fieldset select'
		);

		if ( hasIconInput ) {
			hasIconInput.checked = !! hasIconMatch;
		}

		if ( sizeSelect ) {
			if ( sizeMatch ) {
				sizeSelect.value = sizeMatch[ 1 ];
			} else {
				sizeSelect.value = 'default';
			}
		}

		toggleSizeFieldset( panel );
	}

	document.addEventListener( 'change', function ( e ) {
		const panel = e.target.closest( '.control-box' );
		if ( ! panel ) {
			return;
		}

		const isOrvianOption =
			e.target.matches( 'input[data-tag-option="has_icon"]' ) ||
			e.target.matches( '.orvian-size-fieldset select' );

		if ( isOrvianOption ) {
			if ( e.target.matches( 'input[data-tag-option="has_icon"]' ) ) {
				toggleSizeFieldset( panel );
			}
			updateInsertTag( panel );
		} else {
			updateInsertTag( panel );
		}
	} );

	document.querySelectorAll( '.control-box' ).forEach( function ( panel ) {
		initOrvianOptions( panel );
		updateInsertTag( panel );
	} );
} );