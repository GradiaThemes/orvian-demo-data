let frameImage;
let frameVideo;

function initImagePicker() {
	document.addEventListener( 'click', function ( e ) {
		const button = e.target.closest(
			'.orvian-brand-thumbnail-button, .orvian-type-thumbnail-button, .orvian-portfolio-image-button'
		);
		if ( ! button ) {
			return;
		}

		e.preventDefault();
		const container = button.closest(
			'.orvian-brand-thumbnail, .orvian-type-thumbnail, .orvian-portfolio-image'
		);
		if ( ! container ) {
			return;
		}

		if ( frameImage ) {
			frameImage.open();
			return;
		}

		frameImage = wp.media( {
			title: 'Select or Upload Image',
			button: { text: 'Use this image' },
			multiple: false,
		} );

		frameImage.on( 'select', function () {
			const attachment = frameImage
				.state()
				.get( 'selection' )
				.first()
				.toJSON();
			const idInput = container.querySelector(
				'.orvian-brand-thumbnail-id, .orvian-type-thumbnail-id, .orvian-portfolio-image-id'
			);
			const preview = container.querySelector(
				'.orvian-brand-thumbnail-preview, .orvian-type-thumbnail-preview, .orvian-portfolio-image-preview'
			);
			const toggle = container.querySelector( '.editor-post-featured-image__toggle' );
			const previewWrap = container.querySelector( '.editor-post-featured-image__preview' );
			const actions = container.querySelector( '.editor-post-featured-image__actions' );
			const removeBtn = container.querySelector(
				'.orvian-brand-thumbnail-remove, .orvian-type-thumbnail-remove, .orvian-portfolio-image-remove'
			);

			if ( idInput ) {
				idInput.value = attachment.id;
				idInput.dispatchEvent( new Event( 'change' ) );
			}

			if ( preview ) {
				preview.src =
					attachment.sizes && attachment.sizes.thumbnail
						? attachment.sizes.thumbnail.url
						: attachment.url;
				preview.style.display = 'block';
			}

			if ( previewWrap ) {
				previewWrap.style.display = '';
			}

			if ( toggle ) {
				toggle.style.display = 'none';
			}

			if ( actions ) {
				actions.style.display = '';
			}

			if ( removeBtn ) {
				removeBtn.style.display = '';
			}
		} );

		frameImage.open();
	} );
}

function initVideoPicker() {
	document.addEventListener( 'click', function ( e ) {
		const button = e.target.closest( '.orvian-type-video-button' );
		if ( ! button ) {
			return;
		}

		e.preventDefault();
		const container = button.closest( '.orvian-type-video' );
		if ( ! container ) {
			return;
		}

		if ( frameVideo ) {
			frameVideo.open();
			return;
		}

		frameVideo = wp.media( {
			title: 'Select or Upload Video',
			library: { type: 'video' },
			button: { text: 'Use this video' },
			multiple: false,
		} );

		frameVideo.on( 'select', function () {
			const attachment = frameVideo
				.state()
				.get( 'selection' )
				.first()
				.toJSON();
			const idInput = container.querySelector( '.orvian-type-video-id' );
			const preview = container.querySelector(
				'.orvian-type-video-preview'
			);
			const removeBtn = container.querySelector(
				'.orvian-type-video-remove'
			);

			if ( idInput ) {
				idInput.value = attachment.id;
				idInput.dispatchEvent( new Event( 'change' ) );
			}

			if ( preview ) {
				const title =
					attachment.title || attachment.filename || attachment.url;
				preview.textContent = title;
				preview.style.display = 'block';
			}

			if ( removeBtn ) {
				removeBtn.style.display = 'block';
			}
		} );

		frameVideo.open();
	} );
}

function initRemoveHandlers() {
	document.addEventListener( 'click', function ( e ) {
		const removeBtn = e.target.closest(
			'.orvian-brand-thumbnail-remove, .orvian-type-thumbnail-remove, .orvian-portfolio-image-remove'
		);
		if ( removeBtn ) {
			e.preventDefault();
			const container = removeBtn.closest(
				'.orvian-brand-thumbnail, .orvian-type-thumbnail, .orvian-portfolio-image'
			);
			if ( ! container ) {
				return;
			}

			const idInput = container.querySelector(
				'.orvian-brand-thumbnail-id, .orvian-type-thumbnail-id, .orvian-portfolio-image-id'
			);
			const preview = container.querySelector(
				'.orvian-brand-thumbnail-preview, .orvian-type-thumbnail-preview, .orvian-portfolio-image-preview'
			);
			const toggle = container.querySelector( '.editor-post-featured-image__toggle' );
			const previewWrap = container.querySelector( '.editor-post-featured-image__preview' );
			const actions = container.querySelector( '.editor-post-featured-image__actions' );

			if ( idInput ) {
				idInput.value = '';
			}
			if ( preview ) {
				preview.style.display = 'none';
				preview.src = '';
			}
			if ( previewWrap ) {
				previewWrap.style.display = 'none';
			}
			if ( toggle ) {
				toggle.style.display = '';
			}
			if ( actions ) {
				actions.style.display = 'none';
			}
			removeBtn.style.display = 'none';
		}

		const videoRemoveBtn = e.target.closest( '.orvian-type-video-remove' );
		if ( videoRemoveBtn ) {
			e.preventDefault();
			const container = videoRemoveBtn.closest( '.orvian-type-video' );
			if ( ! container ) {
				return;
			}

			const idInput = container.querySelector( '.orvian-type-video-id' );
			const preview = container.querySelector(
				'.orvian-type-video-preview'
			);

			if ( idInput ) {
				idInput.value = '';
			}
			if ( preview ) {
				preview.style.display = 'none';
				preview.textContent = '';
			}
			videoRemoveBtn.style.display = 'none';
		}
	} );
}

function initSourceToggle() {
	document.addEventListener( 'change', function ( e ) {
		const select = e.target.closest( '.orvian-type-video-source' );
		if ( ! select ) {
			return;
		}

		const container = select.closest( '.orvian-type-video' );
		if ( ! container ) {
			return;
		}

		const youtubeEl = container.querySelector(
			'.orvian-type-video-youtube'
		);
		const selfhostEl = container.querySelector(
			'.orvian-type-video-selfhost'
		);

		if ( youtubeEl ) {
			youtubeEl.style.display = 'none';
		}
		if ( selfhostEl ) {
			selfhostEl.style.display = 'none';
		}

		if ( select.value === 'youtube' && youtubeEl ) {
			youtubeEl.style.display = 'block';
		} else if ( select.value === 'selfhost' && selfhostEl ) {
			selfhostEl.style.display = 'block';
		}
	} );

	document
		.querySelectorAll( '.orvian-type-video-source' )
		.forEach( function ( select ) {
			select.dispatchEvent( new Event( 'change' ) );
		} );
}

document.addEventListener( 'DOMContentLoaded', function () {
	initImagePicker();
	initVideoPicker();
	initRemoveHandlers();
	initSourceToggle();
} );
