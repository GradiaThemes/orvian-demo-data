<?php
/**
 * Create custom post type portfolio
 *
 * @package OrvianAddons
 */

namespace OrvianAddons\Admin;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Class Portfolio
 */
class Portfolio {
	const POST_TYPE      = 'portfolio';
	const TAXONOMY_TYPE  = 'portfolio_type';
	const TAXONOMY_TAG   = 'portfolio_tag';
	const TAXONOMY_BRAND = 'portfolio_brand';
	const OPTION_NAME    = 'orvian_portfolio';

	/**
	 * The single instance of the class
	 *
	 * @var object
	 */
	protected static $instance = null;

	/**
	 * Returns the instance.
	 *
	 * @return object instance of class
	 */
	public static function instance() {
		if ( ! isset( self::$instance ) ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	/**
	 * Class constructor.
	 */
	public function __construct() {
		// Add an option to enable the CPT.
		add_action( 'admin_init', [ $this, 'settings_api_init' ] );
		add_action( 'current_screen', [ $this, 'save_settings' ] );

		// Make sure the post types are loaded for imports.
		add_action( 'import_start', [ $this, 'register_post_type' ] );

		if ( ! $this->get_option( '', true ) ) {
			return;
		}

		$this->register_post_type();
		add_action( sprintf( 'add_option_%s', self::OPTION_NAME ), 'flush_rewrite_rules' );
		add_action( sprintf( 'update_option_%s', self::OPTION_NAME ), 'flush_rewrite_rules' );
		add_action( sprintf( 'publish_%s', self::POST_TYPE ), 'flush_rewrite_rules' );

		// Handle post columns.
		add_filter( sprintf( 'manage_%s_posts_columns', self::POST_TYPE ), [ $this, 'edit_admin_columns' ] );
		add_action( sprintf( 'manage_%s_posts_custom_column', self::POST_TYPE ), [ $this, 'manage_custom_columns' ], 10, 2 );

		// Enqueue style and javascript.
		add_action( 'admin_enqueue_scripts', [ $this, 'enqueue_scripts' ] );

		// Brand taxonomy thumbnail support (admin handlers).
		add_action( 'admin_enqueue_scripts', [ $this, 'enqueue_brand_term_scripts' ] );
		add_action( self::TAXONOMY_BRAND . '_add_form_fields', [ $this, 'brand_add_form_fields' ], 10, 2 );
		add_action( self::TAXONOMY_BRAND . '_edit_form_fields', [ $this, 'brand_edit_form_fields' ], 10, 2 );
		add_action( 'created_' . self::TAXONOMY_BRAND, [ $this, 'save_brand_thumbnail' ], 10, 2 );
		add_action( 'edited_' . self::TAXONOMY_BRAND, [ $this, 'save_brand_thumbnail' ], 10, 2 );
		add_filter( 'manage_edit-' . self::TAXONOMY_BRAND . '_columns', [ $this, 'brand_taxonomy_columns' ] );
		add_filter( 'manage_' . self::TAXONOMY_BRAND . '_custom_column', [ $this, 'brand_taxonomy_column' ], 10, 3 );

		// Portfolio type taxonomy thumbnail support (same as brand).
		add_action( self::TAXONOMY_TYPE . '_add_form_fields', [ $this, 'type_add_form_fields' ], 10, 2 );
		add_action( self::TAXONOMY_TYPE . '_add_form_fields', [ $this, 'type_add_video_form_fields' ], 20, 2 );
		add_action( self::TAXONOMY_TYPE . '_edit_form_fields', [ $this, 'type_edit_form_fields' ], 10, 2 );
		add_action( self::TAXONOMY_TYPE . '_edit_form_fields', [ $this, 'type_edit_video_form_fields' ], 20, 2 );
		add_action( 'created_' . self::TAXONOMY_TYPE, [ $this, 'save_type_thumbnail' ], 10, 2 );
		add_action( 'edited_' . self::TAXONOMY_TYPE, [ $this, 'save_type_thumbnail' ], 10, 2 );
		add_action( 'created_' . self::TAXONOMY_TYPE, [ $this, 'save_type_video' ], 10, 2 );
		add_action( 'edited_' . self::TAXONOMY_TYPE, [ $this, 'save_type_video' ], 10, 2 );
		add_filter( 'manage_edit-' . self::TAXONOMY_TYPE . '_columns', [ $this, 'type_taxonomy_columns' ] );
		add_filter( 'manage_' . self::TAXONOMY_TYPE . '_custom_column', [ $this, 'type_taxonomy_column' ], 10, 3 );

		// Duplicate.
		add_filter( 'post_row_actions', [ $this, 'duplicate_link' ], 10, 2 );
		add_action( sprintf( 'admin_action_duplicate_%s', self::POST_TYPE ), [ $this, 'duplicate_action' ] );

		// Adjust CPT archive and custom taxonomies to obey CPT reading setting.
		add_filter( 'pre_get_posts', [ $this, 'query_reading_setting' ] );

		// Rewrite url.
		add_filter( 'rewrite_rules_array', [ $this, 'rewrite_rules' ], 30 );
		add_filter( 'post_type_link', [ $this, 'portfolio_post_type_link' ], 10, 2 );
		add_filter( 'attachment_link', [ $this, 'portfolio_attachment_link' ], 10, 2 );

		// Template redirect.
		add_action( 'template_redirect', [ $this, 'template_redirect' ] );

		// Breadcrumb & archive title.
		add_filter( 'orvian_breadcrumbs_args', [ $this, 'breadcrumb' ] );
		add_filter( 'get_the_archive_title', [ $this, 'archive_title' ] );

		// Orvian Dashboard.
		add_filter( 'orvian_dashboard_links', [ $this, 'dashboard_links' ] );

		// Fix menu highlight - remove current_page_parent when viewing portfolio CPT/taxonomy.
		add_filter( 'nav_menu_css_class', [ $this, 'fix_nav_menu_current_parent' ], 20, 2 );

		// Display post states for portfolio page.
		add_filter( 'display_post_states', [ $this, 'display_post_states' ], 10, 2 );

		// Portfolio Image meta box.
		add_action( 'add_meta_boxes', [ $this, 'add_portfolio_meta_boxes' ] );
		add_action( 'save_post_' . self::POST_TYPE, [ $this, 'save_portfolio_image_meta' ], 10, 2 );

		// Support WPML.
		if ( defined( 'ICL_SITEPRESS_VERSION' ) && ! ICL_PLUGIN_INACTIVE && class_exists( 'SitePress' ) ) {
			if ( ! is_admin() ) {
				add_filter( 'pre_get_posts', [ $this, 'translate_archive_query' ], 99 );
				add_filter( 'icl_ls_languages', [ $this, 'translate_archive_url' ] );
			}
		}
	}

	/**
	 * Register portfolio post type
	 */
	public function register_post_type() {
		if ( post_type_exists( self::POST_TYPE ) ) {
			return;
		}

		$permalinks          = $this->get_option( 'permalinks' );
		$portfolio_permalink = empty( $permalinks['portfolio_base'] ) ? _x( 'portfolio', 'slug', 'orvian-addons' ) : $permalinks['portfolio_base'];
		$portfolio_page_id   = $this->get_option( 'page_id' );
		$portfolio_type_base = empty( $permalinks['portfolio_type_base'] ) ? _x( 'portfolio-type', 'slug', 'orvian-addons' ) : $permalinks['portfolio_type_base'];
		$portfolio_tag_base  = empty( $permalinks['portfolio_tag_base'] ) ? _x( 'portfolio-tag', 'slug', 'orvian-addons' ) : $permalinks['portfolio_tag_base'];

		register_post_type(
			self::POST_TYPE,
			[
				'description'         => esc_html__( 'Portfolio Items', 'orvian-addons' ),
				'labels'              => [
					'name'                  => esc_html__( 'Portfolio', 'orvian-addons' ),
					'singular_name'         => esc_html__( 'Project', 'orvian-addons' ),
					'menu_name'             => esc_html__( 'Portfolio', 'orvian-addons' ),
					'all_items'             => esc_html__( 'All Projects', 'orvian-addons' ),
					'add_new'               => esc_html__( 'Add New', 'orvian-addons' ),
					'add_new_item'          => esc_html__( 'Add New Project', 'orvian-addons' ),
					'edit_item'             => esc_html__( 'Edit Project', 'orvian-addons' ),
					'new_item'              => esc_html__( 'New Project', 'orvian-addons' ),
					'view_item'             => esc_html__( 'View Project', 'orvian-addons' ),
					'search_items'          => esc_html__( 'Search Projects', 'orvian-addons' ),
					'not_found'             => esc_html__( 'No Projects found', 'orvian-addons' ),
					'not_found_in_trash'    => esc_html__( 'No Projects found in Trash', 'orvian-addons' ),
					'filter_items_list'     => esc_html__( 'Filter projects list', 'orvian-addons' ),
					'items_list_navigation' => esc_html__( 'Project list navigation', 'orvian-addons' ),
					'items_list'            => esc_html__( 'Projects list', 'orvian-addons' ),
				],
				'supports'            => [
					'title',
					'editor',
					'excerpt',
					'thumbnail',
					'author',
				],
				'rewrite'             => $portfolio_permalink ? [
					'slug'       => untrailingslashit( $portfolio_permalink ),
					'with_front' => false,
					'feeds'      => true,
					'pages'      => true,
				] : false,
				'public'              => true,
				'show_ui'             => true,
				'show_in_rest'        => true,
				'menu_position'       => 20,
				'menu_icon'           => 'dashicons-portfolio',
				'capability_type'     => 'page',
				'query_var'           => true,
				'map_meta_cap'        => true,
				'publicly_queryable'  => true,
				'exclude_from_search' => false,
				'hierarchical'        => false,
				'has_archive'         => $portfolio_page_id && get_post( $portfolio_page_id ) ? urldecode( get_page_uri( $portfolio_page_id ) ) : self::POST_TYPE,
				'show_in_nav_menus'   => true,
			]
		);

		register_taxonomy(
			self::TAXONOMY_TYPE,
			self::POST_TYPE,
			[
				'hierarchical'      => true,
				'labels'            => [
					'name'                  => _x( 'Portfolio Categories', 'Portfolio categories', 'orvian-addons' ),
					'singular_name'         => _x( 'Category', 'Portfolio category', 'orvian-addons' ),
					'menu_name'             => _x( 'Categories', 'Portfolio categories', 'orvian-addons' ),
					'all_items'             => _x( 'All Categories', 'Portfolio categories', 'orvian-addons' ),
					'edit_item'             => _x( 'Edit Category', 'Portfolio categories', 'orvian-addons' ),
					'view_item'             => _x( 'View Category', 'Portfolio categories', 'orvian-addons' ),
					'update_item'           => _x( 'Update Category', 'Portfolio categories', 'orvian-addons' ),
					'add_new_item'          => _x( 'Add New Category', 'Portfolio categories', 'orvian-addons' ),
					'new_item_name'         => _x( 'New Category Name', 'Portfolio categories', 'orvian-addons' ),
					'parent_item'           => _x( 'Parent Category', 'Portfolio categories', 'orvian-addons' ),
					'parent_item_colon'     => _x( 'Parent Category:', 'Portfolio categories', 'orvian-addons' ),
					'search_items'          => _x( 'Search Categories', 'Portfolio categories', 'orvian-addons' ),
					'items_list_navigation' => _x( 'Category list navigation', 'Portfolio categories', 'orvian-addons' ),
					'items_list'            => _x( 'Category list', 'Portfolio categories', 'orvian-addons' ),
				],
				'public'            => true,
				'show_ui'           => true,
				'show_in_nav_menus' => true,
				'show_in_rest'      => true,
				'show_admin_column' => true,
				'query_var'         => true,
				'rewrite'           => [
					'slug'         => $portfolio_type_base,
					'with_front'   => false,
					'hierarchical' => true,
				],
			]
		);

		register_taxonomy(
			self::TAXONOMY_TAG,
			self::POST_TYPE,
			[
				'hierarchical'      => false,
				'labels'            => [
					'name'                  => _x( 'Portfolio Tags', 'Portfolio tag', 'orvian-addons' ),
					'singular_name'         => _x( 'Tag', 'Portfolio tag', 'orvian-addons' ),
					'menu_name'             => _x( 'Tags', 'Portfolio tag', 'orvian-addons' ),
					'all_items'             => _x( 'All Tags', 'Portfolio tag', 'orvian-addons' ),
					'edit_item'             => _x( 'Edit Tag', 'Portfolio tag', 'orvian-addons' ),
					'view_item'             => _x( 'View Tag', 'Portfolio tag', 'orvian-addons' ),
					'update_item'           => _x( 'Update Tag', 'Portfolio tag', 'orvian-addons' ),
					'add_new_item'          => _x( 'Add New Tag', 'Portfolio tag', 'orvian-addons' ),
					'new_item_name'         => _x( 'New Tag Name', 'Portfolio tag', 'orvian-addons' ),
					'parent_item'           => _x( 'Parent Tag', 'Portfolio tag', 'orvian-addons' ),
					'parent_item_colon'     => _x( 'Parent Tag:', 'Portfolio tag', 'orvian-addons' ),
					'search_items'          => _x( 'Search Tags', 'Portfolio tag', 'orvian-addons' ),
					'items_list_navigation' => _x( 'Tag list navigation', 'Portfolio tag', 'orvian-addons' ),
					'items_list'            => _x( 'Tag list', 'Portfolio tag', 'orvian-addons' ),
				],
				'public'            => true,
				'show_ui'           => true,
				'show_in_nav_menus' => true,
				'show_in_rest'      => true,
				'show_admin_column' => true,
				'query_var'         => true,
				'rewrite'           => [ 'slug' => $portfolio_tag_base ],
			]
		);

		// Register brand taxonomy with thumbnail support.
		register_taxonomy(
			self::TAXONOMY_BRAND,
			self::POST_TYPE,
			[
				'hierarchical'      => false,
				'labels'            => [
					'name'                  => _x( 'Portfolio Brands', 'Portfolio brand', 'orvian-addons' ),
					'singular_name'         => _x( 'Brand', 'Portfolio brand', 'orvian-addons' ),
					'menu_name'             => _x( 'Brands', 'Portfolio brand', 'orvian-addons' ),
					'all_items'             => _x( 'All Brands', 'Portfolio brand', 'orvian-addons' ),
					'edit_item'             => _x( 'Edit Brand', 'Portfolio brand', 'orvian-addons' ),
					'view_item'             => _x( 'View Brand', 'Portfolio brand', 'orvian-addons' ),
					'update_item'           => _x( 'Update Brand', 'Portfolio brand', 'orvian-addons' ),
					'add_new_item'          => _x( 'Add New Brand', 'Portfolio brand', 'orvian-addons' ),
					'new_item_name'         => _x( 'New Brand Name', 'Portfolio brand', 'orvian-addons' ),
					'search_items'          => _x( 'Search Brands', 'Portfolio brand', 'orvian-addons' ),
					'items_list_navigation' => _x( 'Brand list navigation', 'Portfolio brand', 'orvian-addons' ),
					'items_list'            => _x( 'Brand list', 'Portfolio brand', 'orvian-addons' ),
				],
				'public'            => true,
				'show_ui'           => true,
				'show_in_nav_menus' => true,
				'show_in_rest'      => true,
				'show_admin_column' => true,
				'query_var'         => true,
				'rewrite'           => [ 'slug' => 'portfolio-brand' ],
			]
		);
	}

	/**
	 * Add custom column to manage portfolio screen
	 * Add Thumbnail column
	 *
	 * @param array $columns Default columns.
	 *
	 * @return array
	 */
	public function edit_admin_columns( $columns ) {
		// change 'Title' to 'Project'.
		$columns['title'] = esc_html__( 'Project', 'orvian-addons' );

		if ( current_theme_supports( 'post-thumbnails' ) ) {
			// add featured image before 'Project'.
			$columns = array_slice( $columns, 0, 1, true ) + [ 'thumbnail' => '' ] + array_slice( $columns, 1, null, true );
		}

		return $columns;
	}

	/**
	 * Handle custom column display
	 *
	 * @param string $column Column name.
	 * @param int    $post_id Post ID.
	 */
	public function manage_custom_columns( $column, $post_id ) {
		switch ( $column ) {
			case 'thumbnail':
				echo get_the_post_thumbnail( $post_id, [ 50, 50 ] );
				break;
		}
	}

	/**
	 * Load scripts and style for meta box
	 *
	 * @param string $hook Current admin page.
	 */
	public function enqueue_scripts( $hook ) {
		$screen = get_current_screen();
		$debug = defined( 'SCRIPT_DEBUG' ) && SCRIPT_DEBUG ? '' : '.min';

		if ( ! $screen || self::POST_TYPE !== $screen->post_type ) {
			return;
		}

		if ( 'edit.php' === $hook && current_theme_supports( 'post-thumbnails' ) ) {
			wp_add_inline_style( 'wp-admin', '.manage-column.column-thumbnail { width: 50px; } @media screen and (max-width: 360px) { .column-thumbnail{ display:none; } }' );
		}

		if ( 'post.php' === $hook || 'post-new.php' === $hook ) {
			wp_enqueue_media();
			wp_enqueue_script( 'orvian-portfolio', ORVIAN_ADDONS_URL . 'assets/js/admin/portfolio' . $debug . '.js', [ 'jquery' ], ORVIAN_ADDONS_VERSION, true );
		}
	}

	/**
	 * Add a checkbox field in 'Settings' > 'Writing' for enabling CPT functionality.
	 * Use the Writing section from Flex Posts class.
	 */
	public function settings_api_init() {
		add_settings_section(
			'orvian_custom_post_type_section',
			'<span id="custom-content-options">' . esc_html__( 'Custom Post Type', 'orvian-addons' ) . '</span>',
			'__return_empty_string',
			'writing'
		);
		add_settings_field(
			self::OPTION_NAME,
			'<span class="portfolio-options">' . esc_html__( 'Portfolio Projects', 'orvian-addons' ) . '</span>',
			[ $this, 'enable_field_html' ],
			'writing',
			'orvian_custom_post_type_section'
		);
		register_setting(
			'writing',
			self::OPTION_NAME,
			'intval'
		);

		// Check if CPT is enabled first so that intval doesn't get set to NULL on re-registering.
		if ( $this->get_option( '', true ) ) {
			// Reading settings.
			add_settings_section(
				'orvian_portfolio_section',
				'<span id="portfolio-options">' . esc_html__( 'Portfolio', 'orvian-addons' ) . '</span>',
				[ $this, 'reading_section_html' ],
				'reading'
			);

			add_settings_field(
				self::OPTION_NAME . '_page_id',
				'<span class="portfolio-options">' . esc_html__( 'Portfolio page', 'orvian-addons' ) . '</span>',
				[ $this, 'page_field_html' ],
				'reading',
				'orvian_portfolio_section'
			);

			register_setting(
				'reading',
				self::OPTION_NAME . '_page_id',
				'intval'
			);

			add_settings_field(
				self::OPTION_NAME . '_posts_per_page',
				'<label for="portfolio_items_per_page">' . esc_html__( 'Portfolio items show at most', 'orvian-addons' ) . '</label>',
				[ $this, 'per_page_field_html' ],
				'reading',
				'orvian_portfolio_section'
			);

			register_setting(
				'reading',
				self::OPTION_NAME . '_posts_per_page',
				'intval'
			);

			// Permalink settings.
			add_settings_section(
				'orvian_portfolio_section',
				'<span id="portfolio-options">' . esc_html__( 'Portfolio Item Permalink', 'orvian-addons' ) . '</span>',
				[ $this, 'permalink_section_html' ],
				'permalink'
			);

			add_settings_field(
				'portfolio_type_slug',
				'<label for="portfolio_type_slug">' . esc_html__( 'Portfolio category base', 'orvian-addons' ) . '</label>',
				[ $this, 'portfolio_type_slug_field_html' ],
				'permalink',
				'optional'
			);

			register_setting(
				'permalink',
				'portfolio_type_slug',
				'sanitize_text_field'
			);

			add_settings_field(
				'portfolio_tag_slug',
				'<label for="portfolio_tag_slug">' . esc_html__( 'Portfolio tag base', 'orvian-addons' ) . '</label>',
				[ $this, 'portfolio_tag_slug_field_html' ],
				'permalink',
				'optional'
			);

			register_setting(
				'permalink',
				'portfolio_tag_slug',
				'sanitize_text_field'
			);
		}
	}

	/**
	 * Add reading setting section
	 */
	public function reading_section_html() {
		?>
		<p>
			<?php esc_html_e( 'Use these settings to control custom post type content', 'orvian-addons' ); ?>
		</p>
		<?php
	}

	/**
	 * Add permalink setting section
	 * and add fields
	 */
	public function permalink_section_html() {
		$permalinks          = $this->get_option( 'permalinks' );
		$portfolio_permalink = isset( $permalinks['portfolio_base'] ) ? $permalinks['portfolio_base'] : '';

		$portfolio_page_id = $this->get_option( 'page_id' );
		$base_slug         = urldecode( ( $portfolio_page_id > 0 && get_post( $portfolio_page_id ) ) ? get_page_uri( $portfolio_page_id ) : _x( 'portfolio', 'Default slug', 'orvian-addons' ) );
		$portfolio_base    = _x( 'portfolio', 'Default slug', 'orvian-addons' );

		$structures = [
			0 => '',
			1 => '/' . trailingslashit( $base_slug ),
			2 => '/' . trailingslashit( $base_slug ) . trailingslashit( '%portfolio_type%' ),
		];
		?>
		<p>
			<?php esc_html_e( 'Use these settings to control the permalink used specifically for portfolio.', 'orvian-addons' ); ?>
		</p>

		<table class="form-table orvian-portfolio-permalink-structure">
			<tbody>
			<tr>
				<th>
					<label><input name="portfolio_permalink" type="radio"
									value="<?php echo esc_attr( $structures[0] ); ?>" <?php checked( $structures[0], $portfolio_permalink ); ?>
									class="orvian-portfolio-base" /> <?php esc_html_e( 'Default', 'orvian-addons' ); ?>
					</label>
				</th>
				<td>
					<code class="default-example"><?php echo esc_html( home_url() ); ?>/?portfolio=sample-portfolio</code>
					<code class="non-default-example"><?php echo esc_html( home_url() ); ?>/<?php echo esc_html( $portfolio_base ); ?>/sample-portfolio/</code>
				</td>
			</tr>
			<?php if ( $base_slug !== $portfolio_base ) : ?>
				<tr>
					<th>
						<label><input name="portfolio_permalink" type="radio"
										value="<?php echo esc_attr( $structures[1] ); ?>" <?php checked( $structures[1], $portfolio_permalink ); ?>
										class="orvian-portfolio-base" /> <?php esc_html_e( 'Portfolio base', 'orvian-addons' ); ?>
						</label>
					</th>
					<td>
						<code><?php echo esc_html( home_url() ); ?>/<?php echo esc_html( $base_slug ); ?>/sample-portfolio/</code>
					</td>
				</tr>
			<?php endif; ?>
			<tr>
				<th>
					<label><input name="portfolio_permalink" type="radio"
									value="<?php echo esc_attr( $structures[2] ); ?>" <?php checked( $structures[2], $portfolio_permalink ); ?>
									class="orvian-portfolio-base" /> <?php esc_html_e( 'Portfolio base with type', 'orvian-addons' ); ?>
					</label>
				</th>
				<td>
					<code><?php echo esc_html( home_url() ); ?>/<?php echo esc_html( $base_slug ); ?>/portfolio-type/sample-portfolio/</code>
				</td>
			</tr>
			<tr>
				<th>
					<label><input name="portfolio_permalink" id="orvian_portfolio_custom_selection" type="radio"
									value="custom" <?php checked( in_array( $portfolio_permalink, $structures, true ), false ); ?> /> <?php esc_html_e( 'Custom Base', 'orvian-addons' ); ?>
					</label>
				</th>
				<td>
					<code><?php echo esc_html( home_url() ); ?></code>
					<input name="portfolio_permalink_structure" id="orvian_portfolio_permalink_structure" type="text"
							value="<?php echo esc_attr( $portfolio_permalink ); ?>" class="regular-text code">
				</td>
			</tr>
			</tbody>
		</table>

		<script type="text/javascript">
			jQuery( function () {
				jQuery( 'input.orvian-portfolio-base' ).change( function () {
					jQuery( '#orvian_portfolio_permalink_structure' ).val( jQuery( this ).val() );
				} );
				jQuery( '.permalink-structure input' ).change( function () {
					jQuery( '.orvian-portfolio-permalink-structure' ).find( 'code.non-default-example, code.default-example' ).hide();
					if ( jQuery( this ).val() ) {
						jQuery( '.orvian-portfolio-permalink-structure code.non-default-example' ).show();
						jQuery( '.orvian-portfolio-permalink-structure input' ).removeAttr( 'disabled' );
					} else {
						jQuery( '.orvian-portfolio-permalink-structure code.default-example' ).show();
						jQuery( '.orvian-portfolio-permalink-structure input:eq(0)' ).click();
						jQuery( '.orvian-portfolio-permalink-structure input' ).attr( 'disabled', 'disabled' );
					}
				} );
				jQuery( '.permalink-structure input:checked' ).change();
				jQuery( '#orvian_portfolio_permalink_structure' ).focus( function () {
					jQuery( '#orvian_portfolio_custom_selection' ).click();
				} );
			} );
		</script>
		<?php
	}

	/**
	 * HTML code to display a checkbox true/false option
	 * for the Portfolio CPT setting.
	 */
	public function enable_field_html() {
		?>
		<label for="<?php echo esc_attr( self::OPTION_NAME ); ?>">
			<input name="<?php echo esc_attr( self::OPTION_NAME ); ?>"
					id="<?php echo esc_attr( self::OPTION_NAME ); ?>" <?php checked( $this->get_option( '', true ), true ); ?>
					type="checkbox" value="1" />
			<?php esc_html_e( 'Enable Portfolio Projects for this site.', 'orvian-addons' ); ?>
		</label>
		<?php
	}

	/**
	 * HTML code to display a drop-down of option for portfolio page
	 */
	public function page_field_html() {
		wp_dropdown_pages(
			[
				'selected'          => esc_attr( $this->get_option( 'page_id' ) ),
				'name'              => esc_attr( self::OPTION_NAME . '_page_id' ),
				'show_option_none'  => esc_html__( '&mdash; Select &mdash;', 'orvian-addons' ),
				'option_none_value' => 0,
			]
		);
	}

	/**
	 * HTML code to display a input of option for portfolio items per page
	 */
	public function per_page_field_html() {
		$name = self::OPTION_NAME . '_posts_per_page';
		?>

		<label for="portfolio_posts_per_page">
			<input name="<?php echo esc_attr( $name ); ?>" id="portfolio_items_per_page" type="number" step="1" min="1"
					value="<?php echo esc_attr( get_option( $name, '6' ) ); ?>" class="small-text" />
			<?php echo esc_html( _x( 'items', 'Portfolio items per page', 'orvian-addons' ) ); ?>
		</label>

		<?php
	}

	/**
	 * HTML code to display a input of option for portfolio type slug
	 */
	public function portfolio_type_slug_field_html() {
		$permalinks = $this->get_option( 'permalinks' );
		$type_base  = isset( $permalinks['portfolio_type_base'] ) ? $permalinks['portfolio_type_base'] : _x( 'portfolio-type', 'slug', 'orvian-addons' );
		?>
		<input name="portfolio_type_slug" id="portfolio_type_slug" type="text"
				value="<?php echo esc_attr( $type_base ); ?>"
				placeholder="<?php echo esc_attr( _x( 'portfolio-type', 'Portfolio type base', 'orvian-addons' ) ); ?>"
				class="regular-text code">
		<?php
	}

	/**
	 * HTML code to display a input of option for portfolio type slug
	 */
	public function portfolio_tag_slug_field_html() {
		$permalinks = $this->get_option( 'permalinks' );
		$tag_base   = isset( $permalinks['portfolio_tag_base'] ) ? $permalinks['portfolio_tag_base'] : _x( 'portfolio-tag', 'slug', 'orvian-addons' );
		?>
		<input name="portfolio_tag_slug" id="portfolio_tag_slug" type="text"
				value="<?php echo esc_attr( $tag_base ); ?>"
				placeholder="<?php echo esc_attr( _x( 'portfolio-tag', 'Portfolio tag base', 'orvian-addons' ) ); ?>"
				class="regular-text code">
		<?php
	}

	/**
	 * Save the settings for permalink and reading
	 * Settings api does not trigger save for the permalink page.
	 */
	public function save_settings() {
		// phpcs:disable:WordPress.Security.NonceVerification
		if ( ! is_admin() ) {
			return;
		}

		$screen = get_current_screen();

		if ( ! $screen ) {
			return;
		}

		// Handle reading settings - flush rewrite rules when page_id changes.
		if ( 'options-reading' === $screen->id ) {
			flush_rewrite_rules();
			return;
		}

		if ( 'options-permalink' !== $screen->id ) {
			return;
		}

		$permalinks = $this->get_option( 'permalinks' );

		if ( ! $permalinks ) {
			$permalinks = [];
		}

		if ( isset( $_POST['portfolio_type_slug'] ) ) {
			// phpcs:ignore
			$permalinks['portfolio_type_base'] = $this->sanitize_permalink( wp_unslash( $_POST['portfolio_type_slug'] ) );
		}

		if ( isset( $_POST['portfolio_tag_slug'] ) ) {
			// phpcs:ignore
			$permalinks['portfolio_tag_base'] = $this->sanitize_permalink( wp_unslash( $_POST['portfolio_tag_slug'] ) );
		}

		if ( isset( $_POST['portfolio_permalink'] ) ) {
			$portfolio_permalink = sanitize_text_field( wp_unslash( $_POST['portfolio_permalink'] ) );

			if ( 'custom' === $portfolio_permalink ) {
				if ( isset( $_POST['portfolio_permalink_structure'] ) ) {
					// phpcs:ignore
					$portfolio_permalink = preg_replace( '#/+#', '/', '/' . str_replace( '#', '', trim( $_POST['portfolio_permalink_structure'] ) ) );
				} else {
					$portfolio_permalink = '/';
				}

				// This is an invalid base structure and breaks pages.
				if ( '%portfolio_type%' === $portfolio_permalink ) {
					$portfolio_permalink = '/' . _x( 'portfolio', 'slug', 'orvian-addons' ) . '/' . $portfolio_permalink;
				}
			} elseif ( empty( $portfolio_permalink ) ) {
				$portfolio_permalink = false;
			}

			$permalinks['portfolio_base'] = $this->sanitize_permalink( $portfolio_permalink );

			// Portfolio base may require verbose page rules if nesting pages.
			$portfolio_page_id   = $this->get_option( 'page_id' );
			$portfolio_permalink = ( $portfolio_page_id > 0 && get_post( $portfolio_page_id ) ) ? get_page_uri( $portfolio_page_id ) : _x( 'portfolio', 'Default slug', 'orvian-addons' );

			if ( $portfolio_page_id && trim( $permalinks['portfolio_base'], '/' ) === $portfolio_permalink ) {
				$permalinks['use_verbose_page_rules'] = true;
			}
		}

		update_option( self::OPTION_NAME . '_permalinks', $permalinks );

		// phpcs:enable
	}

	/**
	 * Follow CPT reading setting on CPT archive and taxonomy pages
	 *
	 * @param \WP_Query $query Query object.
	 */
	public function query_reading_setting( $query ) {
		if ( ( ! is_admin() || ( is_admin() && defined( 'DOING_AJAX' ) && DOING_AJAX ) )
			&& $query->is_main_query()
			&& ( $query->is_post_type_archive( self::POST_TYPE )
				|| $query->is_tax( self::TAXONOMY_TYPE )
				|| $query->is_tax( self::TAXONOMY_TAG ) )
		) {
			$query->set( 'posts_per_page', $this->get_option( 'posts_per_page', 6 ) );
		}

		// Special check for portfolio with the portfolio post type archive on front.
		if ( $query->is_page() && 'page' === get_option( 'show_on_front' ) && $query->get( 'page_id' ) === get_option( 'page_on_front' ) && absint( $query->get( 'page_id' ) ) === $this->get_option( 'page_id' ) ) {
			$query->set( 'post_type', self::POST_TYPE );
			$query->set( 'page_id', '' );

			if ( isset( $query->query['paged'] ) ) {
				$query->set( 'paged', $query->query['paged'] );
			}

			$query->is_singular          = false;
			$query->is_page              = true;
			$query->is_post_type_archive = true;
			$query->is_archive           = true;
		}
	}

	/**
	 * Sanitize permalink
	 *
	 * @param string $value Permalink.
	 *
	 * @return string
	 */
	private function sanitize_permalink( $value ) {
		global $wpdb;

		$value = $wpdb->strip_invalid_text_for_column( $wpdb->options, 'option_value', $value );

		if ( is_wp_error( $value ) ) {
			$value = '';
		}

		$value = esc_url_raw( $value );
		$value = str_replace( 'http://', '', $value );

		return untrailingslashit( $value );
	}

	/**
	 * Various rewrite rule fixes.
	 *
	 * @param array $rules Rewrite rules.
	 *
	 * @return array
	 */
	public function rewrite_rules( $rules ) {
		global $wp_rewrite;

		$permalinks          = $this->get_option( 'permalinks' );
		$portfolio_permalink = empty( $permalinks['portfolio_base'] ) ? _x( 'portfolio', 'slug', 'orvian-addons' ) : $permalinks['portfolio_base'];

		// Fix the rewrite rules when the portfolio permalink have %portfolio_type% flag.
		if ( preg_match( '`/(.+)(/%portfolio_type%)`', $portfolio_permalink, $matches ) ) {
			foreach ( $rules as $rule => $rewrite ) {
				if ( preg_match( '`^' . preg_quote( $matches[1], '`' ) . '/\(`', $rule ) && preg_match( '/^(index\.php\?portfolio_type)(?!(.*portfolio))/', $rewrite ) ) {
					unset( $rules[ $rule ] );
				}
			}
		}

		// If the portfolio page is used as the base, we need to handle shop page subpages to avoid 404s.
		if ( ! isset( $permalinks['use_verbose_page_rules'] ) || ! $permalinks['use_verbose_page_rules'] ) {
			return $rules;
		}

		$portfolio_page_id = $this->get_option( 'page_id' );

		if ( $portfolio_page_id ) {
			$page_rewrite_rules = [];
			$subpages           = $this->get_page_children( $portfolio_page_id );

			// Subpage rules.
			foreach ( $subpages as $subpage ) {
				$uri                                = get_page_uri( $subpage );
				$page_rewrite_rules[ $uri . '/?$' ] = 'index.php?pagename=' . $uri;
				$wp_generated_rewrite_rules         = $wp_rewrite->generate_rewrite_rules( $uri, EP_PAGES, true, true, false, false );
				foreach ( $wp_generated_rewrite_rules as $key => $value ) {
					$wp_generated_rewrite_rules[ $key ] = $value . '&pagename=' . $uri;
				}
				$page_rewrite_rules = array_merge( $page_rewrite_rules, $wp_generated_rewrite_rules );
			}

			// Merge with rules.
			$rules = array_merge( $page_rewrite_rules, $rules );
		}

		return $rules;
	}

	/**
	 * Prevent portfolio attachment links from breaking when using complex rewrite structures.
	 *
	 * @param  string $link Link.
	 * @param  int    $post_id Post ID.
	 *
	 * @return string
	 */
	public function portfolio_attachment_link( $link, $post_id ) {
		global $wp_rewrite;

		$post = get_post( $post_id );
		if ( self::POST_TYPE === get_post_type( $post->post_parent ) ) {
			$permalinks          = $this->get_option( 'permalinks' );
			$portfolio_permalink = empty( $permalinks['portfolio_base'] ) ? _x( 'portfolio', 'slug', 'orvian-addons' ) : $permalinks['portfolio_base'];
			if ( preg_match( '/\/(.+)(\/%portfolio_type%)$/', $portfolio_permalink, $matches ) ) {
				$link = home_url( '/?attachment_id=' . $post->ID );
			}
		}

		return $link;
	}

	/**
	 * Handle redirects before content is output - hooked into template_redirect so is_page works.
	 */
	public function template_redirect() {
		if ( ! is_page() ) {
			return;
		}

		// When default permalinks are enabled, redirect portfolio page to post type archive url.
		// phpcs:ignore
		if ( ! empty( $_GET['page_id'] ) && '' === get_option( 'permalink_structure' ) && $_GET['page_id'] === $this->get_option( 'page_id' ) ) {
			wp_safe_redirect( get_post_type_archive_link( self::POST_TYPE ) );
			exit;
		}
	}

	/**
	 * Filter to allow portfolio_type in the permalinks for portfolios.
	 *
	 * @param  string   $permalink The existing permalink URL.
	 * @param  \WP_Post $post      The post object.
	 *
	 * @return string
	 */
	public function portfolio_post_type_link( $permalink, $post ) {
		// Abort if post is not a portfolio.
		if ( self::POST_TYPE !== $post->post_type ) {
			return $permalink;
		}

		// Abort early if the placeholder rewrite tag isn't in the generated URL.
		if ( false === strpos( $permalink, '%' ) ) {
			return $permalink;
		}

		// Get the custom taxonomy terms in use by this post.
		$terms = get_the_terms( $post->ID, self::TAXONOMY_TYPE );

		if ( ! empty( $terms ) ) {
			if ( function_exists( 'wp_list_sort' ) ) {
				$terms = wp_list_sort( $terms, 'term_id', 'ASC' );
			} else {
				usort( $terms, '_usort_terms_by_ID' );
			}
			$type_object    = get_term( $terms[0], self::TAXONOMY_TYPE );
			$portfolio_type = $type_object->slug;

			if ( $type_object->parent ) {
				$ancestors = get_ancestors( $type_object->term_id, self::TAXONOMY_TYPE );

				foreach ( $ancestors as $ancestor ) {
					$ancestor_object = get_term( $ancestor, self::TAXONOMY_TYPE );
					$portfolio_type  = $ancestor_object->slug . '/' . $portfolio_type;
				}
			}
		} else {
			// If no terms are assigned to this post, use a string instead (can't leave the placeholder there).
			$portfolio_type = _x( 'uncategorized', 'slug', 'orvian-addons' );
		}

		$find = [
			'%year%',
			'%monthnum%',
			'%day%',
			'%hour%',
			'%minute%',
			'%second%',
			'%post_id%',
			'%portfolio_type%',
		];

		$replace = [
			date_i18n( 'Y', strtotime( $post->post_date ) ),
			date_i18n( 'm', strtotime( $post->post_date ) ),
			date_i18n( 'd', strtotime( $post->post_date ) ),
			date_i18n( 'H', strtotime( $post->post_date ) ),
			date_i18n( 'i', strtotime( $post->post_date ) ),
			date_i18n( 's', strtotime( $post->post_date ) ),
			$post->ID,
			$portfolio_type,
		];

		$permalink = str_replace( $find, $replace, $permalink );

		return $permalink;
	}

	/**
	 * Change taxonomy for breadcrumb
	 *
	 * @param array $args Array of breadcrumb arguments.
	 *
	 * @return array mixed
	 */
	public function breadcrumb( $args ) {
		if ( is_singular( self::POST_TYPE ) ) {
			$args['taxonomy'] = self::TAXONOMY_TYPE;
		}

		if ( is_post_type_archive( self::POST_TYPE ) ) {
			$portfolio_page_id = $this->get_option( 'page_id' );

			if ( $portfolio_page_id && get_post( $portfolio_page_id ) ) {
				$args['labels']['archive'] = get_the_title( $portfolio_page_id );
			} else {
				$args['labels']['archive'] = _x( 'Portfolio', 'Portfolio post type breadcrumb', 'orvian-addons' );
			}
		}

		return $args;
	}

	/**
	 * Change archive title
	 *
	 * @param string $title Archive title.
	 *
	 * @return string
	 */
	public function archive_title( $title ) {
		if ( is_post_type_archive( self::POST_TYPE ) ) {
			$portfolio_page_id = $this->get_option( 'page_id' );

			if ( $portfolio_page_id && get_post( $portfolio_page_id ) ) {
				$title = get_the_title( $portfolio_page_id );
			} else {
				$title = _x( 'Portfolio', 'Portfolio post type breadcrumb', 'orvian-addons' );
			}
		}

		return $title;
	}

	/**
	 * Recursively get page children.
	 *
	 * @param  int $page_id Page ID.
	 *
	 * @return array
	 */
	public function get_page_children( $page_id ) {
		$page_ids = get_posts(
			[
				'post_parent'      => $page_id,
				'post_type'        => 'page',
				'numberposts'      => -1,
				'post_status'      => 'any',
				'fields'           => 'ids',
				'suppress_filters' => false,
			]
		);

		if ( ! empty( $page_ids ) ) {
			foreach ( $page_ids as $id ) {
				$page_ids = array_merge( $page_ids, $this->get_page_children( $id ) );
			}
		}

		return $page_ids;
	}

	/**
	 * Add duplicate portfolio link
	 *
	 * @param array  $actions Portfolio actions.
	 * @param object $post Portfolio post object.
	 */
	public function duplicate_link( $actions, $post ) {
		if ( self::POST_TYPE === $post->post_type ) {
			$duplicate_url        = wp_nonce_url(
				admin_url( 'admin.php?action=duplicate_' . self::POST_TYPE . '&post=' . $post->ID ),
				basename( __FILE__ ),
				'duplicate_nonce'
			);
			$actions['duplicate'] = '<a href="' . $duplicate_url . '" title="Duplicate this item">' . esc_html__( 'Duplicate', 'orvian-addons' ) . '</a>';
		}

		return $actions;
	}

	/**
	 * Duplicate portfolio post action
	 */
	public function duplicate_action() {
		// Security and permissions.
		if ( ! ( isset( $_GET['post'] ) || isset( $_POST['post'] ) ) ) {
			wp_die( 'No post to duplicate has been supplied!' );
		}

		// Verify nonce.
		if ( ! isset( $_GET['duplicate_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_GET['duplicate_nonce'] ) ), basename( __FILE__ ) ) ) {
			wp_die( 'Security check failed!' );
		}

		// Get original post.
		$post_id = absint( $_GET['post'] );
		$post    = get_post( $post_id );

		if ( ! $post || self::POST_TYPE !== $post->post_type ) {
			wp_die( 'Invalid post type.' );
		}

		// Permission check.
		if ( ! current_user_can( 'edit_posts' ) ) {
			wp_die( 'You do not have permission to duplicate this post.' );
		}

		$is_elementor = get_post_meta( $post_id, '_elementor_edit_mode', true ) === 'builder';

		// New post data.
		$new_post = [
			'post_title'    => $post->post_title . ' (Copy)',
			'post_content'  => $post->post_content,
			'post_status'   => 'draft',
			'post_type'     => $post->post_type,
			'post_author'   => get_current_user_id(),
			'post_excerpt'  => $post->post_excerpt,
			'post_parent'   => $post->post_parent,
			'post_password' => $post->post_password,
			'post_name'     => '',
		];

		// Create new post.
		$new_post_id = wp_insert_post( $new_post );

		// Duplicate taxonomies.
		$taxonomies = get_object_taxonomies( $post->post_type );
		foreach ( $taxonomies as $taxonomy ) {
			$terms = wp_get_object_terms( $post_id, $taxonomy, [ 'fields' => 'slugs' ] );
			wp_set_object_terms( $new_post_id, $terms, $taxonomy, false );
		}

		// Duplicate post meta.
		$post_meta = get_post_meta( $post_id );
		foreach ( $post_meta as $meta_key => $meta_values ) {
			if ( '_wp_old_slug' === $meta_key ) {
				continue;
			}
			foreach ( $meta_values as $meta_value ) {
				add_post_meta( $new_post_id, $meta_key, maybe_unserialize( $meta_value ) );
			}
		}

		// Duplicate featured image.
		$thumbnail_id = get_post_thumbnail_id( $post_id );
		if ( $thumbnail_id ) {
			set_post_thumbnail( $new_post_id, $thumbnail_id );
		}

		// Redirect to Elementor edit screen.
		if ( $is_elementor ) {
			$data = get_post_meta( $new_post_id, '_elementor_data', true );
			if ( ! empty( $data ) ) {
				update_post_meta( $new_post_id, '_elementor_edit_mode', 'builder' );
				update_post_meta( $new_post_id, '_elementor_version', ELEMENTOR_VERSION );
			}

			if ( class_exists( '\Elementor\Plugin' ) && method_exists( \Elementor\Plugin::$instance->files_manager, 'clear_cache' ) ) {
				\Elementor\Plugin::$instance->files_manager->clear_cache();
			}

			wp_safe_redirect( admin_url( 'post.php?action=elementor&post=' . $new_post_id ) );
			exit;
		}

		// Redirect to edit screen.
		wp_safe_redirect( admin_url( 'post.php?action=edit&post=' . $new_post_id ) );
		exit;
	}

	/**
	 * Add CPT to Elementor settings
	 */
	public function add_to_elementor_settings() {
		if ( ! function_exists( 'is_plugin_active' ) ) {
			require_once ABSPATH . 'wp-admin/includes/plugin.php';
		}

		if ( ! is_plugin_active( 'elementor/elementor.php' ) ) {
			return;
		}

		$cpt_support = get_option( 'elementor_cpt_support', [] );

		if ( ! in_array( self::POST_TYPE, $cpt_support, true ) ) {
			if ( empty( $cpt_support ) ) {
				$cpt_support = [ 'post', 'page' ];
			}

			$cpt_support[] = self::POST_TYPE;
			update_option( 'elementor_cpt_support', $cpt_support );
		}
	}

	/**
	 * Add portfolio settings to dashboard
	 *
	 * @param array $links Dashboard links.
	 */
	public function dashboard_links( $links ) {
		$links['portfolio'] = [
			'title'       => esc_html__( 'Portfolio Settings', 'orvian-addons' ),
			'url'         => admin_url( 'options-writing.php' ),
			'icon'        => '⚙️',
			'description' => esc_html__( 'Configure portfolio post type settings.', 'orvian-addons' ),
			'button_text' => esc_html__( 'Open Settings', 'orvian-addons' ),
		];
		return $links;
	}

	/**
	 * Check if we are on portfolio page
	 */
	public static function is_portfolio() {
		if ( is_singular( self::POST_TYPE ) ) {
			return true;
		}

		return false;
	}

	/**
	 * Check if we are on portfolio archive
	 */
	public static function is_portfolio_archive() {
		return is_post_type_archive( self::POST_TYPE ) || is_tax( get_object_taxonomies( self::POST_TYPE ) );
	}

	/**
	 * Fix nav menu highlighting for portfolio page.
	 * - Add highlight to portfolio page menu item when viewing portfolio content
	 * - Remove incorrect highlight from blog page when viewing portfolio
	 *
	 * @param string[] $classes Current nav item classes.
	 * @param \WP_Post $item    Nav item object.
	 *
	 * @return string[]
	 */
	public function fix_nav_menu_current_parent( $classes, $item ) {
		if ( 'page' !== $item->object || ! $item->object_id ) {
			return $classes;
		}

		if ( self::is_portfolio_archive() || self::is_portfolio() ) {
			if ( self::get_portfolio_page_id() && self::get_portfolio_page_id() === intval( $item->object_id ) ) {
				$classes[] = 'current-menu-item';
				$classes[] = 'current_page_item';
			}

			if ( get_option( 'page_for_posts' ) && get_option( 'page_for_posts' ) === $item->object_id ) {
				$classes = array_diff( $classes, [ 'current_page_parent', 'current_page_ancestor' ] );
			}
		}

		return $classes;
	}

	/**
	 * Get portfolio page id
	 */
	public static function get_portfolio_page_id() {
		$portfolio_page_id = ! empty( self::get_option( 'page_id' ) ) ? absint( self::get_option( 'page_id' ) ) : 0;

		return absint( $portfolio_page_id );
	}

	/**
	 * Add portfolio page state to display states.
	 *
	 * @param array    $post_states Post states.
	 * @param \WP_Post $post        Post object.
	 *
	 * @return array
	 */
	public function display_post_states( $post_states, $post ) {
		if ( 'page' !== $post->post_type ) {
			return $post_states;
		}

		$portfolio_page_id = $this->get_option( 'page_id' );

		if ( $portfolio_page_id && (int) $portfolio_page_id === $post->ID ) {
			$post_states['orvian_portfolio_page'] = esc_html__( 'Portfolios Page', 'orvian-addons' );
		}

		return $post_states;
	}

	/**
	 * Get option of portfolio.
	 *
	 * @param string $option Option name.
	 * @param mixed  $fallback Default value.
	 *
	 * @return mixed
	 */
	private static function get_option( $option = '', $fallback = false ) {
		if ( ! is_string( $option ) ) {
			return $fallback;
		}

		if ( empty( $option ) ) {
			return get_option( self::OPTION_NAME, $fallback );
		}

		return get_option( sprintf( '%s_%s', self::OPTION_NAME, $option ), $fallback );
	}

	/**
	 * Modify the main query of the post type archive page in other languages
	 *
	 * @param \WP_Query $query Query object.
	 */
	public function translate_archive_query( $query ) {
		if ( ! $query->is_main_query() ) {
			return;
		}

		$portfolio_page_id = $this->get_option( 'page_id' );
		$portfolio_page_id = apply_filters( 'translate_object_id', $portfolio_page_id, 'page', true, null );
		$page_id           = $query->get( 'page_id' ) ? $query->get( 'page_id' ) : $query->queried_object_id;

		if ( $portfolio_page_id && $portfolio_page_id === $page_id && self::POST_TYPE !== $query->get( 'post_type' ) ) {
			global $wp_query;

			// do not alter query_object and query_object_id (part 1 of 2).
			$queried_object_original    = isset( $wp_query->queried_object ) ? $wp_query->queried_object : null;
			$queried_object_id_original = isset( $wp_query->queried_object_id ) ? $wp_query->queried_object_id : null;

			$query->set( 'post_type', self::POST_TYPE );
			$query->set( 'page_id', '' );
			$query->set( 'pagename', '' );
			$query->set( 'posts_per_page', $this->get_option( 'posts_per_page', 9 ) );
			$query->set( 'suppress_filters', false );

			if ( isset( $query->query['paged'] ) ) {
				$query->set( 'paged', $query->query['paged'] );
			}

			// Get the actual WP page to avoid errors.
			// This is hacky but works. Awaiting http://core.trac.wordpress.org/ticket/21096.
			global $wp_post_types;

			$query->is_page = true;
			$portfolio_page = get_post( $portfolio_page_id );

			$wp_post_types[ self::POST_TYPE ]->ID         = $portfolio_page->ID;
			$wp_post_types[ self::POST_TYPE ]->post_title = $portfolio_page->post_title;
			$wp_post_types[ self::POST_TYPE ]->post_name  = $portfolio_page->post_name;
			$wp_post_types[ self::POST_TYPE ]->post_type  = $portfolio_page->post_type;
			$wp_post_types[ self::POST_TYPE ]->ancestors  = get_ancestors( $portfolio_page->ID, $portfolio_page->post_type );

			// fix condition funcitons.
			$query->is_singular          = false;
			$query->is_post_type_archive = true;
			$query->is_archive           = true;
			$query->is_page              = false;

			add_filter( 'post_type_archive_title', '__return_empty_string', 5 );

			// do not alter query_object and query_object_id (part 2 of 2).
			if ( is_null( $queried_object_original ) ) {
				unset( $wp_query->queried_object );
			} else {
				$wp_query->queried_object = $queried_object_original;
			}
			if ( is_null( $queried_object_id_original ) ) {
				unset( $wp_query->queried_object_id );
			} else {
				$wp_query->queried_object_id = $queried_object_id_original;
			}
		}
	}

	/**
	 * Translate portfolio archive page URL.
	 *
	 * @see WCML_Store_Pages::translate_ls_shop_url
	 *
	 * @param array $languages Array of languages.
	 * @return array
	 */
	public function translate_archive_url( $languages ) {
		$portfolio_page_id = $this->get_option( 'page_id' );
		$current_lang      = apply_filters( 'wpml_current_language', null );

		foreach ( $languages as $language ) {
			if ( is_post_type_archive( self::POST_TYPE ) ) {
				do_action( 'wpml_switch_language', $language['language_code'] );
				$url = get_permalink( apply_filters( 'translate_object_id', $portfolio_page_id, 'page', true, $language['language_code'] ) );
				do_action( 'wpml_switch_language', $current_lang );

				$languages[ $language['language_code'] ]['url'] = $url;
			}
		}

		// copy get parameters?
		$gets_passed       = [];
		$parameters_copied = apply_filters(
			'icl_lang_sel_copy_parameters',
			array_map(
				'trim',
				explode(
					',',
					wpml_get_setting_filter(
						'',
						'icl_lang_sel_copy_parameters'
					)
				)
			)
		);
		if ( $parameters_copied ) {
			// phpcs:ignore WordPress.Security.NonceVerification
			foreach ( $_GET as $k => $v ) {
				if ( in_array( $k, $parameters_copied, true ) ) {
					$gets_passed[ $k ] = $v;
				}
			}

			foreach ( $languages as $code => $language ) {
				$languages[ $code ]['url'] = add_query_arg( $gets_passed, $language['url'] );
			}
		}

		return $languages;
	}

	/**
	 * Enqueue media scripts for brand term screens.
	 *
	 * @param string $hook Current admin page.
	 */
	public function enqueue_brand_term_scripts( $hook ) {
		$screen = get_current_screen();
		$debug = defined( 'SCRIPT_DEBUG' ) && SCRIPT_DEBUG ? '' : '.min';

		if ( ! $screen ) {
			return;
		}

		if ( ( 'term.php' === $hook || 'edit-tags.php' === $hook ) && isset( $screen->taxonomy ) && in_array( $screen->taxonomy, [ self::TAXONOMY_BRAND, self::TAXONOMY_TYPE ], true ) ) {
			// WordPress media.
			wp_enqueue_media();

			// Small inline script to open media uploader and set thumbnail id/preview.
			wp_enqueue_script( 'orvian-portfolio', ORVIAN_ADDONS_URL . 'assets/js/admin/portfolio' . $debug . '.js', [ 'jquery' ], ORVIAN_ADDONS_VERSION, true );
		}
	}

	/**
	 * Output add-term form field for brand thumbnail.
	 */
	public function brand_add_form_fields() {
		?>
		<div class="form-field term-thumbnail-wrap orvian-brand-thumbnail">
			<label><?php esc_html_e( 'Thumbnail', 'orvian-addons' ); ?></label>
			<div>
				<img class="orvian-brand-thumbnail-preview" src="" style="display:none;max-width:80px;height:auto;display:block;margin-bottom:8px;" alt="" />
				<input type="hidden" name="portfolio_brand_thumbnail_id" class="orvian-brand-thumbnail-id" id="portfolio_brand_thumbnail_id" value="" />
				<p>
					<button class="button orvian-brand-thumbnail-button" type="button"><?php esc_html_e( 'Add image', 'orvian-addons' ); ?></button>
					<button class="button orvian-brand-thumbnail-remove" type="button" style="display:none"><?php esc_html_e( 'Remove image', 'orvian-addons' ); ?></button>
				</p>
			</div>
		</div>
		<?php
	}

	/**
	 * Output add-term form field for portfolio type thumbnail.
	 */
	public function type_add_form_fields() {
		?>
		<div class="form-field term-thumbnail-wrap orvian-type-thumbnail">
			<label><?php esc_html_e( 'Thumbnail', 'orvian-addons' ); ?></label>
			<div>
				<img class="orvian-type-thumbnail-preview" src="" style="display:none;max-width:80px;height:auto;display:block;margin-bottom:8px;" alt="" />
				<input type="hidden" name="portfolio_type_thumbnail_id" class="orvian-type-thumbnail-id" id="portfolio_type_thumbnail_id" value="" />
				<p>
					<button class="button orvian-type-thumbnail-button" type="button"><?php esc_html_e( 'Add image', 'orvian-addons' ); ?></button>
					<button class="button orvian-type-thumbnail-remove" type="button" style="display:none"><?php esc_html_e( 'Remove image', 'orvian-addons' ); ?></button>
				</p>
			</div>
		</div>
		<?php
	}

	/**
	 * Output add-term form field for portfolio type video (YouTube or self-hosted).
	 */
	public function type_add_video_form_fields() {
		?>
		<div class="form-field orvian-type-video">
			<label><?php esc_html_e( 'Video (YouTube or Self-hosted)', 'orvian-addons' ); ?></label>
			<div>
				<select name="portfolio_type_video_source" class="orvian-type-video-source">
					<option value="none"><?php esc_html_e( 'None', 'orvian-addons' ); ?></option>
					<option value="youtube"><?php esc_html_e( 'YouTube URL', 'orvian-addons' ); ?></option>
					<option value="selfhost"><?php esc_html_e( 'Self-hosted (media library)', 'orvian-addons' ); ?></option>
				</select>

				<div class="orvian-type-video-youtube" style="display:none;margin-top:8px;">
					<input type="url" name="portfolio_type_video_youtube" class="regular-text" placeholder="https://www.youtube.com/watch?v=..." />
				</div>

				<div class="orvian-type-video-selfhost" style="display:none;margin-top:8px;">
					<span class="orvian-type-video-preview" style="display:none;display:block;margin-bottom:6px;color:#444;"></span>
					<input type="hidden" name="portfolio_type_video_id" class="orvian-type-video-id" value="" />
					<p>
						<button class="button orvian-type-video-button" type="button"><?php esc_html_e( 'Select video', 'orvian-addons' ); ?></button>
						<button class="button orvian-type-video-remove" type="button" style="display:none"><?php esc_html_e( 'Remove', 'orvian-addons' ); ?></button>
					</p>
				</div>
			</div>
		</div>
		<?php
	}

	/**
	 * Output edit-term form field for portfolio type thumbnail.
	 *
	 * @param object $term Term object.
	 */
	public function type_edit_form_fields( $term ) {
		$thumb_id = get_term_meta( $term->term_id, 'thumbnail_id', true );
		$src      = $thumb_id ? wp_get_attachment_image_url( $thumb_id, 'thumbnail' ) : '';
		?>
		<tr class="form-field term-thumbnail-wrap orvian-type-thumbnail">
			<th scope="row"><label for="portfolio_type_thumbnail_id"><?php esc_html_e( 'Thumbnail', 'orvian-addons' ); ?></label></th>
			<td>
				<img class="orvian-type-thumbnail-preview" src="<?php echo esc_url( $src ); ?>" style="<?php echo $src ? '' : 'display:none;'; ?>max-width:80px;height:auto;display:block;margin-bottom:8px;" alt="" />
				<input type="hidden" name="portfolio_type_thumbnail_id" class="orvian-type-thumbnail-id" id="portfolio_type_thumbnail_id" value="<?php echo esc_attr( $thumb_id ); ?>" />
				<p>
					<button class="button orvian-type-thumbnail-button" type="button"><?php esc_html_e( 'Change image', 'orvian-addons' ); ?></button>
					<button class="button orvian-type-thumbnail-remove" type="button" style="<?php echo $src ? '' : 'display:none;'; ?>"><?php esc_html_e( 'Remove image', 'orvian-addons' ); ?></button>
				</p>
				<p class="description"><?php esc_html_e( 'Assign a thumbnail image to this category. Shown in some portfolio lists.', 'orvian-addons' ); ?></p>
			</td>
		</tr>
		<?php
	}

	/**
	 * Output edit-term form field for portfolio type video (YouTube or self-hosted).
	 *
	 * @param object $term Term object.
	 */
	public function type_edit_video_form_fields( $term ) {
		$video_type = get_term_meta( $term->term_id, 'portfolio_type_video_type', true );
		$video_data = get_term_meta( $term->term_id, 'portfolio_type_video', true );
		$youtube    = ( 'youtube' === $video_type ) ? esc_attr( $video_data ) : '';
		$self_id    = ( 'selfhost' === $video_type ) ? intval( $video_data ) : 0;
		$preview    = $self_id ? get_attached_file( $self_id ) : '';
		?>
		<tr class="form-field orvian-type-video">
			<th scope="row"><label><?php esc_html_e( 'Video (YouTube or Self-hosted)', 'orvian-addons' ); ?></label></th>
			<td>
				<select name="portfolio_type_video_source" class="orvian-type-video-source">
					<option value="none" <?php selected( $video_type, '' ); ?>><?php esc_html_e( 'None', 'orvian-addons' ); ?></option>
					<option value="youtube" <?php selected( $video_type, 'youtube' ); ?>><?php esc_html_e( 'YouTube URL', 'orvian-addons' ); ?></option>
					<option value="selfhost" <?php selected( $video_type, 'selfhost' ); ?>><?php esc_html_e( 'Self-hosted (media library)', 'orvian-addons' ); ?></option>
				</select>

				<div class="orvian-type-video-youtube" style="margin-top:8px;<?php echo 'youtube' === $video_type ? '' : 'display:none;'; ?>">
					<input type="url" name="portfolio_type_video_youtube" class="regular-text" placeholder="https://www.youtube.com/watch?v=..." value="<?php echo esc_attr( $youtube ); ?>" />
				</div>

				<div class="orvian-type-video-selfhost" style="margin-top:8px;<?php echo 'selfhost' === $video_type ? '' : 'display:none;'; ?>">
					<span class="orvian-type-video-preview" style="display:<?php echo $self_id ? 'block' : 'none'; ?>;margin-bottom:6px;color:#444;">
						<?php echo $self_id ? esc_html( basename( get_attached_file( $self_id ) ) ) : ''; ?>
					</span>
					<input type="hidden" name="portfolio_type_video_id" class="orvian-type-video-id" value="<?php echo esc_attr( $self_id ); ?>" />
					<p>
						<button class="button orvian-type-video-button" type="button"><?php esc_html_e( 'Select video', 'orvian-addons' ); ?></button>
						<button class="button orvian-type-video-remove" type="button" style="<?php echo $self_id ? '' : 'display:none;'; ?>"><?php esc_html_e( 'Remove', 'orvian-addons' ); ?></button>
					</p>
				</div>
				<p class="description"><?php esc_html_e( 'Provide a YouTube URL or choose a self-hosted video from the media library. Theme may use this when showing portfolio items in lists.', 'orvian-addons' ); ?></p>
			</td>
		</tr>
		<?php
	}

	/**
	 * Save portfolio type thumbnail term meta when a term is created or edited.
	 *
	 * @param int $term_id Term ID.
	 */
	public function save_type_thumbnail( $term_id ) {
		if ( ! current_user_can( 'manage_categories' ) ) {
			return;
		}

		// phpcs:ignore
		if ( isset( $_POST['portfolio_type_thumbnail_id'] ) ) {
			// phpcs:ignore
			$thumbnail_id = intval( $_POST['portfolio_type_thumbnail_id'] );

			if ( $thumbnail_id ) {
				update_term_meta( $term_id, 'thumbnail_id', $thumbnail_id );
			} else {
				delete_term_meta( $term_id, 'thumbnail_id' );
			}
		}
	}

	/**
	 * Save portfolio type video term meta when a term is created or edited.
	 *
	 * @param int $term_id Term ID.
	 */
	public function save_type_video( $term_id ) {
		if ( ! current_user_can( 'manage_categories' ) ) {
			return;
		}

		// phpcs:ignore WordPress.Security.NonceVerification
		if ( isset( $_POST['portfolio_type_video_source'] ) ) {
			// phpcs:ignore WordPress.Security.ValidatedSanitizedInput, WordPress.Security.NonceVerification
			$source = sanitize_text_field( wp_unslash( $_POST['portfolio_type_video_source'] ) );
			// phpcs:ignore WordPress.Security.NonceVerification
			if ( 'youtube' === $source && isset( $_POST['portfolio_type_video_youtube'] ) ) {
				// phpcs:ignore WordPress.Security.ValidatedSanitizedInput, WordPress.Security.NonceVerification
				$youtube = sanitize_text_field( wp_unslash( $_POST['portfolio_type_video_youtube'] ) );
				if ( $youtube ) {
					update_term_meta( $term_id, 'portfolio_type_video_type', 'youtube' );
					update_term_meta( $term_id, 'portfolio_type_video', $youtube );
				} else {
					delete_term_meta( $term_id, 'portfolio_type_video_type' );
					delete_term_meta( $term_id, 'portfolio_type_video' );
				}
			// phpcs:ignore WordPress.Security.NonceVerification
			} elseif ( 'selfhost' === $source && isset( $_POST['portfolio_type_video_id'] ) ) {
				// phpcs:ignore WordPress.Security.ValidatedSanitizedInput, WordPress.Security.NonceVerification
				$vid = intval( $_POST['portfolio_type_video_id'] );
				if ( $vid ) {
					update_term_meta( $term_id, 'portfolio_type_video_type', 'selfhost' );
					update_term_meta( $term_id, 'portfolio_type_video', $vid );
				} else {
					delete_term_meta( $term_id, 'portfolio_type_video_type' );
					delete_term_meta( $term_id, 'portfolio_type_video' );
				}
			} else {
				// none selected. Remove meta.
				delete_term_meta( $term_id, 'portfolio_type_video_type' );
				delete_term_meta( $term_id, 'portfolio_type_video' );
			}
		}
	}

	/**
	 * Add thumbnail column to type taxonomy list table.
	 *
	 * @param array $columns Columns.
	 * @return array
	 */
	public function type_taxonomy_columns( $columns ) {
		if ( ! empty( $columns ) ) {
			$first   = array_slice( $columns, 0, 1, true );
			$rest    = array_slice( $columns, 1, null, true );
			$columns = $first + [ 'thumbnail' => '' ] + $rest;
		}
		return $columns;
	}

	/**
	 * Render thumbnail column content for type taxonomy.
	 *
	 * @param string $out     Deprecated.
	 * @param string $column  Column name.
	 * @param int    $term_id Term ID.
	 * @return string
	 */
	public function type_taxonomy_column( $out, $column, $term_id ) {
		if ( 'thumbnail' === $column ) {
			$thumb_id = get_term_meta( $term_id, 'thumbnail_id', true );
			if ( $thumb_id ) {
				echo wp_get_attachment_image( $thumb_id, [ 50, 50 ] );
			} else {
				echo '&ndash;';
			}
		}
		return $out;
	}

	/**
	 * Output edit-term form field for brand thumbnail.
	 *
	 * @param object $term Term object.
	 */
	public function brand_edit_form_fields( $term ) {
		$thumb_id = get_term_meta( $term->term_id, 'thumbnail_id', true );
		$src      = $thumb_id ? wp_get_attachment_image_url( $thumb_id, 'thumbnail' ) : '';
		?>
		<tr class="form-field term-thumbnail-wrap orvian-brand-thumbnail">
			<th scope="row"><label for="portfolio_brand_thumbnail_id"><?php esc_html_e( 'Thumbnail', 'orvian-addons' ); ?></label></th>
			<td>
				<img class="orvian-brand-thumbnail-preview" src="<?php echo esc_url( $src ); ?>" style="<?php echo $src ? '' : 'display:none;'; ?>max-width:80px;height:auto;display:block;margin-bottom:8px;" alt="" />
				<input type="hidden" name="portfolio_brand_thumbnail_id" class="orvian-brand-thumbnail-id" id="portfolio_brand_thumbnail_id" value="<?php echo esc_attr( $thumb_id ); ?>" />
				<p>
					<button class="button orvian-brand-thumbnail-button" type="button"><?php esc_html_e( 'Change image', 'orvian-addons' ); ?></button>
					<button class="button orvian-brand-thumbnail-remove" type="button" style="<?php echo $src ? '' : 'display:none;'; ?>"><?php esc_html_e( 'Remove image', 'orvian-addons' ); ?></button>
				</p>
				<p class="description"><?php esc_html_e( 'Assign a thumbnail image to this brand. Shown in some portfolio lists.', 'orvian-addons' ); ?></p>
			</td>
		</tr>
		<?php
	}

	/**
	 * Save brand thumbnail term meta when a term is created or edited.
	 *
	 * @param int $term_id Term ID.
	 */
	public function save_brand_thumbnail( $term_id ) {
		if ( ! current_user_can( 'manage_categories' ) ) {
			return;
		}

		// phpcs:ignore
		if ( isset( $_POST['portfolio_brand_thumbnail_id'] ) ) {
			// phpcs:ignore
			$thumbnail_id = intval( $_POST['portfolio_brand_thumbnail_id'] );

			if ( $thumbnail_id ) {
				update_term_meta( $term_id, 'thumbnail_id', $thumbnail_id );
			} else {
				delete_term_meta( $term_id, 'thumbnail_id' );
			}
		}
	}

	/**
	 * Add thumbnail column to brand taxonomy list table.
	 *
	 * @param array $columns Columns.
	 * @return array
	 */
	public function brand_taxonomy_columns( $columns ) {
		if ( ! empty( $columns ) ) {
			// Insert thumbnail column after checkbox (if exists) or at beginning.
			$first   = array_slice( $columns, 0, 1, true );
			$rest    = array_slice( $columns, 1, null, true );
			$columns = $first + [ 'thumbnail' => '' ] + $rest;
		}
		return $columns;
	}

	/**
	 * Render thumbnail column content for brand taxonomy.
	 *
	 * @param string $out     Deprecated.
	 * @param string $column  Column name.
	 * @param int    $term_id Term ID.
	 * @return string
	 */
	public function brand_taxonomy_column( $out, $column, $term_id ) {
		if ( 'thumbnail' === $column ) {
			$thumb_id = get_term_meta( $term_id, 'thumbnail_id', true );
			if ( $thumb_id ) {
				echo wp_get_attachment_image( $thumb_id, [ 50, 50 ] );
			} else {
				echo '&ndash;';
			}
		}
		return $out;
	}

	/**
	 * Register Portfolio Image meta box.
	 *
	 * Adds a "Portfolio Image" meta box in the side column
	 * (below Featured Image, above Categories).
	 */
	public function add_portfolio_meta_boxes() {
		add_meta_box(
			'portfolio_image',
			esc_html__( 'Portfolio Image', 'orvian-addons' ),
			[ $this, 'render_portfolio_image_meta_box' ],
			self::POST_TYPE,
			'side',
			'low'
		);
	}

	/**
	 * Render Portfolio Image meta box.
	 *
	 * @param \WP_Post $post The post object.
	 */
	public function render_portfolio_image_meta_box( $post ) {
		wp_nonce_field( 'portfolio_image_meta', 'portfolio_image_nonce' );

		$image_id  = get_post_meta( $post->ID, '_portfolio_image_id', true );
		$has_image = $image_id && get_post( $image_id );
		$image_url = $has_image ? wp_get_attachment_image_url( $image_id, [ 266, 266 ] ) : '';
		?>
		<div class="orvian-portfolio-image editor-post-featured-image">
			<div class="editor-post-featured-image__container">
				<button type="button"
					class="components-button editor-post-featured-image__preview is-next-40px-default-size orvian-portfolio-image-button"
					style="<?php echo $has_image ? '' : 'display:none;'; ?>"
					aria-label="<?php esc_attr_e( 'Edit or replace the portfolio image', 'orvian-addons' ); ?>">
					<img class="editor-post-featured-image__preview-image orvian-portfolio-image-preview"
						src="<?php echo esc_url( $image_url ); ?>"
						alt="" style="<?php echo $has_image ? '' : 'display:none;'; ?>" />
				</button>

				<button type="button"
					class="components-button editor-post-featured-image__toggle is-next-40px-default-size orvian-portfolio-image-button"
					style="<?php echo $has_image ? 'display:none;' : ''; ?>">
					<?php esc_html_e( 'Set portfolio image', 'orvian-addons' ); ?>
				</button>

				<div class="components-flex components-h-stack editor-post-featured-image__actions css-13b06dz"
					style="<?php echo $has_image ? '' : 'display:none;'; ?>">
					<button type="button"
						class="components-button editor-post-featured-image__action is-next-40px-default-size orvian-portfolio-image-button">
						<?php esc_html_e( 'Replace', 'orvian-addons' ); ?>
					</button>
					<button type="button"
						class="components-button editor-post-featured-image__action is-next-40px-default-size orvian-portfolio-image-remove">
						<?php esc_html_e( 'Remove', 'orvian-addons' ); ?>
					</button>
				</div>

				<div class="components-drop-zone" data-is-drop-zone="true">
					<div class="components-drop-zone__content">
						<div class="components-drop-zone__content-inner">
							<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24" class="components-drop-zone__content-icon" aria-hidden="true" focusable="false">
								<path d="M18.5 15v3.5H13V6.7l4.5 4.1 1-1.1-6.2-5.8-5.8 5.8 1 1.1 4-4v11.7h-6V15H4v5h16v-5z"></path>
							</svg>
							<span class="components-drop-zone__content-text"><?php esc_html_e( 'Drop files to upload', 'orvian-addons' ); ?></span>
						</div>
					</div>
				</div>

				<input type="hidden" name="portfolio_image_id" class="orvian-portfolio-image-id"
					value="<?php echo esc_attr( $image_id ? $image_id : '-1' ); ?>" />
			</div>
		</div>
		<?php
	}

	/**
	 * Save Portfolio Image meta when the post is saved.
	 *
	 * @param int $post_id Post ID.
	 */
	public function save_portfolio_image_meta( $post_id ) {
		if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
			return;
		}

		if ( ! isset( $_POST['portfolio_image_nonce'] )
			|| ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['portfolio_image_nonce'] ) ), 'portfolio_image_meta' ) ) {
			return;
		}

		if ( ! current_user_can( 'edit_post', $post_id ) ) {
			return;
		}

		// phpcs:ignore WordPress.Security.NonceVerification
		if ( isset( $_POST['portfolio_image_id'] ) ) {
			// phpcs:ignore WordPress.Security.ValidatedSanitizedInput, WordPress.Security.NonceVerification
			$image_id = intval( $_POST['portfolio_image_id'] );

			if ( $image_id && $image_id > 0 ) {
				update_post_meta( $post_id, '_portfolio_image_id', $image_id );
			} else {
				delete_post_meta( $post_id, '_portfolio_image_id' );
			}
		}
	}
}
