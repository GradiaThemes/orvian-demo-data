<?php
/**
 * Hooks for importer
 *
 * @package OrvianAddons
 */

namespace OrvianAddons\Admin;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Class Importer
 */
class Importer {

	/**
	 * Instance
	 *
	 * @var $instance
	 */
	private static $instance;

	/**
	 * Demo files base path.
	 *
	 * @var string
	 */
	private $demo_path;

	/**
	 * Demo files base URL.
	 *
	 * @var string
	 */
	private $demo_url;

	/**
	 * Returns the instance.
	 *
	 * @return object instance of class
	 */
	public static function instance() {
		if ( ! isset( self::$instance ) ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	/**
	 * Class constructor.
	 */
	public function __construct() {
		if ( ! did_action( 'elementor/loaded' ) ) {
			return;
		}

		$this->demo_path = ABSPATH . 'csdl/';
		$this->demo_url  = site_url( '/csdl/' );

		add_filter( 'ocdi/import_files', [ $this, 'import_files' ] );
		add_action( 'ocdi/after_import', [ $this, 'after_import_setup' ] );
		add_filter( 'ocdi/plugin_intro_text', [ $this, 'plugin_intro_text' ] );
	}

	/**
	 * Add intro text to OCDI page.
	 *
	 * @param string $default_text Default intro text.
	 * @return string
	 */
	public function plugin_intro_text( $default_text ) {
		$notice = sprintf(
			'<div class="ocdi__intro-text"><strong>%s</strong></div>',
			esc_html__( 'This demo import requires Elementor plugin to be installed and activated.', 'orvian-addons' )
		);

		return $default_text . $notice;
	}

	/**
	 * Define demo import files.
	 *
	 * @return array
	 */
	public function import_files() {
		$base_path = $this->demo_path;
		$base_url  = $this->demo_url;
		$notice    = esc_html__( 'Important: Elementor plugin must be active. After import, regenerate Elementor CSS from Elementor > Tools.', 'orvian-addons' );

		$demos = [
			'home-01' => [
				'title' => esc_html__( 'Home 01', 'orvian-addons' ),
				'pages' => [
					'home'      => 'home-01',
					'blog'      => 'blog',
					'portfolio' => 'portfolio',
				],
				'menus' => [
					'primary'        => 'Main Menu',
					'primary-mobile' => 'Main Menu',
				],
			],
			'home-02' => [
				'title' => esc_html__( 'Home 02', 'orvian-addons' ),
				'pages' => [
					'home'      => 'home-02',
					'blog'      => 'blog',
					'portfolio' => 'portfolio',
				],
				'menus' => [
					'primary'        => 'Main Menu',
					'primary-mobile' => 'Main Menu',
				],
			],
			'home-03' => [
				'title' => esc_html__( 'Home 03', 'orvian-addons' ),
				'pages' => [
					'home'      => 'home-03',
					'blog'      => 'blog',
					'portfolio' => 'portfolio',
				],
				'menus' => [
					'primary'        => 'Main Menu',
					'primary-mobile' => 'Main Menu',
				],
			],
		];

		$import_files = [];

		foreach ( $demos as $folder => $demo ) {
			$import_files[] = [
				'import_file_name'             => $demo['title'],
				'import_preview_image_url'     => $base_url . $folder . '/preview.jpg',
				'local_import_file'            => $base_path . $folder . '/demo-content.xml',
				'local_import_widget_file'     => $base_path . $folder . '/widgets.wie',
				'local_import_customizer_file' => $base_path . $folder . '/customizer.dat',
				'page_slugs'                   => $demo['pages'],
				'menu_slugs'                   => $demo['menus'],
				'import_notice'                => $notice,
			];
		}

		return $import_files;
	}

	/**
	 * Setup after import.
	 *
	 * @param array $selected_import Selected import data.
	 * @return void
	 */
	public function after_import_setup( $selected_import ) {
		$pages = ! empty( $selected_import['page_slugs'] ) ? $selected_import['page_slugs'] : [];
		$menus = ! empty( $selected_import['menu_slugs'] ) ? $selected_import['menu_slugs'] : [];

		if ( ! empty( $pages['home'] ) ) {
			$page = get_page_by_path( $pages['home'] );
			if ( $page ) {
				update_option( 'show_on_front', 'page' );
				update_option( 'page_on_front', $page->ID );
			}
		}

		if ( ! empty( $pages['blog'] ) ) {
			$page = get_page_by_path( $pages['blog'] );
			if ( $page ) {
				update_option( 'page_for_posts', $page->ID );
			}
		}

		if ( ! empty( $pages['portfolio'] ) ) {
			$page = get_page_by_path( $pages['portfolio'] );
			if ( $page ) {
				update_option( 'orvian_portfolio_page_id', $page->ID );
			}
		}

		if ( ! empty( $menus ) ) {
			$locations = [];
			foreach ( $menus as $location => $menu_name ) {
				$menu = get_term_by( 'name', $menu_name, 'nav_menu' );
				if ( $menu ) {
					$locations[ $location ] = $menu->term_id;
				}
			}
			if ( ! empty( $locations ) ) {
				set_theme_mod( 'nav_menu_locations', $locations );
			}
		}

		update_option( 'elementor_disable_color_schemes', 'yes' );
		update_option( 'elementor_disable_typography_schemes', 'yes' );

		flush_rewrite_rules();
	}
}
