<?php
/**
 * ContactForm class
 *
 * @package OrvianAddons
 */

namespace OrvianAddons\Integrations;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

use OrvianAddons\Helper;

/**
 * ContactForm
 */
class ContactForm {

	/**
	 * Instance
	 *
	 * @var $instance
	 */
	private static $instance;

	/**
	 * Initiator
	 *
	 * @return object
	 */
	public static function instance() {
		if ( ! isset( self::$instance ) ) {
			self::$instance = new self();
		}

		return self::$instance;
	}

	/**
	 * Constructor.
	 */
	public function __construct() {
		add_action( 'wpcf7_init', [ $this, 'register_tag' ] );
		add_action( 'wpcf7_admin_init', [ $this, 'register_tag_generator' ], 55 );
		add_action( 'admin_enqueue_scripts', [ $this, 'enqueue_admin_scripts' ] );
	}

	/**
	 * Load JS file cho admin
	 */
	public function enqueue_admin_scripts() {
		$debug = defined( 'SCRIPT_DEBUG' ) && SCRIPT_DEBUG ? '' : '.min';

		wp_enqueue_script(
			'orvian-submit-admin',
			ORVIAN_ADDONS_ASSETS_URL . 'js/admin/contactform' . $debug . '.js',
			[],
			ORVIAN_ADDONS_VERSION,
			true
		);
	}

	/**
	 * Register frontend tag
	 */
	public function register_tag() {
		if ( ! function_exists( 'wpcf7_add_form_tag' ) ) {
			return;
		}

		wpcf7_add_form_tag( 'orvian_submit', [ $this, 'form_tag_handler' ] );
	}

	/**
	 * Form tag output
	 *
	 * @param object $tag form tag.
	 */
	public function form_tag_handler( $tag ) {
		$class = wpcf7_form_controls_class( $tag->type );

		$atts             = [];
		$atts['class']    = $tag->get_class_option( $class );
		$atts['id']       = $tag->get_id_option();
		$atts['tabindex'] = $tag->get_option( 'tabindex', 'signed_int', true );
		$icon             = '';

		if ( empty( $tag->options ) && empty( $tag->values ) && ! empty( $tag->attr ) ) {
			preg_match_all( '/"[^"]*"|\'[^\']*\'/', $tag->attr, $matches );
			$tag->values = array_map(
				function ( $v ) {
					return trim( $v, '"\' ' );
				},
				$matches[0]
			);

			$options_str  = preg_replace( '/"[^"]*"|\'[^\']*\'/', '', $tag->attr );
			$tag->options = array_values(
				array_filter( preg_split( '/\s+/', trim( $options_str ) ) )
			);
		}

		$options = $tag->options;

		if ( in_array( 'has_icon', $options, true ) ) {
			$atts['class'] .= ' button-primary button-has-icon';
			$icon           = Helper::get_svg( 'arrow-up-right' );
		}

		foreach ( $options as $opt ) {
			if ( strpos( $opt, 'size:' ) === 0 ) {
				$size = substr( $opt, 5 );
				if ( 'small' === $size ) {
					$atts['class'] .= ' button-primary--small';
				}
			}
		}

		$value = isset( $tag->values[0] ) ? $tag->values[0] : '';
		if ( empty( $value ) ) {
			$value = esc_html__( 'Submit', 'contact-form-7' );
		}

		$atts = wpcf7_format_atts( $atts );

		return sprintf(
			'<button type="submit" %1$s><span class="button-text">%2$s</span>%3$s</button>',
			$atts,
			esc_html( $value ),
			$icon
		);
	}

	/**
	 * Register tag generator
	 */
	public function register_tag_generator() {
		if ( ! class_exists( '\WPCF7_TagGenerator' ) ) {
			return;
		}

		$tag_generator = \WPCF7_TagGenerator::get_instance();

		$tag_generator->add(
			'orvian_submit',
			__( 'Orvian Submit', 'contact-form-7' ),
			[ $this, 'tag_generator' ],
			[ 'version' => '2' ]
		);
	}

	/**
	 * Tag generator panel
	 *
	 * @param object $contact_form contact form.
	 * @param array  $options options.
	 */
	public function tag_generator( $contact_form, $options ) {
		$field_types = [
			'orvian_submit' => [
				'display_name' => esc_html__( 'Submit button', 'contact-form-7' ),
				'heading'      => esc_html__( 'Submit button form-tag generator', 'contact-form-7' ),
				'description'  => esc_html__( 'Generates a form-tag for a submit button.', 'contact-form-7' ),
			],
		];

		$tgg       = new \WPCF7_TagGeneratorGenerator( $options['content'] );
		$formatter = new \WPCF7_HTMLFormatter();

		$formatter->append_start_tag(
			'header',
			[ 'class' => 'description-box' ]
		);

		$formatter->append_start_tag( 'h3' );
		$formatter->append_preformatted(
			esc_html( $field_types['orvian_submit']['heading'] )
		);
		$formatter->end_tag( 'h3' );

		$formatter->append_start_tag( 'p' );
		$formatter->append_preformatted(
			wp_kses_data( $field_types['orvian_submit']['description'] )
		);
		$formatter->end_tag( 'header' );

		$formatter->append_start_tag(
			'div',
			[ 'class' => 'control-box' ]
		);

		$formatter->call_user_func(
			static function () use ( $tgg ) {
				$tgg->print(
					'field_type',
					[
						'select_options' => [
							'orvian_submit' => esc_html__( 'Orvian Submit', 'contact-form-7' ),
						],
					]
				);

				$tgg->print(
					'default_value',
					[ 'title' => esc_html__( 'Label', 'contact-form-7' ) ]
				);

				$tgg->print( 'class_attr' );
				$tgg->print( 'id_attr' );

				?>
				<fieldset>
					<legend><?php echo esc_html__( 'Has Icon', 'orvian-addons' ); ?></legend>
					<input type="checkbox" data-tag-part="option" data-tag-option="has_icon" />
				</fieldset>
				<fieldset class="orvian-size-fieldset" style="display:none;">
					<legend><?php echo esc_html__( 'Size', 'orvian-addons' ); ?></legend>
					<select data-tag-part="option">
						<option value="default"><?php echo esc_html__( 'Default', 'orvian-addons' ); ?></option>
						<option value="small"><?php echo esc_html__( 'Small', 'orvian-addons' ); ?></option>
					</select>
				</fieldset>
				<?php
			}
		);

		$formatter->end_tag( 'div' );

		$formatter->append_start_tag(
			'footer',
			[ 'class' => 'insert-box' ]
		);

		$formatter->call_user_func(
			static function () use ( $tgg ) {
				$tgg->print( 'insert_box_content' );
			}
		);

		$formatter->print();
	}
}
