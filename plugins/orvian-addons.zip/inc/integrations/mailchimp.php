<?php
/**
 * MailChimp class
 *
 * @package OrvianAddons
 */

namespace OrvianAddons\Integrations;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

use OrvianAddons\Helper;

/**
 * MailChimp
 */
class MailChimp {

	/**
	 * Instance
	 *
	 * @var $instance
	 */
	private static $instance;

	/**
	 * Initiator
	 *
	 * @return object
	 */
	public static function instance() {
		if ( ! isset( self::$instance ) ) {
			self::$instance = new self();
		}

		return self::$instance;
	}

	/**
	 * Instantiate the object.
	 *
	 * @return void
	 */
	public function __construct() {
		add_filter( 'mc4wp_form_css_classes', [ $this, 'add_mailchimp_class' ], 10, 2 );
		add_filter( 'mc4wp_form_content', [ $this, 'add_html_after_fields' ], 10, 3 );
	}

	/**
	 * Add mailchimp class
	 *
	 * @param array $classes CSS classes.
	 * @param array $form Form.
	 * @return array
	 */
	public function add_mailchimp_class( $classes, $form ) {
		if ( empty( $form->settings['css'] ) ) {
			$classes[] = 'orvian-mc4wp-form-mailchimp';
		}

		return $classes;
	}

	/**
	 * Add html after fields
	 *
	 * @param string $content HTML.
	 * @param array  $form Form.
	 * @return string
	 */
	public function add_html_after_fields( $content, $form ) {
		if ( empty( $form->settings['css'] ) ) {
			$content .= '<button class="orvian-mc4wp-form-mailchimp-button button-primary button-icon absolute">' . Helper::get_svg( 'arrow-up-right' ) . '</button>';
		}

		return $content;
	}
}
