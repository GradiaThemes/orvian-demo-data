<?php
/**
 * OrvianAddons init
 *
 * @package OrvianAddons
 */

namespace OrvianAddons;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * OrvianAddons init
 */
class Plugin {

	/**
	 * Instance
	 *
	 * @var $instance
	 */
	private static $instance;

	/**
	 * Initiator
	 *
	 * @return object
	 */
	public static function instance() {
		if ( ! isset( self::$instance ) ) {
			self::$instance = new self();
		}

		return self::$instance;
	}

	/**
	 * Instantiate the object.
	 *
	 * @return void
	 */
	public function __construct() {
		$current_theme = wp_get_theme();
		if ( ! in_array( $current_theme->get( 'Name' ), [ 'Orvian', 'Orvian Child' ], true ) ) {
			return;
		}

		add_action( 'plugins_loaded', [ $this, 'load_templates' ] );
		add_action( 'init', [ $this, 'load_init' ] );
	}

	/**
	 * Load templates
	 *
	 * @return void
	 */
	public function load_templates() {
		Shortcode::instance();

		if ( did_action( 'elementor/loaded' ) ) {
			Elementor\Elementor::instance();
		}

		if ( defined( 'MC4WP_VERSION' ) ) {
			Integrations\MailChimp::instance();
		}

		if ( class_exists( 'WPCF7' ) ) {
			Integrations\ContactForm::instance();
		}
	}

	/**
	 * Load init
	 *
	 * @return void
	 */
	public function load_init() {
		if ( ! defined( 'ORVIAN_PATH' ) ) {
			return;
		}

		Blocks\Icon_Block::instance();

		Admin\Importer::instance();
		Admin\Portfolio::instance();

		if ( did_action( 'elementor/loaded' ) ) {
			register_activation_hook(
				__FILE__,
				function () {
					$instance = Admin\Portfolio::instance();
					$instance->add_to_elementor_settings();
					flush_rewrite_rules();
				}
			);

			$instance = Admin\Portfolio::instance();
			$instance->add_to_elementor_settings();
		}
	}
}
