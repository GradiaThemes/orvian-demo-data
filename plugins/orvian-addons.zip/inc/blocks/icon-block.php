<?php
/**
 * Icon Block registration and REST API.
 *
 * @package Orvian Addons
 */

namespace OrvianAddons\Blocks;

use Orvian\Icon;
use WP_REST_Request;
use WP_REST_Response;
use WP_REST_Server;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class Icon_Block
 */
final class Icon_Block {

	/**
	 * Singleton instance.
	 *
	 * @var Icon_Block|null
	 */
	private static $instance = null;

	/**
	 * Get singleton instance.
	 *
	 * @return Icon_Block
	 */
	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	/**
	 * Constructor.
	 */
	private function __construct() {
		$this->register_block();
		add_action( 'rest_api_init', [ $this, 'register_rest_route' ] );
	}

	/**
	 * Register the Icon block.
	 */
	public function register_block() {
		$path = ORVIAN_ADDONS_PATH . 'inc/blocks/icon';

		if ( ! file_exists( $path ) ) {
			return;
		}

		register_block_type(
			$path,
			[
				'render_callback' => [ $this, 'render_callback' ],
			]
		);
	}

	/**
	 * Render callback for the Icon block.
	 *
	 * @param array $attributes Block attributes.
	 * @return string Rendered HTML.
	 */
	public function render_callback( $attributes ) {
		$icon_attr     = $this->build_icon_attributes( $attributes );
		$wrapper_attrs = get_block_wrapper_attributes(
			[
				'class' => 'wp-block-orvian-block-icon text-heading',
			]
		);

		return sprintf(
			'<div %s>%s</div>',
			$wrapper_attrs,
			$icon_attr
		);
	}

	/**
	 * Build SVG element from attributes.
	 *
	 * @param array $attributes Block attributes.
	 * @return string
	 */
	private function build_svg_element( array $attributes ): string {
		$icon_type  = $attributes['iconType'] ?? 'default';
		$custom_svg = $attributes['customSvg'] ?? '';

		if ( 'custom' === $icon_type && ! empty( $custom_svg ) ) {
			$svg = Icon::sanitize_svg( $custom_svg );
		} else {
			$icons   = self::get_icons_args();
			$svg_raw = $icons[ $attributes['icon'] ] ?? '';

			if ( empty( $svg_raw ) ) {
				return '';
			}

			$svg = $svg_raw;
		}

		return preg_replace( '/^<svg /', '<svg aria-hidden="true" role="img" focusable="false" ', $svg );
	}

	/**
	 * Build icon span with classes and SVG.
	 *
	 * @param array $attributes Block attributes.
	 * @return string
	 */
	private function build_icon_attributes( array $attributes ): string {
		$svg       = $this->build_svg_element( $attributes );
		$icon_type = $attributes['iconType'] ?? 'default';

		$icon_class = 'custom' === $icon_type
			? 'orvian-svg-icon orvian-svg-icon--custom'
			: 'orvian-svg-icon orvian-svg-icon--' . $attributes['icon'];

		$extra_class = $attributes['className'] ?? '';
		if ( ! empty( $extra_class ) ) {
			$icon_class .= ' ' . $extra_class;
		}

		return sprintf(
			'<span class="%s">%s</span>',
			esc_attr( $icon_class ),
			$svg
		);
	}

	/**
	 * Register REST API route for icons list.
	 */
	public function register_rest_route() {
		register_rest_route(
			'orvian/v1',
			'/icons',
			[
				'methods'             => WP_REST_Server::READABLE,
				'callback'            => [ $this, 'get_icons_list' ],
				'permission_callback' => '__return_true',
			]
		);
	}

	/**
	 * Get icons list for REST API.
	 *
	 * @return WP_REST_Response Response object.
	 */
	public function get_icons_list() {
		$icons = $this->get_icons_args();

		$options = [];
		foreach ( $icons as $value => $svg ) {
			$options[] = [
				'value' => $value,
				'label' => ucwords( str_replace( '-', ' ', $value ) ),
			];
		}

		return new WP_REST_Response(
			[
				'icons' => $options,
			],
			200
		);
	}

	/**
	 * Get icons for block editor.
	 *
	 * @return array Array of icons with value and label.
	 */
	public static function get_icons_args() {
		$icons = [
			'star'           => '<svg width="48" height="48" viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="m43 13-15.647 5.177L24 2l-3.353 16.177L5 13l12.295 11L5 35l15.647-5.178L24 46l3.353-16.178L43 35 30.704 24z" fill="currentColor"/></svg>',
			'arrow-right'    => '<svg width="10" height="10" viewBox="0 0 10 10" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M3.75 2.084 6.667 5 3.75 7.917" stroke="currentColor" stroke-width="1.111" stroke-linecap="round" stroke-linejoin="round" fill="none"/></svg>',
			'arrow-left'     => '<svg width="10" height="10" viewBox="0 0 10 10" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M6.25 2.084 3.333 5 6.25 7.917" stroke="currentColor" stroke-width="1.111" stroke-linecap="round" stroke-linejoin="round" fill="none"/></svg>',
			'arrow-up-right' => '<svg width="29" height="29" viewBox="0 0 29 29" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M8.219 19.962 19.96 8.22m0 0h-9.394m9.394 0v9.394" stroke="currentColor" stroke-width="2.348" stroke-linecap="round" stroke-linejoin="round" fill="none"/></svg>',
			'arrow-down'     => '<svg width="15" height="15" viewBox="0 0 15 15" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M11.875 5.625 7.5 10 3.125 5.625" stroke="currentColor" stroke-width="1.25" stroke-linecap="round" stroke-linejoin="round" fill="none"/></svg>',
			'arrow-up'       => '<svg width="15" height="15" viewBox="0 0 15 15" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M3.125 9.375 7.5 5l4.375 4.375" stroke="currentColor" stroke-width="1.25" stroke-linecap="round" stroke-linejoin="round" fill="none"/></svg>',
		];

		return $icons;
	}
}
