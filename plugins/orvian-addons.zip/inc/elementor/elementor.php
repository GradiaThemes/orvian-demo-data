<?php
/**
 * Integrate with Elementor.
 *
 * @package OrvianAddons
 */

namespace OrvianAddons\Elementor;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Elementor class
 */
class Elementor {
	/**
	 * Instance
	 *
	 * @access private
	 *
	 * @var Elementor
	 */
	private static $instance = null;

	/**
	 * Widget category name
	 *
	 * @var string
	 */
	const CATEGORY     = 'orvian-widgets';
	const CLASS_WIDGET = 'orvian-elementor-widget';

	/**
	 * Instance
	 *
	 * Ensures only one instance of the class is loaded or can be loaded.
	 *
	 * @return Elementor An instance of the class.
	 */
	public static function instance() {
		if ( is_null( self::$instance ) ) {
			self::$instance = new self();
		}

		return self::$instance;
	}

	/**
	 * Constructor
	 */
	public function __construct() {
		$this->setup_hooks();

		Dynamic_Controls\Autocomplete\Autocomplete::instance();
		Dynamic_Controls\Tags\Tags::instance();
		Features\Theme_Settings::instance();
		Features\Settings_Layout::instance();
		Features\Page_Settings::instance();
		Features\Animation::instance();
		Features\Custom_CSS::instance();
		Builder\Builder::instance();
	}

	/**
	 * Hooks to init
	 */
	protected function setup_hooks() {
		add_action( 'wp', [ $this, 'actions' ], 20 );

		// Widgets.
		add_action( 'elementor/frontend/after_enqueue_styles', [ $this, 'register_styles' ] );

		add_action( 'elementor/frontend/before_enqueue_scripts', [ $this, 'register_scripts' ] );
		add_action( 'elementor/widgets/register', [ $this, 'register_widgets' ] );
		add_action( 'elementor/elements/categories_registered', [ $this, 'add_category' ] );

		// Editor.
		add_action( 'elementor/editor/after_enqueue_scripts', [ $this, 'enqueue_editor_scripts' ] );
	}

	/**
	 * Actions
	 */
	public function actions() {
		add_filter( 'orvian_content_container_class', [ $this, 'content_container_class' ], 10, 1 );
	}

	/**
	 * Content container class
	 *
	 * @param string $classes Container classes.
	 * @return string
	 */
	public function content_container_class( $classes ) {
		if ( is_singular() ) {
			$id = get_the_ID();

			if ( \OrvianAddons\Admin\Portfolio::is_portfolio_archive() ) {
				$id = \OrvianAddons\Admin\Portfolio::get_portfolio_page_id();
			}

			$document = \Elementor\Plugin::$instance->documents->get( $id );
			if ( $document && $document->is_built_with_elementor() ) {
				$classes = 'orvian-container-elementor';
			}
		}

		return $classes;
	}

	/**
	 * Register styles
	 *
	 * @return void
	 */
	public function register_styles() {
		wp_enqueue_style( 'orvian-elementor-style', ORVIAN_ADDONS_URL . 'assets/css/elementor/elementor.css', [], ORVIAN_ADDONS_VERSION );
	}

	/**
	 * Register styles
	 */
	public function register_scripts() {
		$debug = defined( 'SCRIPT_DEBUG' ) && SCRIPT_DEBUG ? '' : '.min';

		wp_enqueue_script( 'orvian-elementor-widgets', ORVIAN_ADDONS_URL . 'assets/js/elementor/elementor-widgets' . $debug . '.js', [ 'jquery', 'underscore', 'elementor-frontend', 'regenerator-runtime' ], ORVIAN_ADDONS_VERSION, true );
	}

	/**
	 * Init Widgets
	 *
	 * @param \Elementor\Widgets_Manager $widgets_manager Elementor widgets manager instance.
	 */
	public function register_widgets( $widgets_manager ) {
		// Get all widget files from the widgets directory.
		$widgets_dir = ORVIAN_ADDONS_PATH . '/inc/elementor/widgets/';

		if ( ! is_dir( $widgets_dir ) ) {
			return;
		}

		$widget_files = glob( $widgets_dir . '*.php' );

		foreach ( $widget_files as $widget_file ) {
			$widget_name  = basename( $widget_file, '.php' );
			$widget_class = $this->get_widget_class_name( $widget_name );

			// Check if the class exists and register the widget.
			if ( class_exists( $widget_class ) ) {
				$widgets_manager->register( new $widget_class() );
			}
		}
	}

	/**
	 * Get widget class name from file name
	 *
	 * @param string $widget_name Widget name.
	 * @return string
	 */
	private function get_widget_class_name( $widget_name ) {
		// Convert kebab-case to PascalCase.
		$class_name = str_replace( '-', '_', $widget_name );
		$class_name = str_replace( '_', ' ', $class_name );
		$class_name = ucwords( $class_name );
		$class_name = str_replace( ' ', '_', $class_name );

		return '\\OrvianAddons\\Elementor\\Widgets\\' . $class_name;
	}

	/**
	 * Add Orvian category
	 *
	 * @param \Elementor\Elements_Manager $elements_manager Elementor widgets manager instance.
	 */
	public function add_category( $elements_manager ) {
		$elements_manager->add_category(
			self::CATEGORY,
			[
				'title' => esc_html__( 'Orvian', 'orvian-addons' ),
			]
		);
	}

	/**
	 * Enqueue editor scripts
	 */
	public function enqueue_editor_scripts() {
		$debug = defined( 'SCRIPT_DEBUG' ) && SCRIPT_DEBUG ? '' : '.min';
		wp_enqueue_style( 'orvian-elementor-editor', ORVIAN_ADDONS_ASSETS_URL . 'css/elementor/elementor-editor.css', [], ORVIAN_ADDONS_VERSION );

		wp_enqueue_script(
			'orvian-elementor-modules',
			ORVIAN_ADDONS_ASSETS_URL . 'js/elementor/elementor-modules' . $debug . '.js',
			[
				'backbone-marionette',
				'elementor-common-modules',
				'elementor-editor-modules',
			],
			ORVIAN_ADDONS_VERSION,
			true
		);
	}
}
