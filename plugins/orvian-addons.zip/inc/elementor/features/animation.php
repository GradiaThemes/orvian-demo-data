<?php
/**
 * Animation Handler
 *
 * Adds GSAP-based animation controls to all Elementor widgets.
 *
 * @package OrvianAddons
 */

namespace OrvianAddons\Elementor\Features;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use Elementor\Controls_Manager;

/**
 * Animation class
 */
class Animation {
	/**
	 * Instance.
	 *
	 * @var Animation
	 */
	private static $instance = null;

	/**
	 * Cached element paths.
	 *
	 * @var array
	 */
	private static $element_paths = [];

	/**
	 * Get instance.
	 *
	 * @return Animation
	 */
	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	/**
	 * Constructor.
	 *
	 * @since 1.0.0
	 */
	private function __construct() {
		// Register controls on all widgets.
		add_action( 'elementor/element/common/_section_style/after_section_end', [ $this, 'register_controls' ], 10, 2 );

		// Add data attributes to widget wrapper on frontend.
		add_action( 'elementor/frontend/widget/before_render', [ $this, 'add_animation_attributes' ] );
	}

	/**
	 * Get animation presets.
	 *
	 * @since 1.0.0
	 * @return array
	 */
	private function get_animation_presets() {
		return [
			''              => esc_html__( 'None', 'orvian-addons' ),
			'fade-up'       => esc_html__( 'Fade Up', 'orvian-addons' ),
			'fade-down'     => esc_html__( 'Fade Down', 'orvian-addons' ),
			'fade-left'     => esc_html__( 'Fade Left', 'orvian-addons' ),
			'fade-right'    => esc_html__( 'Fade Right', 'orvian-addons' ),
			'fade-in'       => esc_html__( 'Fade In', 'orvian-addons' ),
			'scale-in'      => esc_html__( 'Scale In', 'orvian-addons' ),
			'zoom-in'       => esc_html__( 'Zoom In', 'orvian-addons' ),
			'zoom-out'      => esc_html__( 'Zoom Out', 'orvian-addons' ),
			'blur-in'       => esc_html__( 'Blur In', 'orvian-addons' ),
			'rotate-in'     => esc_html__( 'Rotate In', 'orvian-addons' ),
			'slide-up'      => esc_html__( 'Slide Up', 'orvian-addons' ),
			'slide-down'    => esc_html__( 'Slide Down', 'orvian-addons' ),
			'slide-left'    => esc_html__( 'Slide Left', 'orvian-addons' ),
			'slide-right'   => esc_html__( 'Slide Right', 'orvian-addons' ),
			'clip-up'       => esc_html__( 'Clip Up', 'orvian-addons' ),
			'clip-down'     => esc_html__( 'Clip Down', 'orvian-addons' ),
			'clip-left'     => esc_html__( 'Clip Left', 'orvian-addons' ),
			'clip-right'    => esc_html__( 'Clip Right', 'orvian-addons' ),
			'split-chars'   => esc_html__( 'Split Characters', 'orvian-addons' ),
			'split-words'   => esc_html__( 'Split Words', 'orvian-addons' ),
			'split-lines'   => esc_html__( 'Split Lines', 'orvian-addons' ),
			'flip-x-in'     => esc_html__( 'Flip X In', 'orvian-addons' ),
			'flip-x-out'    => esc_html__( 'Flip X Out', 'orvian-addons' ),
			'flip-y-in'     => esc_html__( 'Flip Y In', 'orvian-addons' ),
			'flip-y-out'    => esc_html__( 'Flip Y Out', 'orvian-addons' ),
			'rotate-in-90'  => esc_html__( 'Rotate In 90', 'orvian-addons' ),
			'rotate-in-180' => esc_html__( 'Rotate In 180', 'orvian-addons' ),
			'clip-circle'   => esc_html__( 'Clip Circle', 'orvian-addons' ),
			'fade-scale-in' => esc_html__( 'Fade Scale In', 'orvian-addons' ),
			'blur-fade-up'  => esc_html__( 'Blur Fade Up', 'orvian-addons' ),
		];
	}

	/**
	 * Get easing options.
	 *
	 * @since 1.0.0
	 * @return array
	 */
	private function get_easing_options() {
		return [
			'power1.out'  => 'Power1 Out',
			'power2.out'  => 'Power2 Out (Default)',
			'power3.out'  => 'Power3 Out',
			'power4.out'  => 'Power4 Out',
			'back.out'    => 'Back Out',
			'elastic.out' => 'Elastic Out',
			'bounce.out'  => 'Bounce Out',
			'circ.out'    => 'Circ Out',
			'expo.out'    => 'Expo Out',
			'sine.out'    => 'Sine Out',
		];
	}

	/**
	 * Get ScrollTrigger start options.
	 *
	 * @since 1.0.0
	 * @return array
	 */
	private function get_trigger_options() {
		return [
			'top 90%'       => esc_html__( 'Top 90%', 'orvian-addons' ),
			'top 85%'       => esc_html__( 'Top 85%', 'orvian-addons' ),
			'top 80%'       => esc_html__( 'Top 80% (Default)', 'orvian-addons' ),
			'top 75%'       => esc_html__( 'Top 75%', 'orvian-addons' ),
			'top 70%'       => esc_html__( 'Top 70%', 'orvian-addons' ),
			'top 60%'       => esc_html__( 'Top 60%', 'orvian-addons' ),
			'top 50%'       => esc_html__( 'Top 50%', 'orvian-addons' ),
			'center center' => esc_html__( 'Center Center', 'orvian-addons' ),
		];
	}

	/**
	 * Get trigger type options.
	 *
	 * @since 1.0.0
	 * @return array
	 */
	private function get_trigger_type_options() {
		return [
			'self'   => esc_html__( 'Element Itself', 'orvian-addons' ),
			'parent' => esc_html__( 'Parent Container', 'orvian-addons' ),
			'header' => esc_html__( 'Site Header', 'orvian-addons' ),
			'footer' => esc_html__( 'Site Footer', 'orvian-addons' ),
			'custom' => esc_html__( 'Custom Selector', 'orvian-addons' ),
		];
	}

	/**
	 * Find element path in Elementor data structure.
	 *
	 * @param string $target_id Element ID to find.
	 * @param int    $post_id   Post ID (optional).
	 * @return array Element path from root to target.
	 */
	private function find_element_path( string $target_id, $post_id = null ): array {
		if ( ! $post_id ) {
			$post_id = get_the_ID();
		}

		$cache_key = $post_id . '_' . $target_id;

		if ( isset( self::$element_paths[ $cache_key ] ) ) {
			return self::$element_paths[ $cache_key ];
		}

		if ( ! class_exists( '\Elementor\Plugin' ) ) {
			return [];
		}

		$document = \Elementor\Plugin::$instance->documents->get( $post_id );

		if ( ! $document ) {
			return [];
		}

		$elements_data = $document->get_elements_data();
		$path          = $this->find_path_recursive( $elements_data, $target_id );

		self::$element_paths[ $cache_key ] = $path;

		return $path;
	}

	/**
	 * Recursively search for element and return its path.
	 *
	 * @param array  $elements  Elements array.
	 * @param string $target_id Target element ID.
	 * @param array  $path      Current path.
	 * @return array
	 */
	private function find_path_recursive( array $elements, string $target_id, array $path = [] ): array {
		foreach ( $elements as $element ) {
			$current_path = array_merge( $path, [ $element ] );
			$current_id   = $element['id'] ?? '';

			if ( $current_id === $target_id ) {
				return $current_path;
			}

			if ( ! empty( $element['elements'] ) && is_array( $element['elements'] ) ) {
				$found = $this->find_path_recursive( $element['elements'], $target_id, $current_path );
				if ( ! empty( $found ) ) {
					return $found;
				}
			}
		}

		return [];
	}

	/**
	 * Register animation controls.
	 *
	 * @param \Elementor\Element_Base $element The element.
	 */
	public function register_controls( $element ) {
		$element->start_controls_section(
			'orvian_motion_effects',
			[
				'label' => esc_html__( 'GSAP Animations', 'orvian-addons' ),
				'tab'   => Controls_Manager::TAB_ADVANCED,
			]
		);

		$element->add_control(
			'orvian_animation_enable',
			[
				'label'        => esc_html__( 'Enable Animation', 'orvian-addons' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => esc_html__( 'Yes', 'orvian-addons' ),
				'label_off'    => esc_html__( 'No', 'orvian-addons' ),
				'return_value' => 'yes',
				'default'      => '',
			]
		);

		$element->add_control(
			'orvian_animation_preset',
			[
				'label'     => esc_html__( 'Animation', 'orvian-addons' ),
				'type'      => Controls_Manager::SELECT,
				'default'   => 'fade-up',
				'options'   => $this->get_animation_presets(),
				'condition' => [
					'orvian_animation_enable' => 'yes',
				],
			]
		);

		$element->add_control(
			'orvian_animation_duration',
			[
				'label'     => esc_html__( 'Duration', 'orvian-addons' ),
				'type'      => Controls_Manager::SLIDER,
				'range'     => [
					'px' => [
						'min'  => 0.1,
						'max'  => 3,
						'step' => 0.1,
					],
				],
				'default'   => [
					'size' => 0.8,
				],
				'condition' => [
					'orvian_animation_enable' => 'yes',
				],
			]
		);

		$element->add_control(
			'orvian_animation_delay',
			[
				'label'     => esc_html__( 'Delay', 'orvian-addons' ),
				'type'      => Controls_Manager::SLIDER,
				'range'     => [
					'px' => [
						'min'  => 0,
						'max'  => 2,
						'step' => 0.1,
					],
				],
				'default'   => [
					'size' => 0,
				],
				'condition' => [
					'orvian_animation_enable' => 'yes',
				],
			]
		);

		$element->add_control(
			'orvian_animation_ease',
			[
				'label'     => esc_html__( 'Easing', 'orvian-addons' ),
				'type'      => Controls_Manager::SELECT,
				'default'   => 'power2.out',
				'options'   => $this->get_easing_options(),
				'condition' => [
					'orvian_animation_enable' => 'yes',
				],
			]
		);

		$element->add_control(
			'orvian_animation_scroll_heading',
			[
				'label'     => esc_html__( 'Scroll Trigger', 'orvian-addons' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
				'condition' => [
					'orvian_animation_enable' => 'yes',
				],
			]
		);

		$element->add_control(
			'orvian_animation_st_start',
			[
				'label'     => esc_html__( 'Trigger Point', 'orvian-addons' ),
				'type'      => Controls_Manager::SELECT,
				'default'   => 'top 80%',
				'options'   => $this->get_trigger_options(),
				'condition' => [
					'orvian_animation_enable' => 'yes',
				],
			]
		);

		$element->add_control(
			'orvian_animation_trigger_type',
			[
				'label'     => esc_html__( 'Trigger Element', 'orvian-addons' ),
				'type'      => Controls_Manager::SELECT,
				'default'   => 'self',
				'options'   => $this->get_trigger_type_options(),
				'condition' => [
					'orvian_animation_enable' => 'yes',
				],
			]
		);

		$element->add_control(
			'orvian_animation_trigger_custom',
			[
				'label'       => esc_html__( 'Custom Selector', 'orvian-addons' ),
				'type'        => Controls_Manager::TEXT,
				'placeholder' => '#id or .class',
				'description' => esc_html__( 'Enter CSS ID (e.g., #my-id) or Class (e.g., .my-class)', 'orvian-addons' ),
				'label_block' => true,
				'condition'   => [
					'orvian_animation_enable'       => 'yes',
					'orvian_animation_trigger_type' => 'custom',
				],
			]
		);

		$element->add_control(
			'orvian_animation_once',
			[
				'label'        => esc_html__( 'Animate Once', 'orvian-addons' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => esc_html__( 'Yes', 'orvian-addons' ),
				'label_off'    => esc_html__( 'No', 'orvian-addons' ),
				'return_value' => 'yes',
				'default'      => 'yes',
				'description'  => esc_html__( 'Run the animation only once when scrolling.', 'orvian-addons' ),
				'condition'    => [
					'orvian_animation_enable' => 'yes',
				],
			]
		);

		$element->add_control(
			'orvian_animation_offset_heading',
			[
				'label'     => esc_html__( 'Offset', 'orvian-addons' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
				'condition' => [
					'orvian_animation_enable' => 'yes',
					'orvian_animation_preset' => [ 'fade-up', 'fade-down', 'fade-left', 'fade-right' ],
				],
			]
		);

		$element->add_control(
			'orvian_animation_offset_y',
			[
				'label'     => esc_html__( 'Vertical Offset', 'orvian-addons' ),
				'type'      => Controls_Manager::SLIDER,
				'range'     => [
					'px' => [
						'min'  => -500,
						'max'  => 500,
						'step' => 10,
					],
				],
				'default'   => [
					'size' => 100,
				],
				'condition' => [
					'orvian_animation_enable' => 'yes',
					'orvian_animation_preset' => [ 'fade-up', 'fade-down' ],
				],
			]
		);

		$element->add_control(
			'orvian_animation_offset_x',
			[
				'label'     => esc_html__( 'Horizontal Offset', 'orvian-addons' ),
				'type'      => Controls_Manager::SLIDER,
				'range'     => [
					'px' => [
						'min'  => -500,
						'max'  => 500,
						'step' => 10,
					],
				],
				'default'   => [
					'size' => 100,
				],
				'condition' => [
					'orvian_animation_enable' => 'yes',
					'orvian_animation_preset' => [ 'fade-left', 'fade-right' ],
				],
			]
		);

		// Split Text Settings.
		$element->add_control(
			'orvian_animation_split_heading',
			[
				'label'     => esc_html__( 'Text Split Settings', 'orvian-addons' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
				'condition' => [
					'orvian_animation_enable' => 'yes',
					'orvian_animation_preset' => [ 'split-chars', 'split-words', 'split-lines' ],
				],
			]
		);

		$element->add_control(
			'orvian_animation_split_selector',
			[
				'label'     => esc_html__( 'Selector', 'orvian-addons' ),
				'type'      => Controls_Manager::SELECT,
				'default'   => 'orvian',
				'options'   => [
					'orvian'  => esc_html__( 'Orvian Heading', 'orvian-addons' ),
					'element' => esc_html__( 'Elementor Heading', 'orvian-addons' ),
					'custom'  => esc_html__( 'Custom', 'orvian-addons' ),
				],
				'condition' => [
					'orvian_animation_enable' => 'yes',
					'orvian_animation_preset' => [ 'split-chars', 'split-words', 'split-lines' ],
				],
			]
		);

		$element->add_control(
			'orvian_animation_split_selector_custom',
			[
				'label'       => esc_html__( 'Text Selector', 'orvian-addons' ),
				'type'        => Controls_Manager::TEXT,
				'placeholder' => esc_html__( '.elementor-heading-title', 'orvian-addons' ),
				'description' => esc_html__( 'CSS selector for the text element inside this widget. Leave empty to use the widget wrapper.', 'orvian-addons' ),
				'label_block' => true,
				'condition'   => [
					'orvian_animation_split_selector' => 'custom',
					'orvian_animation_enable'         => 'yes',
					'orvian_animation_preset'         => [ 'split-chars', 'split-words', 'split-lines' ],
				],
			]
		);

		$element->add_control(
			'orvian_animation_stagger',
			[
				'label'       => esc_html__( 'Stagger', 'orvian-addons' ),
				'type'        => Controls_Manager::SLIDER,
				'range'       => [
					'px' => [
						'min'  => 0,
						'max'  => 0.5,
						'step' => 0.01,
					],
				],
				'default'     => [
					'size' => 0.1,
				],
				'description' => esc_html__( 'Delay between each character/word/line animation.', 'orvian-addons' ),
				'condition'   => [
					'orvian_animation_enable' => 'yes',
					'orvian_animation_preset' => [ 'split-chars', 'split-words', 'split-lines' ],
				],
			]
		);

		$element->add_control(
			'orvian_animation_st_end',
			[
				'label'     => esc_html__( 'End Point', 'orvian-addons' ),
				'type'      => Controls_Manager::SELECT,
				'default'   => 'bottom 20%',
				'options'   => [
					'bottom 20%'    => esc_html__( 'Bottom 20% (Default)', 'orvian-addons' ),
					'bottom 10%'    => esc_html__( 'Bottom 10%', 'orvian-addons' ),
					'bottom 30%'    => esc_html__( 'Bottom 30%', 'orvian-addons' ),
					'center center' => esc_html__( 'Center Center', 'orvian-addons' ),
				],
				'condition' => [
					'orvian_animation_enable' => 'yes',
				],
			]
		);

		$element->end_controls_section();
	}

	/**
	 * Add animation data attributes to widget wrapper.
	 *
	 * @param \Elementor\Element_Base $element The element.
	 */
	public function add_animation_attributes( $element ) {
		$settings = $element->get_settings_for_display();

		// Check if animation is enabled.
		if ( empty( $settings['orvian_animation_enable'] ) || 'yes' !== $settings['orvian_animation_enable'] ) {
			return;
		}

		$preset = $settings['orvian_animation_preset'] ?? '';

		// Skip if no preset selected.
		if ( empty( $preset ) ) {
			return;
		}

		$attributes = [
			'data-animate' => esc_attr( $preset ),
		];

		// Duration (only if different from default).
		$duration = $settings['orvian_animation_duration']['size'] ?? 0.8;
		if ( 0.8 !== (float) $duration ) {
			$attributes['data-animate-duration'] = esc_attr( $duration );
		}

		// Delay (only if greater than 0).
		$delay = $settings['orvian_animation_delay']['size'] ?? 0;
		if ( $delay > 0 ) {
			$attributes['data-animate-delay'] = esc_attr( $delay );
		}

		// Easing (only if different from default).
		$ease = $settings['orvian_animation_ease'] ?? 'power2.out';
		if ( 'power2.out' !== $ease ) {
			$attributes['data-animate-ease'] = esc_attr( $ease );
		}

		// ScrollTrigger start (only if different from default).
		$st_start = $settings['orvian_animation_st_start'] ?? 'top 80%';
		if ( 'top 80%' !== $st_start ) {
			$attributes['data-st-start'] = esc_attr( $st_start );
		}

		// Trigger element (data-st-trigger).
		$trigger_type = $settings['orvian_animation_trigger_type'] ?? 'self';

		if ( 'parent' === $trigger_type ) {
			// Find topmost container by parsing Elementor data structure.
			$widget_id = $element->get_id();
			$path      = $this->find_element_path( $widget_id );

			if ( ! empty( $path ) ) {
				// Find the first container/section/column in the path (topmost parent).
				foreach ( $path as $el ) {
					$el_type = $el['elType'] ?? '';
					if ( in_array( $el_type, [ 'container', 'section', 'column' ], true ) ) {
						$container_id = $el['id'] ?? '';
						if ( $container_id ) {
							$attributes['data-st-trigger'] = '[data-id="' . esc_attr( $container_id ) . '"]';
						}
						break;
					}
				}
			}
		} elseif ( 'custom' === $trigger_type ) {
			$custom_selector = $settings['orvian_animation_trigger_custom'] ?? '';
			if ( ! empty( $custom_selector ) ) {
				$attributes['data-st-trigger'] = esc_attr( $custom_selector );
			}
		} elseif ( 'header' === $trigger_type ) {
			$attributes['data-st-trigger'] = '.site-header';
		} elseif ( 'footer' === $trigger_type ) {
			$attributes['data-st-trigger'] = '.site-footer';
		}

		// Animate once (only if disabled).
		$once = $settings['orvian_animation_once'] ?? 'yes';
		if ( 'yes' !== $once ) {
			$attributes['data-st-once'] = 'false';
		}

		// Offset Y (for fade-up, fade-down).
		if ( in_array( $preset, [ 'fade-up', 'fade-down' ], true ) ) {
			$offset_y = $settings['orvian_animation_offset_y']['size'] ?? 50;
			if ( 50 !== (int) $offset_y ) {
				$attributes['data-animate-y'] = esc_attr( $offset_y );
			}
		}

		// Offset X (for fade-left, fade-right).
		if ( in_array( $preset, [ 'fade-left', 'fade-right' ], true ) ) {
			$offset_x = $settings['orvian_animation_offset_x']['size'] ?? 50;
			if ( 50 !== (int) $offset_x ) {
				$attributes['data-animate-x'] = esc_attr( $offset_x );
			}
		}

		// Split text settings.
		$split_presets = [ 'split-chars', 'split-words', 'split-lines' ];
		if ( in_array( $preset, $split_presets, true ) ) {
			// Text selector.
			if ( 'orvian' === $settings['orvian_animation_split_selector'] ) {
				$selector = '.orvian-heading';
			} elseif ( 'element' === $settings['orvian_animation_split_selector'] ) {
				$selector = '.elementor-heading-title';
			} elseif ( 'custom' === $settings['orvian_animation_split_selector'] ) {
				$selector = $settings['orvian_animation_split_selector_custom'] ?? '';
			}

			if ( ! empty( $selector ) ) {
				$attributes['data-animate-selector'] = esc_attr( $selector );
			}

			// Stagger (only if different from default).
			$stagger = $settings['orvian_animation_stagger']['size'] ?? 0.1;
			if ( 0.1 !== (float) $stagger ) {
				$attributes['data-animate-stagger'] = esc_attr( $stagger );
			}

			// ScrollTrigger end (only if different from default).
			$st_end = $settings['orvian_animation_st_end'] ?? 'bottom 20%';
			if ( 'bottom 20%' !== $st_end ) {
				$attributes['data-st-end'] = esc_attr( $st_end );
			}
		}

		// Add class to disable CSS transitions that conflict with GSAP.
		$element->add_render_attribute( '_wrapper', 'class', 'has-gsap-animation' );
		$element->add_render_attribute( '_wrapper', $attributes );
	}
}
