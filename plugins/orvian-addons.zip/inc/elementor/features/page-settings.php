<?php
/**
 * Elementor Global init
 *
 * @link https://developer.wordpress.org/themes/basics/theme-functions/
 *
 * @package Orvian
 */

namespace OrvianAddons\Elementor\Features;

use Elementor\Controls_Manager;
use Elementor\Core\DocumentTypes\Page;

/**
 * Integrate with Elementor.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Class Page_Settings
 */
class Page_Settings {

	/**
	 * Instance
	 *
	 * @var $instance
	 */
	private static $instance;

	/**
	 * Initiator
	 *
	 * @since 1.0.0
	 * @return object
	 */
	public static function instance() {
		if ( ! isset( self::$instance ) ) {
			self::$instance = new self();
		}

		return self::$instance;
	}

	/**
	 * Instantiate the object.
	 *
	 * @since 1.0.0
	 *
	 * @return void
	 */
	public function __construct() {
		if ( ! class_exists( '\Elementor\Core\DocumentTypes\Page' ) ) {
			return;
		}

		add_action( 'elementor/editor/after_enqueue_styles', [ $this, 'enqueue_styles' ] );
		add_action( 'elementor/documents/register_controls', [ $this, 'register_display_controls' ] );
	}

	/**
	 * Inline Style
	 *
	 * @since 1.0.0
	 *
	 * @return void
	 */
	public function enqueue_styles() {
		wp_add_inline_style( 'elementor-editor', '#elementor-panel .elementor-control-hide_title{display:none}' );
	}

	/**
	 * Register display controls.
	 *
	 * @param object $document Document object.
	 */
	public function register_display_controls( $document ) {
		if ( ! $document instanceof Page ) {
			return;
		}

		$this->register_page_controls( $document );
		$this->register_site_content_controls( $document );
	}

	/**
	 * Register page controls.
	 *
	 * @param object $document Document object.
	 */
	public function register_page_controls( $document ) {
		$post_type = get_post_type( $document->get_main_id() );

		if ( 'page' !== $post_type ) {
			return;
		}

		$document->start_injection(
			[
				'of'       => 'post_status',
				'fallback' => [
					'of' => 'post_title',
				],
			]
		);

		$document->add_control(
			'hide_page_title',
			[
				'label'     => esc_html__( 'Hide Title', 'orvian-addons' ),
				'type'      => Controls_Manager::SWITCHER,
				'selectors' => [
					'.elementor-' . $document->get_main_id() => '--page-title-display: none;',
					'.elementor-page-' . $document->get_main_id() => '--page-title-display: none;',
				],
				'separator' => 'before',
			],
		);

		$document->add_control(
			'hide_sticky_menu',
			[
				'label'     => esc_html__( 'Hide Sticky Menu', 'orvian-addons' ),
				'type'      => Controls_Manager::SWITCHER,
				'selectors' => [
					'.elementor-' . $document->get_main_id() . ' .orvian-sticky-menu__wrapper' => 'display: none !important;',
					'.elementor-page-' . $document->get_main_id() . ' .orvian-sticky-menu__wrapper' => 'display: none !important;',
				],
			],
		);

		$document->add_control(
			'hide_top_panel',
			[
				'label'     => esc_html__( 'Hide Top Panel', 'orvian-addons' ),
				'type'      => Controls_Manager::SWITCHER,
				'selectors' => [
					'.elementor-' . $document->get_main_id() . ' .top-panel__button' => 'display: none !important;',
					'.elementor-page-' . $document->get_main_id() . ' .top-panel__button' => 'display: none !important;',
				],
			],
		);

		$document->add_control(
			'header_transparent_enabled',
			[
				'label'     => esc_html__( 'Header Transparent', 'orvian-addons' ),
				'type'      => Controls_Manager::SWITCHER,
				'selectors' => [
					'.elementor-' . $document->get_main_id() . ' .ScrollSmoother-wrapper' => 'padding-top: 0 !important;',
					'.elementor-' . $document->get_main_id() . ' .header-main:not(.headroom--not-top, .headroom--waiting-unpinned)' => '--body-background-color: transparent;',
					'.elementor-' . $document->get_main_id() . ' .site-header > .elementor:not(.headroom--not-top, .headroom--waiting-unpinned)' => '--body-background-color: transparent;',
					'.elementor-page-' . $document->get_main_id() . ' .ScrollSmoother-wrapper' => 'padding-top: 0 !important;',
					'.elementor-page-' . $document->get_main_id() . ' .header-main:not(.headroom--not-top, .headroom--waiting-unpinned)' => '--body-background-color: transparent;',
					'.elementor-page-' . $document->get_main_id() . ' .site-header > .elementor:not(.headroom--not-top, .headroom--waiting-unpinned)' => '--body-background-color: transparent;',
				],
			]
		);

		$document->end_injection();
	}

	/**
	 * Register site content controls.
	 *
	 * @param object $document Document object.
	 */
	public function register_site_content_controls( $document ) {
		$post_type = get_post_type( $document->get_main_id() );

		if ( \OrvianAddons\Elementor\Builder\Post_Type::POST_TYPE === $post_type ) {
			return;
		}

		$document->start_controls_section(
			'section_site_content_settings',
			[
				'label' => esc_html__( 'Site Content', 'orvian-addons' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$document->add_control(
			'site_content_top_spacing',
			[
				'label'       => esc_html__( 'Top Spacing', 'orvian-addons' ),
				'type'        => Controls_Manager::SELECT,
				'options'     => [
					''       => esc_html__( 'Default', 'orvian-addons' ),
					'custom' => esc_html__( 'Custom', 'orvian-addons' ),
				],
				'default'     => 'custom',
				'label_block' => true,
			]
		);

		$document->add_control(
			'site_content_top_padding',
			[
				'label'     => esc_html__( 'Spacing', 'orvian-addons' ),
				'type'      => Controls_Manager::SLIDER,
				'range'     => [
					'px' => [
						'max' => 300,
						'min' => 0,
					],
				],
				'default'   => [
					'unit' => 'px',
					'size' => 0,
				],
				'selectors' => [
					'{{WRAPPER}} .site-content' => 'padding-top: {{SIZE}}{{UNIT}};',
				],
				'condition' => [
					'site_content_top_spacing' => 'custom',
				],
			]
		);

		$document->add_control(
			'site_content_bottom_spacing',
			[
				'label'       => esc_html__( 'Bottom Spacing', 'orvian-addons' ),
				'type'        => Controls_Manager::SELECT,
				'options'     => [
					''       => esc_html__( 'Default', 'orvian-addons' ),
					'custom' => esc_html__( 'Custom', 'orvian-addons' ),
				],
				'default'     => 'custom',
				'label_block' => true,
			]
		);

		$document->add_control(
			'site_content_bottom_padding',
			[
				'label'     => esc_html__( 'Spacing', 'orvian-addons' ),
				'type'      => Controls_Manager::SLIDER,
				'range'     => [
					'px' => [
						'max' => 300,
						'min' => 0,
					],
				],
				'default'   => [
					'unit' => 'px',
					'size' => 0,
				],
				'selectors' => [
					'{{WRAPPER}} .site-content' => 'padding-bottom: {{SIZE}}{{UNIT}};',
				],
				'condition' => [
					'site_content_bottom_spacing' => 'custom',
				],
			]
		);

		$document->end_controls_section();
	}
}
