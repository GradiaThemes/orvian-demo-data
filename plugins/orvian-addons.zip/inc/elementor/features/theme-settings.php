<?php
/**
 * Theme Settings Handler
 *
 * Adds GSAP-based animation controls to all Elementor widgets.
 *
 * @package OrvianAddons
 */

namespace OrvianAddons\Elementor\Features;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use Elementor\Controls_Manager;

/**
 * Theme Settings class
 */
class Theme_Settings {
	/**
	 * Instance.
	 *
	 * @var Theme_Settings
	 */
	private static $instance = null;

	/**
	 * Get instance.
	 *
	 * @return Theme_Settings
	 */
	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	/**
	 * Constructor.
	 */
	private function __construct() {
		// Register controls on container, column, and section elements.
		add_action( 'elementor/element/section/section_background/before_section_start', [ $this, 'register_controls' ], 10, 2 );
		add_action( 'elementor/element/column/section_style/before_section_start', [ $this, 'register_controls' ], 10, 2 );
		add_action( 'elementor/element/container/section_background/before_section_start', [ $this, 'register_controls' ], 10, 2 );
	}

	/**
	 * Register animation controls.
	 *
	 * @param \Elementor\Element_Base $element The element.
	 */
	public function register_controls( $element ) {
		$element->start_controls_section(
			'orvian_theme_settings',
			[
				'label' => esc_html__( 'Orvian Theme Settings', 'orvian-addons' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$element->add_control(
			'orvian_color_scheme',
			[
				'label'        => esc_html__( 'Color Scheme', 'orvian-addons' ),
				'type'         => Controls_Manager::SELECT,
				'default'      => '',
				'options'      => [
					''            => esc_html__( 'Default', 'orvian-addons' ),
					'theme-light' => esc_html__( 'Light', 'orvian-addons' ),
					'theme-dark'  => esc_html__( 'Dark', 'orvian-addons' ),
				],
				'prefix_class' => 'orvian-color-scheme ',
			]
		);

		$element->end_controls_section();
	}
}
