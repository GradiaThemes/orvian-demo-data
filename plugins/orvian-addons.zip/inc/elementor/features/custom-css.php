<?php
/**
 * Custom CSS
 *
 * @package OrvianAddons
 */

namespace OrvianAddons\Elementor\Features;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

use Elementor\Core\Base\Module;
use Elementor\Controls_Manager;
use Elementor\Plugin;
use Elementor\Core\DynamicTags\Dynamic_CSS;

/**
 * Class Custom_CSS
 */
class Custom_CSS extends Module {
	/**
	 * Get module name.
	 *
	 * @return string
	 */
	public function get_name() {
		return 'custom-css';
	}

	/**
	 * Module constructor.
	 */
	public function __construct() {
		add_action( 'elementor/element/after_section_end', [ $this, 'register_controls' ], 10, 2 );
		add_action( 'elementor/element/parse_css', [ $this, 'add_post_css' ], 10, 2 );
		add_action( 'elementor/css-file/post/parse', [ $this, 'add_page_settings_css' ] );
	}

	/**
	 * Register controls.
	 *
	 * @param \Elementor\Controls_Stack $element    Controls_Stack.
	 * @param \Elementor\Controls_Stack $section_id string Section ID.
	 */
	public function register_controls( $element, $section_id ) {
		if ( 'section_custom_css_pro' !== $section_id ) {
			return;
		}

		Plugin::instance()->controls_manager->remove_control_from_stack( $element->get_unique_name(), [ 'section_custom_css_pro', 'custom_css_pro' ] );

		$element->start_controls_section(
			'section_custom_css',
			[
				'label' => esc_html__( 'Custom CSS', 'orvian-addons' ),
				'tab'   => Controls_Manager::TAB_ADVANCED,
			]
		);

		$element->add_control(
			'custom_css',
			[
				'type'        => Controls_Manager::CODE,
				'label'       => esc_html__( 'Add your own custom CSS here', 'orvian-addons' ),
				'language'    => 'css',
				'render_type' => 'ui',
				'separator'   => 'none',
				'description' => esc_html__( 'Use "selector" to target wrapper element. Examples:<br>selector {color: red;} // For main element<br>selector .child-element {margin: 10px;} // For child element<br>.my-class {text-align: center;} // Or use any custom selector', 'orvian-addons' ),
			]
		);

		$element->end_controls_section();
	}

	/**
	 * Add post css.
	 *
	 * @param \Elementor\Core\Files\CSS\Post $post_css Post.
	 * @param \Elementor\Element_Base        $element  Element_Base.
	 */
	public function add_post_css( $post_css, $element ) {
		if ( $post_css instanceof Dynamic_CSS ) {
			return;
		}

		$element_settings = $element->get_settings();

		if ( empty( $element_settings['custom_css'] ) ) {
			return;
		}

		$css = trim( $element_settings['custom_css'] );

		if ( empty( $css ) ) {
			return;
		}
		$css = str_replace( 'selector', $post_css->get_element_unique_selector( $element ), $css );

		// Add a css comment.
		$css = sprintf( '/* Start custom CSS for %s, class: %s */', $element->get_name(), $element->get_unique_selector() ) . $css . '/* End custom CSS */';

		$post_css->get_stylesheet()->add_raw_css( $css );
	}

	/**
	 * Add page settings css.
	 *
	 * @param \Elementor\Core\Files\CSS\Post $post_css Post.
	 */
	public function add_page_settings_css( $post_css ) {
		$document   = Plugin::instance()->documents->get( $post_css->get_post_id() );
		$custom_css = $document->get_settings( 'custom_css' ) ?? '';

		$custom_css = trim( $custom_css );

		if ( empty( $custom_css ) ) {
			return;
		}

		$custom_css = str_replace( 'selector', $document->get_css_wrapper_selector(), $custom_css );

		// Add a css comment.
		$custom_css = '/* Start custom CSS */' . $custom_css . '/* End custom CSS */';

		$post_css->get_stylesheet()->add_raw_css( $custom_css );
	}
}
