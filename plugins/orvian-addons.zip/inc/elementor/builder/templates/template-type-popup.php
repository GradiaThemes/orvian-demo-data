<?php
/**
 * The Template for displaying all template type
 *
 * @package OrvianAddons
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

?>
<div id="orvian-builder-template-modal" class="orvian-builder-template-modal">
	<div class="modal__backdrop"></div>
	<div class="modal__content">
		<span class="orvian-svg-icon orvian-svg-icon--close modal__button-close"><svg width="24" height="24" aria-hidden="true" role="img" focusable="false" viewBox="0 0 32 32"><path d="M28.336 5.936l-2.272-2.272-10.064 10.080-10.064-10.080-2.272 2.272 10.080 10.064-10.080 10.064 2.272 2.272 10.064-10.080 10.064 10.080 2.272-2.272-10.080-10.064z"></path></svg></span>
		<form class="modal-content__form" action="<?php echo esc_url( admin_url( 'post.php' ) ); ?>">
			<input type="hidden" class="_wpnonce" value="<?php echo esc_attr( wp_create_nonce( 'orvian_buider_new_template' ) ); ?>">
			<div class="modal-content-form__title"><?php echo esc_html__( 'Choose Template Type', 'orvian-addons' ); ?></div>
			<div  class="elementor-form-field">
				<label for="orvian-builder-template-modal-type" class="elementor-form-field__label"><?php echo esc_html__( 'Select the type of template you want to work on', 'orvian-addons' ); ?></label>
				<select id="orvian-builder-template-modal-type" class="elementor-form-field__select" required>
					<option value="footer"><?php echo esc_html__( 'Footer', 'orvian-addons' ); ?></option>
					<option value="header_main"><?php echo esc_html__( 'Header Main', 'orvian-addons' ); ?></option>
					<option value="header_section"><?php echo esc_html__( 'Header Section', 'orvian-addons' ); ?></option>
					<option value="hamburger_menu"><?php echo esc_html__( 'Hamburger Menu', 'orvian-addons' ); ?></option>
				</select>
			</div>
			<div class="elementor-form-field">
				<label for="orvian-builder-template-modal__post-title" class="elementor-form-field__label">
					<?php echo esc_html__( 'Name your template', 'orvian-addons' ); ?>
				</label>
				<input type="text" placeholder="<?php echo esc_attr__( 'Enter template name (optional)', 'orvian-addons' ); ?>" required id="orvian-builder-template-modal__post-title" class="elementor-form-field__text">
			</div>
			<div class="elementor-form-field">
				<input class="elementor-form-field__checkbox" type="checkbox" name="woolentor-template-enable" id="orvian-builder-template-modal__post-enable">
				<label for="orvian-builder-template-modal__post-enable" class="elementor-form-field__label">
					<?php echo esc_html__( 'Enable Builder', 'orvian-addons' ); ?>
				</label>
			</div>
			<button id="orvian-builder-template-modal__submit" class="elementor-button e-primary"><span><?php echo esc_html__( 'Create Template', 'orvian-addons' ); ?></span></button>
			<p class="modal-content-form-message"></p>
		</form>
	</div>
</div>
