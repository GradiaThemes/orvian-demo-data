<?php
/**
 * Elementor Builder
 *
 * @package OrvianAddons
 */

namespace OrvianAddons\Elementor\Builder;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

use OrvianAddons\Elementor\Builder\Helper;

/**
 * Main class of plugin
 */
class Builder {

	/**
	 * Instance
	 *
	 * @var $instance
	 */
	private static $instance;

	/**
	 * Initiator
	 *
	 * @return object
	 */
	public static function instance() {
		if ( ! isset( self::$instance ) ) {
			self::$instance = new self();
		}

		return self::$instance;
	}

	/**
	 * Instantiate the object.
	 *
	 * @return void
	 */
	public function __construct() {
		add_action( 'init', [ $this, 'actions' ] );
	}

	/**
	 * Add Actions
	 *
	 * @return void
	 */
	public function actions() {
		if ( is_admin() ) {
			Settings::instance();
		}

		if ( Helper::is_elementor() ) {
			Post_Type::instance();
			Footer::instance();
			Header_Main::instance();
			Header_Section::instance();
			Hamburger_Menu::instance();

			if ( class_exists( 'Elementor\Core\Base\Module' ) ) {
				Elementor_Settings::instance();
			}
		}
	}
}
