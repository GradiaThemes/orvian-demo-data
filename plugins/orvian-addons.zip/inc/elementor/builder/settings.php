<?php
/**
 * Elementor Builder Settings
 *
 * @package OrvianAddons
 */

namespace OrvianAddons\Elementor\Builder;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Main class of plugin for admin
 */
class Settings {

	/**
	 * Instance
	 *
	 * @var $instance
	 */
	private static $instance;

	/**
	 * Initiator
	 *
	 * @return object
	 */
	public static function instance() {
		if ( ! isset( self::$instance ) ) {
			self::$instance = new self();
		}

		return self::$instance;
	}

	/**
	 * Instantiate the object.
	 *
	 * @return void
	 */
	public function __construct() {
		// Handle post columns.
		add_filter( sprintf( 'manage_%s_posts_columns', Post_Type::POST_TYPE ), [ $this, 'edit_admin_columns' ] );
		add_action( sprintf( 'manage_%s_posts_custom_column', Post_Type::POST_TYPE ), [ $this, 'manage_custom_columns' ], 10, 2 );

		add_action( 'wp_ajax_orvian_save_builder_enable', [ $this, 'save_builder_enable' ] );
		add_action( sprintf( 'wp_ajax_%s_template_type', Post_Type::POST_TYPE ), [ $this, 'builder_template_type' ] );

		// Sortable columns.
		add_action( 'wp_ajax_orvian_sortable_builder', [ $this, 'sortable_builder' ] );
		add_filter( 'posts_orderby', [ $this, 'posts_orderby' ], 99, 2 );

		// Add custom post type to screen ids.
		add_filter( 'woocommerce_screen_ids', [ $this, 'wc_screen_ids' ] );

		add_filter( 'views_edit-' . Post_Type::POST_TYPE, [ $this, 'admin_print_tabs' ] );

		add_filter( 'parse_query', [ $this, 'query_filter' ] );

		// Enqueue style and javascript.
		add_action( 'admin_enqueue_scripts', [ $this, 'admin_scripts' ] );

		// Add meta boxes.
		add_action( 'save_post', [ $this, 'delete_builder_cache' ], 10, 1 );
		add_action( 'wp_trash_post', [ $this, 'delete_builder_cache' ], 10, 1 );
		add_action( 'before_delete_post', [ $this, 'delete_builder_cache' ], 10, 1 );

		add_action( 'admin_footer', [ $this, 'template_type_popup' ] );
	}

	/**
	 * Add custom column to builders management screen
	 * Add Thumbnail column
	 *
	 * @param  array $columns Default columns.
	 *
	 * @return array
	 */
	public function edit_admin_columns( $columns ) {
		$new_columns = array_merge(
			$columns,
			[
				'enable_builder' => esc_html__( 'Enable Builder', 'orvian-addons' ),
				'builder_type'   => esc_html__( 'Type', 'orvian-addons' ),
				'include_pages'  => esc_html__( 'Include', 'orvian-addons' ),
				'exclude_pages'  => esc_html__( 'Exclude', 'orvian-addons' ),
			]
		);

		unset( $new_columns['date'] );

		if ( isset( $columns['date'] ) ) {
			$new_columns['date'] = $columns['date'];
			unset( $columns['date'] );
		}

		return array_merge( $new_columns, $columns );
	}

	/**
	 * Handle custom column display
	 *
	 * @param  string $column Column name.
	 * @param  int    $post_id Post ID.
	 */
	public function manage_custom_columns( $column, $post_id ) {
		$terms           = get_the_terms( $post_id, Post_Type::TAXONOMY_TYPE );
		$settings        = Helper::get_template_settings( $post_id );
		$type_args       = Elementor_Settings::get_types();
		$type_args_extra = Elementor_Settings::get_types_extra();

		if ( ! $terms || is_wp_error( $terms ) ) {
			return;
		}
		$checked = false;
		$type    = '';
		foreach ( $terms as $term ) {
			if ( 'enable' === $term->slug ) {
				$checked = true;
			} else {
				$type = $term->slug;
			}
		}
		switch ( $column ) {
			case 'enable_builder':
				$checked = $checked ? 'checked="checked"' : '';
				echo '<div class="orvian-builder__toggle-button">';
				printf(
					'<input type="checkbox" id="builder_enabled_%1$s" class="orvian-builder__enabled" %2$s data-nonce="orvian_save_enabled_state_%1$s" data-builder-id="%1$s">',
					esc_attr( $post_id ),
					esc_attr( $checked )
				);
				echo '<label for="' . esc_attr( Post_Type::POST_TYPE ) . '_enable' . esc_attr( $post_id ) . '" aria-label="Switch to enable builder"></label>';
				echo '</div>';
				break;
			case 'builder_type':
				foreach ( self::get_template_type() as $tabkey => $tabname ) {
					if ( $type === $tabkey ) {
						// phpcs:ignore
						printf( '%s', $tabname );
					}
				}
				break;
			case 'include_pages':
				if ( ! empty( $settings['include_on'] ) ) {
					foreach ( $settings['include_on'] as $value ) {
						if ( in_array( $value, $type_args_extra, true ) ) {
							// phpcs:ignore
							printf( '<strong>%s</strong><br>', $type_args[ $value ] );
						} else {
							$args = [];
							foreach ( array_filter( explode( ',', $settings[ 'include_' . $value . '_ids' ] ) ) as $id ) {
								$args[] = get_the_title( $id );
							}
							// phpcs:ignore
							printf( '<strong>%s:</strong> %s<br>', $type_args[ $value ], ! empty( $args ) ? esc_html( implode( ', ', $args ) ) : esc_html__( 'All', 'orvian-addons' ) );
						}
					}
				}
				break;
			case 'exclude_pages':
				if ( ! empty( $settings['exclude_on'] ) ) {
					foreach ( $settings['exclude_on'] as $value ) {
						if ( in_array( $value, $type_args_extra, true ) ) {
							// phpcs:ignore
							printf( '<strong>%s</strong><br>', $type_args[ $value ] );
						} else {
							$args = [];
							foreach ( array_filter( explode( ',', $settings[ 'exclude_' . $value . '_ids' ] ) ) as $id ) {
								$args[] = get_the_title( $id );
							}

							// phpcs:ignore
							printf( '<strong>%s:</strong> %s<br>', $type_args[ $value ], ! empty( $args ) ? esc_html( implode( ', ', $args ) ) : esc_html__( 'All', 'orvian-addons' ) );
						}
					}
				}
				break;
		}
	}

	/**
	 * Sets the enabled meta field to on or off
	 */
	public static function save_builder_enable() {
		// phpcs:ignore WordPress.Security.NonceVerification
		if ( empty( $_POST['post_ID'] ) ) {
			wp_die( -1 );
		}

		// phpcs:ignore WordPress.Security.NonceVerification
		$post_ID = absint( $_POST['post_ID'] );
		// phpcs:ignore WordPress.Security.NonceVerification
		$enabled          = isset( $_POST['enabled'] ) && absint( $_POST['enabled'] ) === 1 ? 'yes' : 'no';
		$terms            = get_the_terms( $post_ID, Post_Type::TAXONOMY_TYPE );
		$new_builder_type = '';
		if ( $terms && ! is_wp_error( $terms ) ) {
			foreach ( $terms as $term ) {
				if ( 'enable' === $term->slug && 'no' === $enabled ) {
					continue;
				}

				$new_builder_type .= ! empty( $new_builder_type ) ? ',' : '';
				$new_builder_type .= $term->slug;
			}

			if ( 'yes' === $enabled ) {
				$new_builder_type .= ! empty( $new_builder_type ) ? ',' : '';
				$new_builder_type .= 'enable';
			}
		}

		wp_set_post_terms( $post_ID, $new_builder_type, Post_Type::TAXONOMY_TYPE );
		do_action( 'orvian_after_builder_enable' );
		wp_send_json_success();
	}

	/**
	 * Create a new template
	 */
	public function builder_template_type() {
		if ( ! isset( $_POST ) ) {
			$errormessage = [
				'message' => esc_html__( 'Post request dose not found', 'orvian-addons' ),
			];
			wp_send_json_error( $errormessage );
		}

		if ( ! ( current_user_can( 'manage_options' ) || current_user_can( 'edit_others_posts' ) ) ) {
			$errormessage = [
				'message' => esc_html__( 'You are unauthorize to create a template', 'orvian-addons' ),
			];
			wp_send_json_error( $errormessage );
		}

		// phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
		if ( isset( $_POST['nonce'] ) && ! wp_verify_nonce( wp_unslash( $_POST['nonce'] ), 'orvian_buider_new_template' ) ) {
			$errormessage = [
				'message' => esc_html__( 'Nonce Varification Faild', 'orvian-addons' ),
			];
			wp_send_json_error( $errormessage );
		}

		$post_title     = ! empty( $_POST['post_title'] ) ? sanitize_text_field( wp_unslash( $_POST['post_title'] ) ) : '';
		$template_type  = ! empty( $_POST['template_type'] ) ? sanitize_text_field( wp_unslash( $_POST['template_type'] ) ) : '';
		$enable_builder = ! empty( $_POST['enable_builder'] ) ? sanitize_text_field( wp_unslash( $_POST['enable_builder'] ) ) : '';

		$args = [
			'template_type'  => $template_type,
			'post_title'     => $post_title,
			'enable_builder' => $enable_builder,
		];
		$this->insert_template( $args );
	}

	/**
	 * Insert a new template
	 *
	 * @param array $args Template arguments.
	 */
	public function insert_template( $args ) {
		$args['post_type']   = Post_Type::POST_TYPE;
		$args['post_status'] = 'publish';
		$new_post_id         = wp_insert_post( $args );

		if ( $new_post_id ) {
			$template_type = $args['template_type'];
			if ( ! empty( $args['enable_builder'] ) && 'yes' === $args['enable_builder'] ) {
				$template_type .= ', enable';

				do_action( 'orvian_after_builder_enable' );
			}
			wp_set_post_terms( $new_post_id, $template_type, Post_Type::TAXONOMY_TYPE );

			$response = [
				'id' => $new_post_id,
			];

			wp_send_json_success( $response );
		} else {
			$errormessage = [
				'message' => esc_html__( 'There is an error while create a template. Try it again', 'orvian-addons' ),
			];
			wp_send_json_error( $errormessage );
		}
	}

	/**
	 * Sortable
	 *
	 * @return void
	 */
	public function sortable_builder() {
		global $wpdb, $userdata;

		// phpcs:ignore WordPress.Security.NonceVerification,WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
		$paged_value = isset( $_POST['paged'] ) ? wp_unslash( $_POST['paged'] ) : '1';
		$paged       = filter_var( sanitize_text_field( wp_unslash( $paged_value ) ), FILTER_SANITIZE_NUMBER_INT );
		// phpcs:ignore WordPress.Security.NonceVerification,WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
		$order_value = isset( $_POST['order'] ) ? wp_unslash( $_POST['order'] ) : '';
		parse_str( sanitize_text_field( wp_unslash( $order_value ) ), $data );

		if ( ! is_array( $data ) || count( $data ) < 1 ) {
			die();
		}

		// retrieve a list of all objects.
		$mysql_query = $wpdb->prepare( 'SELECT ID FROM ' . $wpdb->posts . " WHERE post_type = %s AND post_status IN ('publish', 'pending', 'draft', 'private', 'future', 'inherit') ORDER BY menu_order, post_date DESC", Post_Type::POST_TYPE );

		// phpcs:ignore
		$results = $wpdb->get_results( $mysql_query );

		if ( ! is_array( $results ) || count( $results ) < 1 ) {
			die();
		}

		// create the list of ID's.
		$ids = [];
		foreach ( $results as $result ) {
			$ids[] = absint( $result->ID );
		}

		$per_page = get_user_meta( $userdata->ID, 'edit_' . Post_Type::POST_TYPE . '_per_page', true );
		// phpcs:ignore
		$per_page = apply_filters( 'edit_{' . Post_Type::POST_TYPE . '}_per_page', $per_page );

		if ( empty( $per_page ) ) {
			$per_page = 20;
		}

		$edit_start_at = ( $paged * $per_page ) - $per_page;
		$index         = 0;
		for ( $i = $edit_start_at; $i < ( $edit_start_at + $per_page ); $i++ ) {
			if ( ! isset( $ids[ $i ] ) ) {
				break;
			}

			$ids[ $i ] = absint( $data['post'][ $index ] );
			++$index;
		}

		// update the menu_order within database.
		foreach ( $ids as $menu_order => $id ) {
			$data = [
				'menu_order' => $menu_order,
			];

			// phpcs:ignore
			$wpdb->update( $wpdb->posts, $data, array( 'ID' => $id ) );

			clean_post_cache( $id );
		}

		wp_send_json_success();
	}

	/**
	 * Posts OrderBy filter
	 *
	 * @param mixed $orderby OrderBy.
	 * @param mixed $query Query.
	 */
	public function posts_orderby( $orderby, $query ) {
		global $wpdb;

		if ( isset( $query->query_vars['post_type'] ) && Post_Type::POST_TYPE === $query->query_vars['post_type'] ) {
			if ( '' === trim( $orderby ) ) {
				$orderby = "{$wpdb->posts}.menu_order";
			} else {
				$orderby = "{$wpdb->posts}.menu_order, " . $orderby;
			}
		}

		return $orderby;
	}

	/**
	 * Get all WooCommerce screen ids.
	 *
	 * @param array $screen_ids Screen ids.
	 * @return array
	 */
	public static function wc_screen_ids( $screen_ids ) {
		$screen_ids[] = Post_Type::POST_TYPE;

		return $screen_ids;
	}

	/**
	 * Admin scripts
	 *
	 * @param string $hook Hook.
	 * @return void
	 */
	public function admin_scripts( $hook ) {
		$screen = get_current_screen();

		if ( in_array( $hook, [ 'edit.php', 'post-new.php', 'post.php' ], true ) && Post_Type::POST_TYPE === $screen->post_type ) {
			wp_enqueue_style( 'orvian-builder', ORVIAN_ADDONS_ASSETS_URL . 'css/elementor/admin/builder-admin.css', [], '1.0.0' );
			wp_enqueue_script( 'orvian-builder', ORVIAN_ADDONS_ASSETS_URL . 'js/elementor/admin/builder-admin.js', [ 'jquery', 'jquery-ui-sortable' ], '1.0.0', true );
		}
	}

	/**
	 * Admin print tabs
	 *
	 * @param array $views Views.
	 * @return array
	 */
	public function admin_print_tabs( $views ) {
		$active_class = 'nav-tab-active';
		$current_type = '';
		// phpcs:ignore
		if ( isset( $_GET['template_type'] ) ) {
			$active_class = '';
			// phpcs:ignore
			$current_type = sanitize_key( $_GET['template_type'] );
		}
		?>
			<div id="orvian-template-tabs-wrapper" class="nav-tab-wrapper">
				<div class="orvian-menu-area">
					<a class="nav-tab <?php echo esc_attr( $active_class ); ?>" href="edit.php?post_type=<?php echo esc_attr( Post_Type::POST_TYPE ); ?>"><?php esc_html_e( 'All', 'orvian-addons' ); ?></a>
					<?php
					foreach ( self::get_template_type() as $tabkey => $tabname ) {
						$active_class = $current_type === $tabkey ? 'nav-tab-active' : '';
						echo '<a class="nav-tab ' . esc_attr( $active_class ) . '" href="edit.php?post_type=' . esc_attr( Post_Type::POST_TYPE ) . '&template_type=' . esc_attr( $tabkey ) . '">' . wp_kses_post( $tabname ) . '</a>';
					}
					?>
				</div>
			</div>
		<?php
		return $views;
	}

	/**
	 * Query filter
	 *
	 * @param \WP_Query $query Query.
	 * @return void
	 */
	public function query_filter( \WP_Query $query ) {
		if ( ! is_admin() || ! $this->is_current_screen() ) {
			return;
		}

		// phpcs:ignore
		if ( isset( $_GET['template_type'] ) && '' !== $_GET['template_type'] && 'all' !== $_GET['template_type'] ) {
			// phpcs:ignore
			$type     = sanitize_key( $_GET['template_type'] );
			$taxquery = [
				[
					'taxonomy' => Post_Type::TAXONOMY_TYPE,
					'field'    => 'slug',
					'terms'    => [ $type ],
					'operator' => 'IN',
				],
			];
			$query->set( 'tax_query', $taxquery );
		}
	}


	/**
	 * Is current screen
	 *
	 * @return bool
	 */
	private function is_current_screen() {
		global $pagenow, $typenow;
		return 'edit.php' === $pagenow && Post_Type::POST_TYPE === $typenow;
	}

	/**
	 * Get template type
	 *
	 * @return array
	 */
	public static function get_template_type() {
		return [
			'footer'         => esc_html__( 'Footer', 'orvian-addons' ),
			'header_main'    => esc_html__( 'Header Main', 'orvian-addons' ),
			'header_section' => esc_html__( 'Header Section', 'orvian-addons' ),
			'hamburger_menu' => esc_html__( 'Hamburger Menu', 'orvian-addons' ),
		];
	}

	/**
	 * Clear popup ids
	 *
	 * @param int $post_id Post ID.
	 *
	 * @return void
	 */
	public static function delete_builder_cache( $post_id ) {
		$terms = get_the_terms( $post_id, Post_Type::TAXONOMY_TYPE );
		$terms = ! is_wp_error( $terms ) && $terms ? wp_list_pluck( $terms, 'slug' ) : '';
	}

	/**
	 * Template type popup
	 *
	 * @return void
	 */
	public function template_type_popup() {
		// phpcs:ignore
		if ( isset( $_GET['post_type'] ) && Post_Type::POST_TYPE === $_GET['post_type'] ) {
			include_once plugin_dir_path( __FILE__ ) . 'templates/template-type-popup.php';
		}
	}
}
