<?php
/**
 * Elementor Settings
 *
 * @package OrvianAddons
 */

namespace OrvianAddons\Elementor\Builder;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

use Elementor\Core\Base\Module;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Background;
use Elementor\Core\DocumentTypes\PageBase;

/**
 * Elementor Settings
 */
class Elementor_Settings extends Module {

	/**
	 * Get module name.
	 *
	 * @return string
	 */
	public function get_name() {
		return 'orvian-elementor-settings';
	}

	/**
	 * Module constructor.
	 */
	public function __construct() {
		add_action( 'elementor/documents/register_controls', [ $this, 'register_display_controls' ] );

		add_action( 'elementor/document/after_save', [ $this, 'save_post_meta' ], 10, 2 );

		add_filter( 'elementor/document/wrapper_attributes', [ $this, 'add_color_scheme_class' ], 10, 2 );
	}


	/**
	 * Register display controls.
	 *
	 * @param object $document Document object.
	 */
	public function register_display_controls( $document ) {
		if ( ! $document instanceof PageBase ) {
			return;
		}

		$post_type = get_post_type( $document->get_main_id() );

		if ( Post_Type::POST_TYPE !== $post_type ) {
			return;
		}

		$terms = get_the_terms( $document->get_main_id(), Post_Type::TAXONOMY_TYPE );
		$terms = ! is_wp_error( $terms ) && $terms ? wp_list_pluck( $terms, 'slug' ) : '';

		if ( ! $terms ) {
			return;
		}

		if ( in_array( 'footer', $terms, true ) || in_array( 'header_section', $terms, true ) || in_array( 'hamburger_menu', $terms, true ) ) {
			$this->register_builder_content( $document );
			$this->register_color_scheme( $document );
		}

		if ( in_array( 'header_main', $terms, true ) ) {
			$this->register_builder_content( $document );
			$this->register_header_sections( $document );
		}

		if ( in_array( 'header_section', $terms, true ) ) {
			$this->register_header_section_style( $document );
		}
	}

	/**
	 * Register template controls of display.
	 *
	 * @param object $document Document object.
	 */
	protected function register_builder_content( $document ) {
		$document->start_controls_section(
			'section_builder_settings',
			[
				'label' => esc_html__( 'Builder Settings', 'orvian-addons' ),
				'tab'   => Controls_Manager::TAB_SETTINGS,
			]
		);

		$args_types      = $this->get_types();
		$get_types_extra = $this->get_types_extra();

		$document->add_control(
			'include_on',
			[
				'label'       => esc_html__( 'Display On', 'orvian-addons' ),
				'description' => esc_html__( 'Choose where should be displayed.', 'orvian-addons' ),
				'type'        => Controls_Manager::SELECT2,
				'multiple'    => true,
				'options'     => $args_types,
				'default'     => [],
			]
		);

		foreach ( $args_types as $key => $label ) {
			if ( in_array( $key, $get_types_extra, true ) ) {
				continue;
			}

			$document->add_control(
				'include_' . $key . '_ids',
				[
					// phpcs:ignore
					'label'       => sprintf( esc_html__( 'Specific %s', 'orvian-addons' ), $label ),
					'type'        => 'orvian-autocomplete',
					'placeholder' => esc_html__( 'Click here and start typing...', 'orvian-addons' ),
					'default'     => '',
					'multiple'    => true,
					'source'      => $key,
					'sortable'    => true,
					'label_block' => true,
					'conditions'  => [
						'terms' => [
							[
								'name'     => 'include_on',
								'operator' => 'contains',
								'value'    => $key,
							],
						],
					],
				]
			);
		}

		$document->add_control(
			'exclude_on',
			[
				'label'       => esc_html__( 'Exclude From', 'orvian-addons' ),
				'description' => esc_html__( 'Choose where should be excluded.', 'orvian-addons' ),
				'type'        => Controls_Manager::SELECT2,
				'multiple'    => true,
				'options'     => $args_types,
				'default'     => [],
				'separator'   => 'before',
			]
		);

		foreach ( $args_types as $key => $label ) {
			if ( in_array( $key, $get_types_extra, true ) ) {
				continue;
			}

			$document->add_control(
				'exclude_' . $key . '_ids',
				[
					// phpcs:ignore
					'label'       => sprintf( esc_html__( 'Specific %s', 'orvian-addons' ), $label ),
					'type'        => 'orvian-autocomplete',
					'placeholder' => esc_html__( 'Click here and start typing...', 'orvian-addons' ),
					'default'     => '',
					'multiple'    => true,
					'source'      => $key,
					'sortable'    => true,
					'label_block' => true,
					'conditions'  => [
						'terms' => [
							[
								'name'     => 'exclude_on',
								'operator' => 'contains',
								'value'    => $key,
							],
						],
					],
				]
			);
		}

		$document->end_controls_section();
	}

	/**
	 * Register template controls of display.
	 *
	 * @param object $document Document object.
	 */
	protected function register_color_scheme( $document ) {
		$document->start_controls_section(
			'section_builder_style',
			[
				'label' => esc_html__( 'Builder Style', 'orvian-addons' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$document->add_control(
			'orvian_color_scheme',
			[
				'label'   => esc_html__( 'Color Scheme', 'orvian-addons' ),
				'type'    => Controls_Manager::SELECT,
				'default' => '',
				'options' => [
					''            => esc_html__( 'Default', 'orvian-addons' ),
					'theme-light' => esc_html__( 'Light', 'orvian-addons' ),
					'theme-dark'  => esc_html__( 'Dark', 'orvian-addons' ),
				],
			]
		);

		$document->end_controls_section();
	}

	/**
	 * Register template controls of display.
	 *
	 * @param object $document Document object.
	 *
	 * @return void
	 */
	protected function register_header_sections( $document ) {
		$document->start_controls_section(
			'section_builder_style',
			[
				'label' => esc_html__( 'Builder Style', 'orvian-addons' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$document->add_control(
			'orvian_color_scheme',
			[
				'label'   => esc_html__( 'Color Scheme', 'orvian-addons' ),
				'type'    => Controls_Manager::SELECT,
				'default' => '',
				'options' => [
					''            => esc_html__( 'Default', 'orvian-addons' ),
					'theme-light' => esc_html__( 'Light', 'orvian-addons' ),
					'theme-dark'  => esc_html__( 'Dark', 'orvian-addons' ),
				],
			]
		);

		$document->add_control(
			'orvian_sticky_header_enabled',
			[
				'label'   => esc_html__( 'Sticky Header', 'orvian-addons' ),
				'type'    => Controls_Manager::SWITCHER,
				'default' => 'yes',
			]
		);

		$document->end_controls_section();
	}

	/**
	 * Register template controls of display.
	 *
	 * @param object $document Document object.
	 *
	 * @return void
	 */
	public function register_header_section_style( $document ) {
		$document->start_controls_section(
			'header_section_style',
			[
				'label' => esc_html__( 'Header Section Style', 'orvian-addons' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$document->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'     => 'header_section_background',
				'types'    => [ 'classic', 'gradient' ],
				'selector' => '.elementor-' . $document->get_main_id(),
			]
		);

		$document->end_controls_section();
	}

	/**
	 * Save post meta when save page settings in Elementor
	 *
	 * @param object $document Document object.
	 * @param object $data Elementor data.
	 *
	 * @return void
	 */
	public function save_post_meta( $document, $data ) {
		$post_type = get_post_type( $document->get_main_id() );

		if ( Post_Type::POST_TYPE !== $post_type ) {
			return;
		}

		$terms = get_the_terms( $document->get_main_id(), Post_Type::TAXONOMY_TYPE );
		$terms = ! is_wp_error( $terms ) && $terms ? wp_list_pluck( $terms, 'slug' ) : '';

		if ( ! $terms ) {
			return;
		}

		if ( ! isset( $data['settings'] ) ) {
			return;
		}

		$settings   = $data['settings'];
		$args_types = $this->get_types();

		if ( in_array( 'footer', $terms, true ) || in_array( 'header_main', $terms, true ) || in_array( 'header_section', $terms, true ) || in_array( 'hamburger_menu', $terms, true ) ) {
			// Save include settings.
			$include_on = 0;
			if ( ! empty( $settings['include_on'] ) ) {
				$raw_slugs = $settings['include_on'];

				if ( is_array( $raw_slugs ) ) {
					$raw_slugs = implode( ',', $raw_slugs );
				}

				$raw_slugs  = trim( $raw_slugs, ',' );
				$include_on = ',' . $raw_slugs . ',';
			}
			update_post_meta( $document->get_main_id(), 'include_on', $include_on );

			foreach ( $args_types as $key => $value ) {
				$include_ids = 0;
				if ( ! empty( $settings[ 'include_' . $key . '_ids' ] ) ) {
					$raw_ids = $settings[ 'include_' . $key . '_ids' ];

					if ( is_array( $raw_ids ) ) {
						$raw_ids = array_map( 'intval', $raw_ids );
						$raw_ids = implode( ',', $raw_ids );
					}

					$raw_ids     = preg_replace( '/[^0-9,]/', '', $raw_ids );
					$raw_ids     = trim( $raw_ids, ',' );
					$include_ids = ',' . $raw_ids . ',';
				}
				update_post_meta( $document->get_main_id(), $key . '_include', $include_ids );
			}

			// Save exclude settings.
			$exclude_on = 0;
			if ( ! empty( $settings['exclude_on'] ) ) {
				$raw_slugs = $settings['exclude_on'];

				if ( is_array( $raw_slugs ) ) {
					$raw_slugs = implode( ',', $raw_slugs );
				}

				$raw_ids    = trim( $raw_slugs, ',' );
				$exclude_on = ',' . $raw_slugs . ',';
			}
			update_post_meta( $document->get_main_id(), 'exclude_on', $exclude_on );

			foreach ( $args_types as $key => $value ) {
				$exclude_ids = 0;
				if ( ! empty( $settings[ 'exclude_' . $key . '_ids' ] ) ) {
					$raw_ids = $settings[ 'exclude_' . $key . '_ids' ];

					if ( is_array( $raw_ids ) ) {
						$raw_ids = array_map( 'intval', $raw_ids );
						$raw_ids = implode( ',', $raw_ids );
					}

					$raw_ids     = preg_replace( '/[^0-9,]/', '', $raw_ids );
					$raw_ids     = trim( $raw_ids, ',' );
					$exclude_ids = ',' . $raw_ids . ',';
				}
				update_post_meta( $document->get_main_id(), $key . '_exclude', $exclude_ids );
			}
		}
	}

	/**
	 * Get types.
	 *
	 * @return array
	 */
	public static function get_types() {
		$args = [
			'category'       => esc_html__( 'Categories', 'orvian-addons' ),
			'tag'            => esc_html__( 'Tags', 'orvian-addons' ),
			'page'           => esc_html__( 'Pages', 'orvian-addons' ),
			'not_found_page' => esc_html__( '404 Page', 'orvian-addons' ),
		];

		if ( post_type_exists( 'portfolio' ) ) {
			$args = array_merge(
				$args,
				[
					'portfolio_type' => esc_html__( 'Portfolio Types', 'orvian-addons' ),
					'portfolio_tag'  => esc_html__( 'Portfolio Tags', 'orvian-addons' ),
				]
			);
		}

		return $args;
	}

	/**
	 * Get types extra.
	 *
	 * @return array
	 */
	public static function get_types_extra() {
		$args = [
			'not_found_page',
		];

		return $args;
	}

	/**
	 * Add color scheme class to document wrapper attributes.
	 *
	 * @param array                         $attributes Wrapper attributes.
	 * @param \Elementor\Core\Base\Document $document   Document instance.
	 *
	 * @return array
	 */
	public function add_color_scheme_class( $attributes, $document ) {
		$post_id = $document->get_main_id();

		if ( Post_Type::POST_TYPE !== get_post_type( $post_id ) ) {
			return $attributes;
		}

		$page_settings_manager = \Elementor\Core\Settings\Manager::get_settings_managers( 'page' );
		$page_settings_model   = $page_settings_manager->get_model( $post_id );
		$color_scheme          = $page_settings_model->get_settings( 'orvian_color_scheme' );
		$sticky_header         = $page_settings_model->get_settings( 'orvian_sticky_header_enabled' );

		if ( ! empty( $color_scheme ) ) {
			if ( empty( $attributes['class'] ) ) {
				$attributes['class'] = '';
			}
			$attributes['class'] .= ' orvian-color-scheme ' . esc_attr( $color_scheme );
		}

		if ( ! empty( $sticky_header ) ) {
			if ( empty( $attributes['class'] ) ) {
				$attributes['class'] = '';
			}
			$attributes['class'] .= ' orvian-sticky-header';
		}

		return $attributes;
	}
}
