<?php
/**
 * Register template builder
 *
 * @package OrvianAddons
 */

namespace OrvianAddons\Elementor\Builder;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Class Post_Type
 */
class Post_Type {

	/**
	 * Instance
	 *
	 * @var $instance
	 */
	private static $instance;

	/**
	 * Initiator
	 *
	 * @return object
	 */
	public static function instance() {
		if ( ! isset( self::$instance ) ) {
			self::$instance = new self();
		}

		return self::$instance;
	}

	const POST_TYPE     = 'orvian_builder';
	const OPTION_NAME   = 'orvian_builder';
	const TAXONOMY_TYPE = 'orvian_builder_type';

	/**
	 * Class constructor.
	 */
	public function __construct() {
		add_action( 'admin_menu', [ $this, 'register_admin_menu' ], 50 );

		// Make sure the post types are loaded for imports.
		add_action( 'import_start', [ $this, 'register_post_type' ] );

		// Register custom post type and custom taxonomy.
		$this->register_post_type();

		// Register custom post type and custom taxonomy.
		$this->register_taxonomy();

		add_action( 'admin_init', [ $this, 'create_terms' ] );

		add_filter( 'single_template', [ $this, 'load_canvas_template' ] );
	}

	/**
	 * Register portfolio post type
	 */
	public function register_post_type() {
		// Template Builder.
		$labels = [
			'name'               => esc_html__( 'Templates Builder', 'orvian-addons' ),
			'singular_name'      => esc_html__( 'Template', 'orvian-addons' ),
			'menu_name'          => esc_html__( 'Template', 'orvian-addons' ),
			'name_admin_bar'     => esc_html__( 'Template', 'orvian-addons' ),
			'add_new'            => esc_html__( 'Add New', 'orvian-addons' ),
			'add_new_item'       => esc_html__( 'Add New Template', 'orvian-addons' ),
			'new_item'           => esc_html__( 'New Template', 'orvian-addons' ),
			'edit_item'          => esc_html__( 'Edit Template', 'orvian-addons' ),
			'view_item'          => esc_html__( 'View Template', 'orvian-addons' ),
			'all_items'          => esc_html__( 'All Elementor', 'orvian-addons' ),
			'search_items'       => esc_html__( 'Search Templates', 'orvian-addons' ),
			'parent_item_colon'  => esc_html__( 'Parent Template:', 'orvian-addons' ),
			'not_found'          => esc_html__( 'No Templates found.', 'orvian-addons' ),
			'not_found_in_trash' => esc_html__( 'No Templates found in Trash.', 'orvian-addons' ),
		];

		$args = [
			'labels'              => $labels,
			'public'              => true,
			'rewrite'             => false,
			'show_ui'             => true,
			'show_in_menu'        => false,
			'show_in_nav_menus'   => false,
			'exclude_from_search' => true,
			'capability_type'     => 'post',
			'hierarchical'        => false,
			'menu_icon'           => 'dashicons-editor-kitchensink',
			'supports'            => [ 'title', 'editor', 'elementor' ],
		];

		if ( ! post_type_exists( self::POST_TYPE ) ) {
			register_post_type( self::POST_TYPE, $args );
		}
	}

	/**
	 * Register admin menu.
	 */
	public function register_admin_menu() {
		add_submenu_page(
			'orvian_dashboard',
			esc_html__( 'Templates Builder', 'orvian-addons' ),
			esc_html__( 'Templates Builder', 'orvian-addons' ),
			'edit_pages',
			'edit.php?post_type=' . self::POST_TYPE . ''
		);
	}

	/**
	 * Register core taxonomies.
	 */
	public function register_taxonomy() {
		if ( taxonomy_exists( self::TAXONOMY_TYPE ) ) {
			return;
		}

		register_taxonomy(
			self::TAXONOMY_TYPE,
			[ self::POST_TYPE ],
			[
				'hierarchical'      => false,
				'show_ui'           => false,
				'show_in_menu'      => false,
				'show_in_rest'      => false,
				'show_in_nav_menus' => false,
				'query_var'         => true,
				'rewrite'           => [ 'slug' => self::TAXONOMY_TYPE ],
				'public'            => true,
				'label'             => _x( 'Builder Type', 'Taxonomy name', 'orvian-addons' ),
			]
		);
	}

	/**
	 * Create default terms.
	 */
	public function create_terms() {
		$terms = [
			'enable',
			'footer',
			'header_main',
			'header_section',
			'hamburger_menu',
		];

		foreach ( $terms as $term ) {
			if ( ! get_term_by( 'name', $term, self::TAXONOMY_TYPE ) ) { // @codingStandardsIgnoreLine.
				wp_insert_term( $term, self::TAXONOMY_TYPE );
			}
		}
	}

	/**
	 * Add the popup before content
	 *
	 * @param string $single_template Single template.
	 */
	public function load_canvas_template( $single_template ) {
		global $post;

		if ( 'orvian_builder' === $post->post_type ) {
			if ( has_term( 'footer', self::TAXONOMY_TYPE, $post->ID ) || has_term( 'header_section', self::TAXONOMY_TYPE, $post->ID ) || has_term( 'header_main', self::TAXONOMY_TYPE, $post->ID ) || has_term( 'hamburger_menu', self::TAXONOMY_TYPE, $post->ID ) ) {
				return ELEMENTOR_PATH . '/modules/page-templates/templates/canvas.php';
			} else {
				return plugin_dir_path( __FILE__ ) . 'templates/header-footer.php';
			}
		}

		return $single_template;
	}
}
