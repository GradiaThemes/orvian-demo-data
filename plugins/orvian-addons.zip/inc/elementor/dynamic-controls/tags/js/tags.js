( function ( $ ) {
	'use strict';

	const OrvianTagsSelect = elementor.modules.controls.BaseData.extend( {
		onReady() {
			this.initTags();
			this.bindRemove();
			this.bindSortable();
			this.renderFromValue();
		},

		initTags() {
			const control = this;
			const $input = control.$el.find( '.orvian-el-tags-field' );

			$input.on( 'keydown', function ( e ) {
				if ( e.key === 'Enter' ) {
					e.preventDefault();

					const val = $input.val().trim();
					if ( ! val ) {
						return;
					}

					control.addTag( val );
					$input.val( '' );
				}
			} );
		},

		addTag( value ) {
			if (
				this.$el.find( '.orvian-el-tag' ).filter( function () {
					return $( this ).data( 'value' ) === value;
				} ).length
			) {
				return;
			}

			const escapedValue = value
				.replace( /</g, '<' )
				.replace( />/g, '>' );
			const $tag = $(
				'<li class="orvian-el-tag">' +
					'<span class="orvian-el-tag-label">' +
					escapedValue +
					'</span>' +
					'<span class="orvian-el-tag-remove">×</span>' +
					'</li>'
			);
			$tag.data( 'value', value );

			this.$el.find( '.orvian-el-tags-select' ).append( $tag );
			this.syncValue();
		},

		bindRemove() {
			const control = this;

			control.$el.on( 'click', '.orvian-el-tag-remove', function ( e ) {
				e.preventDefault();
				$( this ).closest( '.orvian-el-tag' ).remove();
				control.syncValue();
			} );
		},

		bindSortable() {
			const control = this;

			if ( ! $.fn.sortable ) {
				return;
			}

			const $sortableEl = control.$el.find( '.orvian-el-tags-select' );
			if ( $sortableEl.hasClass( 'ui-sortable' ) ) {
				return;
			}

			$sortableEl.sortable( {
				items: '.orvian-el-tag',
				tolerance: 'pointer',
				cancel: 'input, .orvian-el-tag-remove',
				update() {
					control.syncValue();
				},
			} );
		},

		syncValue() {
			const values = [];

			this.$el.find( '.orvian-el-tag' ).each( function () {
				const v = $( this ).data( 'value' );
				if (
					typeof v === 'string' &&
					v.trim() !== '' &&
					v !== 'undefined'
				) {
					values.push( v );
				}
			} );

			this.setValue( values );
		},

		renderFromValue() {
			const control = this,
				value = this.getControlValue();

			if ( ! value || ! Array.isArray( value ) ) {
				return;
			}

			value.forEach( ( v ) => {
				if (
					typeof v === 'string' &&
					v.trim() !== '' &&
					v !== 'undefined'
				) {
					control.addTag( v );
				}
			} );
		},

		onBeforeDestroy() {
			try {
				const $sortableEl = this.$el.find( '.orvian-el-tags-select' );
				if ( $sortableEl.sortable( 'instance' ) ) {
					$sortableEl.sortable( 'destroy' );
				}
			} catch ( e ) {
				// Ignore errors during destroy
			}
			this.$el.off();
		},
	} );

	elementor.addControlView( 'orvian-tags', OrvianTagsSelect );
} )( jQuery );
