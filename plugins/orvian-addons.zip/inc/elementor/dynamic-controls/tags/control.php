<?php
/**
 * Tags Control
 *
 * @package OrvianAddons
 */

namespace OrvianAddons\Elementor\Dynamic_Controls\Tags;

use Elementor\Base_Data_Control;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class Tags Control
 */
class Control extends Base_Data_Control {

	/**
	 * Get control type.
	 *
	 * Retrieve the control type, in this case `orvian-tags`.
	 *
	 * @access public
	 *
	 * @return string Control type.
	 */
	public function get_type() {
		return 'orvian-tags';
	}

	/**
	 * Enqueue scripts and styles.
	 */
	public function enqueue() {
		wp_enqueue_style(
			'orvian-tags-control',
			plugins_url( 'css/tags.css', __FILE__ ),
			[],
			'1.0.0'
		);

		wp_enqueue_script(
			'orvian-tags-control',
			plugins_url( 'js/tags.js', __FILE__ ),
			[ 'jquery', 'jquery-ui-sortable', 'elementor-editor' ],
			'1.0.0',
			true
		);
	}

	/**
	 * Get default settings.
	 *
	 * Retrieve the default settings of the heading control. Used to return the
	 * default settings while initializing the heading control.
	 *
	 * @access protected
	 *
	 * @return array Control default settings.
	 */
	protected function get_default_settings() {
		return [
			'label_block' => true,
		];
	}

	/**
	 * Render heading control in the editor.
	 *
	 * Used to generate the control HTML in the editor using Underscore JS
	 * template.
	 *
	 * @access public
	 */
	public function content_template() {
		$control_uid = $this->get_control_uid();
		?>
		<div class="elementor-control-field">

			<# if ( data.label ) { #>
				<label for="<?php echo esc_html( $control_uid ); ?>" class="elementor-control-title">
					{{{ data.label }}}
				</label>
			<# } #>

			<div class="elementor-control-input-wrapper">
				<ul class="orvian-el-tags-select">
					<li class="orvian-el-tags-input">
						<input
							id="<?php echo esc_html( $control_uid ); ?>"
							class="orvian-el-tags-field"
							type="text"
							placeholder="{{ data.placeholder || 'Type and press Enter' }}"
						/>
						<input
							type="hidden"
							class="orvian-el-tags-value"
							data-setting="{{ data.name }}"
							value="{{ data.controlValue }}"
						/>
					</li>
				</ul>
			</div>
		</div>

		<# if ( data.description ) { #>
			<div class="elementor-control-field-description">
				{{{ data.description }}}
			</div>
		<# } #>
		<?php
	}
}
