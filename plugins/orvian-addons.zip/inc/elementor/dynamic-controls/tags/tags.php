<?php
/**
 * Tags Control
 *
 * @package OrvianAddons
 */

namespace OrvianAddons\Elementor\Dynamic_Controls\Tags;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Tags
 */
class Tags {
	/**
	 * Instance
	 *
	 * @var $instance
	 */
	private static $instance;

	/**
	 * Initiator
	 *
	 * @return object
	 */
	public static function instance() {
		if ( ! isset( self::$instance ) ) {
			self::$instance = new self();
		}

		return self::$instance;
	}

	/**
	 * Instantiate the object.
	 *
	 * @return void
	 */
	public function __construct() {
		// Register controls.
		add_action( 'elementor/controls/register', [ $this, 'register_controls' ] );
	}

	/**
	 * Register autocomplete control
	 *
	 * @param object $controls_manager Controls manager.
	 *
	 * @return void
	 */
	public function register_controls( $controls_manager ) {
		$controls_manager->register( new Control() );
	}
}
