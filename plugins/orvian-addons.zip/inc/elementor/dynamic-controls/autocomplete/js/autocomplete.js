( function ( $ ) {
	'use strict';

	const ControlFMautocomplete = elementor.modules.controls.BaseData.extend( {
		onReady() {
			this.orvianAutocomplete( this );

			this.orvianRemoveData( this );

			this.orvianSortable( this );

			this.orvianOnRender( this );
		},
		orvianAutocomplete( self ) {
			let $input_value = self.$el.find( '.orvian_autocomplete_value' ),
				self_value = $input_value.val(),
				multiple = $input_value.data( 'multiple' ),
				step = '',
				item_value = '';

			self.$el
				.find( '.orvian_autocomplete_param' )
				.autocomplete( {
					minLength: 1,
					source( request, response ) {
						$.ajax( {
							url: ajaxurl,
							dataType: 'json',
							method: 'post',
					data: {
						action: 'orvian_get_autocomplete_suggest',
						term: request.term,
						source: $input_value.data( 'source' ),
						nonce: typeof orvian_autocomplete !== 'undefined' ? orvian_autocomplete.nonce : '',
					},
							success( data ) {
								response( data.data );
							},
						} );
					},
					response( event, ui ) {
						self.$el
							.find( '.orvian_autocomplete' )
							.removeClass( 'loading' );
					},
					search( event, ui ) {
						self.$el
							.find( '.orvian_autocomplete' )
							.addClass( 'loading' );
					},
					select( event, ui ) {
						item_value = ui.item.value;

						if ( item_value === 'nothing-found' ) {
							return false;
						}
						self_value = $input_value.val();
						if ( self_value !== '' ) {
							step = ',';
						}

						const template =
							'<li class="orvian_autocomplete-label" data-value="' +
							item_value +
							'">' +
							'<span class="orvian_autocomplete-data">' +
							ui.item.label +
							'</span>' +
							'<a href="#" class="orvian_autocomplete-remove">×</a>' +
							'</li>';

						if ( multiple ) {
							self.$el
								.find( '.orvian_autocomplete' )
								.append( template );
							self_value = self_value + step + item_value;
						} else {
							if (
								self.$el.find(
									'.orvian_autocomplete .orvian_autocomplete-label'
								).length > 0
							) {
								self.$el
									.find(
										'.orvian_autocomplete .orvian_autocomplete-label'
									)
									.replaceWith( template );
							} else {
								self.$el
									.find( '.orvian_autocomplete' )
									.append( template );
							}
							self.$el
								.find(
									'.orvian_autocomplete .orvian_autocomplete-label'
								)
								.replaceWith( template );
							self_value = item_value;
						}

						self.$el.find( '.orvian_autocomplete_param' ).val( '' );
						$input_value.val( self_value );
						self.setValue( self_value );

						return false;
					},
					open( event ) {
						$( event.target )
							.data( 'uiAutocomplete' )
							.menu.activeMenu.addClass(
								'elementor-autocomplete-menu orvian-autocomplete-menu'
							);
					},
				} )
				.autocomplete( 'instance' )._renderItem = function (
				ul,
				item
			) {
				return $( '<li>' )
					.attr( 'data-value', item.value )
					.append( item.label )
					.appendTo( ul );
			};
			return self_value;
		},
		orvianRemoveData( self ) {
			const $input_value = self.$el.find( '.orvian_autocomplete_value' );
			self.$el
				.find( '.orvian_autocomplete' )
				.on( 'click', '.orvian_autocomplete-remove', function ( e ) {
					e.preventDefault();
					let $this = $( this ),
						self_value = '';

					$this.closest( '.orvian_autocomplete-label' ).remove();

					self.$el
						.find( '.orvian_autocomplete' )
						.find( '.orvian_autocomplete-label' )
						.each( function () {
							self_value =
								self_value + ',' + $( this ).data( 'value' );
						} );
					$input_value.val( self_value );
					self.setValue( self_value );
				} );
		},
		orvianSortable( self ) {
			let sortable = self.$el
					.find( '.orvian_autocomplete_value' )
					.data( 'sortable' ),
				self_value = '';
			if ( sortable ) {
				self.$el.find( '.orvian_autocomplete' ).sortable( {
					items: 'li.orvian_autocomplete-label',
					update( event, ui ) {
						self_value = '';

						self.$el
							.find( '.orvian_autocomplete' )
							.find( 'li.orvian_autocomplete-label' )
							.each( function () {
								self_value =
									self_value +
									',' +
									$( this ).data( 'value' );
							} );

						self.setValue( self_value );
					},
				} );
			}
		},
		orvianOnRender( self ) {
			const $input_value = self.$el.find( '.orvian_autocomplete_value' ),
				self_value = $input_value.val();

			$.ajax( {
				url: ajaxurl,
				dataType: 'json',
				method: 'post',
				data: {
					action: 'orvian_get_autocomplete_render',
					term: self_value,
					source: $input_value.data( 'source' ),
					nonce: typeof orvian_autocomplete !== 'undefined' ? orvian_autocomplete.nonce : '',
				},
				success( data ) {
					if ( data ) {
						self.$el
							.find( '.orvian_autocomplete' )
							.append( data.data );
						self.$el
							.find( '.orvian_autocomplete' )
							.find( 'li.orvian_autocomplete-loading' )
							.remove();
					}
				},
			} );
		},
		onBeforeDestroy() {
			if ( this.ui.input.data( 'autocomplete' ) ) {
				this.ui.input.autocomplete( 'destroy' );
			}

			this.$el.remove();
		},
	} );
	elementor.addControlView( 'orvian-autocomplete', ControlFMautocomplete );
} )( jQuery );
