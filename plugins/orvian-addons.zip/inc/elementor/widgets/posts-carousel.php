<?php
/**
 * Posts Carousel Widget
 *
 * @package OrvianAddons
 */

namespace OrvianAddons\Elementor\Widgets;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use Elementor\Controls_Manager;
use OrvianAddons\Elementor\Elementor as OrvianAddons_Elementor;
use OrvianAddons\Admin\Portfolio;

/**
 * Posts Carousel Widget Class
 */
class Posts_Carousel extends Base\Carousel_Widget_Base {

	/**
	 * Get widget name
	 *
	 * @return string
	 */
	public function get_name() {
		return 'orvian-posts-carousel';
	}

	/**
	 * Get widget title
	 *
	 * @return string
	 */
	public function get_title() {
		return esc_html__( 'Posts Carousel', 'orvian-addons' );
	}

	/**
	 * Get widget icon
	 *
	 * @return string
	 */
	public function get_icon() {
		return 'eicon-posts-carousel ' . OrvianAddons_Elementor::CLASS_WIDGET;
	}

	/**
	 * Get widget categories
	 *
	 * @return array
	 */
	public function get_categories() {
		return [ OrvianAddons_Elementor::CATEGORY ];
	}

	/**
	 * Get widget keywords
	 *
	 * @return array
	 */
	public function get_keywords() {
		return [ 'orvian', 'posts', 'carousel' ];
	}

	/**
	 * Get carousel controls
	 *
	 * @return array
	 */
	protected function get_carousel_controls(): array {
		return [
			'slides_per_view' => [
				'desktop' => 3,
				'tablet'  => 2,
				'mobile'  => 1,
			],
			'space_between'   => [
				'desktop' => 12,
				'tablet'  => 12,
				'mobile'  => 12,
			],
			'navigation'      => 'both',
		];
	}

	/**
	 * Register widget controls
	 */
	protected function register_controls() {
		$this->start_controls_section(
			'content_section',
			[
				'label' => esc_html__( 'Posts Carousel', 'orvian-addons' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'posts_per_page',
			[
				'label'     => esc_html__( 'Limit', 'orvian-addons' ),
				'type'      => Controls_Manager::NUMBER,
				'min'       => 1,
				'step'      => 1,
				'default'   => 10,
				'separator' => 'after',
			]
		);

		$this->add_control(
			'source',
			[
				'label'   => esc_html__( 'Source', 'orvian-addons' ),
				'type'    => Controls_Manager::SELECT,
				'default' => '',
				'options' => [
					''        => esc_html__( 'Default', 'orvian-addons' ),
					'related' => esc_html__( 'Related', 'orvian-addons' ),
				],
			]
		);

		$this->add_control(
			'post_type',
			[
				'label'   => esc_html__( 'Post Type', 'orvian-addons' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'post',
				'options' => [
					'post'      => esc_html__( 'Post', 'orvian-addons' ),
					'portfolio' => esc_html__( 'Portfolio', 'orvian-addons' ),
				],
			]
		);

		$this->add_control(
			'taxonomy_post',
			[
				'label'     => esc_html__( 'Taxonomy', 'orvian-addons' ),
				'type'      => Controls_Manager::SELECT,
				'default'   => 'category',
				'options'   => [
					'category' => esc_html__( 'Category', 'orvian-addons' ),
					'post_tag' => esc_html__( 'Tag', 'orvian-addons' ),
				],
				'condition' => [
					'source'    => '',
					'post_type' => 'post',
				],
			]
		);

		$this->add_control(
			'taxonomy_portfolio',
			[
				'label'     => esc_html__( 'Taxonomy', 'orvian-addons' ),
				'type'      => Controls_Manager::SELECT,
				'default'   => Portfolio::TAXONOMY_TYPE,
				'options'   => [
					'portfolio_type'  => esc_html__( 'Type', 'orvian-addons' ),
					'portfolio_tag'   => esc_html__( 'Tag', 'orvian-addons' ),
					'portfolio_brand' => esc_html__( 'Brand', 'orvian-addons' ),
				],
				'condition' => [
					'source'    => '',
					'post_type' => 'portfolio',
				],
			]
		);

		$this->add_control(
			'select_category',
			[
				'label'       => esc_html__( 'Select Category', 'orvian-addons' ),
				'type'        => 'orvian-autocomplete',
				'source'      => 'category',
				'multiple'    => true,
				'sortable'    => true,
				'label_block' => true,
				'condition'   => [
					'source'        => 'custom',
					'post_type'     => 'post',
					'taxonomy_post' => 'category',
				],
			]
		);

		$this->add_control(
			'select_tag',
			[
				'label'       => esc_html__( 'Select Tag', 'orvian-addons' ),
				'type'        => 'orvian-autocomplete',
				'source'      => 'post_tag',
				'multiple'    => true,
				'sortable'    => true,
				'label_block' => true,
				'condition'   => [
					'source'        => 'custom',
					'post_type'     => 'post',
					'taxonomy_post' => 'post_tag',
				],
			]
		);

		$this->add_control(
			'select_type',
			[
				'label'       => esc_html__( 'Select Type', 'orvian-addons' ),
				'type'        => 'orvian-autocomplete',
				'source'      => Portfolio::TAXONOMY_TYPE,
				'multiple'    => true,
				'sortable'    => true,
				'label_block' => true,
				'condition'   => [
					'source'             => 'custom',
					'post_type'          => 'portfolio',
					'taxonomy_portfolio' => 'portfolio_type',
				],
			]
		);

		$this->add_control(
			'select_portfolio_tag',
			[
				'label'       => esc_html__( 'Select Tag', 'orvian-addons' ),
				'type'        => 'orvian-autocomplete',
				'source'      => Portfolio::TAXONOMY_TAG,
				'multiple'    => true,
				'sortable'    => true,
				'label_block' => true,
				'condition'   => [
					'source'             => 'custom',
					'post_type'          => 'portfolio',
					'taxonomy_portfolio' => 'portfolio_tag',
				],
			]
		);

		$this->add_control(
			'select_brand',
			[
				'label'       => esc_html__( 'Select Brand', 'orvian-addons' ),
				'type'        => 'orvian-autocomplete',
				'source'      => Portfolio::TAXONOMY_BRAND,
				'multiple'    => true,
				'sortable'    => true,
				'label_block' => true,
				'condition'   => [
					'source'             => 'custom',
					'post_type'          => 'portfolio',
					'taxonomy_portfolio' => 'portfolio_brand',
				],
			]
		);

		$this->add_control(
			'include_posts_post',
			[
				'label'       => esc_html__( 'Include Posts', 'orvian-addons' ),
				'type'        => 'orvian-autocomplete',
				'source'      => 'post',
				'multiple'    => true,
				'sortable'    => true,
				'label_block' => true,
				'condition'   => [
					'source'    => '',
					'post_type' => 'post',
				],
			]
		);

		$this->add_control(
			'include_posts_portfolio',
			[
				'label'       => esc_html__( 'Include Posts', 'orvian-addons' ),
				'type'        => 'orvian-autocomplete',
				'source'      => Portfolio::POST_TYPE,
				'multiple'    => true,
				'sortable'    => true,
				'label_block' => true,
				'condition'   => [
					'source'    => '',
					'post_type' => 'portfolio',
				],
			]
		);

		$this->add_control(
			'exclude_posts_post',
			[
				'label'       => esc_html__( 'Exclude Posts', 'orvian-addons' ),
				'type'        => 'orvian-autocomplete',
				'source'      => 'post',
				'multiple'    => true,
				'sortable'    => true,
				'label_block' => true,
				'condition'   => [
					'source'    => '',
					'post_type' => 'post',
				],
			]
		);

		$this->add_control(
			'exclude_posts_portfolio',
			[
				'label'       => esc_html__( 'Exclude Posts', 'orvian-addons' ),
				'type'        => 'orvian-autocomplete',
				'source'      => Portfolio::POST_TYPE,
				'multiple'    => true,
				'sortable'    => true,
				'label_block' => true,
				'condition'   => [
					'source'    => '',
					'post_type' => 'portfolio',
				],
			]
		);

		$this->add_control(
			'select_post_post',
			[
				'label'       => esc_html__( 'Select Post', 'orvian-addons' ),
				'type'        => 'orvian-autocomplete',
				'source'      => 'post',
				'multiple'    => false,
				'label_block' => true,
				'condition'   => [
					'source'    => 'related',
					'post_type' => 'post',
				],
			]
		);

		$this->add_control(
			'select_post_portfolio',
			[
				'label'       => esc_html__( 'Select Post', 'orvian-addons' ),
				'type'        => 'orvian-autocomplete',
				'source'      => Portfolio::POST_TYPE,
				'multiple'    => false,
				'label_block' => true,
				'condition'   => [
					'source'    => 'related',
					'post_type' => 'portfolio',
				],
			]
		);

		$this->add_control(
			'order_by',
			[
				'label'   => esc_html__( 'Order By', 'orvian-addons' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'date',
				'options' => [
					'date'       => esc_html__( 'Date', 'orvian-addons' ),
					'title'      => esc_html__( 'Title', 'orvian-addons' ),
					'rand'       => esc_html__( 'Random', 'orvian-addons' ),
					'menu_order' => esc_html__( 'Menu Order', 'orvian-addons' ),
					'post__in'   => esc_html__( 'Custom', 'orvian-addons' ),
				],
			]
		);

		$this->add_control(
			'order',
			[
				'label'   => esc_html__( 'Order', 'orvian-addons' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'DESC',
				'options' => [
					'ASC'  => esc_html__( 'Ascending', 'orvian-addons' ),
					'DESC' => esc_html__( 'Descending', 'orvian-addons' ),
				],
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'carousel_settings_section',
			[
				'label' => esc_html__( 'Carousel Settings', 'orvian-addons' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->register_carousel_controls();

		$this->end_controls_section();

		$this->start_controls_section(
			'style_carousel_section',
			[
				'label' => esc_html__( 'Carousel', 'orvian-addons' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->register_carousel_style_controls();

		$this->end_controls_section();
	}

	/**
	 * Get classes swiper.
	 *
	 * @return array
	 */
	protected function get_classes_swiper(): array {
		return [ 'posts-carousel__slider' ];
	}

	/**
	 * Get posts
	 *
	 * @param array $settings Widget settings.
	 * @return array
	 */
	protected function get_posts( array $settings ): array {
		$source = ! empty( $settings['source'] ) ? $settings['source'] : '';

		if ( 'related' === $source ) {
			return $this->get_related_posts( $settings );
		}

		return $this->get_default_posts( $settings );
	}

	/**
	 * Get custom posts
	 *
	 * @param array $settings Widget settings.
	 * @return array
	 */
	protected function get_default_posts( array $settings ): array {
		$post_type      = ! empty( $settings['post_type'] ) ? $settings['post_type'] : 'post';
		$posts_per_page = ! empty( $settings['posts_per_page'] ) ? absint( $settings['posts_per_page'] ) : 10;
		$order_by       = ! empty( $settings['order_by'] ) ? $settings['order_by'] : 'date';
		$order          = ! empty( $settings['order'] ) ? $settings['order'] : 'desc';

		$taxonomy = 'post' === $post_type
			? ( ! empty( $settings['taxonomy_post'] ) ? $settings['taxonomy_post'] : 'category' )
			: ( ! empty( $settings['taxonomy_portfolio'] ) ? $settings['taxonomy_portfolio'] : Portfolio::TAXONOMY_TYPE );

		$exclude_posts_key = 'post' === $post_type ? 'exclude_posts_post' : 'exclude_posts_portfolio';
		$exclude_ids       = [];
		if ( ! empty( $settings[ $exclude_posts_key ] ) ) {
			$exclude_ids = array_map( 'absint', explode( ',', $settings[ $exclude_posts_key ] ) );
		}

		$include_posts_key = 'post' === $post_type ? 'include_posts_post' : 'include_posts_portfolio';
		$include_ids       = [];
		if ( ! empty( $settings[ $include_posts_key ] ) ) {
			$include_ids = array_map( 'absint', explode( ',', $settings[ $include_posts_key ] ) );
		}

		$args = [
			'post_type'              => $post_type,
			'post_status'            => 'publish',
			'posts_per_page'         => $posts_per_page,
			'order'                  => $order,
			'orderby'                => $order_by,
			'post__not_in'           => $exclude_ids,
			'no_found_rows'          => true,
			'update_post_term_cache' => false,
			'update_post_meta_cache' => false,
			'ignore_sticky_posts'    => true,
		];

		if ( ! empty( $include_ids ) ) {
			$args['post__in'] = $include_ids;
		}

		$select_term_key = '';
		if ( 'post' === $post_type ) {
			$tax = ! empty( $settings['taxonomy_post'] ) ? $settings['taxonomy_post'] : 'category';
			if ( 'category' === $tax ) {
				$select_term_key = 'select_category';
				$taxonomy        = 'category';
			} elseif ( 'post_tag' === $tax ) {
				$select_term_key = 'select_tag';
				$taxonomy        = 'post_tag';
			}
		} else {
			$tax = ! empty( $settings['taxonomy_portfolio'] ) ? $settings['taxonomy_portfolio'] : Portfolio::TAXONOMY_TYPE;
			if ( 'portfolio_type' === $tax ) {
				$select_term_key = 'select_type';
				$taxonomy        = Portfolio::TAXONOMY_TYPE;
			} elseif ( 'portfolio_tag' === $tax ) {
				$select_term_key = 'select_portfolio_tag';
				$taxonomy        = Portfolio::TAXONOMY_TAG;
			} elseif ( 'portfolio_brand' === $tax ) {
				$select_term_key = 'select_brand';
				$taxonomy        = Portfolio::TAXONOMY_BRAND;
			}
		}

		if ( $select_term_key && ! empty( $settings[ $select_term_key ] ) ) {
			$term_slugs = array_filter( array_map( 'sanitize_text_field', explode( ',', $settings[ $select_term_key ] ) ) );

			if ( ! empty( $term_slugs ) ) {
				$terms = get_terms(
					[
						'taxonomy' => $taxonomy,
						'slug'     => $term_slugs,
						'fields'   => 'ids',
					]
				);

				if ( ! empty( $terms ) && ! is_wp_error( $terms ) ) {
					// phpcs:ignore
					$args['tax_query'] = [
						[
							'taxonomy' => $taxonomy,
							'terms'    => $terms,
							'field'    => 'term_id',
						],
					];
				}
			}
		}

		$query = new \WP_Query( $args );

		return $query->posts ?? [];
	}

	/**
	 * Get related posts
	 *
	 * @param array $settings Widget settings.
	 * @return array
	 */
	protected function get_related_posts( array $settings ): array {
		$post_type       = ! empty( $settings['post_type'] ) ? $settings['post_type'] : 'post';
		$posts_per_page  = ! empty( $settings['posts_per_page'] ) ? absint( $settings['posts_per_page'] ) : 10;
		$select_post_key = 'post' === $post_type ? 'select_post_post' : 'select_post_portfolio';
		$anchor_post_id  = ! empty( $settings[ $select_post_key ] )
			? absint( $settings[ $select_post_key ] )
			: get_the_ID();

		if ( ! $anchor_post_id ) {
			return [];
		}

		$args = [
			'post_type'              => $post_type,
			'post_status'            => 'publish',
			'posts_per_page'         => $posts_per_page,
			'orderby'                => 'rand',
			'post__not_in'           => [ $anchor_post_id ],
			'no_found_rows'          => true,
			'update_post_term_cache' => false,
			'update_post_meta_cache' => false,
			'ignore_sticky_posts'    => true,
		];

		if ( 'portfolio' === $post_type && post_type_exists( Portfolio::POST_TYPE ) ) {
			$terms = get_the_terms( $anchor_post_id, Portfolio::TAXONOMY_TYPE );
			if ( $terms && ! is_wp_error( $terms ) ) {
				$term_ids = wp_list_pluck( $terms, 'term_id' );
				// phpcs:ignore
				$args['tax_query'] = [
					[
						'taxonomy' => Portfolio::TAXONOMY_TYPE,
						'terms'    => $term_ids,
						'field'    => 'term_id',
					],
				];
			}
		} else {
			$category_ids = wp_get_post_categories( $anchor_post_id, [ 'fields' => 'ids' ] );

			if ( ! empty( $category_ids ) ) {
				$args['category__in'] = $category_ids;
			}
		}

		$query = new \WP_Query( $args );

		return $query->posts ?? [];
	}

	/**
	 * Render items carousel.
	 */
	protected function render_items_carousel() {
		$settings  = $this->get_settings_for_display();
		$posts     = $this->get_posts( $settings );
		$post_type = $settings['post_type'] ?? 'post';

		if ( empty( $posts ) ) {
			return;
		}

		foreach ( $posts as $post ) {
			setup_postdata( $GLOBALS['post'] = $post ); // phpcs:ignore

			get_template_part(
				'template-parts/content',
				$post_type,
				[ 'class' => 'post-carousel-item swiper-slide swiper-slide--stretch' ]
			);
		}

		wp_reset_postdata();
	}

	/**
	 * Render widget output.
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();
		$posts    = $this->get_posts( $settings );

		if ( empty( $posts ) ) {
			return;
		}
		?>
		<div class="posts-carousel posts-carousel--elementor">
			<?php $this->render_carousel(); ?>
		</div>
		<?php
	}
}
