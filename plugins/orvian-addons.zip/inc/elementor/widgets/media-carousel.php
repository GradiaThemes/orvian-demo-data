<?php
/**
 * Media Carousel Widget
 *
 * @package OrvianAddons
 */

namespace OrvianAddons\Elementor\Widgets;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use Elementor\Controls_Manager;
use Elementor\Repeater;
use Elementor\Icons_Manager;
use OrvianAddons\Elementor\Elementor as OrvianAddons_Elementor;

/**
 * Media Carousel Widget Class
 */
class Media_Carousel extends Base\Carousel_Widget_Base {

	/**
	 * Get widget name
	 *
	 * @return string
	 */
	public function get_name() {
		return 'orvian-media-carousel';
	}

	/**
	 * Get widget title
	 *
	 * @return string
	 */
	public function get_title() {
		return esc_html__( 'Media Carousel', 'orvian-addons' );
	}

	/**
	 * Get widget icon
	 *
	 * @return string
	 */
	public function get_icon() {
		return 'eicon-carousel ' . OrvianAddons_Elementor::CLASS_WIDGET;
	}

	/**
	 * Get widget categories
	 *
	 * @return array
	 */
	public function get_categories() {
		return [ OrvianAddons_Elementor::CATEGORY ];
	}

	/**
	 * Get widget keywords
	 *
	 * @return array
	 */
	public function get_keywords() {
		return [ 'orvian', 'media', 'carousel', 'image', 'icon' ];
	}

	/**
	 * Get carousel controls
	 *
	 * @return array
	 */
	protected function get_carousel_controls(): array {
		return [
			'slides_per_view' => [
				'desktop' => 4,
				'tablet'  => 3,
				'mobile'  => 2,
			],
			'space_between'   => [
				'desktop' => 30,
				'tablet'  => 20,
				'mobile'  => 15,
			],
			'navigation'      => 'dots',
		];
	}

	/**
	 * Register widget controls
	 */
	protected function register_controls() {
		$this->start_controls_section(
			'content_section',
			[
				'label' => esc_html__( 'Media Items', 'orvian-addons' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);

		$repeater = new Repeater();

		$repeater->add_control(
			'type',
			[
				'label'   => esc_html__( 'Type', 'orvian-addons' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'icon',
				'options' => [
					'icon'  => esc_html__( 'Icon', 'orvian-addons' ),
					'image' => esc_html__( 'Image', 'orvian-addons' ),
				],
			]
		);

		$repeater->add_control(
			'icon',
			[
				'label'     => esc_html__( 'Icon', 'orvian-addons' ),
				'type'      => Controls_Manager::ICONS,
				'default'   => [
					'value'   => 'fas fa-star',
					'library' => 'fa-solid',
				],
				'condition' => [
					'type' => 'icon',
				],
			]
		);

		$repeater->add_control(
			'image',
			[
				'label'     => esc_html__( 'Image', 'orvian-addons' ),
				'type'      => Controls_Manager::MEDIA,
				'dynamic'   => [
					'active' => true,
				],
				'condition' => [
					'type' => 'image',
				],
			]
		);

		$repeater->add_responsive_control(
			'custom_image_max_width',
			[
				'label'      => esc_html__( 'Max Width', 'orvian-addons' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%', 'em', 'rem' ],
				'range'      => [
					'px' => [
						'min' => 0,
						'max' => 1000,
					],
				],
				'selectors'  => [
					'{{WRAPPER}} {{CURRENT_ITEM}} .orvian-media-carousel__image img' => 'max-width: {{SIZE}}{{UNIT}};',
				],
				'condition'  => [
					'type' => 'image',
				],
			]
		);

		$repeater->add_responsive_control(
			'custom_icon_size',
			[
				'label'      => esc_html__( 'Size', 'orvian-addons' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', 'em', 'rem' ],
				'range'      => [
					'px' => [
						'min' => 0,
						'max' => 500,
					],
				],
				'selectors'  => [
					'{{WRAPPER}} {{CURRENT_ITEM}} .orvian-media-carousel__icon .orvian-svg-icon' => 'font-size: {{SIZE}}{{UNIT}};',
				],
				'condition'  => [
					'type' => 'icon',
				],
			]
		);

		$repeater->add_control(
			'link',
			[
				'label'       => esc_html__( 'Link', 'orvian-addons' ),
				'type'        => Controls_Manager::URL,
				'placeholder' => esc_html__( 'https://your-link.com', 'orvian-addons' ),
			]
		);

		$this->add_control(
			'media_items',
			[
				'label'       => esc_html__( 'Media Items', 'orvian-addons' ),
				'type'        => Controls_Manager::REPEATER,
				'fields'      => $repeater->get_controls(),
				'default'     => [
					[
						'type' => 'icon',
					],
					[
						'type' => 'icon',
					],
					[
						'type' => 'icon',
					],
					[
						'type' => 'icon',
					],
				],
				'title_field' => '{{{ type }}}',
			]
		);

		$this->add_control(
			'show_effect',
			[
				'label'     => esc_html__( 'Show Effect', 'orvian-addons' ),
				'type'      => Controls_Manager::SWITCHER,
				'selectors' => [
					'{{WRAPPER}} .swiper' => 'mask-image: linear-gradient( to right, transparent 0%, var(--color-white) 25%, var(--color-white) 75%, transparent 100% );',
				],
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'carousel_settings_section',
			[
				'label' => esc_html__( 'Carousel Settings', 'orvian-addons' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->register_carousel_controls();

		$this->end_controls_section();

		$this->start_controls_section(
			'icon_style_section',
			[
				'label' => esc_html__( 'Icon', 'orvian-addons' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'icon_color',
			[
				'label'     => esc_html__( 'Color', 'orvian-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .orvian-media-carousel__icon .orvian-svg-icon' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_responsive_control(
			'icon_size',
			[
				'label'      => esc_html__( 'Size', 'orvian-addons' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', 'em', 'rem' ],
				'range'      => [
					'px' => [
						'min' => 0,
						'max' => 500,
					],
				],
				'selectors'  => [
					'{{WRAPPER}} .orvian-media-carousel__icon .orvian-svg-icon' => 'font-size: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'image_style_section',
			[
				'label' => esc_html__( 'Image', 'orvian-addons' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_responsive_control(
			'image_max_width',
			[
				'label'      => esc_html__( 'Max Width', 'orvian-addons' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%', 'em', 'rem' ],
				'range'      => [
					'px' => [
						'min' => 0,
						'max' => 1000,
					],
				],
				'selectors'  => [
					'{{WRAPPER}} .orvian-media-carousel__image img' => 'max-width: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'image_border_radius',
			[
				'label'      => esc_html__( 'Border Radius', 'orvian-addons' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .orvian-media-carousel__image img' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'carousel_style_section',
			[
				'label' => esc_html__( 'Carousel', 'orvian-addons' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->register_carousel_style_controls();

		$this->end_controls_section();
	}

	/**
	 * Render widget output
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();

		if ( empty( $settings['media_items'] ) ) {
			return;
		}

		$this->render_carousel( 'div', 'items-center' );
	}

	/**
	 * Render items carousel
	 */
	protected function render_items_carousel() {
		$settings = $this->get_settings_for_display();

		foreach ( $settings['media_items'] as $index => $item ) :
			$this->add_render_attribute( 'slide_' . $index, 'class', [ 'swiper-slide', 'swiper-slide--stretch', 'orvian-media-carousel__slide', 'elementor-repeater-item-' . $item['_id'], 'flex', 'items-center', 'justify-center' ], true );
			?>
			<div <?php $this->print_render_attribute_string( 'slide_' . $index ); ?>>
				<?php if ( ! empty( $item['link']['url'] ) ) : ?>
					<?php $this->add_link_attributes( 'media_link_' . $index, $item['link'] ); ?>
					<a <?php $this->print_render_attribute_string( 'media_link_' . $index ); ?>>
				<?php endif; ?>

				<?php if ( 'icon' === $item['type'] && ! empty( $item['icon'] ) ) : ?>
					<div class="orvian-media-carousel__icon flex items-center justify-center">
						<span class="orvian-svg-icon">
							<?php
							Icons_Manager::render_icon(
								$item['icon'],
								[
									'aria-hidden' => 'true',
									'fill'        => 'currentColor',
								]
							);
							?>
						</span>
					</div>
				<?php elseif ( 'image' === $item['type'] && ! empty( $item['image']['url'] ) ) : ?>
					<div class="orvian-media-carousel__image ratio-image">
						<?php if ( ! empty( $item['image']['id'] ) ) : ?>
							<?php echo wp_get_attachment_image( $item['image']['id'], 'full' ); ?>
						<?php elseif ( ! empty( $item['image']['url'] ) ) : ?>
							<img src="<?php echo esc_url( $item['image']['url'] ); ?>">
						<?php endif; ?>
					</div>
				<?php endif; ?>

				<?php if ( ! empty( $item['link']['url'] ) ) : ?>
					</a>
				<?php endif; ?>
			</div>
			<?php
		endforeach;
	}
}
