<?php
/**
 * Posts Grid Widget
 *
 * @package OrvianAddons
 */

namespace OrvianAddons\Elementor\Widgets;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use Elementor\Controls_Manager;
use Elementor\Widget_Base;
use Elementor\Group_Control_Typography;
use OrvianAddons\Elementor\Elementor as OrvianAddons_Elementor;
use OrvianAddons\Admin\Portfolio;

/**
 * Posts Grid Widget Class
 */
class Posts_Grid extends Widget_Base {
	use Base\Text_Class;
	use Base\Button_Base;

	/**
	 * Get widget name
	 *
	 * @return string
	 */
	public function get_name() {
		return 'orvian-posts-grid';
	}

	/**
	 * Get widget title
	 *
	 * @return string
	 */
	public function get_title() {
		return esc_html__( 'Posts Grid', 'orvian-addons' );
	}

	/**
	 * Get widget icon
	 *
	 * @return string
	 */
	public function get_icon() {
		return 'eicon-posts-grid ' . OrvianAddons_Elementor::CLASS_WIDGET;
	}

	/**
	 * Get widget categories
	 *
	 * @return array
	 */
	public function get_categories() {
		return [ OrvianAddons_Elementor::CATEGORY ];
	}

	/**
	 * Get widget keywords
	 *
	 * @return array
	 */
	public function get_keywords() {
		return [ 'orvian', 'posts', 'grid' ];
	}

	/**
	 * Register widget controls
	 */
	protected function register_controls() {
		$this->start_controls_section(
			'content_section',
			[
				'label' => esc_html__( 'Posts Grid', 'orvian-addons' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'posts_per_page',
			[
				'label'     => esc_html__( 'Limit', 'orvian-addons' ),
				'type'      => Controls_Manager::NUMBER,
				'min'       => 1,
				'step'      => 1,
				'default'   => 12,
				'separator' => 'after',
			]
		);

		$this->add_control(
			'source',
			[
				'label'   => esc_html__( 'Source', 'orvian-addons' ),
				'type'    => Controls_Manager::SELECT,
				'default' => '',
				'options' => [
					''        => esc_html__( 'Default', 'orvian-addons' ),
					'related' => esc_html__( 'Related', 'orvian-addons' ),
				],
			]
		);

		$this->add_control(
			'post_type',
			[
				'label'   => esc_html__( 'Post Type', 'orvian-addons' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'post',
				'options' => [
					'post'      => esc_html__( 'Post', 'orvian-addons' ),
					'portfolio' => esc_html__( 'Portfolio', 'orvian-addons' ),
				],
			]
		);

		$this->add_control(
			'taxonomy_post',
			[
				'label'     => esc_html__( 'Taxonomy', 'orvian-addons' ),
				'type'      => Controls_Manager::SELECT,
				'default'   => 'category',
				'options'   => [
					'category' => esc_html__( 'Category', 'orvian-addons' ),
					'post_tag' => esc_html__( 'Tag', 'orvian-addons' ),
				],
				'condition' => [
					'source'    => '',
					'post_type' => 'post',
				],
			]
		);

		$this->add_control(
			'taxonomy_portfolio',
			[
				'label'     => esc_html__( 'Taxonomy', 'orvian-addons' ),
				'type'      => Controls_Manager::SELECT,
				'default'   => Portfolio::TAXONOMY_TYPE,
				'options'   => [
					'portfolio_type'  => esc_html__( 'Type', 'orvian-addons' ),
					'portfolio_tag'   => esc_html__( 'Tag', 'orvian-addons' ),
					'portfolio_brand' => esc_html__( 'Brand', 'orvian-addons' ),
				],
				'condition' => [
					'source'    => '',
					'post_type' => 'portfolio',
				],
			]
		);

		$this->add_control(
			'select_category',
			[
				'label'       => esc_html__( 'Select Category', 'orvian-addons' ),
				'type'        => 'orvian-autocomplete',
				'source'      => 'category',
				'multiple'    => true,
				'sortable'    => true,
				'label_block' => true,
				'condition'   => [
					'source'        => 'custom',
					'post_type'     => 'post',
					'taxonomy_post' => 'category',
				],
			]
		);

		$this->add_control(
			'select_tag',
			[
				'label'       => esc_html__( 'Select Tag', 'orvian-addons' ),
				'type'        => 'orvian-autocomplete',
				'source'      => 'post_tag',
				'multiple'    => true,
				'sortable'    => true,
				'label_block' => true,
				'condition'   => [
					'source'        => 'custom',
					'post_type'     => 'post',
					'taxonomy_post' => 'post_tag',
				],
			]
		);

		$this->add_control(
			'select_type',
			[
				'label'       => esc_html__( 'Select Type', 'orvian-addons' ),
				'type'        => 'orvian-autocomplete',
				'source'      => Portfolio::TAXONOMY_TYPE,
				'multiple'    => true,
				'sortable'    => true,
				'label_block' => true,
				'condition'   => [
					'source'             => 'custom',
					'post_type'          => 'portfolio',
					'taxonomy_portfolio' => 'portfolio_type',
				],
			]
		);

		$this->add_control(
			'select_portfolio_tag',
			[
				'label'       => esc_html__( 'Select Tag', 'orvian-addons' ),
				'type'        => 'orvian-autocomplete',
				'source'      => Portfolio::TAXONOMY_TAG,
				'multiple'    => true,
				'sortable'    => true,
				'label_block' => true,
				'condition'   => [
					'source'             => 'custom',
					'post_type'          => 'portfolio',
					'taxonomy_portfolio' => 'portfolio_tag',
				],
			]
		);

		$this->add_control(
			'select_brand',
			[
				'label'       => esc_html__( 'Select Brand', 'orvian-addons' ),
				'type'        => 'orvian-autocomplete',
				'source'      => Portfolio::TAXONOMY_BRAND,
				'multiple'    => true,
				'sortable'    => true,
				'label_block' => true,
				'condition'   => [
					'source'             => 'custom',
					'post_type'          => 'portfolio',
					'taxonomy_portfolio' => 'portfolio_brand',
				],
			]
		);

		$this->add_control(
			'include_posts_post',
			[
				'label'       => esc_html__( 'Include Posts', 'orvian-addons' ),
				'type'        => 'orvian-autocomplete',
				'source'      => 'post',
				'multiple'    => true,
				'sortable'    => true,
				'label_block' => true,
				'condition'   => [
					'source'    => '',
					'post_type' => 'post',
				],
			]
		);

		$this->add_control(
			'include_posts_portfolio',
			[
				'label'       => esc_html__( 'Include Posts', 'orvian-addons' ),
				'type'        => 'orvian-autocomplete',
				'source'      => Portfolio::POST_TYPE,
				'multiple'    => true,
				'sortable'    => true,
				'label_block' => true,
				'condition'   => [
					'source'    => '',
					'post_type' => 'portfolio',
				],
			]
		);

		$this->add_control(
			'exclude_posts_post',
			[
				'label'       => esc_html__( 'Exclude Posts', 'orvian-addons' ),
				'type'        => 'orvian-autocomplete',
				'source'      => 'post',
				'multiple'    => true,
				'sortable'    => true,
				'label_block' => true,
				'condition'   => [
					'source'    => '',
					'post_type' => 'post',
				],
			]
		);

		$this->add_control(
			'exclude_posts_portfolio',
			[
				'label'       => esc_html__( 'Exclude Posts', 'orvian-addons' ),
				'type'        => 'orvian-autocomplete',
				'source'      => Portfolio::POST_TYPE,
				'multiple'    => true,
				'sortable'    => true,
				'label_block' => true,
				'condition'   => [
					'source'    => '',
					'post_type' => 'portfolio',
				],
			]
		);

		$this->add_control(
			'select_post_post',
			[
				'label'       => esc_html__( 'Select Post', 'orvian-addons' ),
				'type'        => 'orvian-autocomplete',
				'source'      => 'post',
				'multiple'    => false,
				'label_block' => true,
				'condition'   => [
					'source'    => 'related',
					'post_type' => 'post',
				],
			]
		);

		$this->add_control(
			'select_post_portfolio',
			[
				'label'       => esc_html__( 'Select Post', 'orvian-addons' ),
				'type'        => 'orvian-autocomplete',
				'source'      => Portfolio::POST_TYPE,
				'multiple'    => false,
				'label_block' => true,
				'condition'   => [
					'source'    => 'related',
					'post_type' => 'portfolio',
				],
			]
		);

		$this->add_control(
			'order_by',
			[
				'label'   => esc_html__( 'Order By', 'orvian-addons' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'date',
				'options' => [
					'date'       => esc_html__( 'Date', 'orvian-addons' ),
					'title'      => esc_html__( 'Title', 'orvian-addons' ),
					'rand'       => esc_html__( 'Random', 'orvian-addons' ),
					'menu_order' => esc_html__( 'Menu Order', 'orvian-addons' ),
					'post__in'   => esc_html__( 'Custom', 'orvian-addons' ),
				],
			]
		);

		$this->add_control(
			'order',
			[
				'label'   => esc_html__( 'Order', 'orvian-addons' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'DESC',
				'options' => [
					'ASC'  => esc_html__( 'Ascending', 'orvian-addons' ),
					'DESC' => esc_html__( 'Descending', 'orvian-addons' ),
				],
			]
		);

		$this->add_control(
			'show_custom_item',
			[
				'label'     => esc_html__( 'Show Custom Item', 'orvian-addons' ),
				'type'      => Controls_Manager::SWITCHER,
				'condition' => [
					'source' => '',
				],
			]
		);

		$this->add_control(
			'custom_item_position',
			[
				'label'     => esc_html__( 'Custom Item Position', 'orvian-addons' ),
				'type'      => Controls_Manager::NUMBER,
				'default'   => 4,
				'min'       => 1,
				'step'      => 1,
				'condition' => [
					'show_custom_item' => 'yes',
				],
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'grid_settings_section',
			[
				'label' => esc_html__( 'Grid Settings', 'orvian-addons' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_responsive_control(
			'post_columns',
			[
				'label'          => esc_html__( 'Columns', 'orvian-addons' ),
				'type'           => Controls_Manager::SELECT,
				'devices'        => [ 'desktop', 'tablet', 'mobile' ],
				'options'        => [
					'1' => esc_html__( '1 Column', 'orvian-addons' ),
					'2' => esc_html__( '2 Columns', 'orvian-addons' ),
					'3' => esc_html__( '3 Columns', 'orvian-addons' ),
					'4' => esc_html__( '4 Columns', 'orvian-addons' ),
					'5' => esc_html__( '5 Columns', 'orvian-addons' ),
				],
				'default'        => '3',
				'tablet_default' => '3',
				'mobile_default' => '1',
				'condition'      => [
					'post_type' => 'post',
				],
			]
		);

		$this->add_responsive_control(
			'portfolio_columns',
			[
				'label'          => esc_html__( 'Layout', 'orvian-addons' ),
				'type'           => Controls_Manager::SELECT,
				'devices'        => [ 'desktop', 'tablet', 'mobile' ],
				'options'        => [
					'1'       => esc_html__( '1 Column', 'orvian-addons' ),
					'2'       => esc_html__( '2 Columns', 'orvian-addons' ),
					'masonry' => esc_html__( 'Masonry', 'orvian-addons' ),
				],
				'default'        => '2',
				'tablet_default' => '2',
				'mobile_default' => '2',
				'condition'      => [
					'post_type' => 'portfolio',
				],
			]
		);

		$this->add_responsive_control(
			'column_gap',
			[
				'label'      => esc_html__( 'Column Gap', 'orvian-addons' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', 'em', 'rem', 'custom' ],
				'selectors'  => [
					'{{WRAPPER}} .posts-grid'         => 'column-gap: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}} .portfolio-columns'  => 'column-gap: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}} .portfolio--masonry' => 'column-gap: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'row_gap',
			[
				'label'      => esc_html__( 'Row Gap', 'orvian-addons' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', 'em', 'rem', 'custom' ],
				'selectors'  => [
					'{{WRAPPER}} .posts-grid'         => 'row-gap: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}} .portfolio-columns'  => 'row-gap: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}} .portfolio--masonry' => 'row-gap: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'portfolio_columns_spacing_top',
			[
				'label'      => esc_html__( 'Spacing Top', 'orvian-addons' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', 'em', 'rem', 'custom' ],
				'selectors'  => [
					'{{WRAPPER}} .orvian-archive-portfolio .columns-2' => 'margin-top: {{SIZE}}{{UNIT}};',
				],
				'condition'  => [
					'post_type' => 'portfolio',
				],
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'item_content_section',
			[
				'label'     => esc_html__( 'Custom Item Content', 'orvian-addons' ),
				'tab'       => Controls_Manager::TAB_CONTENT,
				'condition' => [
					'source'           => '',
					'show_custom_item' => 'yes',
				],
			]
		);

		$this->add_control(
			'title',
			[
				'label' => esc_html__( 'Title', 'orvian-addons' ),
				'type'  => Controls_Manager::TEXT,
			]
		);

		$this->add_control(
			'title_size',
			[
				'label'   => esc_html__( 'HTML Tag', 'orvian-addons' ),
				'type'    => Controls_Manager::SELECT,
				'options' => $this->get_text_class_options_with_tags(),
				'default' => 'text-heading-1',
			]
		);

		$this->add_control(
			'use_font_family_title',
			[
				'label'     => esc_html__( 'Use Font Family of Title', 'orvian-addons' ),
				'type'      => Controls_Manager::SWITCHER,
				'condition' => [
					'title_size!' => [ 'h1', 'h2', 'h3', 'h4', 'h5', 'h6' ],
				],
			]
		);

		$this->add_control(
			'hide_mobile_linebreaks',
			[
				'label'        => esc_html__( 'Disable line breaks on mobile', 'orvian-addons' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => esc_html__( 'Yes', 'orvian-addons' ),
				'label_off'    => esc_html__( 'No', 'orvian-addons' ),
				'return_value' => 'yes',
				'default'      => 'yes',
			]
		);

		$this->add_control(
			'content',
			[
				'label'     => esc_html__( 'Content', 'orvian-addons' ),
				'type'      => Controls_Manager::TEXTAREA,
				'separator' => 'before',
			]
		);

		$this->add_control(
			'hide_mobile_linebreaks_content',
			[
				'label'        => esc_html__( 'Disable line breaks on mobile', 'orvian-addons' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => esc_html__( 'Yes', 'orvian-addons' ),
				'label_off'    => esc_html__( 'No', 'orvian-addons' ),
				'return_value' => 'yes',
				'default'      => 'yes',
			]
		);

		$this->add_control(
			'button_heading',
			[
				'label'     => esc_html__( 'Button', 'orvian-addons' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->register_button_controls();

		$this->end_controls_section();

		$this->start_controls_section(
			'custom_item_style',
			[
				'label' => esc_html__( 'Custom Item', 'orvian-addons' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_responsive_control(
			'custom_item_aligment_vertical',
			[
				'label'     => esc_html__( 'Alignment Vertical', 'orvian-addons' ),
				'type'      => Controls_Manager::CHOOSE,
				'options'   => [
					'flex-start' => [
						'title' => esc_html__( 'Top', 'orvian-addons' ),
						'icon'  => 'eicon-v-align-top',
					],
					'center'     => [
						'title' => esc_html__( 'Middle', 'orvian-addons' ),
						'icon'  => 'eicon-v-align-middle',
					],
					'flex-end'   => [
						'title' => esc_html__( 'Bottom', 'orvian-addons' ),
						'icon'  => 'eicon-v-align-bottom',
					],
				],
				'selectors' => [
					'{{WRAPPER}} .article-card__custom' => 'align-self: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'custom_item_alignment_horizontal',
			[
				'label'     => esc_html__( 'Alignment Horizontal', 'orvian-addons' ),
				'type'      => Controls_Manager::CHOOSE,
				'options'   => [
					'flex-start' => [
						'title' => esc_html__( 'Left', 'orvian-addons' ),
						'icon'  => 'eicon-h-align-left',
					],
					'center'     => [
						'title' => esc_html__( 'Center', 'orvian-addons' ),
						'icon'  => 'eicon-h-align-center',
					],
					'flex-end'   => [
						'title' => esc_html__( 'Right', 'orvian-addons' ),
						'icon'  => 'eicon-h-align-right',
					],
				],
				'selectors' => [
					'{{WRAPPER}} .article-card__custom' => 'justify-content: {{VALUE}};',
				],
			]
		);

		$this->add_responsive_control(
			'custom_item_text_align',
			[
				'label'     => esc_html__( 'Text Align', 'orvian-addons' ),
				'type'      => Controls_Manager::CHOOSE,
				'options'   => [
					'left'   => [
						'title' => esc_html__( 'Left', 'orvian-addons' ),
						'icon'  => 'eicon-text-align-left',
					],
					'center' => [
						'title' => esc_html__( 'Center', 'orvian-addons' ),
						'icon'  => 'eicon-text-align-center',
					],
					'right'  => [
						'title' => esc_html__( 'Right', 'orvian-addons' ),
						'icon'  => 'eicon-text-align-right',
					],
				],
				'selectors' => [
					'{{WRAPPER}} .article-card__custom' => 'text-align: {{VALUE}};',
				],
			]
		);

		$this->add_responsive_control(
			'custom_item_padding',
			[
				'label'      => esc_html__( 'Padding', 'orvian-addons' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors'  => [
					'{{WRAPPER}} .article-card__custom' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'custom_item_title_heading',
			[
				'label'     => esc_html__( 'Title', 'orvian-addons' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'custom_item_title_typography',
				'selector' => '{{WRAPPER}} .article-card__custom-title',
			]
		);

		$this->add_control(
			'custom_item_title_color',
			[
				'label'     => esc_html__( 'Color', 'orvian-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .article-card__custom-title' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_responsive_control(
			'custom_item_title_spacing_bottom',
			[
				'label'     => esc_html__( 'Spacing Bottom', 'orvian-addons' ),
				'type'      => Controls_Manager::SLIDER,
				'range'     => [
					'px' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .article-card__custom-title' => 'margin-bottom: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'custom_item_content_heading',
			[
				'label'     => esc_html__( 'Content', 'orvian-addons' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'custom_item_content_typography',
				'selector' => '{{WRAPPER}} .article-card__custom-content',
			]
		);

		$this->add_control(
			'custom_item_content_color',
			[
				'label'     => esc_html__( 'Color', 'orvian-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .article-card__custom-content' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_responsive_control(
			'custom_item_content_spacing_bottom',
			[
				'label'      => esc_html__( 'Spacing Bottom', 'orvian-addons' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors'  => [
					'{{WRAPPER}} .article-card__custom-content' => 'margin-bottom: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'custom_item_button_heading',
			[
				'label'     => esc_html__( 'Button', 'orvian-addons' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->register_button_controls_style();

		$this->end_controls_section();
	}

	/**
	 * Get posts
	 *
	 * @param array $settings Widget settings.
	 * @return array
	 */
	protected function get_posts( array $settings ): array {
		$source = ! empty( $settings['source'] ) ? $settings['source'] : '';

		if ( 'related' === $source ) {
			return $this->get_related_posts( $settings );
		}

		return $this->get_default_posts( $settings );
	}

	/**
	 * Get custom posts
	 *
	 * @param array $settings Widget settings.
	 * @return array
	 */
	protected function get_default_posts( array $settings ): array {
		$post_type      = ! empty( $settings['post_type'] ) ? $settings['post_type'] : 'post';
		$posts_per_page = ! empty( $settings['posts_per_page'] ) ? absint( $settings['posts_per_page'] ) : 10;
		$order_by       = ! empty( $settings['order_by'] ) ? $settings['order_by'] : 'date';
		$order          = ! empty( $settings['order'] ) ? $settings['order'] : 'desc';

		$taxonomy = 'post' === $post_type
			? ( ! empty( $settings['taxonomy_post'] ) ? $settings['taxonomy_post'] : 'category' )
			: ( ! empty( $settings['taxonomy_portfolio'] ) ? $settings['taxonomy_portfolio'] : Portfolio::TAXONOMY_TYPE );

		$exclude_posts_key = 'post' === $post_type ? 'exclude_posts_post' : 'exclude_posts_portfolio';
		$exclude_ids       = [];
		if ( ! empty( $settings[ $exclude_posts_key ] ) ) {
			$exclude_ids = array_map( 'absint', explode( ',', $settings[ $exclude_posts_key ] ) );
		}

		$include_posts_key = 'post' === $post_type ? 'include_posts_post' : 'include_posts_portfolio';
		$include_ids       = [];
		if ( ! empty( $settings[ $include_posts_key ] ) ) {
			$include_ids = array_map( 'absint', explode( ',', $settings[ $include_posts_key ] ) );
		}

		$args = [
			'post_type'              => $post_type,
			'post_status'            => 'publish',
			'posts_per_page'         => $posts_per_page,
			'order'                  => $order,
			'orderby'                => $order_by,
			'post__not_in'           => $exclude_ids,
			'no_found_rows'          => true,
			'update_post_term_cache' => false,
			'update_post_meta_cache' => false,
			'ignore_sticky_posts'    => true,
		];

		if ( ! empty( $include_ids ) ) {
			$args['post__in'] = $include_ids;
		}

		$select_term_key = '';
		if ( 'post' === $post_type ) {
			$tax = ! empty( $settings['taxonomy_post'] ) ? $settings['taxonomy_post'] : 'category';
			if ( 'category' === $tax ) {
				$select_term_key = 'select_category';
				$taxonomy        = 'category';
			} elseif ( 'post_tag' === $tax ) {
				$select_term_key = 'select_tag';
				$taxonomy        = 'post_tag';
			}
		} else {
			$tax = ! empty( $settings['taxonomy_portfolio'] ) ? $settings['taxonomy_portfolio'] : Portfolio::TAXONOMY_TYPE;
			if ( 'portfolio_type' === $tax ) {
				$select_term_key = 'select_type';
				$taxonomy        = Portfolio::TAXONOMY_TYPE;
			} elseif ( 'portfolio_tag' === $tax ) {
				$select_term_key = 'select_portfolio_tag';
				$taxonomy        = Portfolio::TAXONOMY_TAG;
			} elseif ( 'portfolio_brand' === $tax ) {
				$select_term_key = 'select_brand';
				$taxonomy        = Portfolio::TAXONOMY_BRAND;
			}
		}

		if ( $select_term_key && ! empty( $settings[ $select_term_key ] ) ) {
			$term_slugs = array_filter( array_map( 'sanitize_text_field', explode( ',', $settings[ $select_term_key ] ) ) );

			if ( ! empty( $term_slugs ) ) {
				$terms = get_terms(
					[
						'taxonomy' => $taxonomy,
						'slug'     => $term_slugs,
						'fields'   => 'ids',
					]
				);

				if ( ! empty( $terms ) && ! is_wp_error( $terms ) ) {
					// phpcs:ignore
					$args['tax_query'] = [
						[
							'taxonomy' => $taxonomy,
							'terms'    => $terms,
							'field'    => 'term_id',
						],
					];
				}
			}
		}

		$query = new \WP_Query( $args );

		return $query->posts ?? [];
	}

	/**
	 * Get related posts
	 *
	 * @param array $settings Widget settings.
	 * @return array
	 */
	protected function get_related_posts( array $settings ): array {
		$post_type       = ! empty( $settings['post_type'] ) ? $settings['post_type'] : 'post';
		$posts_per_page  = ! empty( $settings['posts_per_page'] ) ? absint( $settings['posts_per_page'] ) : 10;
		$select_post_key = 'post' === $post_type ? 'select_post_post' : 'select_post_portfolio';
		$anchor_post_id  = ! empty( $settings[ $select_post_key ] )
			? absint( $settings[ $select_post_key ] )
			: get_the_ID();

		if ( ! $anchor_post_id ) {
			return [];
		}

		$args = [
			'post_type'              => $post_type,
			'post_status'            => 'publish',
			'posts_per_page'         => $posts_per_page,
			'orderby'                => 'rand',
			'post__not_in'           => [ $anchor_post_id ],
			'no_found_rows'          => true,
			'update_post_term_cache' => false,
			'update_post_meta_cache' => false,
			'ignore_sticky_posts'    => true,
		];

		if ( 'portfolio' === $post_type && post_type_exists( Portfolio::POST_TYPE ) ) {
			$terms = get_the_terms( $anchor_post_id, Portfolio::TAXONOMY_TYPE );
			if ( $terms && ! is_wp_error( $terms ) ) {
				$term_ids = wp_list_pluck( $terms, 'term_id' );
				// phpcs:ignore
				$args['tax_query'] = [
					[
						'taxonomy' => Portfolio::TAXONOMY_TYPE,
						'terms'    => $term_ids,
						'field'    => 'term_id',
					],
				];
			}
		} else {
			$category_ids = wp_get_post_categories( $anchor_post_id, [ 'fields' => 'ids' ] );

			if ( ! empty( $category_ids ) ) {
				$args['category__in'] = $category_ids;
			}
		}

		$query = new \WP_Query( $args );

		return $query->posts ?? [];
	}

	/**
	 * Get grid classes
	 *
	 * @param array $settings Widget settings.
	 * @return string
	 */
	protected function get_grid_classes( array $settings ): string {
		$post_type = ! empty( $settings['post_type'] ) ? $settings['post_type'] : 'post';

		if ( 'portfolio' === $post_type ) {
			$columns_desktop = ! empty( $settings['portfolio_columns'] ) ? $settings['portfolio_columns'] : '2';
			$columns_tablet  = ! empty( $settings['portfolio_columns_tablet'] ) ? $settings['portfolio_columns_tablet'] : '2';
			$columns_mobile  = ! empty( $settings['portfolio_columns_mobile'] ) ? $settings['portfolio_columns_mobile'] : '1';
		} else {
			$columns_desktop = ! empty( $settings['post_columns'] ) ? $settings['post_columns'] : '3';
			$columns_tablet  = ! empty( $settings['post_columns_tablet'] ) ? $settings['post_columns_tablet'] : '3';
			$columns_mobile  = ! empty( $settings['post_columns_mobile'] ) ? $settings['post_columns_mobile'] : '1';
		}

		if ( 'masonry' === $settings['portfolio_columns'] ) {
			return 'grid';
		}

		return "grid grid-cols-{$columns_mobile} md:grid-cols-{$columns_tablet} lg:grid-cols-{$columns_desktop}";
	}

	/**
	 * Render widget output.
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();
		$posts    = $this->get_posts( $settings );

		$show_custom_item = ! empty( $settings['show_custom_item'] ) && 'yes' === $settings['show_custom_item'];

		if ( $show_custom_item ) {
			$position                    = ! empty( $settings['custom_item_position'] ) ? absint( $settings['custom_item_position'] ) : 4;
			$custom_item                 = new \stdClass();
			$custom_item->is_custom_item = true;
			array_splice( $posts, max( 0, $position - 1 ), 0, [ $custom_item ] );
		}

		if ( empty( $posts ) ) {
			return;
		}

		$post_type           = $settings['post_type'] ?? 'post';
		$total               = count( $posts );
		$grid_classes        = $this->get_grid_classes( $settings );
		$gap_classes         = 'portfolio' === $post_type ? 'gap-2' : 'gap-x-2 gap-y-40px';
		$is_portfolio_2_cols = 'portfolio' === $post_type
			&& ! empty( $settings['portfolio_columns'] )
			&& '2' === $settings['portfolio_columns'] && 1 < $total;

		$first_col = $is_portfolio_2_cols ? intval( ceil( $total / 2 ) ) : 0;
		?>
		<div class="posts-grid posts-grid--elementor orvian-archive-<?php echo esc_attr( $post_type ); ?> <?php echo esc_attr( $grid_classes ); ?> <?php echo esc_attr( $gap_classes ); ?>">
			<?php if ( $is_portfolio_2_cols ) : ?>
				<div class="portfolio-columns columns-1 flex flex-col gap-2">
			<?php endif; ?>

			<?php
			foreach ( $posts as $index => $post ) :
				$current = $index + 1;
				$group   = floor( $index / 3 );
				?>
				<?php if ( $is_portfolio_2_cols && $index === $first_col ) : ?>
					</div>
					<div class="portfolio-columns columns-2 flex flex-col gap-2">
				<?php endif; ?>

				<?php if ( 'portfolio' === $post_type && 'masonry' === $settings['portfolio_columns'] && ( 1 === $current || ( $current - 1 ) % 3 === 0 ) ) : ?>
					<div class="portfolio--masonry gap-2 <?php echo 0 === $group % 2 ? 'even' : 'odd'; ?>">
				<?php endif; ?>

				<?php
				if ( isset( $post->is_custom_item ) ) {
					$this->render_custom_item( $settings );
				} else {
					setup_postdata( $GLOBALS['post'] = $post ); // phpcs:ignore
					get_template_part( 'template-parts/content', $post_type );
				}
				?>

				<?php if ( 'portfolio' === $post_type && 'masonry' === $settings['portfolio_columns'] && ( 0 === $current % 3 || $current === $total ) ) : ?>
					</div>
				<?php endif; ?>
			<?php endforeach; ?>

			<?php if ( $is_portfolio_2_cols ) : ?>
				</div>
			<?php endif; ?>
			<?php wp_reset_postdata(); ?>
		</div>
		<?php
	}

	/**
	 * Render custom item
	 *
	 * @param array $settings Widget settings.
	 * @return void
	 */
	protected function render_custom_item( array $settings ) {
		$this->add_render_attribute( 'title', 'class', [ 'article-card__custom-title', 'my-0', 'font-semibold', 'uppercase' ] );
		$this->add_render_attribute( 'content', 'class', [ 'article-card__custom-content', 'text-body-3', 'font-medium' ] );

		if ( 'yes' === $settings['use_font_family_title'] ) {
			$this->add_render_attribute( 'title', 'class', 'font-heading text-heading tracking-heading' );
		}

		if ( 'yes' === $settings['hide_mobile_linebreaks'] ) {
			$this->add_render_attribute( 'title', 'class', 'sm:no-br' );
		}

		if ( 'yes' === $settings['hide_mobile_linebreaks_content'] ) {
			$this->add_render_attribute( 'content', 'class', 'sm:no-br' );
		}

		$title_tag = $this->resolve_text_tag( $settings['title_size'], 'title' );
		?>
		<article class="article-card orvian-fadeinup relative overflow-hidden rounded-xl article-card__custom inline-flex flex-col items-center justify-center text-center p-4">
			<?php if ( ! empty( $settings['title'] ) ) : ?>
				<<?php echo tag_escape( $title_tag ); ?> <?php $this->print_render_attribute_string( 'title' ); ?>>
					<?php echo wp_kses_post( do_shortcode( nl2br( $settings['title'] ) ) ); ?>
				</<?php echo tag_escape( $title_tag ); ?>>
			<?php endif; ?>

			<?php if ( ! empty( $settings['content'] ) ) : ?>
				<div <?php $this->print_render_attribute_string( 'content' ); ?>>
					<?php echo wp_kses_post( nl2br( $settings['content'] ) ); ?>
				</div>
			<?php endif; ?>

			<?php $this->button_render( $settings ); ?>
		</article>
		<?php
	}
}
