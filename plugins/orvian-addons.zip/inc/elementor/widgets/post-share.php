<?php
/**
 * Post Share Widget
 *
 * @package OrvianAddons
 */

namespace OrvianAddons\Elementor\Widgets;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use OrvianAddons\Elementor\Elementor as OrvianAddons_Elementor;
use OrvianAddons\Admin\Portfolio;

/**
 * Post Share Widget Class
 */
class Post_Share extends Widget_Base {

	/**
	 * Get widget name
	 *
	 * @return string
	 */
	public function get_name() {
		return 'orvian-post-share';
	}

	/**
	 * Get widget title
	 *
	 * @return string
	 */
	public function get_title() {
		return esc_html__( 'Post Share', 'orvian-addons' );
	}

	/**
	 * Get widget icon
	 *
	 * @return string
	 */
	public function get_icon() {
		return 'eicon-share ' . OrvianAddons_Elementor::CLASS_WIDGET;
	}

	/**
	 * Get widget categories
	 *
	 * @return array
	 */
	public function get_categories() {
		return [ OrvianAddons_Elementor::CATEGORY ];
	}

	/**
	 * Get widget keywords
	 *
	 * @return array
	 */
	public function get_keywords() {
		return [ 'orvian', 'post', 'share', 'social' ];
	}

	/**
	 * Register widget controls
	 */
	protected function register_controls() {
		$this->start_controls_section(
			'content_section',
			[
				'label' => esc_html__( 'Post Share', 'orvian-addons' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'post_type',
			[
				'label'   => esc_html__( 'Post Type', 'orvian-addons' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'post',
				'options' => [
					'post'      => esc_html__( 'Post', 'orvian-addons' ),
					'portfolio' => esc_html__( 'Portfolio', 'orvian-addons' ),
				],
			]
		);

		$this->add_control(
			'post_id_post',
			[
				'label'       => esc_html__( 'Post ID', 'orvian-addons' ),
				'type'        => 'orvian-autocomplete',
				'source'      => 'post',
				'multiple'    => false,
				'label_block' => true,
				'condition'   => [
					'post_type' => 'post',
				],
			]
		);

		$this->add_control(
			'post_id_portfolio',
			[
				'label'       => esc_html__( 'Post ID', 'orvian-addons' ),
				'type'        => 'orvian-autocomplete',
				'source'      => Portfolio::POST_TYPE,
				'multiple'    => false,
				'label_block' => true,
				'condition'   => [
					'post_type' => 'portfolio',
				],
			]
		);

		$this->add_control(
			'networks',
			[
				'label'    => esc_html__( 'Networks', 'orvian-addons' ),
				'type'     => Controls_Manager::SELECT2,
				'multiple' => true,
				'default'  => [ 'facebook', 'instagram', 'x', 'linkedin' ],
				'options'  => [
					'facebook'  => esc_html__( 'Facebook', 'orvian-addons' ),
					'x'         => esc_html__( 'X (Twitter)', 'orvian-addons' ),
					'linkedin'  => esc_html__( 'LinkedIn', 'orvian-addons' ),
					'pinterest' => esc_html__( 'Pinterest', 'orvian-addons' ),
					'whatsapp'  => esc_html__( 'WhatsApp', 'orvian-addons' ),
					'telegram'  => esc_html__( 'Telegram', 'orvian-addons' ),
					'email'     => esc_html__( 'Email', 'orvian-addons' ),
					'reddit'    => esc_html__( 'Reddit', 'orvian-addons' ),
					'pocket'    => esc_html__( 'Pocket', 'orvian-addons' ),
					'instagram' => esc_html__( 'Instagram', 'orvian-addons' ),
				],
			]
		);

		$this->add_control(
			'show_label',
			[
				'label'   => esc_html__( 'Show Label', 'orvian-addons' ),
				'type'    => Controls_Manager::SWITCHER,
				'default' => 'yes',
			]
		);

		$this->add_control(
			'label_text',
			[
				'label'     => esc_html__( 'Label Text', 'orvian-addons' ),
				'type'      => Controls_Manager::TEXT,
				'default'   => esc_html__( 'Share this post:', 'orvian-addons' ),
				'condition' => [
					'show_label' => 'yes',
				],
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'style_section',
			[
				'label' => esc_html__( 'Style', 'orvian-addons' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_responsive_control(
			'alignment',
			[
				'label'     => esc_html__( 'Alignment', 'orvian-addons' ),
				'type'      => Controls_Manager::CHOOSE,
				'options'   => [
					'left'          => [
						'title' => esc_html__( 'Left', 'orvian-addons' ),
						'icon'  => 'eicon-text-align-left',
					],
					'center'        => [
						'title' => esc_html__( 'Center', 'orvian-addons' ),
						'icon'  => 'eicon-text-align-center',
					],
					'right'         => [
						'title' => esc_html__( 'Right', 'orvian-addons' ),
						'icon'  => 'eicon-text-align-right',
					],
					'space-between' => [
						'title' => esc_html__( 'Space Between', 'orvian-addons' ),
						'icon'  => 'eicon-text-align-justify',
					],
				],
				'default'   => 'space-between',
				'selectors' => [
					'{{WRAPPER}} .orvian-post-share' => 'justify-content: {{VALUE}};',
				],
			]
		);

		$this->start_controls_tabs( 'icon_tabs' );

		$this->start_controls_tab(
			'tab_icon_normal',
			[
				'label' => esc_html__( 'Normal', 'orvian-addons' ),
			]
		);

		$this->add_control(
			'icon_color',
			[
				'label'     => esc_html__( 'Color', 'orvian-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .orvian-post-share__link' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'icon_background_color',
			[
				'label'     => esc_html__( 'Background Color', 'orvian-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .orvian-post-share__link' => 'background-color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'icon_border_color',
			[
				'label'     => esc_html__( 'Border Color', 'orvian-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .orvian-post-share__link' => 'border-color: {{VALUE}};',
				],
			]
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			'tab_icon_hover',
			[
				'label' => esc_html__( 'Hover', 'orvian-addons' ),
			]
		);

		$this->add_control(
			'icon_color_hover',
			[
				'label'     => esc_html__( 'Color', 'orvian-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .orvian-post-share__link:hover' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'icon_background_color_hover',
			[
				'label'     => esc_html__( 'Background Color', 'orvian-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .orvian-post-share__link:hover' => 'background-color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'icon_border_color_hover',
			[
				'label'     => esc_html__( 'Border Color', 'orvian-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .orvian-post-share__link:hover' => 'border-color: {{VALUE}};',
				],
			]
		);

		$this->end_controls_tab();

		$this->end_controls_tabs();
	}

	/**
	 * Render widget output
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();

		if ( ! class_exists( '\OrvianAddons\Helper' ) || ! method_exists( '\OrvianAddons\Helper', 'get_share_urls' ) ) {
			return;
		}

		$networks = ! empty( $settings['networks'] ) ? $settings['networks'] : [ 'facebook', 'instagram', 'x', 'linkedin' ];

		$post_type   = ! empty( $settings['post_type'] ) ? $settings['post_type'] : 'post';
		$post_id_key = 'post' === $post_type ? 'post_id_post' : 'post_id_portfolio';
		$post_id     = ! empty( $settings[ $post_id_key ] ) ? absint( $settings[ $post_id_key ] ) : 0;

		if ( empty( $post_id ) ) {
			$post_id = get_the_ID();
		}

		if ( empty( $post_id ) ) {
			return;
		}

		$share_urls = \OrvianAddons\Helper::get_share_urls( $networks, $post_id );

		if ( empty( $share_urls ) ) {
			return;
		}

		$this->add_render_attribute( 'wrapper', 'class', 'orvian-post-share flex items-center gap-2' );
		?>
		<div <?php $this->print_render_attribute_string( 'wrapper' ); ?>>
			<?php if ( 'yes' === $settings['show_label'] ) : ?>
				<span class="orvian-post-share__heading font-xl font-medium text-heading">
					<?php echo esc_html( $settings['label_text'] ); ?>
				</span>
			<?php endif; ?>

			<span class="orvian-post-share__list flex flex-wrap gap-8px">
				<?php foreach ( $share_urls as $network => $url ) : ?>
					<?php
					$aria_label = sprintf(
						/* translators: %s: Social network name. */
						esc_html__( 'Share on %s', 'orvian-addons' ),
						ucfirst( $network )
					);
					?>
					<a
						href="<?php echo esc_url( $url ); ?>"
						class="orvian-post-share__link orvian-post-share__link--<?php echo esc_attr( $network ); ?> button button-icon button-icon--border"
						target="_blank"
						rel="noopener noreferrer nofollow"
						aria-label="<?php echo esc_attr( $aria_label ); ?>"
					>
						<?php echo \OrvianAddons\Helper::get_svg( $network, 'social' ); // phpcs:ignore ?>
					</a>
				<?php endforeach; ?>
			</span>
		</div>
		<?php
	}
}
