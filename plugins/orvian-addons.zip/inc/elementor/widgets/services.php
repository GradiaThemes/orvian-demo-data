<?php
/**
 * Services Widget
 *
 * @package OrvianAddons
 */

namespace OrvianAddons\Elementor\Widgets;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Repeater;
use Elementor\Group_Control_Image_Size;
use Elementor\Icons_Manager;
use Elementor\Group_Control_Background;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;
use OrvianAddons\Elementor\Elementor as OrvianAddons_Elementor;

/**
 * Services Widget Class
 */
class Services extends Widget_Base {

	use Base\Text_Class;
	use Base\Button_Base;

	/**
	 * Get widget name
	 *
	 * @return string
	 */
	public function get_name() {
		return 'orvian-services';
	}

	/**
	 * Get widget title
	 *
	 * @return string
	 */
	public function get_title() {
		return esc_html__( 'Services', 'orvian-addons' );
	}

	/**
	 * Get widget icon
	 *
	 * @return string
	 */
	public function get_icon() {
		return 'eicon-site-identity ' . OrvianAddons_Elementor::CLASS_WIDGET;
	}

	/**
	 * Get widget categories
	 *
	 * @return array
	 */
	public function get_categories() {
		return [ OrvianAddons_Elementor::CATEGORY ];
	}

	/**
	 * Get widget keywords
	 *
	 * @return array
	 */
	public function get_keywords() {
		return [ 'orvian', 'services', 'portfolio', 'content' ];
	}

	/**
	 * Register heading widget controls.
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @access protected
	 */
	protected function register_controls() {
		$this->start_controls_section(
			'services_section',
			[
				'label' => esc_html__( 'Services', 'orvian-addons' ),
			]
		);

		$this->add_control(
			'tags_header',
			[
				'label' => esc_html__( 'Tags', 'orvian-addons' ),
				'type'  => 'orvian-tags',
			]
		);

		$this->add_control(
			'tags_header_mobile',
			[
				'label' => esc_html__( 'Tags on Mobile', 'orvian-addons' ),
				'type'  => 'orvian-tags',
			]
		);

		$repeater = new Repeater();

		$repeater->add_control(
			'image',
			[
				'label'   => esc_html__( 'Image', 'orvian-addons' ),
				'type'    => Controls_Manager::MEDIA,
				'default' => [
					'url' => \Elementor\Utils::get_placeholder_image_src(),
				],
			]
		);

		$repeater->add_control(
			'subtitle',
			[
				'label' => esc_html__( 'Subtitle', 'orvian-addons' ),
				'type'  => Controls_Manager::TEXT,
			]
		);

		$repeater->add_control(
			'title',
			[
				'label' => esc_html__( 'Title', 'orvian-addons' ),
				'type'  => Controls_Manager::TEXT,
			]
		);

		$repeater->add_control(
			'tags',
			[
				'label' => esc_html__( 'Tags', 'orvian-addons' ),
				'type'  => 'orvian-tags',
			]
		);

		$repeater->add_control(
			'description',
			[
				'label' => esc_html__( 'Description', 'orvian-addons' ),
				'type'  => Controls_Manager::WYSIWYG,
			]
		);

		$repeater->add_control(
			'button_text',
			[
				'label'   => esc_html__( 'Button Text', 'orvian-addons' ),
				'type'    => Controls_Manager::TEXT,
				'default' => esc_html__( 'Lets Talk', 'orvian-addons' ),
			]
		);

		$repeater->add_control(
			'button_link',
			[
				'label' => esc_html__( 'Link', 'orvian-addons' ),
				'type'  => Controls_Manager::URL,
			]
		);

		$this->add_control(
			'services',
			[
				'label'       => esc_html__( 'Services', 'orvian-addons' ),
				'type'        => Controls_Manager::REPEATER,
				'fields'      => $repeater->get_controls(),
				'default'     => [
					[
						'subtitle'    => esc_html__( 'My Services', 'orvian-addons' ),
						'title'       => esc_html__( 'Service 1', 'orvian-addons' ),
						'description' => esc_html__( 'Description 1', 'orvian-addons' ),
					],
					[
						'subtitle'    => esc_html__( 'My Services', 'orvian-addons' ),
						'title'       => esc_html__( 'Service 2', 'orvian-addons' ),
						'description' => esc_html__( 'Description 2', 'orvian-addons' ),
					],
				],
				'title_field' => '{{{ title }}}',
			]
		);

		$this->add_control(
			'thumbnail_heading',
			[
				'label'     => esc_html__( 'Thumbnail', 'orvian-addons' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_responsive_control(
			'thumbnail_aspect_ratio',
			[
				'label'       => esc_html__( 'Aspect Ratio (width/height)', 'orvian-addons' ),
				'type'        => Controls_Manager::TEXT,
				'placeholder' => '16/9',
				'selectors'   => [
					'{{WRAPPER}} .orvian-services__image img' => 'aspect-ratio: {{VALUE}};',
				],
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'title_section',
			[
				'label' => esc_html__( 'Title', 'orvian-addons' ),
			]
		);

		$this->add_control(
			'title_type',
			[
				'label'   => esc_html__( 'Type', 'orvian-addons' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'icon',
				'options' => [
					'icon'  => esc_html__( 'Icon', 'orvian-addons' ),
					'image' => esc_html__( 'Image', 'orvian-addons' ),
					'none'  => esc_html__( 'None', 'orvian-addons' ),
				],
			]
		);

		$this->add_control(
			'title_icon',
			[
				'label'     => esc_html__( 'Icon', 'orvian-addons' ),
				'type'      => Controls_Manager::ICONS,
				'condition' => [
					'title_type' => 'icon',
				],
			]
		);

		$this->add_control(
			'title_image',
			[
				'label'     => esc_html__( 'Image', 'orvian-addons' ),
				'type'      => Controls_Manager::MEDIA,
				'condition' => [
					'title_type' => 'image',
				],
			]
		);

		$this->add_control(
			'speed',
			[
				'label'              => esc_html__( 'Speed', 'orvian-addons' ),
				'type'               => Controls_Manager::NUMBER,
				'default'            => '0.2',
				'min'                => 0.1,
				'max'                => 0.9,
				'step'               => 0.1,
				'frontend_available' => true,
			]
		);

		$this->add_control(
			'hover_pause',
			[
				'label'     => esc_html__( 'Hover stop', 'orvian-addons' ),
				'type'      => Controls_Manager::SWITCHER,
				'label_on'  => esc_html__( 'Yes', 'orvian-addons' ),
				'label_off' => esc_html__( 'No', 'orvian-addons' ),
			]
		);

		$this->add_control(
			'title_size',
			[
				'label'   => esc_html__( 'HTML Tag', 'orvian-addons' ),
				'type'    => Controls_Manager::SELECT,
				'options' => $this->get_text_class_options_with_tags(),
				'default' => 'h3',
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'button_section',
			[
				'label' => esc_html__( 'Button', 'orvian-addons' ),
			]
		);

		$this->add_control(
			'button_style',
			[
				'label'   => esc_html__( 'Button Style', 'orvian-addons' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'primary',
				'options' => [
					'default' => esc_html__( 'Default', 'orvian-addons' ),
					'primary' => esc_html__( 'Primary', 'orvian-addons' ),
					'icon'    => esc_html__( 'Icon', 'orvian-addons' ),
				],
			]
		);

		$this->add_control(
			'button_show_icon',
			[
				'label'     => esc_html__( 'Show Icon', 'orvian-addons' ),
				'type'      => Controls_Manager::SWITCHER,
				'default'   => 'yes',
				'condition' => [
					'button_style' => 'primary',
				],
			]
		);

		$this->add_control(
			'button_primary_icon',
			[
				'label'       => esc_html__( 'Icon', 'orvian-addons' ),
				'type'        => Controls_Manager::ICONS,
				'condition'   => [
					'button_style' => 'primary',
					'show_icon'    => 'yes',
				],
				'label_block' => true,
			]
		);

		$this->add_control(
			'button_icon',
			[
				'label'       => esc_html__( 'Icon', 'orvian-addons' ),
				'type'        => Controls_Manager::ICONS,
				'default'     => [
					'value'   => 'fa fa-star',
					'library' => 'fa-solid',
				],
				'condition'   => [
					'button_style' => 'icon',
				],
				'label_block' => true,
			]
		);

		$this->add_control(
			'button_size',
			[
				'label'     => esc_html__( 'Size', 'orvian-addons' ),
				'type'      => Controls_Manager::SELECT,
				'default'   => 'normal',
				'options'   => [
					'normal' => esc_html__( 'Normal', 'orvian-addons' ),
					'small'  => esc_html__( 'Small', 'orvian-addons' ),
				],
				'condition' => [
					'button_style' => 'primary',
				],
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'services_header_section_style',
			[
				'label' => esc_html__( 'Header', 'orvian-addons' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'line_heading',
			[
				'label' => esc_html__( 'Line', 'orvian-addons' ),
				'type'  => Controls_Manager::HEADING,
			]
		);

		$this->add_control(
			'line_color',
			[
				'label'     => esc_html__( 'Color', 'orvian-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .orvian-services__line span' => 'background-color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'line_color_active',
			[
				'label'     => esc_html__( 'Color First Line', 'orvian-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .orvian-services__line span[data-active="true"]' => 'background-color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'tags_header_heading',
			[
				'label'     => esc_html__( 'Tags', 'orvian-addons' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->start_controls_tabs(
			'tags_header_style_tabs'
		);

			$this->start_controls_tab(
				'tags_header_style_normal_tab',
				[
					'label' => esc_html__( 'Normal', 'orvian-addons' ),
				]
			);

				$this->add_control(
					'tags_header_color',
					[
						'label'     => esc_html__( 'Color', 'orvian-addons' ),
						'type'      => Controls_Manager::COLOR,
						'selectors' => [
							'{{WRAPPER}} .orvian-services__tags-header .orvian-services__tag' => 'color: {{VALUE}};',
						],
					]
				);

				$this->add_control(
					'tags_header_background_color',
					[
						'label'     => esc_html__( 'Background Color', 'orvian-addons' ),
						'type'      => Controls_Manager::COLOR,
						'selectors' => [
							'{{WRAPPER}} .orvian-services__tags-header .orvian-services__tag' => 'background-color: {{VALUE}};',
						],
					]
				);

			$this->end_controls_tab();

			$this->start_controls_tab(
				'tags_header_style_hover_tab',
				[
					'label' => esc_html__( 'Hover', 'orvian-addons' ),
				]
			);

				$this->add_control(
					'tags_header_color_hover',
					[
						'label'     => esc_html__( 'Color', 'orvian-addons' ),
						'type'      => Controls_Manager::COLOR,
						'selectors' => [
							'{{WRAPPER}} .orvian-services__tags-header .orvian-services__tag:hover' => 'color: {{VALUE}};',
						],
					]
				);

				$this->add_control(
					'tags_header_background_color_hover',
					[
						'label'     => esc_html__( 'Background Color', 'orvian-addons' ),
						'type'      => Controls_Manager::COLOR,
						'selectors' => [
							'{{WRAPPER}} .orvian-services__tags-header .orvian-services__tag:hover' => 'background-color: {{VALUE}};',
						],
					]
				);

			$this->end_controls_tab();

		$this->end_controls_tabs();

		$this->end_controls_section();

		$this->start_controls_section(
			'services_content_style',
			[
				'label' => esc_html__( 'Services Content', 'orvian-addons' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_responsive_control(
			'image_border_radius',
			[
				'label'      => esc_html__( 'Image Border Radius', 'orvian-addons' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem' ],
				'selectors'  => [
					'{{WRAPPER}} .orvian-services__image img' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'subtitle_color',
			[
				'label'     => esc_html__( 'Subtitle Color', 'orvian-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .orvian-services__subtitle .text' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'subtitle_text_color',
			[
				'label'     => esc_html__( 'Text Color', 'orvian-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .orvian-services__subtitle .text span' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'subtitle_line_color',
			[
				'label'     => esc_html__( 'Line Color', 'orvian-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .orvian-services__subtitle::after' => 'background-color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'title_color',
			[
				'label'     => esc_html__( 'Title Color', 'orvian-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .orvian-services__marquee .orvian-services__title' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_control(
			'description_color',
			[
				'label'     => esc_html__( 'Description Color', 'orvian-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .orvian-services__description' => 'color: {{VALUE}};',
				],
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'services_title_style',
			[
				'label' => esc_html__( 'Services Title Marquee', 'orvian-addons' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_responsive_control(
			'marquee_gap',
			[
				'label'      => esc_html__( 'Gap', 'orvian-addons' ),
				'type'       => Controls_Manager::SLIDER,
				'range'      => [
					'px' => [
						'min' => 0,
						'max' => 200,
					],
				],
				'size_units' => [ 'px' ],
				'selectors'  => [
					'{{WRAPPER}} .orvian-services__marquee .orvian-marquee__items' => 'gap: {{SIZE}}{{UNIT}}; margin-right: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'marquee_image_heading',
			[
				'label'     => esc_html__( 'Image', 'orvian-addons' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_responsive_control(
			'marquee_image_width',
			[
				'label'      => esc_html__( 'Width', 'orvian-addons' ),
				'type'       => Controls_Manager::SLIDER,
				'range'      => [
					'px' => [
						'min' => 0,
						'max' => 200,
					],
				],
				'size_units' => [ 'px' ],
				'selectors'  => [
					'{{WRAPPER}} .orvian-services__marquee .orvian-marquee__image' => 'width: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'marquee_image_border_radius',
			[
				'label'      => esc_html__( 'Border Radius', 'orvian-addons' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors'  => [
					'{{WRAPPER}} .orvian-services__marquee .orvian-marquee__image' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'marquee_icon_heading',
			[
				'label'     => esc_html__( 'Icon', 'orvian-addons' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_responsive_control(
			'marquee_icon_size',
			[
				'label'      => esc_html__( 'Size', 'orvian-addons' ),
				'type'       => Controls_Manager::SLIDER,
				'range'      => [
					'px' => [
						'min' => 0,
						'max' => 200,
					],
				],
				'size_units' => [ 'px' ],
				'selectors'  => [
					'{{WRAPPER}} .orvian-services__marquee .orvian-marquee__icon' => 'font-size: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'marquee_icon_color',
			[
				'label'     => esc_html__( 'Color', 'orvian-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .orvian-services__marquee .orvian-marquee__icon' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_responsive_control(
			'marquee_spacing',
			[
				'label'      => esc_html__( 'Spacing', 'orvian-addons' ),
				'type'       => Controls_Manager::SLIDER,
				'range'      => [
					'px' => [
						'min' => 0,
						'max' => 200,
					],
				],
				'size_units' => [ 'px' ],
				'selectors'  => [
					'{{WRAPPER}} .orvian-services__marquee .orvian-marquee__item' => 'gap: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'services_tags_style',
			[
				'label' => esc_html__( 'Services Tags', 'orvian-addons' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'tags_color',
			[
				'label'     => esc_html__( 'Color', 'orvian-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .orvian-services__tags .orvian-services__tag' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'tags_background_color',
			[
				'label'     => esc_html__( 'Background Color', 'orvian-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .orvian-services__tags .orvian-services__tag' => 'background-color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'tags_color_hover',
			[
				'label'     => esc_html__( 'Color Hover', 'orvian-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .orvian-services__tags .orvian-services__tag:hover' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'tags_background_color_hover',
			[
				'label'     => esc_html__( 'Background Color Hover', 'orvian-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .orvian-services__tags .orvian-services__tag:hover' => 'background-color: {{VALUE}};',
				],
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'button_section_style',
			[
				'label' => esc_html__( 'Button', 'orvian-addons' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->register_button_controls_style();

		$this->end_controls_section();
	}

	/**
	 * Render heading widget output on the frontend.
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @access protected
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();

		if ( empty( $settings['services'] ) ) {
			return;
		}

		$services_count = count( $settings['services'] );

		$this->add_render_attribute( 'line_wrapper', 'class', [ 'orvian-services__line', 'flex', 'flex-col', 'gap-2' ] );
		$this->add_render_attribute( 'tags_header_wrapper', 'class', [ 'orvian-services__tags-header', 'orvian-tags', 'ms-auto' ] );
		$this->add_render_attribute( 'grid', 'class', [ 'orvian-services__grid', 'lg:grid', 'grid-cols-2', 'gap-2' ] );
		$this->add_render_attribute( 'images_col', 'class', [ 'orvian-services__images-col' ] );
		$this->add_render_attribute(
			'content_col',
			'class',
			[
				'orvian-services__content-col',
				'hidden',
				'lg:block',
				'relative',
				'self-start',
				'h-screen',
			]
		);

		if ( ! empty( $settings['tags_header_mobile'] ) ) {
			$this->add_render_attribute( 'tags_header_wrapper', 'class', 'hidden md:flex' );
		}

		?>
		<div class="orvian-services">
			<div class="orvian-services__header flex items-center justify-between gap-2">
				<div <?php $this->print_render_attribute_string( 'line_wrapper' ); ?>>
					<?php for ( $i = 0; $i < $services_count; $i++ ) : ?>
						<?php
						$this->add_render_attribute( 'line_' . $i, 'class', 'relative w-4px h-4px rounded-full' );
						$this->add_render_attribute( 'line_' . $i, 'data-index', $i );
						$this->add_render_attribute( 'line_' . $i, 'data-active', 0 === $i ? 'true' : 'false' );
						?>
						<span <?php $this->print_render_attribute_string( 'line_' . $i ); ?>></span>
					<?php endfor; ?>
				</div>
			<?php if ( ! empty( $settings['tags_header'] ) ) : ?>
				<div <?php $this->print_render_attribute_string( 'tags_header_wrapper' ); ?>>
					<?php foreach ( $settings['tags_header'] as $tag ) : ?>
						<span class="orvian-services__tag orvian-tag">
							<?php echo esc_html( $tag ); ?>
						</span>
					<?php endforeach; ?>
				</div>
			<?php endif; ?>
			<?php if ( ! empty( $settings['tags_header_mobile'] ) ) : ?>
				<div class="orvian-services__tags-header orvian-tags ms-auto md:hidden">
					<?php foreach ( $settings['tags_header_mobile'] as $tag ) : ?>
						<span class="orvian-services__tag orvian-tag">
							<?php echo esc_html( $tag ); ?>
						</span>
					<?php endforeach; ?>
				</div>
			<?php endif; ?>
			</div>
			<div <?php $this->print_render_attribute_string( 'grid' ); ?>>
				<div <?php $this->print_render_attribute_string( 'images_col' ); ?>>
					<?php foreach ( $settings['services'] as $index => $item ) : ?>
						<?php $this->render_item_image( $item, $index ); ?>
					<?php endforeach; ?>
				</div>
				<div <?php $this->print_render_attribute_string( 'content_col' ); ?>>
					<?php foreach ( $settings['services'] as $index => $item ) : ?>
						<?php $this->render_item_content( $item, $index ); ?>
					<?php endforeach; ?>
				</div>
			</div>
		</div>
		<?php
	}

	/**
	 * Render item image
	 *
	 * @param array $item Item settings.
	 * @param int   $index Item index.
	 */
	protected function render_item_image( $item, $index ) {
		$settings = $this->get_settings_for_display();

		$this->add_render_attribute( 'item_' . $index, 'class', [ 'orvian-services__item', 'orvian-services__item--' . $index ] );
		$this->add_render_attribute( 'item_' . $index, 'data-item_index', $index );

		?>
		<div <?php $this->print_render_attribute_string( 'item_' . $index ); ?>>
			<?php if ( ! empty( $item['image']['id'] ) ) : ?>
				<div class="orvian-services__image relative z-2">
					<?php echo wp_get_attachment_image( $item['image']['id'], 'full' ); // phpcs:ignore ?>
				</div>
			<?php elseif ( ! empty( $item['image']['url'] ) ) : ?>
				<div class="orvian-services__image relative z-2">
					<img src="<?php echo esc_url( $item['image']['url'] ); ?>">
				</div>
			<?php endif; ?>

			<div class="block lg:hidden">
				<?php $this->render_item_content( $item, $index ); ?>
			</div>
		</div>
		<?php
	}

	/**
	 * Render item content
	 *
	 * @param array $item Item settings.
	 * @param int   $index Item index.
	 */
	protected function render_item_content( $item, $index ) {
		$settings = $this->get_settings_for_display();

		$this->add_render_attribute( 'content_' . $index, 'class', [ 'orvian-services__content' ] );
		$this->add_render_attribute( 'content_' . $index, 'data-item_index', $index );

		$this->add_render_attribute( 'marquee_' . $index, 'class', [ 'orvian-services__marquee', 'orvian-marquee', 'orvian-elementor--marquee', 'relative', 'z-n1' ] );
		if ( 'yes' === $settings['hover_pause'] ) {
			$this->add_render_attribute( 'marquee_' . $index, 'class', 'hover-stop' );
		}

		?>
		<div <?php $this->print_render_attribute_string( 'content_' . $index ); ?>>
			<?php if ( ! empty( $item['subtitle'] ) ) : ?>
				<div class="orvian-services__subtitle flex items-center gap-2 relative">
					<?php printf( '<span class="text inline-flex items-center gap-2 shrink-0">[ %s ] <span class="text-white font-semibold font-heading uppercase">%s</span></span>', esc_attr( str_pad( $index + 1, 2, '0', STR_PAD_LEFT ) ), wp_kses_post( nl2br( $item['subtitle'] ) ) ); ?>
				</div>
			<?php endif; ?>
			<?php if ( ! empty( $item['title'] ) ) : ?>
				<div <?php $this->print_render_attribute_string( 'marquee_' . $index ); ?>>
					<div class="orvian-marquee--inner relative items-center">
						<div class="orvian-marquee__items orvian-marquee--original items-center">
							<?php $title_tag = $this->resolve_text_tag( $settings['title_size'] ); ?>
							<?php $title_class = 'orvian-services__title font-medium m-0 uppercase' . ( 'div' === $title_tag ? ' ' . $settings['title_size'] : '' ); ?>
							<<?php echo esc_attr( $title_tag ); ?> class="<?php echo esc_attr( $title_class ); ?>">
								<?php echo wp_kses_post( nl2br( $item['title'] ) ); ?>
							</<?php echo esc_attr( $title_tag ); ?>>
							<?php if ( 'image' === $settings['title_type'] ) : ?>
								<?php if ( ! empty( $settings['title_image']['id'] ) ) : ?>
									<div class="orvian-marquee__image">
										<?php echo wp_get_attachment_image( $settings['title_image']['id'], 'thumbnail' ); ?>
									</div>
								<?php elseif ( ! empty( $settings['title_image']['url'] ) ) : ?>
									<div class="orvian-marquee__image">
										<img src="<?php echo esc_url( $settings['title_image']['url'] ); ?>">
									</div>
								<?php else : ?>
									<?php echo \OrvianAddons\Helper::get_svg( 'dot', 'ui', [ 'class' => 'orvian-marquee__icon' ] ); // phpcs:ignore ?>
								<?php endif; ?>
							<?php elseif ( 'icon' === $settings['title_type'] ) : ?>
								<?php if ( ! empty( $settings['title_icon'] ) && ! empty( $settings['title_icon']['value'] ) ) : ?>
									<span class="orvian-marquee__icon orvian-svg-icon">
										<?php Icons_Manager::render_icon( $settings['title_icon'], [ 'aria-hidden' => 'true' ] ); ?>
									</span>
								<?php else : ?>
									<?php echo \OrvianAddons\Helper::get_svg( 'dot', 'ui', [ 'class' => 'orvian-marquee__icon' ] ); // phpcs:ignore ?>
								<?php endif; ?>
							<?php endif; ?>
						</div>
					</div>
				</div>
			<?php endif; ?>
			<?php if ( ! empty( $item['tags'] ) ) : ?>
				<div class="orvian-services__tags orvian-tags">
					<?php foreach ( $item['tags'] as $tag ) : ?>
						<span class="orvian-services__tag orvian-tag">
							<?php echo esc_html( $tag ); ?>
						</span>
					<?php endforeach; ?>
				</div>
			<?php endif; ?>
			<?php if ( ! empty( $item['description'] ) ) : ?>
				<div class="orvian-services__description">
					<?php echo wp_kses_post( $item['description'] ); ?>
				</div>
			<?php endif; ?>
			<?php $this->button_render( array_merge( $item, $settings ), '', 'orvian-services__button' ); ?>
		</div>
		<?php
	}
}
