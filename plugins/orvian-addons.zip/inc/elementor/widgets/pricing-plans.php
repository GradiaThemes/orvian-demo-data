<?php
/**
 * Pricing Plans Widget
 *
 * @package OrvianAddons
 */

namespace OrvianAddons\Elementor\Widgets;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Repeater;
use Elementor\Group_Control_Background;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Box_Shadow;
use OrvianAddons\Elementor\Elementor as OrvianAddons_Elementor;

/**
 * Pricing Plans Widget Class
 */
class Pricing_Plans extends Widget_Base {
	use Base\Text_Class;

	/**
	 * Get widget name
	 *
	 * @return string
	 */
	public function get_name() {
		return 'orvian-pricing-plans';
	}

	/**
	 * Get widget title
	 *
	 * @return string
	 */
	public function get_title() {
		return esc_html__( 'Pricing Plans', 'orvian-addons' );
	}

	/**
	 * Get widget icon
	 *
	 * @return string
	 */
	public function get_icon() {
		return 'eicon-price-table ' . OrvianAddons_Elementor::CLASS_WIDGET;
	}

	/**
	 * Get widget categories
	 *
	 * @return array
	 */
	public function get_categories() {
		return [ OrvianAddons_Elementor::CATEGORY ];
	}

	/**
	 * Get widget keywords
	 *
	 * @return array
	 */
	public function get_keywords() {
		return [ 'orvian', 'price', 'plans' ];
	}

	/**
	 * Register widget controls
	 */
	protected function register_controls() {
		$this->start_controls_section(
			'pricing_plans_heading',
			[
				'label' => esc_html__( 'Heading', 'orvian-addons' ),
			]
		);

		$this->add_control(
			'heading',
			[
				'label'       => esc_html__( 'Heading', 'orvian-addons' ),
				'type'        => Controls_Manager::TEXTAREA,
				'label_block' => true,
			]
		);

		$this->add_control(
			'heading_size',
			[
				'label'   => esc_html__( 'Title Size', 'orvian-addons' ),
				'type'    => Controls_Manager::SELECT,
				'options' => $this->get_text_class_options_with_tags(),
				'default' => 'h2',
			]
		);

		$this->add_control(
			'use_font_family_heading',
			[
				'label'     => esc_html__( 'Use Font Family of Heading', 'orvian-addons' ),
				'type'      => Controls_Manager::SWITCHER,
				'condition' => [
					'heading_size!' => [ 'h1', 'h2', 'h3', 'h4', 'h5', 'h6' ],
				],
			]
		);

		$this->add_control(
			'subheading',
			[
				'label'       => esc_html__( 'Sub Heading', 'orvian-addons' ),
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
				'separator'   => 'before',
			]
		);

		$this->add_control(
			'subheading_size',
			[
				'label'   => esc_html__( 'Sub Heading Size', 'orvian-addons' ),
				'type'    => Controls_Manager::SELECT,
				'options' => $this->get_text_class_options_with_tags(),
				'default' => 'span',
			]
		);

		$this->add_control(
			'subheading_use_font_family_heading',
			[
				'label'     => esc_html__( 'Use Font Family of Heading', 'orvian-addons' ),
				'type'      => Controls_Manager::SWITCHER,
				'default'   => 'yes',
				'condition' => [
					'subheading_size!' => [ 'h1', 'h2', 'h3', 'h4', 'h5', 'h6' ],
				],
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'pricing_plans_monthly_section',
			[
				'label' => esc_html__( 'Pricing Plans Monthly', 'orvian-addons' ),
			]
		);

		$this->add_control(
			'pricing_plans_monthly_title',
			[
				'label'       => esc_html__( 'Title', 'orvian-addons' ),
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
				'default'     => esc_html__( 'Monthly', 'orvian-addons' ),
			]
		);

		$this->add_control(
			'pricing_plans_monthly_save',
			[
				'label'       => esc_html__( 'Save', 'orvian-addons' ),
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
				'default'     => esc_html__( '-5%', 'orvian-addons' ),
			]
		);

		$repeater = new Repeater();

		$repeater->add_control(
			'badge',
			[
				'label'       => esc_html__( 'Badge', 'orvian-addons' ),
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
			]
		);

		$repeater->add_control(
			'title',
			[
				'label'       => esc_html__( 'Title', 'orvian-addons' ),
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
			]
		);

		$repeater->add_control(
			'subtitle',
			[
				'label'       => esc_html__( 'Subtitle', 'orvian-addons' ),
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
			]
		);

		$repeater->add_control(
			'description',
			[
				'label'       => esc_html__( 'Description', 'orvian-addons' ),
				'type'        => Controls_Manager::WYSIWYG,
				'label_block' => true,
			]
		);

		$repeater->add_control(
			'button_heading',
			[
				'label'     => esc_html__( 'Button', 'orvian-addons' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$repeater->add_control(
			'button_text_before',
			[
				'label'       => esc_html__( 'Text Before', 'orvian-addons' ),
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
			]
		);

		$repeater->add_control(
			'price',
			[
				'label'       => esc_html__( 'Price', 'orvian-addons' ),
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
			]
		);

		$repeater->add_control(
			'button_text_after',
			[
				'label'       => esc_html__( 'Text After', 'orvian-addons' ),
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
			]
		);

		$repeater->add_control(
			'button_link',
			[
				'label'       => esc_html__( 'Link', 'orvian-addons' ),
				'type'        => Controls_Manager::URL,
				'label_block' => true,
			]
		);

		$this->add_control(
			'pricing_plans_monthly',
			[
				'type'    => Controls_Manager::REPEATER,
				'fields'  => $repeater->get_controls(),
				'default' => [
					[
						'badge'              => esc_html__( 'Basic', 'orvian-addons' ),
						'title'              => esc_html__( 'Single Project', 'orvian-addons' ),
						'button_text_before' => esc_html__( 'From', 'orvian-addons' ),
						'price'              => esc_html__( '$799', 'orvian-addons' ),
						'button_text_after'  => esc_html__( '/project', 'orvian-addons' ),
					],
					[
						'badge'              => esc_html__( 'Premium', 'orvian-addons' ),
						'title'              => esc_html__( 'Multi Project', 'orvian-addons' ),
						'button_text_before' => esc_html__( 'From', 'orvian-addons' ),
						'price'              => esc_html__( '$1299', 'orvian-addons' ),
						'button_text_after'  => esc_html__( '/project', 'orvian-addons' ),
					],
				],
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'pricing_plans_yearly_section',
			[
				'label' => esc_html__( 'Pricing Plans Yearly', 'orvian-addons' ),
			]
		);

		$this->add_control(
			'pricing_plans_yearly_title',
			[
				'label'       => esc_html__( 'Title', 'orvian-addons' ),
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
				'default'     => esc_html__( 'Yearly', 'orvian-addons' ),
			]
		);

		$this->add_control(
			'pricing_plans_yearly_save',
			[
				'label'       => esc_html__( 'Save', 'orvian-addons' ),
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
				'default'     => esc_html__( '-10%', 'orvian-addons' ),
			]
		);

		$repeater = new Repeater();

		$repeater->add_control(
			'badge',
			[
				'label'       => esc_html__( 'Badge', 'orvian-addons' ),
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
			]
		);

		$repeater->add_control(
			'title',
			[
				'label'       => esc_html__( 'Title', 'orvian-addons' ),
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
			]
		);

		$repeater->add_control(
			'subtitle',
			[
				'label'       => esc_html__( 'Subtitle', 'orvian-addons' ),
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
			]
		);

		$repeater->add_control(
			'description',
			[
				'label'       => esc_html__( 'Description', 'orvian-addons' ),
				'type'        => Controls_Manager::WYSIWYG,
				'label_block' => true,
			]
		);

		$repeater->add_control(
			'button_heading',
			[
				'label'     => esc_html__( 'Button', 'orvian-addons' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$repeater->add_control(
			'button_text_before',
			[
				'label'       => esc_html__( 'Text Before', 'orvian-addons' ),
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
			]
		);

		$repeater->add_control(
			'price',
			[
				'label'       => esc_html__( 'Price', 'orvian-addons' ),
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
			]
		);

		$repeater->add_control(
			'button_text_after',
			[
				'label'       => esc_html__( 'Text After', 'orvian-addons' ),
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
			]
		);

		$repeater->add_control(
			'button_link',
			[
				'label'       => esc_html__( 'Link', 'orvian-addons' ),
				'type'        => Controls_Manager::URL,
				'label_block' => true,
			]
		);

		$this->add_control(
			'pricing_plans_yearly',
			[
				'type'    => Controls_Manager::REPEATER,
				'fields'  => $repeater->get_controls(),
				'default' => [
					[
						'badge'              => esc_html__( 'Basic', 'orvian-addons' ),
						'title'              => esc_html__( 'Single Project', 'orvian-addons' ),
						'button_text_before' => esc_html__( 'From', 'orvian-addons' ),
						'price'              => esc_html__( '$799', 'orvian-addons' ),
						'button_text_after'  => esc_html__( '/project', 'orvian-addons' ),
					],
					[
						'badge'              => esc_html__( 'Premium', 'orvian-addons' ),
						'title'              => esc_html__( 'Multi Project', 'orvian-addons' ),
						'button_text_before' => esc_html__( 'From', 'orvian-addons' ),
						'price'              => esc_html__( '$1299', 'orvian-addons' ),
						'button_text_after'  => esc_html__( '/project', 'orvian-addons' ),
					],
				],
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'section_header_style',
			[
				'label' => esc_html__( 'Header', 'orvian-addons' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_responsive_control(
			'header_spacing_bottom',
			[
				'label'     => esc_html__( 'Spacing Bottom', 'orvian-addons' ),
				'type'      => Controls_Manager::SLIDER,
				'range'     => [
					'px' => [
						'min' => 0,
						'max' => 1000,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .orvian-pricing-plans__header' => 'margin-bottom: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'heading_heading',
			[
				'label'     => esc_html__( 'Heading', 'orvian-addons' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'heading_typography',
				'selector' => '{{WRAPPER}} .orvian-pricing-plans__heading',
			]
		);

		$this->add_control(
			'heading_color',
			[
				'label'     => esc_html__( 'Color', 'orvian-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .orvian-pricing-plans__heading' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'subheading_heading',
			[
				'label'     => esc_html__( 'Sub Heading', 'orvian-addons' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'subheading_typography',
				'selector' => '{{WRAPPER}} .orvian-pricing-plans__subheading',
			]
		);

		$this->add_control(
			'subheading_color',
			[
				'label'     => esc_html__( 'Color', 'orvian-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .orvian-pricing-plans__subheading' => 'color: {{VALUE}};',
				],
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'section_button_tab_style',
			[
				'label' => esc_html__( 'Tab Buttons', 'orvian-addons' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'tab_buttons_color_scheme',
			[
				'label'       => esc_html__( 'Color Scheme', 'orvian-addons' ),
				'type'        => Controls_Manager::SELECT,
				'options'     => [
					''            => esc_html__( 'Default', 'orvian-addons' ),
					'theme-light' => esc_html__( 'Light', 'orvian-addons' ),
					'theme-dark'  => esc_html__( 'Dark', 'orvian-addons' ),
				],
				'render_type' => 'template',
			]
		);

		$this->add_responsive_control(
			'tab_buttons_border_radius',
			[
				'label'      => esc_html__( 'Border Radius', 'orvian-addons' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .orvian-pricing-plans__tabs-header' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'section_plan_style',
			[
				'label' => esc_html__( 'Plan', 'orvian-addons' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_responsive_control(
			'plan_border_radius',
			[
				'label'      => esc_html__( 'Border Radius', 'orvian-addons' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%' ],
				'selectors'  => [
					'{{WRAPPER}} .orvian-pricing-plans__plan' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'plan_box_shadow',
				'selector' => '{{WRAPPER}} .orvian-pricing-plans__plan',
			]
		);

		$this->add_control(
			'plan_background_heading',
			[
				'label'     => esc_html__( 'Even', 'orvian-addons' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'     => 'plan_background',
				'types'    => [ 'classic', 'gradient' ],
				'selector' => '{{WRAPPER}} .orvian-pricing-plans__plan:not(.odd) .orvian-pricing-plans__background',
			]
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'plan_background_box_shadow',
				'selector' => '{{WRAPPER}} .orvian-pricing-plans__plan:not(.odd) .orvian-pricing-plans__background',
			]
		);

		$this->add_control(
			'plan_background_odd_heading',
			[
				'label'     => esc_html__( 'Odd', 'orvian-addons' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'     => 'plan_background_odd',
				'types'    => [ 'classic', 'gradient' ],
				'selector' => '{{WRAPPER}} .orvian-pricing-plans__plan.odd .orvian-pricing-plans__background',
			]
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'plan_background_odd_box_shadow',
				'selector' => '{{WRAPPER}} .orvian-pricing-plans__plan.odd .orvian-pricing-plans__background',
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'section_button_style',
			[
				'label' => esc_html__( 'Price', 'orvian-addons' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'button_style',
			[
				'label'   => esc_html__( 'Button Style', 'orvian-addons' ),
				'type'    => Controls_Manager::HIDDEN,
				'default' => 'primary',
			]
		);

		$this->add_control(
			'button_show_icon',
			[
				'label'   => esc_html__( 'Show Icon', 'orvian-addons' ),
				'type'    => Controls_Manager::HIDDEN,
				'default' => 'yes',
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'button_price_typography',
				'selector' => '{{WRAPPER}} .orvian-pricing-plans__price',
			]
		);

		$this->add_control(
			'button_price_color',
			[
				'label'     => esc_html__( 'Color', 'orvian-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .orvian-pricing-plans__price' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_control(
			'button_price_color_hover',
			[
				'label'     => esc_html__( 'Color Hover', 'orvian-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .orvian-button:hover .orvian-pricing-plans__price' => 'color: {{VALUE}}',
				],
			]
		);

		$this->end_controls_section();
	}

	/**
	 * Render widget output
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();

		$this->add_render_attribute( 'heading', 'class', [ 'orvian-pricing-plans__heading', 'inline', 'uppercase', 'm-0' ] );

		if ( 'yes' === $settings['use_font_family_heading'] ) {
			$this->add_render_attribute( 'heading', 'class', 'font-heading text-heading tracking-heading' );
		}

		$this->add_render_attribute( 'subheading', 'class', [ 'orvian-pricing-plans__subheading', 'font-semibold', 'inline' ] );

		if ( 'yes' === $settings['subheading_use_font_family_heading'] ) {
			$this->add_render_attribute( 'subheading', 'class', 'font-heading tracking-heading' );
		}

		$heading_tag = $this->resolve_text_tag( $settings['heading_size'], 'heading' );

		$subheading_tag = $this->resolve_text_tag( $settings['subheading_size'], 'subheading' );

		$this->add_inline_editing_attributes( 'heading' );
		$this->add_inline_editing_attributes( 'subheading' );
		?>
		<div class="orvian-pricing-plans__header flex flex-col md:flex-row justify-center items-center md:justify-between md:items-end gap-28px md:gap-32px">
			<div class="flex justify-between items-end w-full md:block">
			<?php if ( ! empty( $settings['heading'] ) ) : ?>
					<<?php echo esc_attr( $heading_tag ); ?> <?php $this->print_render_attribute_string( 'heading' ); ?>>
						<?php echo wp_kses_post( nl2br( $settings['heading'] ) ); ?>
					</<?php echo esc_attr( $heading_tag ); ?>>
				<?php endif; ?>
			<?php if ( ! empty( $settings['subheading'] ) ) : ?>
					<<?php echo esc_attr( $subheading_tag ); ?> <?php $this->print_render_attribute_string( 'subheading' ); ?>>
						<?php echo wp_kses_post( $settings['subheading'] ); ?>
					</<?php echo esc_attr( $subheading_tag ); ?>>
				<?php endif; ?>
			</div>
			<div class="orvian-pricing-plans__tabs-header inline-flex circle mb-2 gap-1 relative <?php echo esc_attr( isset( $settings['tab_buttons_color_scheme'] ) ? $settings['tab_buttons_color_scheme'] : '' ); ?>">
				<span class="orvian-pricing-plans__tab-bg absolute pointer-events-none"></span>
			<?php if ( ! empty( $settings['pricing_plans_monthly_title'] ) ) : ?>
					<button class="button-primary button-has-icon button-primary--small orvian-pricing-plans__tab orvian-pricing-plans__tab--monthly no-effect-hover no-effect-active active" data-tab="monthly">
						<?php echo wp_kses_post( $settings['pricing_plans_monthly_title'] ); ?>
						<?php if ( ! empty( $settings['pricing_plans_monthly_save'] ) ) : ?>
							<span class="orvian-pricing-plans__save orvian-svg-icon pointer-events-none font-medium">
								<?php echo wp_kses_post( $settings['pricing_plans_monthly_save'] ); ?>
							</span>
						<?php endif; ?>
					</button>
				<?php endif; ?>
			<?php if ( ! empty( $settings['pricing_plans_yearly_title'] ) ) : ?>
					<button class="button-primary button-has-icon button-primary--small orvian-pricing-plans__tab orvian-pricing-plans__tab--yearly no-effect-hover no-effect-active" data-tab="yearly">
						<?php echo wp_kses_post( $settings['pricing_plans_yearly_title'] ); ?>
						<?php if ( ! empty( $settings['pricing_plans_yearly_save'] ) ) : ?>
							<span class="orvian-pricing-plans__save orvian-svg-icon pointer-events-none font-medium">
								<?php echo wp_kses_post( $settings['pricing_plans_yearly_save'] ); ?>
							</span>
						<?php endif; ?>
					</button>
				<?php endif; ?>
			</div>
		</div>
		<div class="orvian-pricing-plans__tabs flex flex-col md:grid grid-cols-2 gap-2 justify-space-between active theme-dark" data-tab="monthly">
		<?php foreach ( $settings['pricing_plans_monthly'] as $index => $plan ) : ?>
				<?php $this->render_plan( $plan, $index ); ?>
			<?php endforeach; ?>
		</div>
		<div class="orvian-pricing-plans__tabs flex flex-col md:grid grid-cols-2 gap-2 justify-space-between" data-tab="yearly">
		<?php foreach ( $settings['pricing_plans_yearly'] as $index => $plan ) : ?>
				<?php $this->render_plan( $plan, $index ); ?>
			<?php endforeach; ?>
		</div>
		<?php
	}

	/**
	 * Render plan
	 *
	 * @param array $plan Plan data.
	 * @param int   $index Plan index.
	 */
	private function render_plan( array $plan, int $index ): void {
		?>
		<div class="orvian-pricing-plans__plan flex flex-col items-start relative overflow-hidden col-start-<?php echo 0 === $index % 2 ? '1 odd' : '2'; ?>">
			<div class="orvian-pricing-plans__background absolute w-full h-full top-0 left-0 z-n1 pointer-events-none"></div>
		<?php if ( ! empty( $plan['badge'] ) ) : ?>
				<div class="orvian-pricing-plans__badge inline-block text-body-3 font-medium circle">
					<?php echo wp_kses_post( $plan['badge'] ); ?>
				</div>
			<?php endif; ?>
		<?php if ( ! empty( $plan['title'] ) ) : ?>
				<div class="orvian-pricing-plans__title font-heading text-heading tracking-heading text-heading-1 font-semibold uppercase m-0">
					<?php echo wp_kses_post( $plan['title'] ); ?>
				</div>
			<?php endif; ?>
		<?php if ( ! empty( $plan['subtitle'] ) ) : ?>
				<div class="orvian-pricing-plans__subtitle text-body-3">
					<?php echo wp_kses_post( $plan['subtitle'] ); ?>
				</div>
			<?php endif; ?>
		<?php if ( ! empty( $plan['description'] ) ) : ?>
				<div class="orvian-pricing-plans__description text-body-3">
					<?php echo wp_kses_post( $plan['description'] ); ?>
				</div>
			<?php endif; ?>
		<?php if ( ! empty( $plan['price'] ) ) : ?>
				<a href="<?php echo ! empty( $plan['button_link']['url'] ) ? esc_url( $plan['button_link']['url'] ) : '#'; ?>" class="orvian-button button-primary button-primary--dark button-has-icon uppercase orvian-pricing-plans__button w-full">
					<span class="button-text text-body-3 font-semibold inline-flex items-center gap-2">
						<span class="hidden lg:inline"><?php echo wp_kses_post( $plan['button_text_before'] ); ?></span>
						<?php if ( ! empty( $plan['price'] ) ) : ?>
							<span class="orvian-pricing-plans__price text-display-3">
								<?php echo wp_kses_post( $plan['price'] ); ?>
							</span>
						<?php endif; ?>
						<?php echo wp_kses_post( $plan['button_text_after'] ); ?>
					</span>
					<?php echo \OrvianAddons\Helper::get_svg( 'arrow-up-right' ); // phpcs:ignore ?>
				</a>
			<?php endif; ?>
		</div>
		<?php
	}
}
