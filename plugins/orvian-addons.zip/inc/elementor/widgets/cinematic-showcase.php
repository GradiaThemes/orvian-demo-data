<?php
/**
 * Cinematic Showcase Widget
 *
 * @package OrvianAddons
 */

namespace OrvianAddons\Elementor\Widgets;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use Elementor\Controls_Manager;
use Elementor\Repeater;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Background;
use Elementor\Group_Control_Border;
use OrvianAddons\Elementor\Elementor as OrvianAddons_Elementor;

/**
 * Cinematic Showcase Widget Class
 */
class Cinematic_Showcase extends Base\Carousel_Widget_Base {

	use Base\Button_Base;
	use Base\Text_Class;

	/**
	 * Get widget name
	 *
	 * @return string
	 */
	public function get_name() {
		return 'orvian-cinematic-showcase';
	}

	/**
	 * Get widget title
	 *
	 * @return string
	 */
	public function get_title() {
		return esc_html__( 'Cinematic Showcase', 'orvian-addons' );
	}

	/**
	 * Get widget icon
	 *
	 * @return string
	 */
	public function get_icon() {
		return 'eicon-slider-vertical ' . OrvianAddons_Elementor::CLASS_WIDGET;
	}

	/**
	 * Get widget categories
	 *
	 * @return array
	 */
	public function get_categories() {
		return [ OrvianAddons_Elementor::CATEGORY ];
	}

	/**
	 * Get widget keywords
	 *
	 * @return array
	 */
	public function get_keywords() {
		return [ 'orvian', 'cinematic', 'showcase', 'carousel', 'animation' ];
	}

	/**
	 * Get carousel controls
	 *
	 * @return array
	 */
	protected function get_carousel_controls(): array {
		return [
			'slides_per_view' => [
				'desktop' => 1,
				'tablet'  => 1,
				'mobile'  => 1,
			],
			'space_between'   => [
				'desktop' => 40,
				'tablet'  => 12,
				'mobile'  => 12,
			],
			'centered_slides' => 'yes',
		];
	}

	/**
	 * Register widget controls
	 */
	protected function register_controls() {
		$this->start_controls_section(
			'content_section',
			[
				'label' => esc_html__( 'Cinematic Showcase', 'orvian-addons' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);

		$repeater = new Repeater();

		$repeater->add_control(
			'title',
			[
				'label'       => esc_html__( 'Title', 'orvian-addons' ),
				'type'        => Controls_Manager::TEXTAREA,
				'default'     => esc_html__( 'This is Title', 'orvian-addons' ),
				'label_block' => true,
				'dynamic'     => [ 'active' => true ],
			]
		);

		$repeater->add_control(
			'thumbnail',
			[
				'label'   => esc_html__( 'Thumbnail', 'orvian-addons' ),
				'type'    => Controls_Manager::MEDIA,
				'dynamic' => [ 'active' => true ],
			]
		);

		$repeater->add_control(
			'orvian_tags',
			[
				'label' => esc_html__( 'Tags', 'orvian-addons' ),
				'type'  => 'orvian-tags',
			]
		);

		$repeater->add_control(
			'gallery',
			[
				'label'      => esc_html__( 'Gallery', 'orvian-addons' ),
				'type'       => Controls_Manager::GALLERY,
				'show_label' => false,
				'dynamic'    => [ 'active' => true ],
			]
		);

		$repeater->add_control(
			'description',
			[
				'label'   => esc_html__( 'Description', 'orvian-addons' ),
				'type'    => Controls_Manager::TEXTAREA,
				'default' => esc_html__( 'This is a description', 'orvian-addons' ),
				'dynamic' => [ 'active' => true ],
			]
		);

		$this->register_button_controls( '', $repeater );

		$this->add_control(
			'items',
			[
				'label'       => esc_html__( 'Items', 'orvian-addons' ),
				'type'        => Controls_Manager::REPEATER,
				'fields'      => $repeater->get_controls(),
				'default'     => [
					[
						'title'       => esc_html__( 'This is Title', 'orvian-addons' ),
						'description' => esc_html__( 'This is a description', 'orvian-addons' ),
					],
					[
						'title'       => esc_html__( 'This is Title', 'orvian-addons' ),
						'description' => esc_html__( 'This is a description', 'orvian-addons' ),
					],
					[
						'title'       => esc_html__( 'This is Title', 'orvian-addons' ),
						'description' => esc_html__( 'This is a description', 'orvian-addons' ),
					],
				],
				'title_field' => '{{{ title }}}',
			]
		);

		$this->add_control(
			'layout',
			[
				'label'     => esc_html__( 'Layout', 'orvian-addons' ),
				'type'      => Controls_Manager::SELECT,
				'options'   => [
					'single-column'    => esc_html__( 'Single Column', 'orvian-addons' ),
					'two-column-left'  => esc_html__( 'Two Column (Thumbnail Left)', 'orvian-addons' ),
					'two-column-right' => esc_html__( 'Two Column (Thumbnail Right)', 'orvian-addons' ),
				],
				'default'   => 'two-column-left',
				'separator' => 'before',
			]
		);

		$this->add_control(
			'title_html_tag',
			[
				'label'     => esc_html__( 'Title HTML Tag', 'orvian-addons' ),
				'type'      => Controls_Manager::SELECT,
				'options'   => $this->get_text_class_options_with_tags(),
				'default'   => 'text-display-3',
				'separator' => 'before',
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'carousel_settings_section',
			[
				'label' => esc_html__( 'Carousel Settings', 'orvian-addons' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->register_carousel_controls( [], true );

		$this->add_control(
			'use_mouse_wheel',
			[
				'label' => esc_html__( 'Use Mouse Wheel', 'orvian-addons' ),
				'type'  => Controls_Manager::SWITCHER,
			]
		);

		$this->add_control(
			'use_mouse_wheel_outside_slider',
			[
				'label'     => esc_html__( 'Enable Mouse Wheel Outside Slider', 'orvian-addons' ),
				'type'      => Controls_Manager::SWITCHER,
				'default'   => 'yes',
				'condition' => [
					'use_mouse_wheel' => 'yes',
				],
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'style_content',
			[
				'label' => esc_html__( 'General', 'orvian-addons' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_responsive_control(
			'padding',
			[
				'label'      => esc_html__( 'Padding', 'orvian-addons' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', 'rem', 'custom' ],
				'selectors'  => [
					'{{WRAPPER}} .orvian-cinematic-showcase' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'border_radius',
			[
				'label'      => esc_html__( 'Border Radius', 'orvian-addons' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', 'rem', 'custom' ],
				'selectors'  => [
					'{{WRAPPER}} .orvian-cinematic-showcase' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'     => 'border',
				'selector' => '{{WRAPPER}} .orvian-cinematic-showcase',
			]
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'     => 'background',
				'types'    => [ 'classic', 'gradient' ],
				'selector' => '{{WRAPPER}} .orvian-cinematic-showcase',
			]
		);

		$this->add_control(
			'thumbnail_heading',
			[
				'label'     => esc_html__( 'Thumbnail', 'orvian-addons' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_responsive_control(
			'thumbnail_aspect_ratio',
			[
				'label'       => esc_html__( 'Aspect Ratio (width/height)', 'orvian-addons' ),
				'type'        => Controls_Manager::TEXT,
				'placeholder' => '16/9',
				'selectors'   => [
					'{{WRAPPER}} .orvian-cinematic-showcase__thumbnail img' => 'aspect-ratio: {{VALUE}};',
					'{{WRAPPER}} .orvian-cinematic-showcase__thumbnails img' => 'aspect-ratio: {{VALUE}};',
				],
			]
		);

		$this->add_responsive_control(
			'thumbnail_border_radius',
			[
				'label'      => esc_html__( 'Border Radius', 'orvian-addons' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem' ],
				'selectors'  => [
					'{{WRAPPER}} .orvian-cinematic-showcase__thumbnail img' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					'{{WRAPPER}} .orvian-cinematic-showcase__thumbnails' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'tags_heading',
			[
				'label'     => esc_html__( 'Tags', 'orvian-addons' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_control(
			'tags_color',
			[
				'label'     => esc_html__( 'Color', 'orvian-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .orvian-cinematic-showcase__tags .orvian-tag' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'tags_background_color',
			[
				'label'     => esc_html__( 'Background Color', 'orvian-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .orvian-cinematic-showcase__tags .orvian-tag' => 'background-color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'index_heading',
			[
				'label'     => esc_html__( 'Number Order', 'orvian-addons' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_control(
			'index_color',
			[
				'label'     => esc_html__( 'Color', 'orvian-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .orvian-cinematic-showcase__index' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'index_background_color',
			[
				'label'     => esc_html__( 'Background Color', 'orvian-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .orvian-cinematic-showcase__index' => 'background-color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'title_heading',
			[
				'label'     => esc_html__( 'Title', 'orvian-addons' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'title_typography',
				'selector' => '{{WRAPPER}} .orvian-cinematic-showcase__title',
			]
		);

		$this->add_control(
			'title_color',
			[
				'label'     => esc_html__( 'Color', 'orvian-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .orvian-cinematic-showcase__title' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'description_heading',
			[
				'label'     => esc_html__( 'Description', 'orvian-addons' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'description_typography',
				'selector' => '{{WRAPPER}} .orvian-cinematic-showcase__description',
			]
		);

		$this->add_control(
			'description_color',
			[
				'label'     => esc_html__( 'Color', 'orvian-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .orvian-cinematic-showcase__description' => 'color: {{VALUE}};',
				],
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'carousel_style_content',
			[
				'label' => esc_html__( 'Carousel Style', 'orvian-addons' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->register_carousel_style_controls();

		$this->end_controls_section();
	}

	/**
	 * Render widget output
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();

		if ( empty( $settings['items'] ) ) {
			return;
		}

		$this->render_carousel();
	}

	/**
	 * Render items carousel.
	 */
	protected function render_items_carousel() {
		$settings = $this->get_settings_for_display();

		$layout = $settings['layout'];

		$layout_classes = [
			'orvian-cinematic-showcase__item',
			'orvian-cinematic-showcase__item--' . $layout,
		];

		if ( in_array( $layout, [ 'two-column-left', 'two-column-right' ], true ) ) {
			$layout_classes[] = 'flex';
			$layout_classes[] = 'lg:items-center';
			$layout_classes[] = 'flex-col';
			$layout_classes[] = 'gap-6';

			if ( 'two-column-left' === $layout ) {
				$layout_classes[] = 'lg:flex-row';
			}

			if ( 'two-column-right' === $layout ) {
				$layout_classes[] = 'lg:flex-row-reverse';
			}
		}

		$this->add_render_attribute( 'item', 'class', $layout_classes );

		$this->add_render_attribute( 'summary', 'class', [ 'orvian-cinematic-showcase__summary', 'flex-1' ] );
		$this->add_render_attribute( 'index', 'class', [ 'orvian-cinematic-showcase__index', 'inline-flex', 'items-center', 'justify-center', 'shrink-0', 'p-14px', 'circle', 'caption', 'leading-none', 'bg-primary', 'text-white', 'font-heading', 'font-medium', 'mb-5' ] );
		$this->add_render_attribute( 'title', 'class', [ 'orvian-cinematic-showcase__title', 'm-0', 'uppercase', 'text-heading', 'font-medium', 'border-bottom', 'pb-2', 'mb-4' ] );
		$this->add_render_attribute( 'gallery', 'class', [ 'orvian-cinematic-showcase__gallery', 'flex', 'flex-wrap', 'gap-8px', 'md:gap-16px', 'mb-14px' ] );
		$this->add_render_attribute( 'description', 'class', [ 'orvian-cinematic-showcase__description', 'text-body-3', 'font-bold', 'sm:no-br' ] );

		$title_tag = $this->resolve_text_tag( $settings['title_html_tag'], 'title' );
		$this->add_inline_editing_attributes( 'title' );
		$this->add_inline_editing_attributes( 'description' );

		foreach ( $settings['items'] as $index => $item ) :
			?>
			<div class="swiper-slide">
				<div <?php $this->print_render_attribute_string( 'item' ); ?>>
					<?php if ( 'single-column' !== $layout ) : ?>
						<?php if ( ! empty( $item['thumbnail']['url'] ) ) : ?>
							<div class="orvian-cinematic-showcase__thumbnails hidden lg:block relative h-full rounded-lg overflow-hidden">
								<span class="block ratio-image">
									<?php if ( ! empty( $item['thumbnail']['id'] ) ) : ?>
										<?php echo wp_get_attachment_image( $item['thumbnail']['id'], 'full' ); ?>
									<?php elseif ( ! empty( $item['thumbnail']['url'] ) ) : ?>
										<img src="<?php echo esc_url( $item['thumbnail']['url'] ); ?>">
									<?php endif; ?>
								</span>
								<?php if ( ! empty( $item['orvian_tags'] ) ) : ?>
									<div class="orvian-cinematic-showcase__tags orvian-tags flex flex-wrap items-center gap-8px absolute inset-x-0 bottom-0 p-3">
										<?php foreach ( $item['orvian_tags'] as $tag ) : ?>
											<span class="orvian-tag"><?php echo esc_html( $tag ); ?></span>
										<?php endforeach; ?>
									</div>
								<?php endif; ?>
							</div>
						<?php endif; ?>
					<?php endif; ?>

					<div <?php $this->print_render_attribute_string( 'summary' ); ?>>
						<?php $index_display = str_pad( $index + 1, 2, '0', STR_PAD_LEFT ); ?>

						<div <?php $this->print_render_attribute_string( 'index' ); ?>><?php echo esc_html( $index_display ); ?></div>

						<<?php echo esc_attr( $title_tag ); ?> <?php $this->print_render_attribute_string( 'title' ); ?>><?php echo wp_kses_post( nl2br( $item['title'] ) ); ?></<?php echo esc_attr( $title_tag ); ?>>

						<?php if ( ! empty( $item['gallery'] ) ) : ?>
							<div <?php $this->print_render_attribute_string( 'gallery' ); ?>>
								<?php foreach ( $item['gallery'] as $image ) : ?>
									<span class="block ratio-image">
										<?php if ( ! empty( $image['id'] ) ) : ?>
											<?php echo wp_get_attachment_image( $image['id'], 'full' ); ?>
										<?php elseif ( ! empty( $image['url'] ) ) : ?>
											<img src="<?php echo esc_url( $image['url'] ); ?>">
										<?php endif; ?>
									</span>
								<?php endforeach; ?>
							</div>
						<?php endif; ?>

						<?php if ( ! empty( $item['description'] ) ) : ?>
							<div <?php $this->print_render_attribute_string( 'description' ); ?>><?php echo wp_kses_post( nl2br( $item['description'] ) ); ?></div>
						<?php endif; ?>

						<?php if ( ! empty( $item['thumbnail']['url'] ) ) : ?>
							<div class="border-top pt-2 mt-4 relative <?php echo 'single-column' !== $layout ? 'lg:hidden' : ''; ?>">
								<span class="block ratio-image orvian-cinematic-showcase__thumbnail rounded-sm">
									<?php if ( $item['thumbnail']['id'] ) : ?>
										<?php echo wp_get_attachment_image( $item['thumbnail']['id'], 'full' ); ?>
									<?php elseif ( $item['thumbnail']['url'] ) : ?>
										<img src="<?php echo esc_url( $item['thumbnail']['url'] ); ?>">
									<?php endif; ?>
								</span>
								<?php if ( ! empty( $item['orvian_tags'] ) ) : ?>
									<div class="orvian-cinematic-showcase__tags orvian-tags flex flex-wrap items-center gap-8px absolute inset-x-0 bottom-0 p-3">
										<?php foreach ( $item['orvian_tags'] as $tag ) : ?>
											<span class="orvian-tag"><?php echo esc_html( $tag ); ?></span>
										<?php endforeach; ?>
									</div>
								<?php endif; ?>
							</div>
						<?php endif; ?>

						<?php $this->button_render( $item, '', 'mt-9' ); ?>
					</div>
				</div>
			</div>
			<?php
		endforeach;
	}

	/**
	 * Get manual attributes.
	 *
	 * @return array
	 */
	protected function get_manual_attributes(): array {
		$settings = $this->get_settings_for_display();

		return [
			'direction'         => 'vertical',
			'mousewheel'        => 'yes' === $settings['use_mouse_wheel'] ? true : false,
			'mousewheeloutside' => 'yes' === $settings['use_mouse_wheel_outside_slider'] ? true : false,
		];
	}

	/**
	 * Get classes swiper.
	 *
	 * @return array
	 */
	protected function get_classes_swiper(): array {
		return [ 'orvian-cinematic-showcase' ];
	}
}
