<?php
/**
 * Carousel Widget Base
 *
 * @package OrvianAddons
 */

namespace OrvianAddons\Elementor\Widgets\Base;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use OrvianAddons\Helper;

/**
 * Carousel Widget Base Class
 */
abstract class Carousel_Widget_Base extends Widget_Base {

	/**
	 * Get carousel controls
	 *
	 * @return array
	 */
	protected function get_carousel_controls(): array {
		return [];
	}

	/**
	 * Register carousel controls.
	 *
	 * @param array $supported_controls Supported controls.
	 * @param bool  $vertical Vertical.
	 */
	protected function register_carousel_controls( $supported_controls = [], $vertical = false ) {
		$carousel_controls = $this->get_carousel_controls();

		if ( empty( $supported_controls ) ) {
			$supported_controls = [
				'effect'          => 'slide',
				'show_items'      => 'yes',
				'slides_per_view' => [
					'desktop' => 1,
					'tablet'  => 1,
					'mobile'  => 1,
				],
				'space_between'   => [
					'desktop' => 30,
					'tablet'  => 30,
					'mobile'  => 15,
				],
				'navigation'      => 'arrows',
				'autoplay'        => '',
				'autoplay_speed'  => 3000,
				'speed'           => 800,
				'infinite'        => '1',
				'centered_slides' => '',
			];
		}

		$controls = empty( $carousel_controls ) ? $supported_controls : array_merge( $supported_controls, $carousel_controls );

		foreach ( $controls as $option => $default ) {
			switch ( $option ) {
				case 'effect':
					$this->add_control(
						'effect',
						[
							'label'   => esc_html__( 'Effect', 'orvian-addons' ),
							'type'    => Controls_Manager::SELECT,
							'default' => $default,
							'options' => [
								'slide'     => esc_html__( 'Slide', 'orvian-addons' ),
								'fade'      => esc_html__( 'Fade', 'orvian-addons' ),
								'coverflow' => esc_html__( 'Coverflow', 'orvian-addons' ),
							],
						]
					);
					break;

				case 'show_items':
					$this->add_control(
						'show_items',
						[
							'label'     => esc_html__( 'Only 3 items are shown.', 'orvian-addons' ),
							'type'      => Controls_Manager::SWITCHER,
							'label_off' => esc_html__( 'Hide', 'orvian-addons' ),
							'label_on'  => esc_html__( 'Show', 'orvian-addons' ),
							'default'   => $default,
							'condition' => [
								'effect' => 'coverflow',
							],
						]
					);
					break;

				case 'slides_per_view':
					$this->add_responsive_control(
						'slides_per_view',
						[
							'label'          => esc_html__( 'Slides to Show', 'orvian-addons' ),
							'type'           => Controls_Manager::NUMBER,
							'min'            => 1,
							'max'            => 50,
							'step'           => 1,
							'default'        => ! empty( $default['desktop'] ) ? $default['desktop'] : $default,
							'tablet_default' => ! empty( $default['tablet'] ) ? $default['tablet'] : '',
							'mobile_default' => ! empty( $default['mobile'] ) ? $default['mobile'] : '',
						]
					);
					break;

				case 'space_between':
					$this->add_responsive_control(
						'space_between',
						[
							'label'          => esc_html__( 'Space Between', 'orvian-addons' ),
							'type'           => Controls_Manager::NUMBER,
							'min'            => 0,
							'max'            => 200,
							'default'        => ! empty( $default['desktop'] ) ? $default['desktop'] : $default,
							'tablet_default' => ! empty( $default['tablet'] ) ? $default['tablet'] : '',
							'mobile_default' => ! empty( $default['mobile'] ) ? $default['mobile'] : '',
						]
					);
					break;

				case 'navigation':
					$this->add_responsive_control(
						'navigation',
						[
							'label'          => esc_html__( 'Navigation', 'orvian-addons' ),
							'type'           => Controls_Manager::SELECT,
							'options'        => [
								'arrows' => esc_html__( 'Arrows', 'orvian-addons' ),
								'dots'   => esc_html__( 'Dots', 'orvian-addons' ),
								'both'   => esc_html__( 'Arrows and Dots', 'orvian-addons' ),
								'none'   => esc_html__( 'None', 'orvian-addons' ),
							],
							'default'        => $default,
							'tablet_default' => 'dots',
							'mobile_default' => 'dots',
							'prefix_class'   => 'gt-swiper-navigation%s-',
						]
					);
					break;

				case 'autoplay':
					$this->add_control(
						'autoplay',
						[
							'label'     => esc_html__( 'Autoplay', 'orvian-addons' ),
							'type'      => Controls_Manager::SWITCHER,
							'label_off' => esc_html__( 'Off', 'orvian-addons' ),
							'label_on'  => esc_html__( 'On', 'orvian-addons' ),
							'default'   => $default,
						]
					);
					break;

				case 'autoplay_speed':
					$this->add_control(
						'autoplay_speed',
						[
							'label'     => esc_html__( 'Autoplay Speed', 'orvian-addons' ),
							'type'      => Controls_Manager::NUMBER,
							'default'   => $default,
							'min'       => 100,
							'step'      => 50,
							'condition' => [
								'autoplay' => 'yes',
							],
						]
					);
					break;

				case 'speed':
					$this->add_control(
						'speed',
						[
							'label'   => esc_html__( 'Animation Speed', 'orvian-addons' ),
							'type'    => Controls_Manager::NUMBER,
							'default' => $default,
							'min'     => 100,
							'step'    => 50,
						]
					);
					break;

				case 'infinite':
					$this->add_control(
						'infinite',
						[
							'label'        => esc_html__( 'Infinite Loop', 'orvian-addons' ),
							'type'         => Controls_Manager::SWITCHER,
							'label_off'    => esc_html__( 'Off', 'orvian-addons' ),
							'label_on'     => esc_html__( 'On', 'orvian-addons' ),
							'default'      => $default,
							'return_value' => '1',
							'condition'    => $vertical ? [ 'use_mouse_wheel!' => 'yes' ] : [],
						]
					);
					break;

				case 'centered_slides':
					$condition = [ 'effect' => 'slide' ];
					if ( $vertical ) {
						$condition = [ 'use_mouse_wheel!' => 'yes' ];
					}
					$this->add_control(
						'centered_slides',
						[
							'label'     => esc_html__( 'Centered Slides', 'orvian-addons' ),
							'type'      => Controls_Manager::SWITCHER,
							'label_off' => esc_html__( 'Off', 'orvian-addons' ),
							'label_on'  => esc_html__( 'On', 'orvian-addons' ),
							'default'   => $default,
							'condition' => $condition,
						]
					);
					break;
			}
		}
	}

	/**
	 * Register carousel style controls.
	 */
	protected function register_carousel_style_controls() {
		$this->add_responsive_control(
			'carousel_padding',
			[
				'label'      => esc_html__( 'Padding', 'orvian-addons' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .swiper' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'carousel_navigation_type',
			[
				'label'   => esc_html__( 'Navigation Type', 'orvian-addons' ),
				'type'    => Controls_Manager::SELECT,
				'default' => '',
				'options' => [
					''       => esc_html__( 'Default', 'orvian-addons' ),
					'inline' => esc_html__( 'Inline', 'orvian-addons' ),
				],
			]
		);

		$this->add_control(
			'carousel_navigation_position',
			[
				'label'     => esc_html__( 'Navigation Position', 'orvian-addons' ),
				'type'      => Controls_Manager::SELECT,
				'options'   => [
					''         => esc_html__( 'Default', 'orvian-addons' ),
					'absolute' => esc_html__( 'Absolute', 'orvian-addons' ),
				],
				'selectors' => [
					'{{WRAPPER}} .orvian-swiper-controls' => 'position: {{VALUE}};',
				],
				'condition' => [
					'carousel_navigation_type' => 'inline',
				],
			]
		);

		$this->add_responsive_control(
			'carousel_navigation_gap',
			[
				'label'      => esc_html__( 'Navigation Gap', 'orvian-addons' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', 'em', 'rem', 'custom' ],
				'selectors'  => [
					'{{WRAPPER}} .orvian-swiper-controls' => 'gap: {{SIZE}}{{UNIT}};',
				],
				'condition'  => [
					'carousel_navigation_type' => 'inline',
				],
			]
		);

		$this->add_responsive_control(
			'carousel_navigation_spacing_top',
			[
				'label'      => esc_html__( 'Spacing Top', 'orvian-addons' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'selectors'  => [
					'{{WRAPPER}} .orvian-swiper-controls' => 'margin-top: {{SIZE}}{{UNIT}}',
				],
			]
		);

		$this->add_control(
			'carousel_navigation_position_vertical',
			[
				'label'     => esc_html__( 'Vertical Position', 'orvian-addons' ),
				'type'      => Controls_Manager::CHOOSE,
				'default'   => 'top',
				'options'   => [
					'top'    => [
						'title' => esc_html__( 'Top', 'orvian-addons' ),
						'icon'  => 'eicon-v-align-top',
					],
					'bottom' => [
						'title' => esc_html__( 'Bottom', 'orvian-addons' ),
						'icon'  => 'eicon-v-align-bottom',
					],
				],
				'condition' => [
					'carousel_navigation_type'     => 'inline',
					'carousel_navigation_position' => 'absolute',
				],
			]
		);

		$this->add_responsive_control(
			'carousel_navigation_position_top',
			[
				'label'      => esc_html__( 'Position Top', 'orvian-addons' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'selectors'  => [
					'{{WRAPPER}} .orvian-swiper-controls' => 'top: {{SIZE}}{{UNIT}}; bottom: auto;',
				],
				'condition'  => [
					'carousel_navigation_type'     => 'inline',
					'carousel_navigation_position' => 'absolute',
					'carousel_navigation_position_vertical' => 'top',
				],
			]
		);

		$this->add_responsive_control(
			'carousel_navigation_position_bottom',
			[
				'label'      => esc_html__( 'Position Bottom', 'orvian-addons' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'selectors'  => [
					'{{WRAPPER}} .orvian-swiper-controls' => 'bottom: {{SIZE}}{{UNIT}}; top: auto;',
				],
				'condition'  => [
					'carousel_navigation_type'     => 'inline',
					'carousel_navigation_position' => 'absolute',
					'carousel_navigation_position_vertical' => 'bottom',
				],
			]
		);

		$this->add_control(
			'carousel_navigation_position_horizontal',
			[
				'label'     => esc_html__( 'Horizontal Position', 'orvian-addons' ),
				'type'      => Controls_Manager::CHOOSE,
				'default'   => 'left',
				'options'   => [
					'left'  => [
						'title' => esc_html__( 'Left', 'orvian-addons' ),
						'icon'  => 'eicon-h-align-left',
					],
					'right' => [
						'title' => esc_html__( 'Right', 'orvian-addons' ),
						'icon'  => 'eicon-h-align-right',
					],
				],
				'condition' => [
					'carousel_navigation_type'     => 'inline',
					'carousel_navigation_position' => 'absolute',
				],
			]
		);

		$this->add_responsive_control(
			'carousel_navigation_position_left',
			[
				'label'      => esc_html__( 'Position Left', 'orvian-addons' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'selectors'  => [
					'{{WRAPPER}} .orvian-swiper-controls' => 'left: {{SIZE}}{{UNIT}}; right: auto;',
				],
				'condition'  => [
					'carousel_navigation_type'     => 'inline',
					'carousel_navigation_position' => 'absolute',
					'carousel_navigation_position_horizontal' => 'left',
				],
			]
		);

		$this->add_responsive_control(
			'carousel_navigation_position_right',
			[
				'label'      => esc_html__( 'Position Right', 'orvian-addons' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'selectors'  => [
					'{{WRAPPER}} .orvian-swiper-controls' => 'right: {{SIZE}}{{UNIT}}; left: auto;',
				],
				'condition'  => [
					'carousel_navigation_type'     => 'inline',
					'carousel_navigation_position' => 'absolute',
					'carousel_navigation_position_horizontal' => 'right',
				],
			]
		);

		$this->register_carousel_arrows_type_controls();
		$this->register_carousel_dots_style_controls();
	}

	/**
	 * Register carousel arrows style controls.
	 */
	protected function register_carousel_arrows_type_controls() {
		$this->add_control(
			'arrows_type_heading',
			[
				'label' => esc_html__( 'Arrows', 'orvian-addons' ),
				'type'  => Controls_Manager::HEADING,
			]
		);

		$this->add_control(
			'arrows_show',
			[
				'label'        => esc_html__( 'Always show button', 'orvian-addons' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_off'    => esc_html__( 'Off', 'orvian-addons' ),
				'label_on'     => esc_html__( 'On', 'orvian-addons' ),
				'default'      => '',
				'return_value' => '1',
				'selectors'    => [
					'{{WRAPPER}} .swiper-button' => 'opacity: {{VALUE}}; margin-left: 0 !important; margin-right: 0 !important;',
				],
			]
		);

		$this->add_control(
			'arrows_type',
			[
				'label'   => esc_html__( 'Arrows Type', 'orvian-addons' ),
				'type'    => Controls_Manager::SELECT,
				'options' => [
					'normal'     => esc_html__( 'Default', 'orvian-addons' ),
					''           => esc_html__( 'Small', 'orvian-addons' ),
					'small-plus' => esc_html__( 'Small Plus', 'orvian-addons' ),
					'primary'    => esc_html__( 'Primary', 'orvian-addons' ),
				],
				'default' => 'normal',
			]
		);

		$this->add_control(
			'arrows_icon_type',
			[
				'label'   => esc_html__( 'Icon Type', 'orvian-addons' ),
				'type'    => Controls_Manager::SELECT,
				'default' => '1',
				'options' => [
					'1' => esc_html__( 'Type 1', 'orvian-addons' ),
					'2' => esc_html__( 'Type 2', 'orvian-addons' ),
				],
			]
		);

		$this->add_responsive_control(
			'arrows_horizontal_spacing',
			[
				'label'      => esc_html__( 'Horizontal Spacing', 'orvian-addons' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'selectors'  => [
					'{{WRAPPER}} .swiper-button-prev' => '--swiper-navigation-sides-offset: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}} .swiper-button-next' => '--swiper-navigation-sides-offset: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'arrows_width',
			[
				'label'      => esc_html__( 'Width', 'orvian-addons' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', 'em', 'rem', 'custom' ],
				'selectors'  => [
					'{{WRAPPER}} .swiper-button' => '--arrow-width: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'arrows_height',
			[
				'label'      => esc_html__( 'Height', 'orvian-addons' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', 'em', 'rem', 'custom' ],
				'selectors'  => [
					'{{WRAPPER}} .swiper-button' => '--arrow-height: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'arrows_icon_size',
			[
				'label'      => esc_html__( 'Icon Size', 'orvian-addons' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', 'em', 'rem', 'custom' ],
				'selectors'  => [
					'{{WRAPPER}} .swiper-button' => '--arrow-font-size: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'arrows_radius',
			[
				'label'      => esc_html__( 'Border Radius', 'orvian-addons' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%' ],
				'selectors'  => [
					'{{WRAPPER}} .swiper-button-prev'     => '--btn-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					'.rtl {{WRAPPER}} swiper-button-prev' => '--btn-radius: {{TOP}}{{UNIT}} {{LEFT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{RIGHT}}{{UNIT}};',
					'{{WRAPPER}} .swiper-button-next'     => '--btn-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					'.rtl {{WRAPPER}} swiper-button-next' => '--btn-radius: {{TOP}}{{UNIT}} {{LEFT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{RIGHT}}{{UNIT}};',
				],
			]
		);

		$this->start_controls_tabs(
			'arrows_tabs'
		);
		$this->start_controls_tab(
			'arrows_normal_tab',
			[
				'label'     => esc_html__( 'Normal', 'orvian-addons' ),
				'condition' => [
					'arrows_type!' => 'primary',
				],
			]
		);
		$this->add_control(
			'arrows_bgcolor',
			[
				'label'     => esc_html__( 'Background Color', 'orvian-addons' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .swiper-button-prev' => '--btn-bg: {{VALUE}};',
					'{{WRAPPER}} .swiper-button-next' => '--btn-bg: {{VALUE}};',
				],
				'condition' => [
					'arrows_type!' => 'primary',
				],
			]
		);

		$this->add_control(
			'arrows_color',
			[
				'label'     => esc_html__( 'Color', 'orvian-addons' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .swiper-button-prev' => '--btn-color: {{VALUE}};',
					'{{WRAPPER}} .swiper-button-next' => '--btn-color: {{VALUE}};',
				],
				'condition' => [
					'arrows_type!' => 'primary',
				],
			]
		);

		$this->add_control(
			'arrows_border_color',
			[
				'label'     => esc_html__( 'Border Color', 'orvian-addons' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .swiper-button-prev' => '--btn-border-color: {{VALUE}};',
					'{{WRAPPER}} .swiper-button-next' => '--btn-border-color: {{VALUE}};',
				],
				'condition' => [
					'arrows_type!' => 'primary',
				],
			]
		);
		$this->end_controls_tab();

		$this->start_controls_tab(
			'arrows_hover_tab',
			[
				'label'     => esc_html__( 'Hover', 'orvian-addons' ),
				'condition' => [
					'arrows_type!' => 'primary',
				],
			]
		);

		$this->add_control(
			'arrows_hover_bgcolor',
			[
				'label'     => esc_html__( 'Background Color', 'orvian-addons' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .swiper-button-prev:hover' => '--btn-bg: {{VALUE}};',
					'{{WRAPPER}} .swiper-button-next:hover' => '--btn-bg: {{VALUE}};',
				],
				'condition' => [
					'arrows_type!' => 'primary',
				],
			]
		);

		$this->add_control(
			'arrows_hover_color',
			[
				'label'     => esc_html__( 'Color', 'orvian-addons' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .swiper-button-prev:hover' => '--btn-color: {{VALUE}};',
					'{{WRAPPER}} .swiper-button-next:hover' => '--btn-color: {{VALUE}};',
				],
				'condition' => [
					'arrows_type!' => 'primary',
				],
			]
		);

		$this->add_control(
			'arrows_hover_border_color',
			[
				'label'     => esc_html__( 'Border Color', 'orvian-addons' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .swiper-button-prev:hover' => '--btn-border-color: {{VALUE}};',
					'{{WRAPPER}} .swiper-button-next:hover' => '--btn-border-color: {{VALUE}};',
				],
				'condition' => [
					'arrows_type!' => 'primary',
				],
			]
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			'arrows_disable_tab',
			[
				'label'     => esc_html__( 'Disable', 'orvian-addons' ),
				'condition' => [
					'arrows_type!' => 'primary',
				],
			]
		);
		$this->add_control(
			'arrows_disable_bgcolor',
			[
				'label'     => esc_html__( 'Background Color', 'orvian-addons' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .swiper-button-prev.swiper-button-disabled' => '--btn-bg: {{VALUE}};',
					'{{WRAPPER}} .swiper-button-next.swiper-button-disabled' => '--btn-bg: {{VALUE}};',
				],
				'condition' => [
					'arrows_type!' => 'primary',
				],
			]
		);

		$this->add_control(
			'arrows_disable_color',
			[
				'label'     => esc_html__( 'Color', 'orvian-addons' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .swiper-button-prev.swiper-button-disabled' => '--btn-color: {{VALUE}};',
					'{{WRAPPER}} .swiper-button-next.swiper-button-disabled' => '--btn-color: {{VALUE}};',
				],
				'condition' => [
					'arrows_type!' => 'primary',
				],
			]
		);

		$this->add_control(
			'arrows_disable_border_color',
			[
				'label'     => esc_html__( 'Border Color', 'orvian-addons' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .swiper-button-prev.swiper-button-disabled' => '--btn-border-color: {{VALUE}};',
					'{{WRAPPER}} .swiper-button-next.swiper-button-disabled' => '--btn-border-color: {{VALUE}};',
				],
				'condition' => [
					'arrows_type!' => 'primary',
				],
			]
		);
		$this->end_controls_tab();

		$this->end_controls_tabs();
	}

	/**
	 * Register carousel dots style controls.
	 */
	protected function register_carousel_dots_style_controls() {
		$this->add_control(
			'dots_style_heading',
			[
				'label'     => esc_html__( 'Dots', 'orvian-addons' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_control(
			'dots_type',
			[
				'label'   => esc_html__( 'Dots Type', 'orvian-addons' ),
				'type'    => Controls_Manager::SELECT,
				'options' => [
					''        => esc_html__( 'Default', 'orvian-addons' ),
					'numeric' => esc_html__( 'Numeric', 'orvian-addons' ),
					'line'    => esc_html__( 'Line', 'orvian-addons' ),
				],
				'default' => '',
			]
		);

		$this->add_responsive_control(
			'dots_gap',
			[
				'label'     => esc_html__( 'Gap', 'orvian-addons' ),
				'type'      => Controls_Manager::SLIDER,
				'range'     => [
					'px' => [
						'max' => 50,
						'min' => 0,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .swiper-pagination-bullets .swiper-pagination-bullet' => '--swiper-pagination-gap: {{SIZE}}{{UNIT}}',
				],
			]
		);

		$this->add_responsive_control(
			'dots_size',
			[
				'label'      => esc_html__( 'Dot Size', 'orvian-addons' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'selectors'  => [
					'{{WRAPPER}} .swiper-pagination-bullets .swiper-pagination-bullet' => '--swiper-pagination-bullet-size: {{SIZE}}{{UNIT}};',
				],
				'condition'  => [
					'dots_type!' => 'line',
				],
			]
		);

		$this->add_responsive_control(
			'dots_line_size',
			[
				'label'      => esc_html__( 'Dot Size', 'orvian-addons' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'selectors'  => [
					'{{WRAPPER}} .swiper-pagination--line' => '--swiper-pagination-bullet-width: {{SIZE}}{{UNIT}};',
				],
				'condition'  => [
					'dots_type' => 'line',
				],
			]
		);

		$this->add_responsive_control(
			'dots_spacing',
			[
				'label'      => esc_html__( 'Spacing', 'orvian-addons' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'selectors'  => [
					'{{WRAPPER}} .swiper-pagination' => 'margin-top: {{SIZE}}{{UNIT}}',
				],
				'condition'  => [
					'carousel_navigation_type!' => 'inline',
				],
			]
		);

		$this->start_controls_tabs(
			'dot_tabs'
		);

			$this->start_controls_tab(
				'dot_inactive_tab',
				[
					'label' => esc_html__( 'Inactive', 'orvian-addons' ),
				]
			);

				$this->add_control(
					'dot_item_color',
					[
						'label'     => esc_html__( 'Color', 'orvian-addons' ),
						'type'      => Controls_Manager::COLOR,
						'default'   => '',
						'selectors' => [
							'{{WRAPPER}} .swiper-pagination-bullet' => '--swiper-pagination-bullet-inactive-color: {{VALUE}}; --swiper-pagination-color: {{VALUE}};',
						],
					]
				);

				$this->add_control(
					'dot_item_opacity',
					[
						'label'     => esc_html__( 'Opacity', 'orvian-addons' ),
						'type'      => Controls_Manager::NUMBER,
						'min'       => 0,
						'max'       => 1,
						'step'      => 0.1,
						'selectors' => [
							'{{WRAPPER}} .swiper-pagination-bullet' => '--swiper-pagination-bullet-inactive-opacity: {{VALUE}};',
						],
					]
				);

			$this->end_controls_tab();

			$this->start_controls_tab(
				'dot_active_tab',
				[
					'label' => esc_html__( 'Active', 'orvian-addons' ),
				]
			);

				$this->add_control(
					'dot_item_active_color',
					[
						'label'     => esc_html__( 'Color', 'orvian-addons' ),
						'type'      => Controls_Manager::COLOR,
						'default'   => '',
						'selectors' => [
							'{{WRAPPER}} .swiper-pagination-bullet-active' => '--swiper-pagination-color: {{VALUE}};',
						],
					]
				);

				$this->add_control(
					'dot_item_opacity_active',
					[
						'label'     => esc_html__( 'Opacity', 'orvian-addons' ),
						'type'      => Controls_Manager::NUMBER,
						'min'       => 0,
						'max'       => 1,
						'step'      => 0.1,
						'selectors' => [
							'{{WRAPPER}} .swiper-pagination-bullet-active' => '--swiper-pagination-bullet-opacity: {{VALUE}};',
						],
					]
				);

			$this->end_controls_tab();

		$this->end_controls_tabs();
	}

	/**
	 * Render pagination.
	 */
	protected function render_pagination() {
		$settings = $this->get_settings_for_display();
		?>
		<div class="swiper-pagination swiper-pagination--elementor swiper-pagination--<?php echo esc_attr( $settings['dots_type'] ); ?>"></div>
		<?php
	}

	/**
	 * Render arrows.
	 */
	protected function render_arrows() {
		$settings = $this->get_settings_for_display();
		?>
		<div class="swiper-navigation">
			<button type="button" class="swiper-button swiper-button-prev button--no-style swiper-button--<?php echo esc_attr( $settings['arrows_type'] ); ?>" aria-label="<?php esc_attr_e( 'Previous', 'orvian-addons' ); ?>">
				<?php
				// phpcs:ignore
				echo Helper::get_svg( 'arrow-left' );
				?>
			</button>
			<button type="button" class="swiper-button swiper-button-next button--no-style swiper-button--<?php echo esc_attr( $settings['arrows_type'] ); ?>" aria-label="<?php esc_attr_e( 'Next', 'orvian-addons' ); ?>">
				<?php
				// phpcs:ignore
				echo Helper::get_svg( 'arrow-right' );
				?>
			</button>
		</div>
		<?php
	}

	/**
	 * Render pagination arrows.
	 */
	protected function render_pagination_arrows() {
		$settings = $this->get_settings_for_display();
		?>
		<div class="orvian-swiper-controls flex justify-center items-center">
			<button type="button" class="swiper-button swiper-button-prev button--no-style swiper-button--<?php echo esc_attr( $settings['arrows_type'] ); ?>" aria-label="<?php esc_attr_e( 'Previous', 'orvian-addons' ); ?>">
				<?php
				$icon_left = '1' === $settings['arrows_icon_type'] ? 'arrow-left' : 'arrow-left-1';
				// phpcs:ignore
				echo Helper::get_svg( $icon_left );
				?>
			</button>
			<div class="swiper-pagination swiper-pagination--<?php echo esc_attr( $settings['dots_type'] ); ?>" <?php echo ! in_array( $settings['dots_type'], [ 'bullets', 'fraction', 'progressbar' ], true ) ? 'data-type_bullets="' . esc_attr( $settings['dots_type'] ) . '"' : ''; ?>></div>
			<button type="button" class="swiper-button swiper-button-next button--no-style swiper-button--<?php echo esc_attr( $settings['arrows_type'] ); ?>" aria-label="<?php esc_attr_e( 'Next', 'orvian-addons' ); ?>">
				<?php
				$icon_right = '1' === $settings['arrows_icon_type'] ? 'arrow-right' : 'arrow-right-1';
				// phpcs:ignore
				echo Helper::get_svg( $icon_right );
				?>
			</button>
		</div>
		<?php
	}

	/**
	 * Render navigation custom.
	 */
	protected function render_navigation_custom() {}

	/**
	 * Print attributes.
	 *
	 * @param array $attributes Attributes.
	 */
	protected function print_attributes( array $attributes ) {
		foreach ( $attributes as $key => $value ) {
			if ( ! empty( $value ) ) {
				echo ' ' . esc_attr( $key ) . '="' . esc_attr( $value ) . '"';
			}
		}
	}

	/**
	 * Get attributes.
	 *
	 * @return array
	 */
	protected function get_attributes(): array {
		$settings          = $this->get_settings_for_display();
		$carousel_controls = $this->get_carousel_controls();
		$_attributes       = $this->get_manual_attributes();

		$slides_per_view = 1;
		$space_between   = 30;

		if ( ! empty( $carousel_controls ) ) {
			if ( empty( $settings['slides_per_view'] ) && ! empty( $carousel_controls['slides_per_view']['desktop'] ) ) {
				$slides_per_view = $carousel_controls['slides_per_view']['desktop'];
			}

			if ( empty( $settings['space_between'] ) && ! empty( $carousel_controls['space_between']['desktop'] ) ) {
				$space_between = $carousel_controls['space_between']['desktop'];
			}
		}

		$slides_per_view = ! empty( $settings['slides_per_view'] ) ? $settings['slides_per_view'] : $slides_per_view;
		$space_between   = ! empty( $settings['space_between'] ) ? $settings['space_between'] : $space_between;

		$slides_per_view_tablet = $slides_per_view;
		$space_between_tablet   = $space_between;

		if ( ! empty( $carousel_controls ) ) {
			if ( empty( $settings['slides_per_view_tablet'] ) && ! empty( $carousel_controls['slides_per_view']['tablet'] ) ) {
				$slides_per_view_tablet = $carousel_controls['slides_per_view']['tablet'];
			}

			if ( empty( $settings['space_between_tablet'] ) && ! empty( $carousel_controls['space_between']['tablet'] ) ) {
				$space_between_tablet = $carousel_controls['space_between']['tablet'];
			}
		}

		$slides_per_view_tablet = ! empty( $settings['slides_per_view_tablet'] ) ? $settings['slides_per_view_tablet'] : $slides_per_view_tablet;
		$space_between_tablet   = ! empty( $settings['space_between_tablet'] ) ? $settings['space_between_tablet'] : $space_between_tablet;

		$slides_per_view_mobile = $slides_per_view_tablet;
		$space_between_mobile   = $space_between_tablet;

		if ( ! empty( $carousel_controls ) ) {
			if ( empty( $settings['slides_per_view_mobile'] ) && ! empty( $carousel_controls['slides_per_view']['mobile'] ) ) {
				$slides_per_view_mobile = $carousel_controls['slides_per_view']['mobile'];
			}

			if ( empty( $settings['space_between_mobile'] ) && ! empty( $carousel_controls['space_between']['mobile'] ) ) {
				$space_between_mobile = $carousel_controls['space_between']['mobile'];
			}
		}

		$slides_per_view_mobile = ! empty( $settings['slides_per_view_mobile'] ) ? $settings['slides_per_view_mobile'] : $slides_per_view_mobile;
		$space_between_mobile   = ! empty( $settings['space_between_mobile'] ) ? $settings['space_between_mobile'] : $space_between_mobile;

		return array_merge(
			$_attributes,
			[
				'effect'          => $settings['effect'],
				'show_items'      => $settings['show_items'],
				'slides-per-view' => $slides_per_view_mobile,
				'space-between'   => $space_between_mobile,
				'speed'           => $settings['speed'],
				'autoplay'        => 'yes' === $settings['autoplay'] ? $settings['autoplay_speed'] : '',
				'loop'            => $settings['infinite'],
				'centered-slides' => $settings['centered_slides'],
				'breakpoints'     => esc_attr(
					wp_json_encode(
						[
							'768'  => [
								'slidesPerView' => $slides_per_view_tablet,
								'spaceBetween'  => $space_between_tablet,
							],
							'1024' => [
								'slidesPerView' => $slides_per_view,
								'spaceBetween'  => $space_between,
							],
						]
					)
				),
			]
		);
	}

	/**
	 * Get manual attributes.
	 *
	 * @return array
	 */
	protected function get_manual_attributes(): array {
		return [];
	}

	/**
	 * Get classes swiper.
	 *
	 * @return array
	 */
	protected function get_classes_swiper(): array {
		return [];
	}

	/**
	 * Render items carousel.
	 */
	protected function render_items_carousel() {}

	/**
	 * Render carousel.
	 *
	 * @param string $html_tag Html tag.
	 * @param string $classes Classes.
	 * @param bool   $navigation Navigation.
	 */
	protected function render_carousel( string $html_tag = 'div', string $classes = '', $navigation = false ): void {
		$settings = $this->get_settings_for_display();
		?>
		<gt-slider <?php $this->print_attributes( $this->get_attributes() ); ?>>
			<div class="swiper swiper--elementor <?php echo esc_attr( implode( ' ', $this->get_classes_swiper() ) ); ?>">
				<<?php echo esc_attr( $html_tag ); ?> class="swiper-wrapper <?php echo esc_attr( $classes ); ?>">
					<?php $this->render_items_carousel(); ?>
				</<?php echo esc_attr( $html_tag ); ?>>

				<?php
				if ( $navigation ) {
					$this->render_navigation_custom();
				} elseif ( 'inline' === $settings['carousel_navigation_type'] ) {
						$this->render_pagination_arrows();
				} else {
					$this->render_pagination();
					$this->render_arrows();
				}
				?>
			</div>
		</gt-slider>
		<?php
	}
}
