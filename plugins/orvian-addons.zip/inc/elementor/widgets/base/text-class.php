<?php
/**
 * Text Class
 *
 * @package OrvianAddons
 */

namespace OrvianAddons\Elementor\Widgets\Base;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Text Class Trait
 *
 * @mixin \Elementor\Widget_Base
 */
trait Text_Class {

	/**
	 * Get text class options (text-display, text-body, caption)
	 *
	 * @return array
	 */
	protected function get_text_class_options(): array {
		return [
			'text-display-1' => 'Text Display 1',
			'text-display-2' => 'Text Display 2',
			'text-display-3' => 'Text Display 3',
			'text-heading-1' => 'Text Heading 1',
			'text-heading-2' => 'Text Heading 2',
			'text-body-1'    => 'Text Body 1',
			'text-body-2'    => 'Text Body 2',
			'text-body-3'    => 'Text Body 3',
			'caption'        => 'Caption',
		];
	}

	/**
	 * Get text class options with HTML tags
	 *
	 * @return array
	 */
	protected function get_text_class_options_with_tags(): array {
		return array_merge(
			[
				'h1'   => 'H1',
				'h2'   => 'H2',
				'h3'   => 'H3',
				'h4'   => 'H4',
				'h5'   => 'H5',
				'h6'   => 'H6',
				'div'  => 'div',
				'span' => 'span',
				'p'    => 'p',
			],
			$this->get_text_class_options()
		);
	}

	/**
	 * Resolve the correct HTML tag. If a text class is passed, add it as a CSS class and return 'div'.
	 *
	 * @param string $tag       The selected tag or text class.
	 * @param string $attr_name The render attribute name (optional).
	 * @return string
	 */
	protected function resolve_text_tag( string $tag, string $attr_name = '' ): string {
		$html_tags = [ 'h1', 'h2', 'h3', 'h4', 'h5', 'h6', 'div', 'span', 'p' ];
		if ( ! in_array( $tag, $html_tags, true ) ) {
			if ( ! empty( $attr_name ) ) {
				$this->add_render_attribute( $attr_name, 'class', $tag );
			}
			return 'div';
		}
		return $tag;
	}
}
