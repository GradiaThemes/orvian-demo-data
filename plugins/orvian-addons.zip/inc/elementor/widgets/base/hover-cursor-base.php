<?php
/**
 * Hover Cursor Base
 *
 * @package OrvianAddons
 */

namespace OrvianAddons\Elementor\Widgets\Base;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

use Elementor\Controls_Manager;
use Elementor\Icons_Manager;
use Elementor\Group_Control_Image_Size;
use Elementor\Group_Control_Typography;

/**
 * Hover Cursor Base Class
 *
 * @mixin \Elementor\Widget_Base
 */
trait Hover_Cursor_Base {
	use Text_Class;

	/**
	 * Register Hover Cursor Controls
	 *
	 * @param string $prefix Prefix.
	 * @param array  $defaults Defaults.
	 * @param array  $conditions Conditions.
	 */
	protected function register_hover_cursor_controls( $prefix = '', $defaults = [], $conditions = [] ) {
		$this->add_control(
			$prefix . 'hover_cursor',
			[
				'label'     => esc_html__( 'Hover Cursor', 'orvian-addons' ),
				'type'      => Controls_Manager::SWITCHER,
				'default'   => $defaults['hover_cursor'] ?? '',
				'condition' => $conditions,
			]
		);

		$this->add_control(
			$prefix . 'hover_cursor_type',
			[
				'label'     => esc_html__( 'Hover Cursor Type', 'orvian-addons' ),
				'type'      => Controls_Manager::SELECT,
				'default'   => $defaults['hover_cursor_type'] ?? 'image',
				'condition' => wp_parse_args( $conditions, [ $prefix . 'hover_cursor' => 'yes' ] ),
				'options'   => [
					'image' => esc_html__( 'Image', 'orvian-addons' ),
					'icon'  => esc_html__( 'Icon', 'orvian-addons' ),
				],
			]
		);

		$this->add_control(
			$prefix . 'hover_cursor_icon',
			[
				'label'     => esc_html__( 'Icon', 'orvian-addons' ),
				'type'      => Controls_Manager::ICONS,
				'default'   => [
					'value'   => 'fas fa-star',
					'library' => 'fa-solid',
				],
				'condition' => wp_parse_args(
					$conditions,
					[
						'hover_cursor'      => 'yes',
						'hover_cursor_type' => 'icon',
					]
				),
			]
		);

		$this->add_control(
			$prefix . 'hover_cursor_image',
			[
				'label'     => esc_html__( 'Image', 'orvian-addons' ),
				'type'      => Controls_Manager::MEDIA,
				'condition' => wp_parse_args(
					$conditions,
					[
						'hover_cursor'      => 'yes',
						'hover_cursor_type' => 'image',
					]
				),
			]
		);

		$this->add_control(
			$prefix . 'hover_cursor_text',
			[
				'label'     => esc_html__( 'Hover Cursor Text', 'orvian-addons' ),
				'type'      => Controls_Manager::TEXT,
				'default'   => $defaults['hover_cursor_text'] ?? '',
				'condition' => wp_parse_args( $conditions, [ $prefix . 'hover_cursor' => 'yes' ] ),
			]
		);

		$this->add_control(
			$prefix . 'hover_cursor_text_size',
			[
				'label'     => esc_html__( 'HTML Tag', 'orvian-addons' ),
				'type'      => Controls_Manager::SELECT,
				'options'   => $this->get_text_class_options_with_tags(),
				'default'   => $defaults['hover_cursor_text_size'] ?? 'div',
				'condition' => wp_parse_args( $conditions, [ $prefix . 'hover_cursor' => 'yes' ] ),
			]
		);

		$this->add_control(
			$prefix . 'use_font_family_heading',
			[
				'label'     => esc_html__( 'Use Font Family of Heading', 'orvian-addons' ),
				'type'      => Controls_Manager::SWITCHER,
				'condition' => wp_parse_args(
					$conditions,
					[
						$prefix . 'hover_cursor' => 'yes',
						$prefix . 'hover_cursor_text_size!' => [ 'h1', 'h2', 'h3', 'h4', 'h5', 'h6' ],
					]
				),
			]
		);

		$this->add_control(
			$prefix . 'hover_cursor_class',
			[
				'label'     => esc_html__( 'Hover Cursor Class', 'orvian-addons' ),
				'type'      => Controls_Manager::TEXT,
				'default'   => $defaults['hover_cursor_class'] ?? '',
				'condition' => wp_parse_args( $conditions, [ $prefix . 'hover_cursor' => 'yes' ] ),
			]
		);
	}

	/**
	 * Register Hover Cursor Style Controls
	 *
	 * @param string $prefix Prefix.
	 * @param array  $conditions Conditions.
	 */
	protected function register_hover_cursor_controls_style( $prefix = '', $conditions = [] ) {
		$this->add_responsive_control(
			$prefix . 'hover_cursor_position',
			[
				'label'     => esc_html__( 'Position', 'orvian-addons' ),
				'type'      => Controls_Manager::CHOOSE,
				'default'   => 'column',
				'options'   => [
					'row'            => [
						'title' => esc_html__( 'Left', 'orvian-addons' ),
						'icon'  => 'eicon-h-align-left',
					],
					'column'         => [
						'title' => esc_html__( 'Top', 'orvian-addons' ),
						'icon'  => 'eicon-v-align-top',
					],
					'row-reverse'    => [
						'title' => esc_html__( 'Right', 'orvian-addons' ),
						'icon'  => 'eicon-h-align-right',
					],
					'column-reverse' => [
						'title' => esc_html__( 'Bottom', 'orvian-addons' ),
						'icon'  => 'eicon-v-align-bottom',
					],
				],
				'selectors' => [
					'.orvian-hover-cursor__' . esc_attr( $prefix ) . '{{ID}}' => '--icon-position: {{VALUE}};',
				],
				'condition' => wp_parse_args( $conditions, [ $prefix . 'hover_cursor' => 'yes' ] ),
			]
		);

		$this->add_responsive_control(
			$prefix . 'hover_cursor_vertical_alignment',
			[
				'label'                => esc_html__( 'Vertical Alignment', 'orvian-addons' ),
				'type'                 => Controls_Manager::CHOOSE,
				'options'              => [
					'top'    => [
						'title' => esc_html__( 'Top', 'orvian-addons' ),
						'icon'  => 'eicon-v-align-top',
					],
					'middle' => [
						'title' => esc_html__( 'Middle', 'orvian-addons' ),
						'icon'  => 'eicon-v-align-middle',
					],
					'bottom' => [
						'title' => esc_html__( 'Bottom', 'orvian-addons' ),
						'icon'  => 'eicon-v-align-bottom',
					],
				],
				'default'              => 'middle',
				'selectors_dictionary' => [
					'top'    => 'start',
					'middle' => 'center',
					'bottom' => 'end',
				],
				'selectors'            => [
					'.orvian-hover-cursor__' . esc_attr( $prefix ) . '{{ID}}' => '--content-vertical-alignment: {{VALUE}};',
				],
				'condition'            => wp_parse_args(
					$conditions,
					[
						$prefix . 'hover_cursor' => 'yes',
					]
				),
			]
		);

		$this->add_responsive_control(
			$prefix . 'hover_cursor_vertical_position',
			[
				'label'      => esc_html__( 'Adjust Vertical Position', 'orvian-addons' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%', 'em', 'rem', 'vw', 'custom' ],
				'selectors'  => [
					'.orvian-hover-cursor__' . esc_attr( $prefix ) . '{{ID}}' => '--icon-vertical-position: {{SIZE}}{{UNIT}};',
				],
				'condition'  => wp_parse_args(
					$conditions,
					[
						$prefix . 'hover_cursor'          => 'yes',
						$prefix . 'hover_cursor_position' => [ 'row', 'row-reverse' ],
					]
				),
			]
		);

		$this->add_responsive_control(
			$prefix . 'hover_cursor_alignment',
			[
				'label'     => esc_html__( 'Alignment', 'orvian-addons' ),
				'type'      => Controls_Manager::CHOOSE,
				'options'   => [
					'left'   => [
						'title' => esc_html__( 'Left', 'orvian-addons' ),
						'icon'  => 'eicon-text-align-left',
					],
					'center' => [
						'title' => esc_html__( 'Center', 'orvian-addons' ),
						'icon'  => 'eicon-text-align-center',
					],
					'right'  => [
						'title' => esc_html__( 'Right', 'orvian-addons' ),
						'icon'  => 'eicon-text-align-right',
					],
				],
				'default'   => 'center',
				'selectors' => [
					'.orvian-hover-cursor__' . esc_attr( $prefix ) . '{{ID}}' => '--text-align: {{VALUE}}',
				],
				'condition' => wp_parse_args( $conditions, [ $prefix . 'hover_cursor' => 'yes' ] ),
			]
		);

		$this->add_control(
			$prefix . 'hover_cursor_image_heading',
			[
				'label'     => esc_html__( 'Image', 'orvian-addons' ),
				'type'      => Controls_Manager::HEADING,
				'condition' => wp_parse_args(
					$conditions,
					[
						$prefix . 'hover_cursor'      => 'yes',
						$prefix . 'hover_cursor_type' => 'image',
					]
				),
				'separator' => 'before',
			]
		);

		$this->add_group_control(
			Group_Control_Image_Size::get_type(),
			[
				'name'      => $prefix . 'hover_cursor_image_size',
				'default'   => 'thumbnail',
				'separator' => 'none',
				'condition' => wp_parse_args(
					$conditions,
					[
						$prefix . 'hover_cursor'      => 'yes',
						$prefix . 'hover_cursor_type' => 'image',
					]
				),
			]
		);

		$this->add_control(
			$prefix . 'hover_cursor_icon_heading',
			[
				'label'     => esc_html__( 'Icon', 'orvian-addons' ),
				'type'      => Controls_Manager::HEADING,
				'condition' => wp_parse_args(
					$conditions,
					[
						$prefix . 'hover_cursor'      => 'yes',
						$prefix . 'hover_cursor_type' => 'icon',
					]
				),
				'separator' => 'before',
			]
		);

		$this->add_responsive_control(
			$prefix . 'hover_cursor_icon_size',
			[
				'label'      => esc_html__( 'Size', 'orvian-addons' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%', 'em', 'rem', 'vw', 'custom' ],
				'selectors'  => [
					'.orvian-hover-cursor__' . esc_attr( $prefix ) . '{{ID}} .orvian-hover-cursor__icon' => 'font-size: {{SIZE}}{{UNIT}};',
				],
				'condition'  => wp_parse_args(
					$conditions,
					[
						$prefix . 'hover_cursor'      => 'yes',
						$prefix . 'hover_cursor_type' => 'icon',
					]
				),
			]
		);

		$this->add_control(
			$prefix . 'hover_cursor_icon_color',
			[
				'label'     => esc_html__( 'Color', 'orvian-addons' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'.orvian-hover-cursor__' . esc_attr( $prefix ) . '{{ID}} .orvian-hover-cursor__icon' => 'color: {{VALUE}};',
				],
				'condition' => wp_parse_args(
					$conditions,
					[
						$prefix . 'hover_cursor'      => 'yes',
						$prefix . 'hover_cursor_type' => 'icon',
					]
				),
			]
		);

		$this->add_control(
			$prefix . 'hover_cursor_icon_background_color',
			[
				'label'     => esc_html__( 'Background Color', 'orvian-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selector'  => '.orvian-hover-cursor__' . esc_attr( $prefix ) . '{{ID}} .orvian-hover-cursor__icon',
				'condition' => wp_parse_args(
					$conditions,
					[
						$prefix . 'hover_cursor'      => 'yes',
						$prefix . 'hover_cursor_type' => 'icon',
					]
				),
			]
		);

		$this->add_responsive_control(
			$prefix . 'hover_cursor_icon_backdrop_filter',
			[
				'label'      => esc_html__( 'Backdrop Filter', 'orvian-addons' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px' ],
				'selectors'  => [
					'.orvian-hover-cursor__' . esc_attr( $prefix ) . '{{ID}} .orvian-hover-cursor__icon' => 'backdrop-filter: blur({{SIZE}}{{UNIT}});',
				],
				'condition'  => wp_parse_args(
					$conditions,
					[
						$prefix . 'hover_cursor'      => 'yes',
						$prefix . 'hover_cursor_type' => 'icon',
					]
				),
			]
		);

		$this->add_responsive_control(
			$prefix . 'hover_cursor_icon_width',
			[
				'label'      => esc_html__( 'Width', 'orvian-addons' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', 'em', 'rem' ],
				'selectors'  => [
					'.orvian-hover-cursor__' . esc_attr( $prefix ) . '{{ID}} .orvian-hover-cursor__icon' => 'width: {{SIZE}}{{UNIT}};',
				],
				'condition'  => wp_parse_args(
					$conditions,
					[
						$prefix . 'hover_cursor'      => 'yes',
						$prefix . 'hover_cursor_type' => 'icon',
					]
				),
			]
		);

		$this->add_responsive_control(
			$prefix . 'hover_cursor_icon_height',
			[
				'label'      => esc_html__( 'Height', 'orvian-addons' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', 'em', 'rem' ],
				'selectors'  => [
					'.orvian-hover-cursor__' . esc_attr( $prefix ) . '{{ID}} .orvian-hover-cursor__icon' => 'height: {{SIZE}}{{UNIT}};',
				],
				'condition'  => wp_parse_args(
					$conditions,
					[
						$prefix . 'hover_cursor'      => 'yes',
						$prefix . 'hover_cursor_type' => 'icon',
					]
				),
			]
		);

		$this->add_responsive_control(
			$prefix . 'hover_cursor_icon_border_radius',
			[
				'label'      => esc_html__( 'Border Radius', 'orvian-addons' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem', 'vw', 'custom' ],
				'selectors'  => [
					'.orvian-hover-cursor__' . esc_attr( $prefix ) . '{{ID}} .orvian-hover-cursor__icon' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'condition'  => wp_parse_args(
					$conditions,
					[
						$prefix . 'hover_cursor'      => 'yes',
						$prefix . 'hover_cursor_type' => 'icon',
					]
				),
			]
		);

		$this->add_control(
			$prefix . 'hover_cursor_text_heading',
			[
				'label'     => esc_html__( 'Text', 'orvian-addons' ),
				'type'      => Controls_Manager::HEADING,
				'condition' => wp_parse_args(
					$conditions,
					[
						$prefix . 'hover_cursor'       => 'yes',
						$prefix . 'hover_cursor_text!' => '',
					]
				),
				'separator' => 'before',
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'      => $prefix . 'hover_cursor_text_typography',
				'selector'  => '.orvian-hover-cursor__' . esc_attr( $prefix ) . '{{ID}} .orvian-hover-cursor__text',
				'condition' => wp_parse_args(
					$conditions,
					[
						$prefix . 'hover_cursor'       => 'yes',
						$prefix . 'hover_cursor_text!' => '',
					]
				),
			]
		);

		$this->add_control(
			$prefix . 'hover_cursor_text_color',
			[
				'label'     => esc_html__( 'Color', 'orvian-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'.orvian-hover-cursor__' . esc_attr( $prefix ) . '{{ID}} .orvian-hover-cursor__text' => 'color: {{VALUE}};',
				],
				'condition' => wp_parse_args(
					$conditions,
					[
						$prefix . 'hover_cursor'       => 'yes',
						$prefix . 'hover_cursor_text!' => '',
					]
				),
			]
		);

		$this->add_control(
			$prefix . 'hover_cursor_text_background_color',
			[
				'label'     => esc_html__( 'Background Color', 'orvian-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'.orvian-hover-cursor__' . esc_attr( $prefix ) . '{{ID}} .orvian-hover-cursor__text' => 'background-color: {{VALUE}};',
				],
				'condition' => wp_parse_args(
					$conditions,
					[
						$prefix . 'hover_cursor'       => 'yes',
						$prefix . 'hover_cursor_text!' => '',
					]
				),
			]
		);

		$this->add_responsive_control(
			$prefix . 'hover_cursor_text_padding',
			[
				'label'      => esc_html__( 'Padding', 'orvian-addons' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', 'rem', 'custom' ],
				'selectors'  => [
					'.orvian-hover-cursor__' . esc_attr( $prefix ) . '{{ID}} .orvian-hover-cursor__text' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'condition'  => wp_parse_args(
					$conditions,
					[
						$prefix . 'hover_cursor'       => 'yes',
						$prefix . 'hover_cursor_text!' => '',
					]
				),
			]
		);

		$this->add_responsive_control(
			$prefix . 'hover_cursor_text_border_radius',
			[
				'label'      => esc_html__( 'Border Radius', 'orvian-addons' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', 'rem', 'custom' ],
				'selectors'  => [
					'.orvian-hover-cursor__' . esc_attr( $prefix ) . '{{ID}} .orvian-hover-cursor__text' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'condition'  => wp_parse_args(
					$conditions,
					[
						$prefix . 'hover_cursor'       => 'yes',
						$prefix . 'hover_cursor_text!' => '',
					]
				),
			]
		);
	}

	/**
	 * Render hover cursor attributes for element
	 *
	 * @param string $prefix Prefix.
	 * @return void
	 */
	protected function render_hover_cursor_attributes( $prefix = '' ) {
		$settings = $this->get_settings_for_display();
		if ( isset( $settings[ $prefix . 'hover_cursor' ] ) && 'yes' === $settings[ $prefix . 'hover_cursor' ] ) {
			$widget_id = $this->get_id();
			$cursor_id = $prefix . $widget_id;
			printf( 'hover-cursor hover-cursor-data="%s"', esc_attr( $cursor_id ) );
		}
	}

	/**
	 * Render hover cursor template
	 *
	 * Output hidden template for theme's hover-cursor base to use
	 *
	 * @param string $prefix Prefix.
	 */
	protected function render_hover_cursor_template( $prefix = '' ) {
		$settings = $this->get_settings_for_display();
		if ( ! isset( $settings[ $prefix . 'hover_cursor' ] ) || 'yes' !== $settings[ $prefix . 'hover_cursor' ] ) {
			return;
		}

		$widget_id = $this->get_id();
		$cursor_id = $prefix . $widget_id;

		$this->add_render_attribute( 'hover_cursor_text_elementor', 'class', [ 'orvian-hover-cursor__' . esc_attr( $cursor_id ), 'orvian-hover-cursor--elementor', 'inline-flex' ] );
		if ( ! empty( $this->get_hover_cursor_classes() ) ) {
			$this->add_render_attribute( 'hover_cursor_text_elementor', 'class', $this->get_hover_cursor_classes() );
		}

		$this->add_render_attribute( 'hover_cursor_text', 'class', [ 'orvian-hover-cursor__text', 'text-body-1', 'text-white', 'shrink-0' ] );
		$hover_cursor_text_size = $this->resolve_text_tag( $settings['hover_cursor_text_size'], 'hover_cursor_text' );
		?>
		<template hover-cursor-data="<?php echo esc_attr( $cursor_id ); ?>">
			<div <?php $this->print_render_attribute_string( 'hover_cursor_text_elementor' ); ?>>
				<?php
				if ( 'icon' === $settings[ $prefix . 'hover_cursor_type' ] && ! empty( $settings[ $prefix . 'hover_cursor_icon' ] ) ) {
					?>
					<div class="orvian-hover-cursor__icon inline-flex items-center justify-center shrink-0 text-white mb-2">
						<span class="orvian-svg-icon">
							<?php Icons_Manager::render_icon( $settings[ $prefix . 'hover_cursor_icon' ], [ 'aria-hidden' => 'true' ] ); ?>
						</span>
					</div>
					<?php
				} elseif ( 'image' === $settings[ $prefix . 'hover_cursor_type' ] && ! empty( $settings[ $prefix . 'hover_cursor_image' ]['url'] ) ) {
					?>
					<div class="orvian-hover-cursor__image shrink-0">
						<?php echo Group_Control_Image_Size::get_attachment_image_html( $settings, $prefix . 'hover_cursor_image_size', $prefix . 'hover_cursor_image' ); // phpcs:ignore ?>
					</div>
					<?php
				}

				if ( ! empty( $settings[ $prefix . 'hover_cursor_text' ] ) ) {
					?>
					<<?php echo esc_attr( $hover_cursor_text_size ); ?> <?php $this->print_render_attribute_string( 'hover_cursor_text' ); ?> hover-cursor-text>
						<?php echo wp_kses_post( nl2br( $settings[ $prefix . 'hover_cursor_text' ] ) ); ?>
					</<?php echo esc_attr( $hover_cursor_text_size ); ?>>
					<?php
				}
				?>
			</div>
		</template>
		<?php
	}

	/**
	 * Get hover cursor classes
	 *
	 * @return array
	 */
	protected function get_hover_cursor_classes() {
		return [];
	}
}
