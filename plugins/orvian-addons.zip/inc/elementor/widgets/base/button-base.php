<?php
/**
 * Button Base
 *
 * @package OrvianAddons
 */

namespace OrvianAddons\Elementor\Widgets\Base;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Box_Shadow;
use OrvianAddons\Helper;

/**
 * Button Base Class
 *
 * @mixin \Elementor\Widget_Base
 */
trait Button_Base {

	/**
	 * Register button controls.
	 *
	 * @param string $prefix Control prefix.
	 * @param object $control Control.
	 */
	public function register_button_controls( $prefix = '', $control = null ) {
		if ( null === $control ) {
			$control = $this;
		}

		$control->add_control(
			$prefix . 'button_style',
			[
				'label'   => esc_html__( 'Button Style', 'orvian-addons' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'default',
				'options' => [
					'default' => esc_html__( 'Default', 'orvian-addons' ),
					'primary' => esc_html__( 'Primary', 'orvian-addons' ),
					'icon'    => esc_html__( 'Icon', 'orvian-addons' ),
				],
			]
		);

		$control->add_control(
			$prefix . 'button_primary_type',
			[
				'label'     => esc_html__( 'Button Primary Type', 'orvian-addons' ),
				'type'      => Controls_Manager::SELECT,
				'default'   => '',
				'options'   => [
					''        => esc_html__( 'Default', 'orvian-addons' ),
					'reverse' => esc_html__( 'Reverse', 'orvian-addons' ),
				],
				'condition' => [
					$prefix . 'button_style' => 'primary',
				],
			]
		);

		$control->add_control(
			$prefix . 'button_size',
			[
				'label'     => esc_html__( 'Size', 'orvian-addons' ),
				'type'      => Controls_Manager::SELECT,
				'default'   => 'default',
				'options'   => [
					'default' => esc_html__( 'Default', 'orvian-addons' ),
					'small'   => esc_html__( 'Small', 'orvian-addons' ),
				],
				'condition' => [
					$prefix . 'button_style' => 'primary',
				],
			]
		);

		$control->add_control(
			$prefix . 'button_text',
			[
				'label'       => esc_html__( 'Button Text', 'orvian-addons' ),
				'type'        => Controls_Manager::TEXT,
				'default'     => esc_html__( 'Click Here', 'orvian-addons' ),
				'placeholder' => esc_html__( 'Enter button text', 'orvian-addons' ),
				'label_block' => true,
				'condition'   => [
					$prefix . 'button_style!' => 'icon',
				],
			]
		);

		$control->add_control(
			$prefix . 'button_use_font_heading',
			[
				'label'     => esc_html__( 'Button Text Use Font Family of Heading', 'orvian-addons' ),
				'type'      => Controls_Manager::SWITCHER,
				'condition' => [
					$prefix . 'button_style!' => 'icon',
				],
			]
		);

		$control->add_control(
			$prefix . 'button_show_icon',
			[
				'label'     => esc_html__( 'Show Icon', 'orvian-addons' ),
				'type'      => Controls_Manager::SWITCHER,
				'default'   => 'yes',
				'condition' => [
					$prefix . 'button_style' => 'primary',
				],
			]
		);

		$control->add_control(
			$prefix . 'button_primary_icon',
			[
				'label'       => esc_html__( 'Icon', 'orvian-addons' ),
				'type'        => Controls_Manager::ICONS,
				'condition'   => [
					$prefix . 'button_style'     => 'primary',
					$prefix . 'button_show_icon' => 'yes',
				],
				'label_block' => true,
			]
		);

		$control->add_control(
			$prefix . 'button_icon_type',
			[
				'label'     => esc_html__( 'Icon Type', 'orvian-addons' ),
				'type'      => Controls_Manager::SELECT,
				'default'   => 'default',
				'options'   => [
					'default' => esc_html__( 'Default', 'orvian-addons' ),
					'border'  => esc_html__( 'Border', 'orvian-addons' ),
				],
				'condition' => [
					$prefix . 'button_style' => 'icon',
				],
			]
		);

		$control->add_control(
			$prefix . 'button_icon',
			[
				'label'       => esc_html__( 'Icon', 'orvian-addons' ),
				'type'        => Controls_Manager::ICONS,
				'default'     => [
					'value'   => 'fa fa-star',
					'library' => 'fa-solid',
				],
				'condition'   => [
					$prefix . 'button_style' => 'icon',
				],
				'label_block' => true,
			]
		);

		$control->add_control(
			$prefix . 'button_link',
			[
				'label'       => esc_html__( 'Link', 'orvian-addons' ),
				'type'        => Controls_Manager::URL,
				'placeholder' => esc_html__( 'https://your-link.com', 'orvian-addons' ),
				'default'     => [
					'url' => '',
				],
			]
		);

		$control->add_responsive_control(
			$prefix . 'button_alignment',
			[
				'label'     => esc_html__( 'Alignment', 'orvian-addons' ),
				'type'      => Controls_Manager::CHOOSE,
				'options'   => [
					'left'   => [
						'title' => esc_html__( 'Left', 'orvian-addons' ),
						'icon'  => 'eicon-text-align-left',
					],
					'center' => [
						'title' => esc_html__( 'Center', 'orvian-addons' ),
						'icon'  => 'eicon-text-align-center',
					],
					'right'  => [
						'title' => esc_html__( 'Right', 'orvian-addons' ),
						'icon'  => 'eicon-text-align-right',
					],
				],
				'default'   => 'left',
				'selectors' => [
					'{{WRAPPER}}' => 'text-align: {{VALUE}};',
				],
			]
		);
	}

	/**
	 * Register heading widget controls.
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @param string $prefix Prefix.
	 * @param object $control Control.
	 * @param string $classes Classes.
	 */
	protected function register_button_controls_style( $prefix = '', $control = null, $classes = null ) {
		if ( ! $control ) {
			$control = $this;
		}

		$control->add_responsive_control(
			$prefix . 'button_icon_width',
			[
				'label'      => esc_html__( 'Width', 'orvian-addons' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', 'em', 'custom' ],
				'selectors'  => [
					'{{WRAPPER}} .button-icon' . esc_attr( ! empty( $classes ) ? '.' . $classes : null ) => '--button-icon-width: {{SIZE}}{{UNIT}};',
				],
				'condition'  => [
					$prefix . 'button_style' => 'icon',
				],
			]
		);

		$control->add_responsive_control(
			$prefix . 'button_icon_height',
			[
				'label'      => esc_html__( 'Height', 'orvian-addons' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', 'em', 'custom' ],
				'selectors'  => [
					'{{WRAPPER}} .button-icon' . esc_attr( ! empty( $classes ) ? '.' . $classes : null ) => '--button-icon-height: {{SIZE}}{{UNIT}};',
				],
				'condition'  => [
					$prefix . 'button_style' => 'icon',
				],
			]
		);

		$control->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => $prefix . 'button_typography',
				'selector' => '{{WRAPPER}} .orvian-button' . esc_attr( ! empty( $classes ) ? '.' . $classes : null ),
			]
		);

		$control->add_responsive_control(
			$prefix . 'button_padding',
			[
				'label'      => esc_html__( 'Padding', 'orvian-addons' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', 'custom' ],
				'selectors'  => [
					'{{WRAPPER}} .orvian-button' . esc_attr( ! empty( $classes ) ? '.' . $classes : null ) => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'condition'  => [
					$prefix . 'button_style' => 'default',
				],
			]
		);

		$control->add_responsive_control(
			$prefix . 'button_border_radius',
			[
				'label'      => esc_html__( 'Border Radius', 'orvian-addons' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', 'custom' ],
				'selectors'  => [
					'{{WRAPPER}} .orvian-button' . esc_attr( ! empty( $classes ) ? '.' . $classes : null ) => '--button-border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$control->start_controls_tabs( $prefix . 'button_tabs' );

		$control->start_controls_tab(
			$prefix . 'tab_button_normal',
			[
				'label' => esc_html__( 'Normal', 'orvian-addons' ),
			]
		);

		$control->add_control(
			$prefix . 'button_color',
			[
				'label'     => esc_html__( 'Color', 'orvian-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .orvian-button' . esc_attr( ! empty( $classes ) ? '.' . $classes : null ) . ':not(:hover)' => 'color: {{VALUE}};',
				],
			]
		);

		$control->add_control(
			$prefix . 'button_background_color',
			[
				'label'     => esc_html__( 'Background Color', 'orvian-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .orvian-button' . esc_attr( ! empty( $classes ) ? '.' . $classes : null ) . ':not(:hover)' => 'background-color: {{VALUE}};',
				],
			]
		);

		$control->add_control(
			$prefix . 'button_backdrop_blur',
			[
				'label'      => esc_html__( 'Backdrop Blur', 'orvian-addons' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px' ],
				'selectors'  => [
					'{{WRAPPER}} .orvian-button' . esc_attr( ! empty( $classes ) ? '.' . $classes : null ) . ':not(:hover)' => 'backdrop-filter: blur({{SIZE}}px);',
				],
				'condition'  => [
					$prefix . 'button_style' => 'default',
				],
			]
		);

		$control->add_control(
			$prefix . 'button_border_color',
			[
				'label'     => esc_html__( 'Border Color', 'orvian-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .orvian-button' . esc_attr( ! empty( $classes ) ? '.' . $classes : null ) . ':not(:hover)' => 'border-color: {{VALUE}};',
				],
			]
		);

		$control->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'     => $prefix . 'button_box_shadow',
				'selector' => '{{WRAPPER}} .orvian-button' . esc_attr( ! empty( $classes ) ? '.' . $classes : null ) . ':not(:hover)',
			]
		);

		$control->end_controls_tab();

		$control->start_controls_tab(
			$prefix . 'tab_button_hover',
			[
				'label' => esc_html__( 'Hover', 'orvian-addons' ),
			]
		);

		$control->add_control(
			$prefix . 'button_color_hover',
			[
				'label'     => esc_html__( 'Color', 'orvian-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .orvian-button' . esc_attr( ! empty( $classes ) ? '.' . $classes : null ) . ':hover' => 'color: {{VALUE}};',
				],
			]
		);

		$control->add_control(
			$prefix . 'button_background_color_hover',
			[
				'label'     => esc_html__( 'Background Color', 'orvian-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .orvian-button' . esc_attr( ! empty( $classes ) ? '.' . $classes : null ) . ':hover' => 'background-color: {{VALUE}};',
				],
			]
		);

		$control->add_control(
			$prefix . 'button_backdrop_blur_hover',
			[
				'label'      => esc_html__( 'Backdrop Blur', 'orvian-addons' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px' ],
				'selectors'  => [
					'{{WRAPPER}} .orvian-button' . esc_attr( ! empty( $classes ) ? '.' . $classes : null ) . ':hover' => 'backdrop-filter: blur({{SIZE}}px);',
				],
				'condition'  => [
					$prefix . 'button_style' => 'default',
				],
			]
		);

		$control->add_control(
			$prefix . 'button_border_color_hover',
			[
				'label'     => esc_html__( 'Border Color', 'orvian-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .orvian-button' . esc_attr( ! empty( $classes ) ? '.' . $classes : null ) . ':hover' => 'border-color: {{VALUE}};',
				],
			]
		);

		$control->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'     => $prefix . 'button_box_shadow_hover',
				'selector' => '{{WRAPPER}} .orvian-button' . esc_attr( ! empty( $classes ) ? '.' . $classes : null ) . ':hover',
			]
		);

		$control->end_controls_tab();

		$control->end_controls_tabs();

		$control->add_control(
			$prefix . 'button_icon_heading',
			[
				'label'     => esc_html__( 'Icon', 'orvian-addons' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
				'condition' => [
					$prefix . 'button_style' => [ 'primary', 'icon' ],
				],
			]
		);

		$control->add_responsive_control(
			$prefix . 'button_icon_size',
			[
				'label'      => esc_html__( 'Size', 'orvian-addons' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', 'em', 'custom' ],
				'selectors'  => [
					'{{WRAPPER}} .button-icon' . esc_attr( ! empty( $classes ) ? '.' . $classes : null ) => '--button-font-size: {{SIZE}}{{UNIT}};',
				],
				'condition'  => [
					$prefix . 'button_style' => 'icon',
				],
			]
		);

		$control->add_responsive_control(
			$prefix . 'button_has_icon_size',
			[
				'label'      => esc_html__( 'Size', 'orvian-addons' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', 'em', 'custom' ],
				'selectors'  => [
					'{{WRAPPER}} .button-has-icon' . esc_attr( ! empty( $classes ) ? '.' . $classes : null ) => '--button-has-icon-size: {{SIZE}}{{UNIT}};',
				],
				'condition'  => [
					$prefix . 'button_style' => 'primary',
				],
			]
		);

		$control->add_responsive_control(
			$prefix . 'button_has_icon_border_radius',
			[
				'label'      => esc_html__( 'Border Radius', 'orvian-addons' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', 'rem', 'custom' ],
				'selectors'  => [
					'{{WRAPPER}} .button-has-icon' . esc_attr( ! empty( $classes ) ? '.' . $classes : null ) => '--button-has-icon-border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'condition'  => [
					$prefix . 'button_style' => 'primary',
				],
			]
		);

		$control->start_controls_tabs( $prefix . 'button_has_icon_tabs' );

		$control->start_controls_tab(
			$prefix . 'tab_button_has_icon_normal',
			[
				'label'     => esc_html__( 'Normal', 'orvian-addons' ),
				'condition' => [
					$prefix . 'button_style' => 'primary',
				],
			]
		);

		$control->add_control(
			$prefix . 'button_has_icon_color',
			[
				'label'     => esc_html__( 'Color', 'orvian-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .button-has-icon' . esc_attr( ! empty( $classes ) ? '.' . $classes : null ) . ' .orvian-svg-icon' => 'color: {{VALUE}};',
				],
				'condition' => [
					$prefix . 'button_style' => 'primary',
				],
			]
		);

		$control->add_control(
			$prefix . 'button_has_icon_background_color',
			[
				'label'     => esc_html__( 'Background Color', 'orvian-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .button-has-icon' . esc_attr( ! empty( $classes ) ? '.' . $classes : null ) . ' .orvian-svg-icon' => 'background-color: {{VALUE}};',
				],
				'condition' => [
					$prefix . 'button_style' => 'primary',
				],
			]
		);

		$control->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'      => $prefix . 'button_has_icon_box_shadow',
				'selector'  => '{{WRAPPER}} .button-has-icon' . esc_attr( ! empty( $classes ) ? '.' . $classes : null ) . ' .orvian-svg-icon',
				'condition' => [
					$prefix . 'button_style' => 'primary',
				],
			]
		);

		$control->end_controls_tab();

		$control->start_controls_tab(
			$prefix . 'tab_button_has_icon_hover',
			[
				'label'     => esc_html__( 'Hover', 'orvian-addons' ),
				'condition' => [
					$prefix . 'button_style' => 'primary',
				],
			]
		);

		$control->add_control(
			$prefix . 'button_has_icon_color_hover',
			[
				'label'     => esc_html__( 'Color', 'orvian-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .button-has-icon' . esc_attr( ! empty( $classes ) ? '.' . $classes : null ) . ':hover .orvian-svg-icon' => 'color: {{VALUE}};',
				],
				'condition' => [
					$prefix . 'button_style' => 'primary',
				],
			]
		);

		$control->add_control(
			$prefix . 'button_has_icon_background_color_hover',
			[
				'label'     => esc_html__( 'Background Color', 'orvian-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .button-has-icon' . esc_attr( ! empty( $classes ) ? '.' . $classes : null ) . ':hover .orvian-svg-icon' => 'background-color: {{VALUE}};',
				],
				'condition' => [
					$prefix . 'button_style' => 'primary',
				],
			]
		);

		$control->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'      => $prefix . 'button_has_icon_box_shadow_hover',
				'selector'  => '{{WRAPPER}} .button-has-icon' . esc_attr( ! empty( $classes ) ? '.' . $classes : null ) . ':hover .orvian-svg-icon',
				'condition' => [
					$prefix . 'button_style' => 'primary',
				],
			]
		);

		$control->end_controls_tab();

		$control->end_controls_tabs();
	}

	/**
	 * Render button.
	 *
	 * @param array  $settings Settings.
	 * @param string $prefix Prefix.
	 * @param string $classes Classes.
	 */
	protected function button_render( $settings = [], $prefix = '', $classes = null ) {
		if ( empty( $settings ) ) {
			$settings = $this->get_settings_for_display();
		}

		if ( ! empty( $settings[ $prefix . 'button_link' ]['url'] ) ) {
			$this->add_link_attributes( $prefix . 'button', $settings[ $prefix . 'button_link' ] );
		}

		$button_class = 'orvian-button ' . esc_attr( $classes );
		if ( 'primary' === $settings[ $prefix . 'button_style' ] ) {
			if ( empty( $settings[ $prefix . 'button_primary_type' ] ) ) {
				$button_class .= ' button-primary';
			} else {
				$button_class .= ' button-primary--reverse';
			}

			if ( 'yes' === $settings[ $prefix . 'button_show_icon' ] ) {
				$button_class .= ' button-has-icon';
			}
			if ( 'small' === $settings[ $prefix . 'button_size' ] ) {
				$button_class .= ' button-primary--small';
			}
		}

		if ( 'icon' === $settings[ $prefix . 'button_style' ] ) {
			$button_class .= ' button-icon';
			if ( 'border' === $settings[ $prefix . 'button_icon_type' ] ) {
				$button_class .= ' button-icon--border';
			}
		}

		$this->add_render_attribute(
			'button',
			[
				'class' => $button_class,
			]
		);

		$tag = ! empty( $settings[ $prefix . 'button_link' ]['url'] ) ? 'a' : 'button';

		?>
		<<?php echo esc_attr( $tag ); ?> <?php $this->print_render_attribute_string( $prefix . 'button' ); ?>>
			<?php if ( 'icon' === $settings[ $prefix . 'button_style' ] ) { ?>
				<?php
				if ( ! empty( $settings[ $prefix . 'button_icon' ]['value'] ) ) {
					?>
					<span class="orvian-svg-icon">
					<?php
					\Elementor\Icons_Manager::render_icon(
						$settings[ $prefix . 'button_icon' ],
						[
							'aria-hidden' => 'true',
							'fill'        => 'currentColor',
						]
					);
					?>
					</span>
					<?php
				} else {
					// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
					echo Helper::get_svg( 'arrow-up-right' );
				}
				?>
			<?php } elseif ( 'primary' === $settings[ $prefix . 'button_style' ] && 'yes' === $settings[ $prefix . 'button_show_icon' ] ) { ?>
				<span class="button-text <?php echo isset( $settings[ $prefix . 'button_use_font_heading' ] ) && 'yes' === $settings[ $prefix . 'button_use_font_heading' ] ? 'font-heading' : ''; ?>"><?php echo esc_html( $settings[ $prefix . 'button_text' ] ); ?></span>
				<?php
				if ( ! empty( $settings[ $prefix . 'button_primary_icon' ]['value'] ) ) {
					?>
					<span class="orvian-svg-icon">
					<?php
					\Elementor\Icons_Manager::render_icon(
						$settings[ $prefix . 'button_primary_icon' ],
						[
							'aria-hidden' => 'true',
							'fill'        => 'currentColor',
						]
					);
					?>
					</span>
					<?php
				} else {
					// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
					echo Helper::get_svg( 'arrow-up-right' );
				}
				?>
			<?php } elseif ( 'primary' === $settings[ $prefix . 'button_style' ] && 'no' === $settings[ $prefix . 'button_show_icon' ] ) { ?>
				<span class="button-text <?php echo isset( $settings[ $prefix . 'button_use_font_heading' ] ) && 'yes' === $settings[ $prefix . 'button_use_font_heading' ] ? 'font-heading' : ''; ?>"><?php echo esc_html( $settings[ $prefix . 'button_text' ] ); ?></span>
			<?php } else { ?>
				<span class="button-text <?php echo isset( $settings[ $prefix . 'button_use_font_heading' ] ) && 'yes' === $settings[ $prefix . 'button_use_font_heading' ] ? 'font-heading' : ''; ?>"><?php echo esc_html( $settings[ $prefix . 'button_text' ] ); ?></span>
			<?php } ?>
		</<?php echo esc_attr( $tag ); ?>>
		<?php
	}
}
