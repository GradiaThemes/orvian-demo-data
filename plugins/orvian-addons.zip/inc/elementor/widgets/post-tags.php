<?php
/**
 * Post Tags Widget
 *
 * @package OrvianAddons
 */

namespace OrvianAddons\Elementor\Widgets;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use OrvianAddons\Elementor\Elementor as OrvianAddons_Elementor;
use OrvianAddons\Admin\Portfolio;

/**
 * Post Tags Widget Class
 */
class Post_Tags extends Widget_Base {

	/**
	 * Get widget name
	 *
	 * @return string
	 */
	public function get_name() {
		return 'orvian-post-tags';
	}

	/**
	 * Get widget title
	 *
	 * @return string
	 */
	public function get_title() {
		return esc_html__( 'Post Tags', 'orvian-addons' );
	}

	/**
	 * Get widget icon
	 *
	 * @return string
	 */
	public function get_icon() {
		return 'eicon-tags ' . OrvianAddons_Elementor::CLASS_WIDGET;
	}

	/**
	 * Get widget categories
	 *
	 * @return array
	 */
	public function get_categories() {
		return [ OrvianAddons_Elementor::CATEGORY ];
	}

	/**
	 * Get widget keywords
	 *
	 * @return array
	 */
	public function get_keywords() {
		return [ 'orvian', 'post', 'tags', 'categories' ];
	}

	/**
	 * Register widget controls
	 */
	protected function register_controls() {
		$this->start_controls_section(
			'content_section',
			[
				'label' => esc_html__( 'Post Tags', 'orvian-addons' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'post_type',
			[
				'label'   => esc_html__( 'Post Type', 'orvian-addons' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'post',
				'options' => [
					'post'      => esc_html__( 'Post', 'orvian-addons' ),
					'portfolio' => esc_html__( 'Portfolio', 'orvian-addons' ),
				],
			]
		);

		$this->add_control(
			'post_id_post',
			[
				'label'       => esc_html__( 'Post ID', 'orvian-addons' ),
				'type'        => 'orvian-autocomplete',
				'source'      => 'post',
				'multiple'    => false,
				'label_block' => true,
				'condition'   => [
					'post_type' => 'post',
				],
			]
		);

		$this->add_control(
			'post_id_portfolio',
			[
				'label'       => esc_html__( 'Post ID', 'orvian-addons' ),
				'type'        => 'orvian-autocomplete',
				'source'      => Portfolio::POST_TYPE,
				'multiple'    => false,
				'label_block' => true,
				'condition'   => [
					'post_type' => 'portfolio',
				],
			]
		);

		$this->add_control(
			'taxonomy_post',
			[
				'label'     => esc_html__( 'Taxonomy', 'orvian-addons' ),
				'type'      => Controls_Manager::SELECT,
				'default'   => 'post_tag',
				'options'   => [
					'post_tag' => esc_html__( 'Tags', 'orvian-addons' ),
					'category' => esc_html__( 'Categories', 'orvian-addons' ),
				],
				'condition' => [
					'post_type' => 'post',
				],
			]
		);

		$this->add_control(
			'taxonomy_portfolio',
			[
				'label'     => esc_html__( 'Taxonomy', 'orvian-addons' ),
				'type'      => Controls_Manager::SELECT,
				'default'   => 'portfolio_tag',
				'options'   => [
					'portfolio_tag'   => esc_html__( 'Tag', 'orvian-addons' ),
					'portfolio_type'  => esc_html__( 'Type', 'orvian-addons' ),
					'portfolio_brand' => esc_html__( 'Brand', 'orvian-addons' ),
				],
				'condition' => [
					'post_type' => 'portfolio',
				],
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'style_section',
			[
				'label' => esc_html__( 'Style', 'orvian-addons' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_responsive_control(
			'alignment',
			[
				'label'     => esc_html__( 'Alignment', 'orvian-addons' ),
				'type'      => Controls_Manager::CHOOSE,
				'options'   => [
					'left'   => [
						'title' => esc_html__( 'Left', 'orvian-addons' ),
						'icon'  => 'eicon-text-align-left',
					],
					'center' => [
						'title' => esc_html__( 'Center', 'orvian-addons' ),
						'icon'  => 'eicon-text-align-center',
					],
					'right'  => [
						'title' => esc_html__( 'Right', 'orvian-addons' ),
						'icon'  => 'eicon-text-align-right',
					],
				],
				'default'   => 'center',
				'selectors' => [
					'{{WRAPPER}} .orvian-tags--elementor' => 'justify-content: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'tags_color',
			[
				'label'     => esc_html__( 'Color', 'orvian-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .orvian-tags--elementor > *' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'tags_background_color',
			[
				'label'     => esc_html__( 'Background Color', 'orvian-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .orvian-tags--elementor > *' => 'background-color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'tags_hover_color',
			[
				'label'     => esc_html__( 'Hover Color', 'orvian-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .orvian-tags--elementor > *:hover' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'tags_hover_background_color',
			[
				'label'     => esc_html__( 'Hover Background Color', 'orvian-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .orvian-tags--elementor > *:hover' => 'background-color: {{VALUE}};',
				],
			]
		);

		$this->end_controls_section();
	}

	/**
	 * Render widget output
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();

		$post_type   = ! empty( $settings['post_type'] ) ? $settings['post_type'] : 'post';
		$post_id_key = 'post' === $post_type ? 'post_id_post' : 'post_id_portfolio';
		$post_id     = ! empty( $settings[ $post_id_key ] ) ? absint( $settings[ $post_id_key ] ) : 0;

		if ( empty( $post_id ) ) {
			$post_id = get_the_ID();
		}

		if ( empty( $post_id ) ) {
			return;
		}

		$taxonomy = 'post' === $post_type
			? ( ! empty( $settings['taxonomy_post'] ) ? $settings['taxonomy_post'] : 'post_tag' )
			: ( ! empty( $settings['taxonomy_portfolio'] ) ? $settings['taxonomy_portfolio'] : 'portfolio_tag' );

		if ( ! has_term( '', $taxonomy, $post_id ) ) {
			return;
		}

		$classes = [
			'orvian-tags',
			'orvian-tags--small',
			'orvian-tags--elementor',
			'flex',
			'flex-wrap',
			'gap-2',
		];

		printf(
			'<div class="%s">%s</div>',
			esc_attr( implode( ' ', $classes ) ),
			get_the_term_list( $post_id, $taxonomy, '', '', '' )
		);
	}
}
