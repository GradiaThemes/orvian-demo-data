<?php
/**
 * Image Accordion Widget
 *
 * @package OrvianAddons
 */

namespace OrvianAddons\Elementor\Widgets;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Repeater;
use OrvianAddons\Elementor\Elementor as OrvianAddons_Elementor;

/**
 * Image Accordion Widget Class
 */
class Image_Accordion extends Widget_Base {

	use Base\Text_Class;

	/**
	 * Get widget name
	 *
	 * @return string
	 */
	public function get_name() {
		return 'orvian-image-accordion';
	}

	/**
	 * Get widget title
	 *
	 * @return string
	 */
	public function get_title() {
		return esc_html__( 'Image Accordion', 'orvian-addons' );
	}

	/**
	 * Get widget icon
	 *
	 * @return string
	 */
	public function get_icon() {
		return 'eicon-accordion ' . OrvianAddons_Elementor::CLASS_WIDGET;
	}

	/**
	 * Get widget categories
	 *
	 * @return array
	 */
	public function get_categories() {
		return [ OrvianAddons_Elementor::CATEGORY ];
	}

	/**
	 * Get widget keywords
	 *
	 * @return array
	 */
	public function get_keywords() {
		return [ 'orvian', 'image-accordion', 'accordion', 'faq', 'toggle' ];
	}

	/**
	 * Register widget controls
	 */
	protected function register_controls() {
		$this->start_controls_section(
			'content_section',
			[
				'label' => esc_html__( 'Image Accordion', 'orvian-addons' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);

		$repeater = new Repeater();

		$repeater->add_control(
			'title',
			[
				'label'   => esc_html__( 'Title', 'orvian-addons' ),
				'type'    => Controls_Manager::TEXT,
				'dynamic' => [
					'active' => true,
				],
			]
		);

		$repeater->add_control(
			'thumbnail',
			[
				'label'   => esc_html__( 'Thumbnail', 'orvian-addons' ),
				'type'    => Controls_Manager::MEDIA,
				'dynamic' => [
					'active' => true,
				],
			]
		);

		$repeater->add_control(
			'orvian_tags',
			[
				'label' => esc_html__( 'Tags', 'orvian-addons' ),
				'type'  => 'orvian-tags',
			]
		);

		$repeater->add_control(
			'gallery',
			[
				'label'      => esc_html__( 'Gallery', 'orvian-addons' ),
				'type'       => Controls_Manager::GALLERY,
				'show_label' => false,
				'dynamic'    => [
					'active' => true,
				],
			]
		);

		$repeater->add_control(
			'content',
			[
				'label'   => esc_html__( 'Content', 'orvian-addons' ),
				'type'    => Controls_Manager::WYSIWYG,
				'dynamic' => [
					'active' => true,
				],
			]
		);

		$this->add_control(
			'accordion_items',
			[
				'label'       => esc_html__( 'Accordion Items', 'orvian-addons' ),
				'type'        => Controls_Manager::REPEATER,
				'fields'      => $repeater->get_controls(),
				'default'     => [
					[
						'title'   => esc_html__( 'Accordion Item #1', 'orvian-addons' ),
						'content' => esc_html__( 'Accordion Item Content #1', 'orvian-addons' ),
					],
					[
						'title'   => esc_html__( 'Accordion Item #2', 'orvian-addons' ),
						'content' => esc_html__( 'Accordion Item Content #2', 'orvian-addons' ),
					],
				],
				'title_field' => '{{{ title }}}',
			]
		);

		$this->add_control(
			'layout',
			[
				'label'     => esc_html__( 'Layout', 'orvian-addons' ),
				'type'      => Controls_Manager::SELECT,
				'options'   => [
					'single-column'    => esc_html__( 'Single Column', 'orvian-addons' ),
					'two-column-left'  => esc_html__( 'Two Column (Thumbnail Left)', 'orvian-addons' ),
					'two-column-right' => esc_html__( 'Two Column (Thumbnail Right)', 'orvian-addons' ),
				],
				'default'   => 'two-column-left',
				'separator' => 'before',
			]
		);

		$this->add_control(
			'title_html_tag',
			[
				'label'     => esc_html__( 'Title HTML Tag', 'orvian-addons' ),
				'type'      => Controls_Manager::SELECT,
				'options'   => $this->get_text_class_options_with_tags(),
				'default'   => 'text-display-3',
				'separator' => 'before',
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'section_thumbnail_style',
			[
				'label' => esc_html__( 'Thumbnail', 'orvian-addons' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_responsive_control(
			'thumbnail_aspect_ratio',
			[
				'label'       => esc_html__( 'Aspect Ratio (width/height)', 'orvian-addons' ),
				'type'        => Controls_Manager::TEXT,
				'placeholder' => '16/9',
				'selectors'   => [
					'{{WRAPPER}} .orvian-image-accordion__thumbnail img' => 'aspect-ratio: {{VALUE}};',
					'{{WRAPPER}} .orvian-image-accordion__thumbnails img' => 'aspect-ratio: {{VALUE}};',
				],
			]
		);

		$this->add_responsive_control(
			'thumbnail_border_radius',
			[
				'label'      => esc_html__( 'Border Radius', 'orvian-addons' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem' ],
				'selectors'  => [
					'{{WRAPPER}} .orvian-image-accordion__thumbnail img' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					'{{WRAPPER}} .orvian-image-accordion__thumbnails' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'section_gallery_style',
			[
				'label' => esc_html__( 'Gallery', 'orvian-addons' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_responsive_control(
			'gallery_border_radius',
			[
				'label'      => esc_html__( 'Border Radius', 'orvian-addons' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem' ],
				'selectors'  => [
					'{{WRAPPER}} .orvian-image-accordion__gallery span' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();
	}

	/**
	 * Render widget output
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();

		if ( empty( $settings['accordion_items'] ) ) {
			return;
		}

		$layout = $settings['layout'];

		$layout_classes = [
			'orvian-image-accordion',
			'orvian-image-accordion--' . $layout,
		];

		if ( in_array( $layout, [ 'two-column-left', 'two-column-right' ], true ) ) {
			$layout_classes[] = 'flex';
			$layout_classes[] = 'flex-col';
			$layout_classes[] = 'gap-6';

			if ( 'two-column-left' === $layout ) {
				$layout_classes[] = 'lg:flex-row';
			}

			if ( 'two-column-right' === $layout ) {
				$layout_classes[] = 'lg:flex-row-reverse';
			}
		}

		$this->add_render_attribute( 'wrapper', 'class', $layout_classes );
		$this->add_render_attribute( 'title', 'class', [ 'orvian-image-accordion__title', 'm-0', 'uppercase', 'text-heading', 'font-medium' ] );

		$title_tag = $this->resolve_text_tag( $settings['title_html_tag'], 'title' );

		$this->add_inline_editing_attributes( 'title' );

		?>
		<div <?php $this->print_render_attribute_string( 'wrapper' ); ?>>
			<?php if ( 'single-column' !== $layout ) : ?>
				<div class="orvian-image-accordion__thumbnails hidden lg:block relative h-full rounded-lg overflow-hidden">
					<?php foreach ( $settings['accordion_items'] as $index => $item ) : ?>
						<?php if ( ! empty( $item['thumbnail']['url'] ) ) : ?>
							<span class="block ratio-image <?php echo 0 === $index ? 'open relative' : 'absolute inset-0'; ?>" data-index="<?php echo esc_attr( $index ); ?>">
								<?php if ( ! empty( $item['thumbnail']['id'] ) ) : ?>
									<?php echo wp_get_attachment_image( $item['thumbnail']['id'], 'full' ); ?>
								<?php elseif ( ! empty( $item['thumbnail']['url'] ) ) : ?>
									<img src="<?php echo esc_url( $item['thumbnail']['url'] ); ?>">
								<?php endif; ?>
							</span>
						<?php endif; ?>
					<?php endforeach; ?>
				</div>
			<?php endif; ?>

			<?php if ( in_array( $layout, [ 'two-column-left', 'two-column-right' ], true ) ) : ?>
				<div class="orvian-image-accordion__items flex-1">
			<?php endif; ?>

			<?php foreach ( $settings['accordion_items'] as $index => $item ) : ?>
				<?php
				$index_display = str_pad( $index + 1, 2, '0', STR_PAD_LEFT );

				$this->add_render_attribute( 'content_' . $index, 'class', [ 'orvian-image-accordion__content', 'text-body-3', 0 === $index ? '' : 'hidden' ] );
				?>
				<div class="orvian-image-accordion__item border-top py-4 md:pt-40px md:pb-45px <?php echo 0 === $index ? 'open' : ''; ?>" data-index="<?php echo esc_attr( $index ); ?>">
					<div class="flex gap-20px md:gap-11">
						<span class="orvian-image-accordion__index hidden lg:inline-flex items-center justify-center shrink-0 p-14px circle caption leading-none bg-primary text-white font-heading font-medium"><?php echo esc_html( $index_display ); ?></span>
						<div class="flex-1">
							<div class="orvian-image-accordion__header flex items-center justify-between gap-20px md:gap-11">
								<div class="flex items-center gap-4 md:gap-11">
									<span class="orvian-image-accordion__index inline-flex lg:hidden items-center justify-center shrink-0 p-14px circle caption leading-none bg-primary text-white font-heading font-medium"><?php echo esc_html( $index_display ); ?></span>
									<<?php echo esc_attr( $title_tag ); ?> <?php $this->print_render_attribute_string( 'title' ); ?>><?php echo wp_kses_post( $item['title'] ); ?></<?php echo esc_attr( $title_tag ); ?>>
								</div>

								<button class="orvian-image-accordion__toggle button-icon shrink-0"></button>
							</div>
							<div <?php $this->print_render_attribute_string( 'content_' . $index ); ?>>
								<?php if ( ! empty( $item['orvian_tags'] ) ) : ?>
									<div class="orvian-image-accordion__tags orvian-tags flex flex-wrap items-center gap-8px mb-14px md:mb-3 pt-4 md:hidden">
										<?php foreach ( $item['orvian_tags'] as $tag ) : ?>
											<span class="orvian-tag"><?php echo esc_html( $tag ); ?></span>
										<?php endforeach; ?>
									</div>
								<?php endif; ?>
								<?php if ( ! empty( $item['orvian_tags'] ) || ! empty( $item['content'] ) || ! empty( $item['gallery'] ) ) : ?>
									<div class="orvian-image-accordion__content-inner flex items-center justify-between gap-4 lg:gap-10 md:pt-7">
										<?php if ( ! empty( $item['orvian_tags'] ) || ! empty( $item['content'] ) ) : ?>
											<div class="orvian-image-accordion__tags-content flex-1">
												<?php if ( ! empty( $item['orvian_tags'] ) ) : ?>
													<div class="orvian-image-accordion__tags orvian-tags flex-wrap items-center gap-8px mb-3 hidden md:flex">
														<?php foreach ( $item['orvian_tags'] as $tag ) : ?>
															<span class="orvian-tag"><?php echo esc_html( $tag ); ?></span>
														<?php endforeach; ?>
													</div>
												<?php endif; ?>
												<?php if ( ! empty( $item['content'] ) ) : ?>
													<div class="orvian-image-accordion__text"><?php echo wp_kses_post( $item['content'] ); ?></div>
												<?php endif; ?>
											</div>
										<?php endif; ?>

										<?php if ( ! empty( $item['gallery'] ) ) : ?>
											<div class="orvian-image-accordion__gallery grid grid-cols-2 gap-8px md:gap-16px shrink-0">
												<?php foreach ( $item['gallery'] as $image ) : ?>
													<span class="block ratio-image">
														<?php if ( ! empty( $image['id'] ) ) : ?>
															<?php echo wp_get_attachment_image( $image['id'], 'full' ); ?>
														<?php elseif ( ! empty( $image['url'] ) ) : ?>
															<img src="<?php echo esc_url( $image['url'] ); ?>">
														<?php endif; ?>
													</span>
												<?php endforeach; ?>
											</div>
										<?php endif; ?>
									</div>
								<?php endif; ?>

								<?php if ( ! empty( $item['thumbnail']['url'] ) ) : ?>
									<div class="border-top pt-2 mt-3 <?php echo 'single-column' !== $layout ? 'lg:hidden' : ''; ?>">
										<span class="block ratio-image orvian-image-accordion__thumbnail rounded-sm">
											<?php if ( ! empty( $item['thumbnail']['id'] ) ) : ?>
												<?php echo wp_get_attachment_image( $item['thumbnail']['id'], 'full' ); ?>
											<?php elseif ( ! empty( $item['thumbnail']['url'] ) ) : ?>
												<img src="<?php echo esc_url( $item['thumbnail']['url'] ); ?>">
											<?php endif; ?>
										</span>
									</div>
								<?php endif; ?>
							</div>
						</div>
					</div>
				</div>
			<?php endforeach; ?>

			<?php if ( in_array( $layout, [ 'two-column-left', 'two-column-right' ], true ) ) : ?>
				</div>
			<?php endif; ?>
		</div>
		<?php
	}
}
