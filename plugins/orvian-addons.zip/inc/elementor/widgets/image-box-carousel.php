<?php
/**
 * Image Box Carousel Widget
 *
 * @package OrvianAddons
 */

namespace OrvianAddons\Elementor\Widgets;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use Elementor\Controls_Manager;
use Elementor\Repeater;
use OrvianAddons\Elementor\Elementor as OrvianAddons_Elementor;

/**
 * Image Box Carousel Widget Class
 */
class Image_Box_Carousel extends Base\Carousel_Widget_Base {

	use Base\Hover_Cursor_Base;

	/**
	 * Get widget name
	 *
	 * @return string
	 */
	public function get_name() {
		return 'orvian-image-box-carousel';
	}

	/**
	 * Get widget title
	 *
	 * @return string
	 */
	public function get_title() {
		return esc_html__( 'Image Box Carousel', 'orvian-addons' );
	}

	/**
	 * Get widget icon
	 *
	 * @return string
	 */
	public function get_icon() {
		return 'eicon-carousel ' . OrvianAddons_Elementor::CLASS_WIDGET;
	}

	/**
	 * Get widget categories
	 *
	 * @return array
	 */
	public function get_categories() {
		return [ OrvianAddons_Elementor::CATEGORY ];
	}

	/**
	 * Get carousel controls
	 *
	 * @return array
	 */
	protected function get_carousel_controls(): array {
		return [
			'slides_per_view' => [
				'desktop' => 1,
				'tablet'  => 1,
				'mobile'  => 1,
			],
		];
	}

	/**
	 * Register widget controls
	 */
	protected function register_controls() {
		$this->start_controls_section(
			'content_section',
			[
				'label' => esc_html__( 'Image Box Items', 'orvian-addons' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);

		$repeater = new Repeater();

		$repeater->add_control(
			'image',
			[
				'label' => esc_html__( 'Image', 'orvian-addons' ),
				'type'  => Controls_Manager::MEDIA,
			]
		);

		$repeater->add_control(
			'tags',
			[
				'label' => esc_html__( 'Tags', 'orvian-addons' ),
				'type'  => 'orvian-tags',
			]
		);

		$repeater->add_control(
			'title',
			[
				'label' => esc_html__( 'Title', 'orvian-addons' ),
				'type'  => Controls_Manager::TEXT,
			]
		);

		$repeater->add_control(
			'description',
			[
				'label' => esc_html__( 'Description', 'orvian-addons' ),
				'type'  => Controls_Manager::TEXTAREA,
			]
		);

		$repeater->add_control(
			'link',
			[
				'label'       => esc_html__( 'Link', 'orvian-addons' ),
				'type'        => Controls_Manager::URL,
				'placeholder' => esc_html__( 'https://your-link.com', 'orvian-addons' ),
			]
		);

		$this->add_control(
			'image_box_items',
			[
				'label'       => esc_html__( 'Items', 'orvian-addons' ),
				'type'        => Controls_Manager::REPEATER,
				'fields'      => $repeater->get_controls(),
				'default'     => [
					[
						'title'       => esc_html__( 'Item 1', 'orvian-addons' ),
						'description' => esc_html__( 'Description 1', 'orvian-addons' ),
					],
					[
						'title'       => esc_html__( 'Item 2', 'orvian-addons' ),
						'description' => esc_html__( 'Description 2', 'orvian-addons' ),
					],
					[
						'title'       => esc_html__( 'Item 3', 'orvian-addons' ),
						'description' => esc_html__( 'Description 3', 'orvian-addons' ),
					],
				],
				'title_field' => '{{{ title }}}',
			]
		);

		$this->add_control(
			'hide_tags_on_mobile',
			[
				'label' => esc_html__( 'Hide Tags on Mobile', 'orvian-addons' ),
				'type'  => Controls_Manager::SWITCHER,
			]
		);

		$this->add_control(
			'hide_description_on_mobile',
			[
				'label' => esc_html__( 'Hide Description on Mobile', 'orvian-addons' ),
				'type'  => Controls_Manager::SWITCHER,
			]
		);

		$this->register_hover_cursor_controls();

		$this->end_controls_section();

		$this->start_controls_section(
			'carousel_settings_section',
			[
				'label' => esc_html__( 'Carousel Settings', 'orvian-addons' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->register_carousel_controls();

		$this->end_controls_section();

		$this->start_controls_section(
			'item_style_section',
			[
				'label' => esc_html__( 'Item Style', 'orvian-addons' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'item_background_color',
			[
				'label'     => esc_html__( 'Background Color', 'orvian-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .orvian-image-box__slide::after' => 'background-color: {{VALUE}};',
				],
			]
		);

		$this->add_responsive_control(
			'item_backdrop_filter',
			[
				'label'      => esc_html__( 'Backdrop Filter', 'orvian-addons' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px' ],
				'selectors'  => [
					'{{WRAPPER}} .orvian-image-box__slide::after' => 'backdrop-filter: blur({{SIZE}}{{UNIT}});',
				],
			]
		);

		$this->add_responsive_control(
			'item_padding',
			[
				'label'      => esc_html__( 'Padding', 'orvian-addons' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', 'rem', 'custom' ],
				'selectors'  => [
					'{{WRAPPER}} .orvian-image-box__slide' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'item_border_radius',
			[
				'label'      => esc_html__( 'Border Radius', 'orvian-addons' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', 'rem', 'custom' ],
				'selectors'  => [
					'{{WRAPPER}} .orvian-image-box__slide' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'content_style_section',
			[
				'label' => esc_html__( 'Content Style', 'orvian-addons' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_responsive_control(
			'image_border_radius',
			[
				'label'      => esc_html__( 'Image Border Radius', 'orvian-addons' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', 'rem', 'custom' ],
				'selectors'  => [
					'{{WRAPPER}} .orvian-image-box__media' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'title_color',
			[
				'label'     => esc_html__( 'Title Color', 'orvian-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .orvian-image-box__title' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'description_color',
			[
				'label'     => esc_html__( 'Description Color', 'orvian-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .orvian-image-box__description' => 'color: {{VALUE}};',
				],
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'tag_style_section',
			[
				'label' => esc_html__( 'Tag Style', 'orvian-addons' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'tag_color',
			[
				'label'     => esc_html__( 'Color', 'orvian-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .orvian-image-box__tag' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'tag_background_color',
			[
				'label'     => esc_html__( 'Background Color', 'orvian-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .orvian-image-box__tag' => 'background-color: {{VALUE}};',
				],
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'hover_cursor_style_section',
			[
				'label' => esc_html__( 'Hover Cursor Style', 'orvian-addons' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->register_hover_cursor_controls_style();

		$this->end_controls_section();

		$this->start_controls_section(
			'carousel_style_section',
			[
				'label' => esc_html__( 'Carousel Style', 'orvian-addons' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->register_carousel_style_controls();

		$this->end_controls_section();
	}

	/**
	 * Render widget output
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();

		if ( empty( $settings['image_box_items'] ) ) {
			return;
		}

		$this->render_carousel();
		$this->render_hover_cursor_template();
	}

	/**
	 * Render items carousel
	 *
	 * @return void
	 */
	protected function render_items_carousel(): void {
		$settings = $this->get_settings_for_display();

		foreach ( $settings['image_box_items'] as $index => $item ) :
			$slide_key = 'slide_' . $index;

			// Add base classes.
			$this->add_render_attribute( $slide_key, 'class', [ 'swiper-slide',  'orvian-image-box__slide', 'relative', 'overflow-hidden', 'px-14px', 'pt-14px', 'pb-4' ] );

			// Add elementor repeater item class.
			if ( ! empty( $item['_id'] ) ) {
				$this->add_render_attribute( $slide_key, 'class', 'elementor-repeater-item-' . $item['_id'] );
			}

			$this->add_render_attribute( $slide_key . '_link', 'class', [ 'absolute', 'inset-0', 'block' ] );
			?>

			<div <?php $this->print_render_attribute_string( $slide_key ); ?>>
				<?php
				if ( ! empty( $item['image']['url'] ) ) {
					?>
					<div class="orvian-image-box__media relative overflow-hidden rounded-lg ratio-image mb-4" <?php $this->render_hover_cursor_attributes(); ?>>
						<?php if ( ! empty( $item['image']['id'] ) ) : ?>
							<?php echo wp_get_attachment_image( $item['image']['id'], 'full' ); ?>
						<?php elseif ( ! empty( $item['image']['url'] ) ) : ?>
							<img src="<?php echo esc_url( $item['image']['url'] ); ?>">
						<?php endif; ?>

						<?php if ( ! empty( $item['tags'] ) ) : ?>
						<div class="orvian-image-box__tags orvian-tags absolute top-0 left-0 z-10 pointer-events-none <?php echo ! empty( $settings['hide_tags_on_mobile'] ) ? 'hidden md:flex' : 'flex'; ?> gap-14px flex-wrap items-center p-14px">
							<?php foreach ( $item['tags'] as $tag ) : ?>
								<span class="orvian-tag orvian-image-box__tag">
									<?php echo esc_html( $tag ); ?>
								</span>
							<?php endforeach; ?>
						</div>
					<?php endif; ?>
					</div>
					<?php
				}
				?>

				<div class="orvian-image-box__content px-1">
					<?php if ( ! empty( $item['title'] ) ) : ?>
						<h3 class="orvian-image-box__title m-0 text-body-1"><?php echo esc_html( $item['title'] ); ?></h3>
					<?php endif; ?>

					<?php if ( ! empty( $item['description'] ) ) : ?>
						<div class="orvian-image-box__description text-body-3 <?php echo ! empty( $settings['hide_description_on_mobile'] ) ? 'hidden md:block' : ''; ?>"><?php echo wp_kses_post( nl2br( $item['description'] ) ); ?></div>
					<?php endif; ?>
				</div>

				<?php
				if ( ! empty( $item['link']['url'] ) ) {
					$this->add_link_attributes( $slide_key . '_link', $item['link'] );
					?>
					<a <?php $this->print_render_attribute_string( $slide_key . '_link' ); ?>></a>
					<?php
				}
				?>
			</div>

			<?php
		endforeach;
	}

	/**
	 * Get classes swiper
	 *
	 * @return array
	 */
	protected function get_classes_swiper(): array {
		return [ 'orvian-image-box-carousel' ];
	}
}
