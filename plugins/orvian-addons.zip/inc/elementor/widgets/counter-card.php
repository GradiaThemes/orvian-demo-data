<?php
/**
 * Counter Card Widget
 *
 * @package OrvianAddons
 */

namespace OrvianAddons\Elementor\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Icons_Manager;
use OrvianAddons\Elementor\Elementor as OrvianAddons_Elementor;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Counter Card Widget
 */
class Counter_Card extends Widget_Base {

	/**
	 * Get widget name
	 *
	 * @return string
	 */
	public function get_name() {
		return 'orvian-counter-card';
	}

	/**
	 * Get widget title
	 *
	 * @return string
	 */
	public function get_title() {
		return esc_html__( 'Counter Card', 'orvian-addons' );
	}

	/**
	 * Get widget icon
	 *
	 * @return string
	 */
	public function get_icon() {
		return 'eicon-counter ' . OrvianAddons_Elementor::CLASS_WIDGET;
	}

	/**
	 * Get widget categories
	 *
	 * @return array
	 */
	public function get_categories() {
		return [ OrvianAddons_Elementor::CATEGORY ];
	}

	/**
	 * Get widget keywords
	 *
	 * @return array
	 */
	/**
	 * Get widget keywords
	 *
	 * @return array
	 */
	public function get_keywords() {
		return [ 'counter', 'card', 'number', 'rating', 'animate' ];
	}

	/**
	 * Register widget controls
	 *
	 * @return void
	 */
	protected function register_controls() {
		$this->start_controls_section(
			'section_card',
			[
				'label' => esc_html__( 'Card', 'orvian-addons' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'active',
			[
				'label'     => esc_html__( 'Enable Active', 'orvian-addons' ),
				'type'      => Controls_Manager::SWITCHER,
				'separator' => 'after',
			]
		);

		$this->add_control(
			'rating_type',
			[
				'label'   => esc_html__( 'Rating Type', 'orvian-addons' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'star',
				'options' => [
					'none' => esc_html__( 'None', 'orvian-addons' ),
					'star' => esc_html__( 'Star Rating', 'orvian-addons' ),
				],
			]
		);

		$this->add_control(
			'rating_value',
			[
				'label'     => esc_html__( 'Rating Value', 'orvian-addons' ),
				'type'      => Controls_Manager::SELECT,
				'default'   => 5,
				'options'   => [
					1 => '1',
					2 => '2',
					3 => '3',
					4 => '4',
					5 => '5',
				],
				'condition' => [
					'rating_type!' => 'none',
				],
			]
		);

		$this->add_control(
			'text_top',
			[
				'label'       => esc_html__( 'Top Text', 'orvian-addons' ),
				'type'        => Controls_Manager::TEXTAREA,
				'default'     => esc_html__( 'Customer satisfaction', 'orvian-addons' ),
				'placeholder' => esc_html__( 'Enter text here', 'orvian-addons' ),
				'label_block' => true,
			]
		);

		$this->add_control(
			'counter_heading',
			[
				'label'     => esc_html__( 'Counter', 'orvian-addons' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_control(
			'counter_number',
			[
				'label'   => esc_html__( 'Number', 'orvian-addons' ),
				'type'    => Controls_Manager::NUMBER,
				'default' => 100,
				'min'     => 0,
			]
		);

		$this->add_control(
			'counter_prefix',
			[
				'label'       => esc_html__( 'Prefix', 'orvian-addons' ),
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
			]
		);

		$this->add_control(
			'counter_suffix',
			[
				'label'       => esc_html__( 'Suffix', 'orvian-addons' ),
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
			]
		);

		$this->add_control(
			'counter_duration',
			[
				'label'   => esc_html__( 'Animation Duration (s)', 'orvian-addons' ),
				'type'    => Controls_Manager::SLIDER,
				'range'   => [
					's' => [
						'min'  => 0.5,
						'max'  => 5,
						'step' => 0.5,
					],
				],
				'default' => [
					'size' => 2,
				],
			]
		);

		$this->add_control(
			'bottom_heading',
			[
				'label'     => esc_html__( 'Bottom Content', 'orvian-addons' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_control(
			'text_bottom',
			[
				'label'       => esc_html__( 'Bottom Text', 'orvian-addons' ),
				'type'        => Controls_Manager::TEXTAREA,
				'default'     => esc_html__( 'This is a description', 'orvian-addons' ),
				'placeholder' => esc_html__( 'Enter text here', 'orvian-addons' ),
				'label_block' => true,
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'section_style_overlay',
			[
				'label' => esc_html__( 'Overlay', 'orvian-addons' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'overlay_icon',
			[
				'label' => esc_html__( 'Icon Overlay', 'orvian-addons' ),
				'type'  => Controls_Manager::ICONS,
			]
		);

		$this->add_control(
			'overlay_icon_position_horizontal',
			[
				'label'     => esc_html__( 'Horizontal Position', 'orvian-addons' ),
				'type'      => Controls_Manager::CHOOSE,
				'options'   => [
					'flex-start' => [
						'title' => esc_html__( 'Left', 'orvian-addons' ),
						'icon'  => 'eicon-h-align-left',
					],
					'center'     => [
						'title' => esc_html__( 'Center', 'orvian-addons' ),
						'icon'  => 'eicon-h-align-center',
					],
					'flex-end'   => [
						'title' => esc_html__( 'Right', 'orvian-addons' ),
						'icon'  => 'eicon-h-align-right',
					],
				],
				'selectors' => [
					'{{WRAPPER}} .orvian-counter-card__overlay' => 'justify-content: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'overlay_icon_position_vertical',
			[
				'label'     => esc_html__( 'Vertical Position', 'orvian-addons' ),
				'type'      => Controls_Manager::CHOOSE,
				'options'   => [
					'flex-start' => [
						'title' => esc_html__( 'Top', 'orvian-addons' ),
						'icon'  => 'eicon-v-align-top',
					],
					'center'     => [
						'title' => esc_html__( 'Middle', 'orvian-addons' ),
						'icon'  => 'eicon-v-align-middle',
					],
					'flex-end'   => [
						'title' => esc_html__( 'Bottom', 'orvian-addons' ),
						'icon'  => 'eicon-v-align-bottom',
					],
				],
				'selectors' => [
					'{{WRAPPER}} .orvian-counter-card__overlay' => 'align-items: {{VALUE}};',
				],
			]
		);

		$this->add_responsive_control(
			'overlay_icon_size',
			[
				'label'      => esc_html__( 'Icon Size', 'orvian-addons' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', 'em', 'rem', 'custom' ],
				'selectors'  => [
					'{{WRAPPER}} .orvian-counter-card__overlay-icon' => 'font-size: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'overlay_icon_color',
			[
				'label'     => esc_html__( 'Icon Color', 'orvian-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .orvian-counter-card__overlay-icon' => 'color: {{VALUE}};',
				],
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'section_style_rating',
			[
				'label'     => esc_html__( 'Rating', 'orvian-addons' ),
				'tab'       => Controls_Manager::TAB_STYLE,
				'condition' => [
					'rating_type!' => 'none',
				],
			]
		);

		$this->add_control(
			'rating_color',
			[
				'label'     => esc_html__( 'Color', 'orvian-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .orvian-counter-card__rating span' => 'color: {{VALUE}};',
				],
				'condition' => [
					'rating_type' => 'star',
				],
			]
		);

		$this->add_control(
			'rating_color_active',
			[
				'label'     => esc_html__( 'Color Active', 'orvian-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .orvian-counter-card__rating span.active' => 'color: {{VALUE}};',
				],
				'condition' => [
					'rating_type' => 'star',
				],
			]
		);

		$this->add_responsive_control(
			'rating_size',
			[
				'label'      => esc_html__( 'Star Size', 'orvian-addons' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', 'em', 'rem', 'custom' ],
				'selectors'  => [
					'{{WRAPPER}} .orvian-counter-card__rating span' => 'font-size: {{SIZE}}{{UNIT}};',
				],
				'condition'  => [
					'rating_type' => 'star',
				],
			]
		);

		$this->add_responsive_control(
			'rating_spacing',
			[
				'label'      => esc_html__( 'Spacing Bottom', 'orvian-addons' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', 'em', 'rem', 'custom' ],
				'selectors'  => [
					'{{WRAPPER}} .orvian-counter-card__rating' => 'margin-bottom: {{SIZE}}{{UNIT}};',
				],
				'condition'  => [
					'rating_type' => 'star',
				],
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'section_style_text_top',
			[
				'label' => esc_html__( 'Top Text', 'orvian-addons' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'text_top_color',
			[
				'label'     => esc_html__( 'Color', 'orvian-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .orvian-counter-card__text-top' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'text_top_color_active',
			[
				'label'     => esc_html__( 'Color Active', 'orvian-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .orvian-counter-card.is-active .orvian-counter-card__text-top' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'text_top_typography',
				'selector' => '{{WRAPPER}} .orvian-counter-card__text-top',
			]
		);

		$this->add_responsive_control(
			'text_top_spacing',
			[
				'label'      => esc_html__( 'Spacing Bottom', 'orvian-addons' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', 'em', 'rem', 'custom' ],
				'selectors'  => [
					'{{WRAPPER}} .orvian-counter-card__text-top' => 'margin-bottom: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'section_style_counter',
			[
				'label' => esc_html__( 'Counter', 'orvian-addons' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'counter_color',
			[
				'label'     => esc_html__( 'Color', 'orvian-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .orvian-counter-card__number' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'counter_color_active',
			[
				'label'     => esc_html__( 'Color Active', 'orvian-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .orvian-counter-card.is-active .orvian-counter-card__number' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'counter_typography',
				'selector' => '{{WRAPPER}} .orvian-counter-card__number',
			]
		);

		$this->add_control(
			'prefix_suffix_heading',
			[
				'label'     => esc_html__( 'Prefix & Suffix', 'orvian-addons' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_control(
			'prefix_suffix_color',
			[
				'label'     => esc_html__( 'Color', 'orvian-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .orvian-counter-card__prefix' => 'color: {{VALUE}};',
					'{{WRAPPER}} .orvian-counter-card__suffix' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'prefix_suffix_color_active',
			[
				'label'     => esc_html__( 'Color Active', 'orvian-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .orvian-counter-card.is-active .orvian-counter-card__prefix' => 'color: {{VALUE}};',
					'{{WRAPPER}} .orvian-counter-card.is-active .orvian-counter-card__suffix' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'prefix_suffix_typography',
				'selector' => '{{WRAPPER}} .orvian-counter-card__prefix, {{WRAPPER}} .orvian-counter-card__suffix',
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'section_style_text_bottom',
			[
				'label' => esc_html__( 'Bottom Text', 'orvian-addons' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'text_bottom_color',
			[
				'label'     => esc_html__( 'Color', 'orvian-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .orvian-counter-card__text-bottom' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'text_bottom_color_active',
			[
				'label'     => esc_html__( 'Color Active', 'orvian-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .orvian-counter-card.is-active .orvian-counter-card__text-bottom' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'text_bottom_typography',
				'selector' => '{{WRAPPER}} .orvian-counter-card__text-bottom',
			]
		);

		$this->add_responsive_control(
			'counter_spacing',
			[
				'label'      => esc_html__( 'Spacing Top', 'orvian-addons' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', 'em', 'rem', 'custom' ],
				'selectors'  => [
					'{{WRAPPER}} .orvian-counter-card__text-bottom' => 'margin-top: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();
	}

	/**
	 * Render star rating using SVG icons
	 *
	 * @param int $rating Rating value (1-5).
	 * @return string
	 */
	protected function render_stars( $rating ) {
		$rating = intval( $rating );
		$html   = '';

		for ( $i = 1; $i <= 5; $i++ ) {
			$attr = [];
			if ( $i <= $rating ) {
				$attr['class'] = 'active';
			}
			// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
			$html .= \OrvianAddons\Helper::get_svg( 'star', 'ui', $attr );
		}

		return $html;
	}

	/**
	 * Render widget output
	 *
	 * @return void
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();

		$this->add_render_attribute( 'wrapper', 'class', 'orvian-counter-card rounded-lg overflow-hidden relative' );
		$this->add_render_attribute( 'overlay', 'class', 'orvian-counter-card__overlay absolute inset-0 pointer-events-none overflow-hidden flex items-end' );
		$this->add_render_attribute( 'overlay_icon', 'class', 'orvian-counter-card__overlay-icon orvian-svg-icon' );

		if ( ! empty( $settings['active'] ) ) {
			$this->add_render_attribute( 'wrapper', 'class', 'is-active theme-dark' );
		}

		$this->add_render_attribute( 'rating', 'class', 'orvian-counter-card__rating mb-2' );
		$this->add_render_attribute( 'text_top', 'class', 'orvian-counter-card__text-top text-heading text-body-2' );
		$this->add_render_attribute( 'counter', 'class', 'orvian-counter-card__counter text-display-2 text-heading inline-flex items-center' );
		$this->add_render_attribute( 'text_bottom', 'class', 'orvian-counter-card__text-bottom mt-2 text-body-3' );

		?>
		<div <?php $this->print_render_attribute_string( 'wrapper' ); ?>>
			<div <?php $this->print_render_attribute_string( 'overlay' ); ?>>
				<?php if ( ! empty( $settings['overlay_icon']['value'] ) ) : ?>
					<span <?php $this->print_render_attribute_string( 'overlay_icon' ); ?>>
						<?php
						Icons_Manager::render_icon(
							$settings['overlay_icon'],
							[
								'aria-hidden' => 'true',
								'fill'        => 'currentColor',
							]
						);
						?>
					</span>
				<?php endif; ?>
			</div>
			<?php if ( ! empty( $settings['rating_type'] ) && 'none' !== $settings['rating_type'] ) : ?>
				<div <?php $this->print_render_attribute_string( 'rating' ); ?>>
					<?php
					// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
					echo $this->render_stars( intval( $settings['rating_value'] ) );
					?>
				</div>
			<?php endif; ?>

			<?php if ( ! empty( $settings['text_top'] ) ) : ?>
				<div <?php $this->print_render_attribute_string( 'text_top' ); ?>>
					<?php echo wp_kses_post( nl2br( $settings['text_top'] ) ); ?>
				</div>
			<?php endif; ?>

			<?php if ( ! empty( $settings['counter_number'] ) ) : ?>
				<?php
					$this->add_render_attribute( 'counter', 'data-counter-value', esc_attr( $settings['counter_number'] ) );
					$this->add_render_attribute( 'counter', 'data-counter-duration', esc_attr( $settings['counter_duration']['size'] ?? 2 ) );
				?>
				<div <?php $this->print_render_attribute_string( 'counter' ); ?>>
					<?php if ( ! empty( $settings['counter_prefix'] ) ) : ?>
						<span class="orvian-counter-card__prefix"><?php echo esc_html( $settings['counter_prefix'] ); ?></span>
					<?php endif; ?>

					<span class="orvian-counter-card__number">0</span>

					<?php if ( ! empty( $settings['counter_suffix'] ) ) : ?>
						<span class="orvian-counter-card__suffix"><?php echo esc_html( $settings['counter_suffix'] ); ?></span>
					<?php endif; ?>
				</div>
			<?php endif; ?>

			<?php if ( ! empty( $settings['text_bottom'] ) ) : ?>
				<div <?php $this->print_render_attribute_string( 'text_bottom' ); ?>>
					<?php echo wp_kses_post( nl2br( $settings['text_bottom'] ) ); ?>
				</div>
			<?php endif; ?>
		</div>
		<?php
	}
}
