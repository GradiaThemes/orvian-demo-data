<?php
/**
 * Testimonials Widget
 *
 * @package OrvianAddons
 */

namespace OrvianAddons\Elementor\Widgets;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use Elementor\Controls_Manager;
use Elementor\Repeater;
use Elementor\Icons_Manager;
use Elementor\Group_Control_Image_Size;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Border;
use OrvianAddons\Elementor\Elementor as OrvianAddons_Elementor;

/**
 * Testimonials Widget Class
 */
class Testimonials extends Base\Carousel_Widget_Base {

	/**
	 * Get widget name
	 *
	 * @return string
	 */
	public function get_name() {
		return 'orvian-testimonials';
	}

	/**
	 * Get widget title
	 *
	 * @return string
	 */
	public function get_title() {
		return esc_html__( 'Testimonials', 'orvian-addons' );
	}

	/**
	 * Get widget icon
	 *
	 * @return string
	 */
	public function get_icon() {
		return 'eicon-testimonial ' . OrvianAddons_Elementor::CLASS_WIDGET;
	}

	/**
	 * Get widget categories
	 *
	 * @return array
	 */
	public function get_categories() {
		return [ OrvianAddons_Elementor::CATEGORY ];
	}

	/**
	 * Get widget keywords
	 *
	 * @return array
	 */
	public function get_keywords() {
		return [ 'orvian', 'testimonial', 'review', 'feedback' ];
	}

	/**
	 * Get carousel controls
	 *
	 * @return array
	 */
	protected function get_carousel_controls(): array {
		return [
			'slides_per_view' => [
				'desktop' => 3,
				'tablet'  => 2,
				'mobile'  => 1,
			],
			'space_between'   => [
				'desktop' => 30,
				'tablet'  => 15,
				'mobile'  => 15,
			],
			'effect'          => 'slide',
			'centered_slides' => '',
			'navigation'      => 'none',
		];
	}

	/**
	 * Get attributes.
	 *
	 * @return array
	 */
	protected function get_attributes(): array {
		$attributes                              = parent::get_attributes();
		$attributes['disable-slider-breakpoint'] = '1200';
		return $attributes;
	}

	/**
	 * Get classes swiper.
	 *
	 * @return array
	 */
	protected function get_classes_swiper(): array {
		return [ 'orvian-testimonials__items' ];
	}

	/**
	 * Register widget controls
	 */
	protected function register_controls() {
		$this->start_controls_section(
			'section_testimonials',
			[
				'label' => esc_html__( 'Testimonials', 'orvian-addons' ),
			]
		);

		$repeater = new Repeater();

		$repeater->add_control(
			'testimonial_name',
			[
				'label' => esc_html__( 'Name', 'orvian-addons' ),
				'type'  => Controls_Manager::TEXT,
			]
		);

		$repeater->add_control(
			'testimonial_position',
			[
				'label' => esc_html__( 'Position', 'orvian-addons' ),
				'type'  => Controls_Manager::TEXT,
			]
		);

		$repeater->add_control(
			'testimonial_content',
			[
				'label' => esc_html__( 'Content', 'orvian-addons' ),
				'type'  => Controls_Manager::TEXTAREA,
			]
		);

		$repeater->add_control(
			'testimonial_image',
			[
				'label' => esc_html__( 'Image', 'orvian-addons' ),
				'type'  => Controls_Manager::MEDIA,
			]
		);

		$repeater->add_control(
			'testimonial_icon',
			[
				'label' => esc_html__( 'Icon', 'orvian-addons' ),
				'type'  => Controls_Manager::ICONS,
			]
		);

		$this->add_control(
			'testimonials',
			[
				'label'       => esc_html__( 'Testimonials', 'orvian-addons' ),
				'type'        => Controls_Manager::REPEATER,
				'fields'      => $repeater->get_controls(),
				'default'     => [],
				'title_field' => '{{{ testimonial_name }}}',
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'section_circular',
			[
				'label' => esc_html__( 'Circular', 'orvian-addons' ),
			]
		);

		$this->add_control(
			'circular_type',
			[
				'label'   => esc_html__( 'Type', 'orvian-addons' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'icon',
				'options' => [
					'icon'  => esc_html__( 'Icon', 'orvian-addons' ),
					'image' => esc_html__( 'Image', 'orvian-addons' ),
				],
			]
		);

		$this->add_control(
			'circular_icon',
			[
				'label'     => esc_html__( 'Icon', 'orvian-addons' ),
				'type'      => Controls_Manager::ICONS,
				'default'   => [
					'value'   => 'fas fa-star',
					'library' => 'fa-solid',
				],
				'condition' => [
					'circular_type' => 'icon',
				],
			]
		);

		$this->add_control(
			'circular_image',
			[
				'label'     => esc_html__( 'Image', 'orvian-addons' ),
				'type'      => Controls_Manager::MEDIA,
				'condition' => [
					'circular_type' => 'image',
				],
			]
		);

		$this->add_control(
			'circular_text',
			[
				'label'       => esc_html__( 'Circular Text', 'orvian-addons' ),
				'type'        => Controls_Manager::TEXTAREA,
				'default'     => esc_html__( '  -  Testimonials  -  Trusted by clients', 'orvian-addons' ),
				'label_block' => true,
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'carousel_settings_section',
			[
				'label' => esc_html__( 'Carousel Settings', 'orvian-addons' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->register_carousel_controls();

		$this->end_controls_section();

		$this->start_controls_section(
			'testimonial_item_style',
			[
				'label' => esc_html__( 'Testimonial Item', 'orvian-addons' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'testimonial_item_background_color',
			[
				'label'     => esc_html__( 'Background Color', 'orvian-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .orvian-testimonial__inner' => 'background-color: {{VALUE}}',
				],
			]
		);

		$this->add_responsive_control(
			'testimonial_item_backdrop_filter',
			[
				'label'     => esc_html__( 'Backdrop Filter', 'orvian-addons' ),
				'type'      => Controls_Manager::NUMBER,
				'selectors' => [
					'{{WRAPPER}} .orvian-testimonial__inner' => 'backdrop-filter: blur({{VALUE}}px);',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'     => 'testimonial_item_border',
				'label'    => esc_html__( 'Border', 'orvian-addons' ),
				'selector' => '{{WRAPPER}} .orvian-testimonial__inner',
			]
		);

		$this->add_responsive_control(
			'testimonial_item_border_radius',
			[
				'label'      => esc_html__( 'Border Radius', 'orvian-addons' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .orvian-testimonial__inner' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'testimonial_item_padding',
			[
				'label'      => esc_html__( 'Padding', 'orvian-addons' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .orvian-testimonial__inner' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'testimonial_item_content_heading',
			[
				'label'     => esc_html__( 'Content', 'orvian-addons' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_control(
			'testimonial_item_content_color',
			[
				'label'     => esc_html__( 'Text Color', 'orvian-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .orvian-testimonial__content' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'testimonial_item_content_typography',
				'selector' => '{{WRAPPER}} .orvian-testimonial__content',
			]
		);

		$this->add_responsive_control(
			'testimonial_item_content_margin',
			[
				'label'      => esc_html__( 'Margin', 'orvian-addons' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .orvian-testimonial__content' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'testimonial_item_image_heading',
			[
				'label'     => esc_html__( 'Image', 'orvian-addons' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_group_control(
			Group_Control_Image_Size::get_type(),
			[
				'name' => 'image',
			]
		);

		$this->add_responsive_control(
			'testimonial_item_image_border_radius',
			[
				'label'      => esc_html__( 'Border Radius', 'orvian-addons' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .orvian-testimonial__image img' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'testimonial_item_image_spacing_right',
			[
				'label'      => esc_html__( 'Spacing Right', 'orvian-addons' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%', 'em', 'rem' ],
				'selectors'  => [
					'{{WRAPPER}} .orvian-testimonial__author' => 'gap: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'testimonial_item_name_heading',
			[
				'label'     => esc_html__( 'Name', 'orvian-addons' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_control(
			'testimonial_item_name_color',
			[
				'label'     => esc_html__( 'Color', 'orvian-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .orvian-testimonial__author-name' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'testimonial_item_name_typography',
				'selector' => '{{WRAPPER}} .orvian-testimonial__author-name',
			]
		);

		$this->add_responsive_control(
			'testimonial_item_name_margin',
			[
				'label'      => esc_html__( 'Margin', 'orvian-addons' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem' ],
				'selectors'  => [
					'{{WRAPPER}} .orvian-testimonial__author-name' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'testimonial_item_position_heading',
			[
				'label'     => esc_html__( 'Position', 'orvian-addons' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_control(
			'testimonial_item_position_color',
			[
				'label'     => esc_html__( 'Color', 'orvian-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .orvian-testimonial__author-position' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'testimonial_item_position_typography',
				'selector' => '{{WRAPPER}} .orvian-testimonial__author-position',
			]
		);

		$this->add_control(
			'testimonial_item_icon_heading',
			[
				'label'     => esc_html__( 'Icon', 'orvian-addons' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_control(
			'testimonial_item_icon_color',
			[
				'label'     => esc_html__( 'Color', 'orvian-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .orvian-testimonial__author-icon' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_responsive_control(
			'testimonial_item_icon_size',
			[
				'label'      => esc_html__( 'Size', 'orvian-addons' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%', 'em', 'rem' ],
				'selectors'  => [
					'{{WRAPPER}} .orvian-testimonial__author-icon' => 'font-size: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'circular_style',
			[
				'label' => esc_html__( 'Circular', 'orvian-addons' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_responsive_control(
			'circular_width',
			[
				'label'      => esc_html__( 'Width', 'orvian-addons' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', 'em', 'rem' ],
				'range'      => [
					'px' => [
						'min' => 0,
						'max' => 1000,
					],
				],
				'selectors'  => [
					'{{WRAPPER}} .orvian-circular' => 'width: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'circular_text_color',
			[
				'label'     => esc_html__( 'Text Color', 'orvian-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .orvian-circular__text' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'circular_text_typography',
				'selector' => '{{WRAPPER}} .orvian-circular__text',
			]
		);

		$this->add_control(
			'circular_icon_heading',
			[
				'label'     => esc_html__( 'Icon', 'orvian-addons' ),
				'type'      => Controls_Manager::HEADING,
				'condition' => [
					'circular_type' => 'icon',
				],
			]
		);

		$this->add_control(
			'circular_icon_color',
			[
				'label'     => esc_html__( 'Color', 'orvian-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .orvian-circular__item .orvian-svg-icon' => 'color: {{VALUE}}',
				],
				'condition' => [
					'circular_type' => 'icon',
				],
			]
		);

		$this->add_responsive_control(
			'circular_icon_size',
			[
				'label'      => esc_html__( 'Size', 'orvian-addons' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px' ],
				'range'      => [
					'px' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'selectors'  => [
					'{{WRAPPER}} .orvian-circular__item .orvian-svg-icon' => 'font-size: {{SIZE}}{{UNIT}};',
				],
				'condition'  => [
					'circular_type' => 'icon',
				],
			]
		);

		$this->add_control(
			'circular_image_heading',
			[
				'label'     => esc_html__( 'Image', 'orvian-addons' ),
				'type'      => Controls_Manager::HEADING,
				'condition' => [
					'circular_type' => 'image',
				],
			]
		);

		$this->add_responsive_control(
			'circular_image_width',
			[
				'label'      => esc_html__( 'Width', 'orvian-addons' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px' ],
				'range'      => [
					'px' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'selectors'  => [
					'{{WRAPPER}} .orvian-circular__item img' => 'width: {{SIZE}}{{UNIT}};',
				],
				'condition'  => [
					'circular_type' => 'image',
				],
			]
		);

		$this->add_responsive_control(
			'circular_image_height',
			[
				'label'      => esc_html__( 'Height', 'orvian-addons' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px' ],
				'range'      => [
					'px' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'selectors'  => [
					'{{WRAPPER}} .orvian-circular__item img' => 'height: {{SIZE}}{{UNIT}};',
				],
				'condition'  => [
					'circular_type' => 'image',
				],
			]
		);

		$this->add_responsive_control(
			'circular_image_radius',
			[
				'label'      => esc_html__( 'Border Radius', 'orvian-addons' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem' ],
				'selectors'  => [
					'{{WRAPPER}} .orvian-circular__item img' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'condition'  => [
					'circular_type' => 'image',
				],
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'carousel_style_content',
			[
				'label' => esc_html__( 'Carousel Style', 'orvian-addons' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->register_carousel_style_controls();

		$this->end_controls_section();
	}

	/**
	 * Render widget output
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();

		if ( empty( $settings['testimonials'] ) ) {
			return;
		}

		$this->add_render_attribute( 'wrapper', 'class', [ 'orvian-testimonials', 'relative' ] );
		$this->add_render_attribute( 'circular', 'class', [ 'orvian-circular', 'absolute', 'left-1/2', 'top-1/2', '-translate-1/2' ] );
		$this->add_render_attribute( 'circular_text', 'class', [ 'orvian-circular__text', 'absolute', 'uppercase', 'circle', 'font-sm', 'font-semibold', 'text-heading' ] );
		$this->add_render_attribute( 'circular_text', 'data-text', $settings['circular_text'] );
		$this->add_render_attribute( 'circular_item', 'class', [ 'orvian-circular__item', 'absolute', 'left-1/2', 'top-1/2', '-translate-1/2' ] );
		?>
		<div <?php $this->print_render_attribute_string( 'wrapper' ); ?>>
			<div <?php $this->print_render_attribute_string( 'circular' ); ?>>
				<div <?php $this->print_render_attribute_string( 'circular_text' ); ?>></div>
				<div <?php $this->print_render_attribute_string( 'circular_item' ); ?>>
					<?php if ( 'icon' === $settings['circular_type'] ) : ?>
						<span class="orvian-svg-icon text-primary">
							<?php Icons_Manager::render_icon( $settings['circular_icon'], [ 'aria-hidden' => 'true' ] ); ?>
						</span>
					<?php endif; ?>
					<?php if ( 'image' === $settings['circular_type'] ) : ?>
						<?php echo Group_Control_Image_Size::get_attachment_image_html( $settings, 'circular_image', 'circular_image' ); // phpcs:ignore ?>
					<?php endif; ?>
				</div>
			</div>
			<?php $this->render_carousel( 'div', 'grid-cols-2 grid-rows-3' ); ?>
		</div>
		<?php
	}

	/**
	 * Render items carousel.
	 */
	protected function render_items_carousel() {
		$settings        = $this->get_settings_for_display();
		$grid_positions  = [
			[
				'row' => 1,
				'col' => 2,
			],
			[
				'row' => 1,
				'col' => 1,
			],
			[
				'row' => 2,
				'col' => 2,
			],
			[
				'row' => 2,
				'col' => 1,
			],
			[
				'row' => 3,
				'col' => 2,
			],
			[
				'row' => 3,
				'col' => 1,
			],
		];
		$total_positions = count( $grid_positions );

		$this->add_render_attribute( 'inner', 'class', [ 'orvian-testimonial__inner' ] );
		$this->add_render_attribute( 'content', 'class', [ 'orvian-testimonial__content', 'uppercase', 'text-heading', 'font-heading', 'font-semibold' ] );
		$this->add_render_attribute( 'author', 'class', [ 'orvian-testimonial__author', 'flex', 'items-center' ] );
		$this->add_render_attribute( 'author_image', 'class', [ 'orvian-testimonial__author-image', 'shrink-0' ] );
		$this->add_render_attribute( 'author_info', 'class', [ 'orvian-testimonial__author-info', 'shrink-0' ] );
		$this->add_render_attribute( 'author_name', 'class', [ 'orvian-testimonial__author-name', 'font-medium', 'text-heading', 'leading-none' ] );
		$this->add_render_attribute( 'author_position', 'class', [ 'orvian-testimonial__author-position', 'uppercase', 'leading-none' ] );

		foreach ( $settings['testimonials'] as $index => $testimonial ) :
			$pos         = $grid_positions[ $index % $total_positions ];
			$grid_class  = sprintf( 'row-start-%d col-start-%d', $pos['row'], $pos['col'] );
			$align_class = ( 2 === $pos['col'] ) ? 'justify-items-end' : '';

			$this->add_render_attribute( 'slide_' . $index, 'class', [ 'orvian-testimonials__item', 'w-full', 'swiper-slide', 'swiper-slide--stretch', $grid_class, $align_class ] );
			$this->add_render_attribute( 'slide_' . $index, 'data-index', $index );
			$this->add_render_attribute( 'slide_' . $index, 'data-row', $pos['row'] );
			$this->add_render_attribute( 'slide_' . $index, 'data-col', $pos['col'] );
			?>
			<div <?php $this->print_render_attribute_string( 'slide_' . $index ); ?>>
				<div <?php $this->print_render_attribute_string( 'inner' ); ?>>
					<?php if ( ! empty( $testimonial['testimonial_content'] ) ) : ?>
						<div <?php $this->print_render_attribute_string( 'content' ); ?>>
							<?php echo wp_kses_post( $testimonial['testimonial_content'] ); ?>
						</div>
					<?php endif; ?>
					<div <?php $this->print_render_attribute_string( 'author' ); ?>>
						<?php if ( ! empty( $testimonial['testimonial_image']['url'] ) ) : ?>
							<div <?php $this->print_render_attribute_string( 'author_image' ); ?>>
								<?php echo Group_Control_Image_Size::get_attachment_image_html( array_merge( $testimonial, $settings ), 'image', 'testimonial_image' ); // phpcs:ignore ?>
							</div>
						<?php endif; ?>
						<div <?php $this->print_render_attribute_string( 'author_info' ); ?>>
							<?php if ( ! empty( $testimonial['testimonial_name'] ) ) : ?>
								<div <?php $this->print_render_attribute_string( 'author_name' ); ?>>
									<?php echo wp_kses_post( $testimonial['testimonial_name'] ); ?>
								</div>
							<?php endif; ?>
							<?php if ( ! empty( $testimonial['testimonial_position'] ) ) : ?>
								<div <?php $this->print_render_attribute_string( 'author_position' ); ?>>
									<?php echo wp_kses_post( $testimonial['testimonial_position'] ); ?>
								</div>
							<?php endif; ?>
						</div>
						<?php if ( ! empty( $testimonial['testimonial_icon'] ) ) : ?>
							<span class="orvian-testimonial__author-icon orvian-svg-icon shrink-0 ms-auto text-heading">
								<?php Icons_Manager::render_icon( $testimonial['testimonial_icon'], [ 'aria-hidden' => 'true' ] ); ?>
							</span>
						<?php endif; ?>
					</div>
				</div>
			</div>
			<?php
		endforeach;
	}
}
