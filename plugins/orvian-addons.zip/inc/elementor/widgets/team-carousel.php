<?php
/**
 * Team Carousel Widget
 *
 * @package OrvianAddons
 */

namespace OrvianAddons\Elementor\Widgets;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use Elementor\Controls_Manager;
use Elementor\Repeater;
use OrvianAddons\Elementor\Elementor as OrvianAddons_Elementor;
use OrvianAddons\Helper;
use OrvianAddons\Elementor\Widgets\Base\Carousel_Widget_Base;

/**
 * Team Carousel Widget Class
 */
class Team_Carousel extends Carousel_Widget_Base {

	/**
	 * Get widget name
	 *
	 * @return string
	 */
	public function get_name() {
		return 'orvian-team-carousel';
	}

	/**
	 * Get widget title
	 *
	 * @return string
	 */
	public function get_title() {
		return esc_html__( 'Team Carousel', 'orvian-addons' );
	}

	/**
	 * Get widget icon
	 *
	 * @return string
	 */
	public function get_icon() {
		return 'eicon-carousel ' . OrvianAddons_Elementor::CLASS_WIDGET;
	}

	/**
	 * Get widget categories
	 *
	 * @return array
	 */
	public function get_categories() {
		return [ OrvianAddons_Elementor::CATEGORY ];
	}

	/**
	 * Get widget keywords
	 *
	 * @return array
	 */
	public function get_keywords() {
		return [ 'orvian', 'team', 'carousel', 'member' ];
	}

	/**
	 * Get carousel controls
	 *
	 * @return array
	 */
	protected function get_carousel_controls(): array {
		return [
			'slides_per_view' => [
				'desktop' => 3,
				'tablet'  => 2,
				'mobile'  => 1,
			],
			'space_between'   => [
				'desktop' => 12,
				'tablet'  => 12,
				'mobile'  => 12,
			],
		];
	}

	/**
	 * Register widget controls
	 */
	protected function register_controls() {
		$this->start_controls_section(
			'content_section',
			[
				'label' => esc_html__( 'Team Carousel', 'orvian-addons' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);

		$repeater = new Repeater();

		$repeater->add_control(
			'member_image',
			[
				'label'   => esc_html__( 'Member Photo', 'orvian-addons' ),
				'type'    => Controls_Manager::MEDIA,
				'default' => [
					'url' => \Elementor\Utils::get_placeholder_image_src(),
				],
			]
		);

		$repeater->add_control(
			'member_name',
			[
				'label'       => esc_html__( 'Member Name', 'orvian-addons' ),
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
			]
		);

		$repeater->add_control(
			'member_role',
			[
				'label'       => esc_html__( 'Member Role', 'orvian-addons' ),
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
			]
		);

		$repeater->add_control(
			'member_logo',
			[
				'label' => esc_html__( 'Member Logo', 'orvian-addons' ),
				'type'  => Controls_Manager::MEDIA,
			]
		);

		$repeater->add_control(
			'networks',
			[
				'label'       => esc_html__( 'Social Networks', 'orvian-addons' ),
				'type'        => Controls_Manager::SELECT2,
				'multiple'    => true,
				'label_block' => true,
				'default'     => [ 'x', 'linkedin', 'github' ],
				'options'     => [
					'facebook'  => esc_html__( 'Facebook', 'orvian-addons' ),
					'x'         => esc_html__( 'X (Twitter)', 'orvian-addons' ),
					'linkedin'  => esc_html__( 'LinkedIn', 'orvian-addons' ),
					'github'    => esc_html__( 'GitHub', 'orvian-addons' ),
					'pinterest' => esc_html__( 'Pinterest', 'orvian-addons' ),
					'whatsapp'  => esc_html__( 'WhatsApp', 'orvian-addons' ),
					'telegram'  => esc_html__( 'Telegram', 'orvian-addons' ),
					'email'     => esc_html__( 'Email', 'orvian-addons' ),
					'reddit'    => esc_html__( 'Reddit', 'orvian-addons' ),
					'pocket'    => esc_html__( 'Pocket', 'orvian-addons' ),
					'instagram' => esc_html__( 'Instagram', 'orvian-addons' ),
				],
			]
		);

		$repeater->add_control(
			'social_facebook_url',
			[
				'label'      => esc_html__( 'Facebook Profile URL', 'orvian-addons' ),
				'type'       => Controls_Manager::URL,
				'conditions' => [
					'terms' => [
						[
							'name'     => 'networks',
							'value'    => 'facebook',
							'operator' => 'contains',
						],
					],
				],
			]
		);

		$repeater->add_control(
			'social_x_url',
			[
				'label'      => esc_html__( 'X Profile URL', 'orvian-addons' ),
				'type'       => Controls_Manager::URL,
				'conditions' => [
					'terms' => [
						[
							'name'     => 'networks',
							'value'    => 'x',
							'operator' => 'contains',
						],
					],
				],
			]
		);

		$repeater->add_control(
			'social_linkedin_url',
			[
				'label'      => esc_html__( 'LinkedIn Profile URL', 'orvian-addons' ),
				'type'       => Controls_Manager::URL,
				'conditions' => [
					'terms' => [
						[
							'name'     => 'networks',
							'value'    => 'linkedin',
							'operator' => 'contains',
						],
					],
				],
			]
		);

		$repeater->add_control(
			'social_pinterest_url',
			[
				'label'      => esc_html__( 'Pinterest Profile URL', 'orvian-addons' ),
				'type'       => Controls_Manager::URL,
				'conditions' => [
					'terms' => [
						[
							'name'     => 'networks',
							'value'    => 'pinterest',
							'operator' => 'contains',
						],
					],
				],
			]
		);

		$repeater->add_control(
			'social_github_url',
			[
				'label'      => esc_html__( 'GitHub Profile URL', 'orvian-addons' ),
				'type'       => Controls_Manager::URL,
				'conditions' => [
					'terms' => [
						[
							'name'     => 'networks',
							'value'    => 'github',
							'operator' => 'contains',
						],
					],
				],
			]
		);

		$repeater->add_control(
			'social_whatsapp_url',
			[
				'label'      => esc_html__( 'WhatsApp Profile URL', 'orvian-addons' ),
				'type'       => Controls_Manager::URL,
				'conditions' => [
					'terms' => [
						[
							'name'     => 'networks',
							'value'    => 'whatsapp',
							'operator' => 'contains',
						],
					],
				],
			]
		);

		$repeater->add_control(
			'social_telegram_url',
			[
				'label'      => esc_html__( 'Telegram Profile URL', 'orvian-addons' ),
				'type'       => Controls_Manager::URL,
				'conditions' => [
					'terms' => [
						[
							'name'     => 'networks',
							'value'    => 'telegram',
							'operator' => 'contains',
						],
					],
				],
			]
		);

		$repeater->add_control(
			'social_email_url',
			[
				'label'      => esc_html__( 'Email Address', 'orvian-addons' ),
				'type'       => Controls_Manager::URL,
				'conditions' => [
					'terms' => [
						[
							'name'     => 'networks',
							'value'    => 'email',
							'operator' => 'contains',
						],
					],
				],
			]
		);

		$repeater->add_control(
			'social_reddit_url',
			[
				'label'      => esc_html__( 'Reddit Profile URL', 'orvian-addons' ),
				'type'       => Controls_Manager::URL,
				'conditions' => [
					'terms' => [
						[
							'name'     => 'networks',
							'value'    => 'reddit',
							'operator' => 'contains',
						],
					],
				],
			]
		);

		$repeater->add_control(
			'social_pocket_url',
			[
				'label'      => esc_html__( 'Pocket Profile URL', 'orvian-addons' ),
				'type'       => Controls_Manager::URL,
				'conditions' => [
					'terms' => [
						[
							'name'     => 'networks',
							'value'    => 'pocket',
							'operator' => 'contains',
						],
					],
				],
			]
		);

		$repeater->add_control(
			'social_instagram_url',
			[
				'label'      => esc_html__( 'Instagram Profile URL', 'orvian-addons' ),
				'type'       => Controls_Manager::URL,
				'conditions' => [
					'terms' => [
						[
							'name'     => 'networks',
							'value'    => 'instagram',
							'operator' => 'contains',
						],
					],
				],
			]
		);

		$this->add_control(
			'team_members',
			[
				'label'       => esc_html__( 'Team Members', 'orvian-addons' ),
				'type'        => Controls_Manager::REPEATER,
				'fields'      => $repeater->get_controls(),
				'default'     => [
					[
						'member_name' => esc_html__( 'Member Name', 'orvian-addons' ),
						'member_role' => esc_html__( 'Member Role', 'orvian-addons' ),
					],
					[
						'member_name' => esc_html__( 'Member Name', 'orvian-addons' ),
						'member_role' => esc_html__( 'Member Role', 'orvian-addons' ),
					],
					[
						'member_name' => esc_html__( 'Member Name', 'orvian-addons' ),
						'member_role' => esc_html__( 'Member Role', 'orvian-addons' ),
					],
				],
				'title_field' => '{{{ member_name }}}',
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'carousel_settings_section',
			[
				'label' => esc_html__( 'Carousel Settings', 'orvian-addons' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->register_carousel_controls();

		$this->end_controls_section();

		$this->start_controls_section(
			'style_content',
			[
				'label' => esc_html__( 'Item', 'orvian-addons' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'background_image',
			[
				'label'     => esc_html__( 'Background Image', 'orvian-addons' ),
				'type'      => Controls_Manager::MEDIA,
				'selectors' => [
					'{{WRAPPER}} .orvian-team-carousel__slide' => 'background-image: url({{url}});',
				],
			]
		);

		$this->add_control(
			'background_image_active',
			[
				'label'     => esc_html__( 'Background Image Active', 'orvian-addons' ),
				'type'      => Controls_Manager::MEDIA,
				'selectors' => [
					'{{WRAPPER}} .orvian-team-carousel__slide.swiper-slide-active' => 'background-image: url({{url}});',
					'{{WRAPPER}} .orvian-team-carousel__slide:hover' => 'background-image: url({{url}});',
				],
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'carousel_style_content',
			[
				'label' => esc_html__( 'Carousel Style', 'orvian-addons' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->register_carousel_style_controls();

		$this->end_controls_section();
	}

	/**
	 * Render carousel items
	 */
	protected function render_items_carousel() {
		$settings = $this->get_settings_for_display();
		$items    = $settings['team_members'] ?? [];

		if ( empty( $items ) ) {
			return;
		}

		$this->add_render_attribute( 'slide', 'class', [ 'swiper-slide', 'orvian-team-carousel__slide', 'relative', 'rounded-xl', 'overflow-hidden' ] );

		$this->add_render_attribute( 'overlay', 'class', [ 'orvian-team-carousel__overlay', 'absolute', 'bottom-0', 'inset-x-0', 'pointer-events-none' ] );

		$this->add_render_attribute( 'order', 'class', [ 'orvian-team-carousel__order', 'absolute', 'top-0', 'right-0', 'p-32px', 'pointer-events-none', 'text-display-1', 'text-heading', 'font-heading' ] );
		$this->add_render_attribute( 'image', 'class', [ 'orvian-team-carousel__image', 'ratio-image' ] );
		$this->add_render_attribute( 'info', 'class', [ 'orvian-team-carousel__info', 'absolute', 'bottom-0', 'inset-x-0', 'orvian-color-scheme theme-light', 'm-28px', 'px-4', 'pb-4', 'pt-3', 'rounded-sm' ] );
		$this->add_render_attribute( 'summary', 'class', [ 'orvian-team-carousel__summary', 'flex', 'items-end', 'gap-2' ] );
		$this->add_render_attribute( 'name', 'class', [ 'orvian-team-carousel__name', 'text-heading', 'font-heading', 'font-semibold', 'font-2xl' ] );
		$this->add_render_attribute( 'role', 'class', [ 'orvian-team-carousel__role', 'text-body-3', 'font-medium' ] );
		$this->add_render_attribute( 'logo', 'class', [ 'orvian-team-carousel__logo', 'shrink-0' ] );
		$this->add_render_attribute( 'social', 'class', [ 'orvian-team-carousel__socials', 'flex', 'gap-8px', 'flex-wrap', 'border-top', 'pt-20px', 'mt-1' ] );

		foreach ( $items as $index => $item ) {
			$networks = $item['networks'] ?? [];
			?>
			<div <?php $this->print_render_attribute_string( 'slide' ); ?>>
				<span <?php $this->print_render_attribute_string( 'order' ); ?>><?php echo esc_html( str_pad( $index + 1, 2, '0', STR_PAD_LEFT ) ); ?></span>

				<div <?php $this->print_render_attribute_string( 'image' ); ?>>
					<?php if ( ! empty( $item['member_image']['url'] ) ) : ?>
						<?php if ( ! empty( $item['member_image']['id'] ) ) : ?>
							<?php echo wp_get_attachment_image( $item['member_image']['id'], 'full' ); ?>
						<?php elseif ( ! empty( $item['member_image']['url'] ) ) : ?>
							<img src="<?php echo esc_url( $item['member_image']['url'] ); ?>">
						<?php endif; ?>
					<?php elseif ( ! empty( $item['member_image']['url'] ) ) : ?>
						<img src="<?php echo esc_url( $item['member_image']['url'] ); ?>" alt="<?php echo esc_attr( $item['member_name'] ); ?>">
					<?php endif; ?>

					<?php if ( ! empty( $item['member_name'] ) || ! empty( $item['member_role'] ) || ! empty( $item['member_logo']['id'] ) || ! empty( $networks ) ) : ?>
						<div <?php $this->print_render_attribute_string( 'overlay' ); ?>></div>
					<?php endif; ?>
				</div>

				<?php if ( ! empty( $item['member_name'] ) || ! empty( $item['member_role'] ) || ! empty( $item['member_logo']['id'] ) || ! empty( $networks ) ) : ?>
				<div <?php $this->print_render_attribute_string( 'info' ); ?>>
					<?php if ( ! empty( $item['member_name'] ) || ! empty( $item['member_role'] ) || ! empty( $item['member_logo']['id'] ) ) : ?>
					<div <?php $this->print_render_attribute_string( 'summary' ); ?>>
						<?php if ( ! empty( $item['member_name'] ) || ! empty( $item['member_role'] ) ) : ?>
							<div class="flex-1">
								<?php if ( ! empty( $item['member_name'] ) ) : ?>
									<div <?php $this->print_render_attribute_string( 'name' ); ?>><?php echo esc_html( $item['member_name'] ); ?></div>
								<?php endif; ?>

								<?php if ( ! empty( $item['member_role'] ) ) : ?>
									<div <?php $this->print_render_attribute_string( 'role' ); ?>><?php echo esc_html( $item['member_role'] ); ?></div>
								<?php endif; ?>
							</div>
						<?php endif; ?>

						<?php if ( ! empty( $item['member_logo']['url'] ) ) : ?>
							<div <?php $this->print_render_attribute_string( 'logo' ); ?>>
								<?php if ( ! empty( $item['member_logo']['id'] ) ) : ?>
									<?php echo wp_get_attachment_image( $item['member_logo']['id'], 'full' ); ?>
								<?php elseif ( ! empty( $item['member_logo']['url'] ) ) : ?>
									<img src="<?php echo esc_url( $item['member_logo']['url'] ); ?>">
								<?php endif; ?>
							</div>
						<?php endif; ?>
					</div>
					<?php endif; ?>

					<?php if ( ! empty( $networks ) ) : ?>
					<div <?php $this->print_render_attribute_string( 'social' ); ?>>
						<?php foreach ( $networks as $network ) : ?>
							<?php
							$url_key   = 'social_' . $network . '_url';
							$link_data = $item[ $url_key ] ?? [];

							if ( empty( $link_data['url'] ) ) {
								continue;
							}

							$link_attr_name = 'social_link_' . $index . '_' . $network;
							$this->add_link_attributes( $link_attr_name, $link_data );

							$aria_label = sprintf(
								/* translators: %s: Social network name. */
								esc_html__( 'Visit %s profile', 'orvian-addons' ),
								ucfirst( $network )
							);

							$this->add_render_attribute( $link_attr_name, 'class', [ 'button', 'button-icon', 'orvian-team-carousel__social', 'orvian-team-carousel__social--' . $network ] );
							$this->add_render_attribute( $link_attr_name, 'aria-label', $aria_label );
							?>
							<a <?php $this->print_render_attribute_string( $link_attr_name ); ?>>
								<?php echo Helper::get_svg( $network, 'social' ); // phpcs:ignore ?>
							</a>
						<?php endforeach; ?>
					</div>
					<?php endif; ?>
				</div>
				<?php endif; ?>
			</div>
			<?php
		}
	}

	/**
	 * Render widget output
	 */
	public function render() {
		$this->render_carousel( 'div', 'orvian-team-carousel' );
	}
}
