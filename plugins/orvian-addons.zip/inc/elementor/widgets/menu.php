<?php
/**
 * Menu Widget
 *
 * @package OrvianAddons
 */

namespace OrvianAddons\Elementor\Widgets;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;
use OrvianAddons\Elementor\Elementor as OrvianAddons_Elementor;

/**
 * Menu Widget Class
 */
class Menu extends Widget_Base {

	/**
	 * Get widget name
	 *
	 * @return string
	 */
	public function get_name() {
		return 'orvian-menu';
	}

	/**
	 * Get widget title
	 *
	 * @return string
	 */
	public function get_title() {
		return esc_html__( 'Menu', 'orvian-addons' );
	}

	/**
	 * Get widget icon
	 *
	 * @return string
	 */
	public function get_icon() {
		return 'eicon-nav-menu ' . OrvianAddons_Elementor::CLASS_WIDGET;
	}

	/**
	 * Get widget categories
	 *
	 * @return array
	 */
	public function get_categories() {
		return [ OrvianAddons_Elementor::CATEGORY ];
	}

	/**
	 * Get widget keywords
	 *
	 * @return array
	 */
	public function get_keywords() {
		return [ 'orvian', 'menu', 'nav', 'navigation' ];
	}

	/**
	 * Get menu options
	 *
	 * @return array
	 */
	private function get_menu_options() {
		$menus = get_terms(
			[
				'taxonomy'   => 'nav_menu',
				'hide_empty' => false,
			]
		);

		$options = [];

		if ( ! empty( $menus ) && ! is_wp_error( $menus ) ) {
			foreach ( $menus as $menu ) {
				$options[ $menu->slug ] = $menu->name;
			}
		}

		return $options;
	}

	/**
	 * Register widget controls
	 */
	protected function register_controls() {
		$this->start_controls_section(
			'content_section',
			[
				'label' => esc_html__( 'Menu', 'orvian-addons' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'menu_selected',
			[
				'label'       => esc_html__( 'Select Menu', 'orvian-addons' ),
				'type'        => Controls_Manager::SELECT,
				'options'     => $this->get_menu_options(),
				'default'     => '',
				'label_block' => true,
			]
		);

		$this->add_control(
			'layout',
			[
				'label'     => esc_html__( 'Layout', 'orvian-addons' ),
				'type'      => Controls_Manager::CHOOSE,
				'options'   => [
					'horizontal' => [
						'title' => esc_html__( 'Horizontal', 'orvian-addons' ),
						'icon'  => 'eicon-navigation-horizontal',
					],
					'vertical'   => [
						'title' => esc_html__( 'Vertical', 'orvian-addons' ),
						'icon'  => 'eicon-navigation-vertical',
					],
				],
				'default'   => 'horizontal',
				'separator' => 'before',
			]
		);

		$this->add_control(
			'menu_align',
			[
				'label'     => esc_html__( 'Alignment', 'orvian-addons' ),
				'type'      => Controls_Manager::CHOOSE,
				'options'   => [
					'left'   => [
						'title' => esc_html__( 'Left', 'orvian-addons' ),
						'icon'  => 'eicon-text-align-left',
					],
					'center' => [
						'title' => esc_html__( 'Center', 'orvian-addons' ),
						'icon'  => 'eicon-text-align-center',
					],
					'right'  => [
						'title' => esc_html__( 'Right', 'orvian-addons' ),
						'icon'  => 'eicon-text-align-right',
					],
				],
				'default'   => 'center',
				'condition' => [
					'layout' => 'horizontal',
				],
				'selectors' => [
					'{{WRAPPER}} .main-navigation--elementor' => 'text-align: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'menu_depth',
			[
				'label'       => esc_html__( 'Menu Depth', 'orvian-addons' ),
				'description' => esc_html__( '0 = unlimited depth, 1 = parent only, 2 = parent + children, etc.', 'orvian-addons' ),
				'type'        => Controls_Manager::NUMBER,
				'min'         => 0,
				'max'         => 10,
				'step'        => 1,
				'default'     => 0,
				'separator'   => 'before',
			]
		);

		$this->add_control(
			'menu_class',
			[
				'label'       => esc_html__( 'Custom Menu Class', 'orvian-addons' ),
				'type'        => Controls_Manager::TEXT,
				'placeholder' => esc_html__( 'my-custom-class', 'orvian-addons' ),
				'label_block' => true,
				'separator'   => 'before',
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'section_menu_items_style',
			[
				'label' => esc_html__( 'Menu Items', 'orvian-addons' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'menu_items_typography',
				'selector' => '{{WRAPPER}} .main-navigation--elementor .nav-menu > li > a',
			]
		);

		$this->add_control(
			'menu_items_color',
			[
				'label'     => esc_html__( 'Color', 'orvian-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .main-navigation--elementor .nav-menu > li > a' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'menu_items_color_hover',
			[
				'label'     => esc_html__( 'Hover Color', 'orvian-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .main-navigation--elementor .nav-menu > li > a:hover' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'menu_items_color_active',
			[
				'label'     => esc_html__( 'Active Color', 'orvian-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .main-navigation--elementor .nav-menu > li.current-menu-item > a' => 'color: {{VALUE}};',
					'{{WRAPPER}} .main-navigation--elementor .nav-menu > li.current-menu-parent > a' => 'color: {{VALUE}};',
					'{{WRAPPER}} .main-navigation--elementor .nav-menu > li.current-menu-ancestor > a' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_responsive_control(
			'menu_items_padding',
			[
				'label'      => esc_html__( 'Padding', 'orvian-addons' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', 'rem', 'custom' ],
				'selectors'  => [
					'{{WRAPPER}} .main-navigation--elementor .nav-menu > li > a' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'menu_items_gap',
			[
				'label'      => esc_html__( 'Gap Between Items', 'orvian-addons' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', 'em', 'rem', 'custom' ],
				'range'      => [
					'px' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'selectors'  => [
					'{{WRAPPER}} .main-navigation--elementor .nav-menu' => 'gap: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'menu_items_border_radius',
			[
				'label'      => esc_html__( 'Border Radius', 'orvian-addons' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'selectors'  => [
					'{{WRAPPER}} .main-navigation--elementor .nav-menu > li > a' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'section_submenu_style',
			[
				'label' => esc_html__( 'Sub Menu', 'orvian-addons' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_responsive_control(
			'submenu_width',
			[
				'label'      => esc_html__( 'Width', 'orvian-addons' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', 'em', 'rem', 'custom' ],
				'range'      => [
					'px' => [
						'min' => 200,
						'max' => 1000,
					],
				],
				'selectors'  => [
					'{{WRAPPER}} .main-navigation:not(.main-navigation--vertical) .sub-menu' => 'width: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}} .main-navigation--vertical .nav-menu > li > .sub-menu' => 'width: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'submenu_items_gap',
			[
				'label'      => esc_html__( 'Gap Between Items', 'orvian-addons' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', 'em', 'rem', 'custom' ],
				'range'      => [
					'px' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'selectors'  => [
					'{{WRAPPER}} .main-navigation--elementor .nav-menu ul li' => 'margin-bottom: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'submenu_typography',
				'selector' => '{{WRAPPER}} .main-navigation--elementor .nav-menu .sub-menu a',
			]
		);

		$this->add_control(
			'submenu_color',
			[
				'label'     => esc_html__( 'Color', 'orvian-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .main-navigation--elementor .nav-menu .sub-menu a' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'submenu_color_hover',
			[
				'label'     => esc_html__( 'Hover Color', 'orvian-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .main-navigation--elementor .nav-menu .sub-menu a:hover' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'submenu_background_color',
			[
				'label'     => esc_html__( 'Background Color', 'orvian-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .main-navigation.main-navigation--vertical .nav-menu .sub-menu' => 'background-color: {{VALUE}};',
					'{{WRAPPER}} .main-navigation:not(.main-navigation--vertical) .nav-menu ul::after' => 'background-color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'submenu_backdrop_blur',
			[
				'label'      => esc_html__( 'Backdrop Blur', 'orvian-addons' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px' ],
				'selectors'  => [
					'{{WRAPPER}} .main-navigation:not(.main-navigation--vertical) .nav-menu ul::after' => 'backdrop-filter: blur({{SIZE}}px);',
				],
				'condition'  => [
					'layout' => 'horizontal',
				],
			]
		);

		$this->add_responsive_control(
			'submenu_padding',
			[
				'label'      => esc_html__( 'Padding', 'orvian-addons' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', 'rem', 'custom' ],
				'selectors'  => [
					'{{WRAPPER}} .main-navigation--elementor .nav-menu ul' => 'padding: {{TOP}}{{UNIT}} 0 {{BOTTOM}}{{UNIT}} 0;',
					'{{WRAPPER}} .main-navigation--elementor .nav-menu ul li' => 'padding: 0 {{RIGHT}}{{UNIT}} 0 {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'submenu_border_radius',
			[
				'label'      => esc_html__( 'Border Radius', 'orvian-addons' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'selectors'  => [
					'{{WRAPPER}} .main-navigation--elementor .nav-menu .sub-menu' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'      => 'submenu_border',
				'selector'  => '{{WRAPPER}} .main-navigation:not(.main-navigation--vertical) .nav-menu ul::after',
				'condition' => [
					'layout' => 'horizontal',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'      => 'submenu_box_shadow',
				'selector'  => '{{WRAPPER}} .main-navigation:not(.main-navigation--vertical) .nav-menu ul::after',
				'condition' => [
					'layout' => 'horizontal',
				],
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'section_container_style',
			[
				'label' => esc_html__( 'Container', 'orvian-addons' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'container_background_color',
			[
				'label'     => esc_html__( 'Background Color', 'orvian-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .main-navigation.main-navigation--vertical' => 'background-color: {{VALUE}};',
					'{{WRAPPER}} .main-navigation:not(.main-navigation--vertical) .nav-menu::after' => 'background-color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'container_backdrop_blur',
			[
				'label'      => esc_html__( 'Backdrop Blur', 'orvian-addons' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px' ],
				'selectors'  => [
					'{{WRAPPER}} .main-navigation:not(.main-navigation--vertical) .nav-menu::after' => 'backdrop-filter: blur({{SIZE}}px);',
				],
				'condition'  => [
					'layout' => 'horizontal',
				],
			]
		);

		$this->add_responsive_control(
			'container_padding',
			[
				'label'      => esc_html__( 'Padding', 'orvian-addons' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', 'rem', 'custom' ],
				'selectors'  => [
					'{{WRAPPER}} .main-navigation--elementor' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'container_border_radius',
			[
				'label'      => esc_html__( 'Border Radius', 'orvian-addons' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'selectors'  => [
					'{{WRAPPER}} .main-navigation.main-navigation--vertical' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					'{{WRAPPER}} .main-navigation:not(.main-navigation--vertical) .nav-menu::after' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'      => 'container_border',
				'selector'  => '{{WRAPPER}} .main-navigation:not(.main-navigation--vertical) .nav-menu::after',
				'condition' => [
					'layout' => 'horizontal',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'      => 'container_box_shadow',
				'selector'  => '{{WRAPPER}} .main-navigation:not(.main-navigation--vertical) .nav-menu::after',
				'condition' => [
					'layout' => 'horizontal',
				],
			]
		);

		$this->end_controls_section();
	}

	/**
	 * Render widget output
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();

		if ( empty( $settings['menu_selected'] ) ) {
			return;
		}

		$container_class = 'main-navigation primary-navigation main-navigation--elementor pointer-events-none main-navigation--' . esc_attr( $settings['layout'] );

		$menu_class = 'menu nav-menu main-menu pointer-events-auto';
		if ( ! empty( $settings['menu_class'] ) ) {
			$menu_class = ' ' . $settings['menu_class'];
		}

		$nav_menu_args = [
			'menu'            => esc_attr( $settings['menu_selected'] ),
			'menu_class'      => $menu_class,
			'depth'           => ! empty( $settings['menu_depth'] ) ? absint( $settings['menu_depth'] ) : 0,
			'container'       => 'nav',
			'container_class' => $container_class,
			'fallback_cb'     => false,
			'echo'            => true,
		];

		wp_nav_menu( $nav_menu_args );
	}
}
