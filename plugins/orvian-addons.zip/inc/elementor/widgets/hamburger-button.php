<?php
/**
 * Hamburger Menu Button Widget
 *
 * @package OrvianAddons
 */

namespace OrvianAddons\Elementor\Widgets;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Icons_Manager;
use Elementor\Group_Control_Box_Shadow;
use OrvianAddons\Elementor\Elementor as OrvianAddons_Elementor;

/**
 * Hamburger Menu Button Widget Class
 */
class Hamburger_Button extends Widget_Base {

	/**
	 * Get widget name
	 *
	 * @return string
	 */
	public function get_name() {
		return 'orvian-hamburger-button';
	}

	/**
	 * Get widget title
	 *
	 * @return string
	 */
	public function get_title() {
		return esc_html__( 'Hamburger Menu Button', 'orvian-addons' );
	}

	/**
	 * Get widget icon
	 *
	 * @return string
	 */
	public function get_icon() {
		return 'eicon-menu-bar ' . OrvianAddons_Elementor::CLASS_WIDGET;
	}

	/**
	 * Get widget categories
	 *
	 * @return array
	 */
	public function get_categories() {
		return [ OrvianAddons_Elementor::CATEGORY ];
	}

	/**
	 * Get widget keywords
	 *
	 * @return array
	 */
	public function get_keywords() {
		return [ 'orvian', 'hamburger', 'menu', 'button' ];
	}

	/**
	 * Register widget controls
	 */
	protected function register_controls() {
		$this->start_controls_section(
			'content_section',
			[
				'label' => esc_html__( 'Button', 'orvian-addons' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'icon_selected',
			[
				'label' => esc_html__( 'Icon', 'orvian-addons' ),
				'type'  => Controls_Manager::ICONS,
			]
		);

		$this->add_responsive_control(
			'button_alignment',
			[
				'label'     => esc_html__( 'Alignment', 'orvian-addons' ),
				'type'      => Controls_Manager::CHOOSE,
				'options'   => [
					'left'   => [
						'title' => esc_html__( 'Left', 'orvian-addons' ),
						'icon'  => 'eicon-text-align-left',
					],
					'center' => [
						'title' => esc_html__( 'Center', 'orvian-addons' ),
						'icon'  => 'eicon-text-align-center',
					],
					'right'  => [
						'title' => esc_html__( 'Right', 'orvian-addons' ),
						'icon'  => 'eicon-text-align-right',
					],
				],
				'selectors' => [
					'{{WRAPPER}}' => 'text-align: {{VALUE}};',
				],
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'section_button_style',
			[
				'label' => esc_html__( 'Button', 'orvian-addons' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_responsive_control(
			'button_width',
			[
				'label'      => esc_html__( 'Width', 'orvian-addons' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', 'em', 'custom' ],
				'range'      => [
					'px' => [
						'min' => 20,
						'max' => 200,
					],
				],
				'selectors'  => [
					'{{WRAPPER}} .hamburger-menu__button' => 'width: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'button_height',
			[
				'label'      => esc_html__( 'Height', 'orvian-addons' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', 'em', 'custom' ],
				'range'      => [
					'px' => [
						'min' => 20,
						'max' => 200,
					],
				],
				'selectors'  => [
					'{{WRAPPER}} .hamburger-menu__button' => 'height: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'button_border_radius',
			[
				'label'      => esc_html__( 'Border Radius', 'orvian-addons' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'custom' ],
				'selectors'  => [
					'{{WRAPPER}} .hamburger-menu__button' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'button_box_shadow',
				'selector' => '{{WRAPPER}} .hamburger-menu__button',
			]
		);

		$this->start_controls_tabs( 'button_tabs' );

		$this->start_controls_tab(
			'tab_button_normal',
			[
				'label' => esc_html__( 'Normal', 'orvian-addons' ),
			]
		);

		$this->add_control(
			'button_background_color',
			[
				'label'     => esc_html__( 'Background Color', 'orvian-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .hamburger-menu__button' => 'background-color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'button_border_color',
			[
				'label'     => esc_html__( 'Border Color', 'orvian-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .hamburger-menu__button' => 'border-color: {{VALUE}};',
				],
			]
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			'tab_button_hover',
			[
				'label' => esc_html__( 'Hover', 'orvian-addons' ),
			]
		);

		$this->add_control(
			'button_background_color_hover',
			[
				'label'     => esc_html__( 'Background Color', 'orvian-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .hamburger-menu__button:hover' => 'background-color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'button_border_color_hover',
			[
				'label'     => esc_html__( 'Border Color', 'orvian-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .hamburger-menu__button:hover' => 'border-color: {{VALUE}};',
				],
			]
		);

		$this->end_controls_tab();

		$this->end_controls_tabs();

		$this->end_controls_section();

		$this->start_controls_section(
			'section_icon_style',
			[
				'label'     => esc_html__( 'Hamburger Icon', 'orvian-addons' ),
				'tab'       => Controls_Manager::TAB_STYLE,
				'condition' => [
					'icon_selected[value]!' => '',
				],
			]
		);

		$this->add_control(
			'icon_color',
			[
				'label'     => esc_html__( 'Color', 'orvian-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .hamburger-menu__button' => 'color: {{VALUE}};',
				],
				'condition' => [
					'icon_selected[value]!' => '',
				],
			]
		);

		$this->add_control(
			'icon_color_hover',
			[
				'label'     => esc_html__( 'Hover Color', 'orvian-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .hamburger-menu__button:hover' => 'color: {{VALUE}};',
				],
				'condition' => [
					'icon_selected[value]!' => '',
				],
			]
		);

		$this->add_responsive_control(
			'icon_size',
			[
				'label'      => esc_html__( 'Size', 'orvian-addons' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', 'em', 'custom' ],
				'selectors'  => [
					'{{WRAPPER}} .hamburger-menu__button .orvian-svg-icon' => 'font-size: {{SIZE}}{{UNIT}};',
				],
				'condition'  => [
					'icon_selected[value]!' => '',
				],
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'section_lines_style',
			[
				'label'     => esc_html__( 'Hamburger Lines', 'orvian-addons' ),
				'tab'       => Controls_Manager::TAB_STYLE,
				'condition' => [
					'icon_selected[value]' => '',
				],
			]
		);

		$this->add_control(
			'lines_color',
			[
				'label'     => esc_html__( 'Color', 'orvian-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .hamburger-menu__button::before,
					 {{WRAPPER}} .hamburger-menu__button::after' => 'background-color: {{VALUE}};',
				],
				'condition' => [
					'icon_selected[value]' => '',
				],
			]
		);

		$this->add_control(
			'lines_color_hover',
			[
				'label'     => esc_html__( 'Hover Color', 'orvian-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .hamburger-menu__button:hover::before,
					 {{WRAPPER}} .hamburger-menu__button:hover::after' => 'background-color: {{VALUE}};',
				],
				'condition' => [
					'icon_selected[value]' => '',
				],
			]
		);

		$this->add_responsive_control(
			'lines_width',
			[
				'label'      => esc_html__( 'Width', 'orvian-addons' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', 'em', 'custom' ],
				'range'      => [
					'px' => [
						'min' => 8,
						'max' => 60,
					],
				],
				'selectors'  => [
					'{{WRAPPER}} .hamburger-menu__button::before,
					 {{WRAPPER}} .hamburger-menu__button::after' => 'width: {{SIZE}}{{UNIT}};',
				],
				'condition'  => [
					'icon_selected[value]' => '',
				],
			]
		);

		$this->add_responsive_control(
			'lines_height',
			[
				'label'      => esc_html__( 'Thickness', 'orvian-addons' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', 'em', 'custom' ],
				'range'      => [
					'px' => [
						'min' => 1,
						'max' => 10,
					],
				],
				'selectors'  => [
					'{{WRAPPER}} .hamburger-menu__button::before,
					 {{WRAPPER}} .hamburger-menu__button::after' => 'height: {{SIZE}}{{UNIT}};',
				],
				'condition'  => [
					'icon_selected[value]' => '',
				],
			]
		);

		$this->add_responsive_control(
			'lines_gap',
			[
				'label'      => esc_html__( 'Spacing Between Lines', 'orvian-addons' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', 'em', 'custom' ],
				'range'      => [
					'px' => [
						'min' => 1,
						'max' => 20,
					],
				],
				'selectors'  => [
					'{{WRAPPER}} .hamburger-menu__button' => 'gap: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}} .hamburger-menu__button::before' => 'transform: translateY(calc(-1 * {{SIZE}}{{UNIT}}));',
					'{{WRAPPER}} .hamburger-menu__button::after' => 'transform: translateY({{SIZE}}{{UNIT}});',
					'{{WRAPPER}} .hamburger-menu__button.is-active::before' => 'transform: translateY(0) rotate(45deg);',
					'{{WRAPPER}} .hamburger-menu__button.is-active::after' => 'transform: translateY(0) rotate(-45deg);',
				],
				'condition'  => [
					'icon_selected[value]' => '',
				],
			]
		);

		$this->add_responsive_control(
			'lines_border_radius',
			[
				'label'      => esc_html__( 'Lines Border Radius', 'orvian-addons' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%', 'em', 'custom' ],
				'range'      => [
					'px' => [
						'min' => 0,
						'max' => 20,
					],
				],
				'selectors'  => [
					'{{WRAPPER}} .hamburger-menu__button::before,
					 {{WRAPPER}} .hamburger-menu__button::after' => 'border-radius: {{SIZE}}{{UNIT}};',
				],
				'condition'  => [
					'icon_selected[value]' => '',
				],
			]
		);

		$this->end_controls_section();
	}

	/**
	 * Render widget output
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();

		$button_class = 'hamburger-menu__button button-primary button-icon no-effect-active circle';

		if ( ! empty( $settings['icon_selected']['value'] ) ) {
			$button_class .= ' has-icon';
		}

		$this->add_render_attribute(
			'button',
			[
				'class'       => $button_class,
				'type'        => 'button',
				'aria-label'  => esc_attr__( 'Hamburger menu', 'orvian-addons' ),
				'data-toggle' => 'off-canvas',
				'data-target' => 'orvian-hamburger-menu',
			]
		);

		// Register the hamburger panel so the theme renders it in footer.
		if ( class_exists( '\Orvian\Theme' ) && method_exists( '\Orvian\Theme', 'set_prop' ) ) {
			\Orvian\Theme::set_prop( 'panels', 'hamburger' );
		}

		?>
		<button <?php $this->print_render_attribute_string( 'button' ); ?>>
			<?php if ( ! empty( $settings['icon_selected']['value'] ) ) : ?>
				<span class="orvian-svg-icon">
				<?php
				Icons_Manager::render_icon(
					$settings['icon_selected'],
					[
						'aria-hidden' => 'true',
						'fill'        => 'currentColor',
					]
				);
				?>
			</span>
			<?php endif; ?>
		</button>
		<?php
	}
}
