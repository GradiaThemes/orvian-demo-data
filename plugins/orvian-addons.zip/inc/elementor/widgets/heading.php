<?php
/**
 * Heading Widget
 *
 * @package OrvianAddons
 */

namespace OrvianAddons\Elementor\Widgets;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use OrvianAddons\Elementor\Elementor as OrvianAddons_Elementor;

/**
 * Heading Widget Class
 */
class Heading extends Widget_Base {

	use Base\Text_Class;

	/**
	 * Get widget name
	 *
	 * @return string
	 */
	public function get_name() {
		return 'orvian-heading';
	}

	/**
	 * Get widget title
	 *
	 * @return string
	 */
	public function get_title() {
		return esc_html__( 'Heading', 'orvian-addons' );
	}

	/**
	 * Get widget icon
	 *
	 * @return string
	 */
	public function get_icon() {
		return 'eicon-heading ' . OrvianAddons_Elementor::CLASS_WIDGET;
	}

	/**
	 * Get widget categories
	 *
	 * @return array
	 */
	public function get_categories() {
		return [ OrvianAddons_Elementor::CATEGORY ];
	}

	/**
	 * Get widget keywords
	 *
	 * @return array
	 */
	public function get_keywords() {
		return [ 'orvian', 'heading', 'title', 'text' ];
	}

	/**
	 * Register widget controls
	 */
	protected function register_controls() {
		// Section content.
		$this->start_controls_section(
			'content_section',
			[
				'label' => esc_html__( 'Heading', 'orvian-addons' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'auto_detect',
			[
				'label' => esc_html__( 'Auto Detect', 'orvian-addons' ),
				'type'  => Controls_Manager::SWITCHER,
			]
		);

		$this->add_control(
			'heading',
			[
				'label'       => esc_html__( 'Heading', 'orvian-addons' ),
				'type'        => Controls_Manager::TEXTAREA,
				'dynamic'     => [
					'active' => true,
				],
				'placeholder' => esc_html__( 'Enter your heading', 'orvian-addons' ),
				'default'     => esc_html__( 'Add Your Heading Text Here', 'orvian-addons' ),
				'condition'   => [
					'auto_detect!' => 'yes',
				],
			]
		);

		$this->add_control(
			'heading_size',
			[
				'label'   => esc_html__( 'HTML Tag', 'orvian-addons' ),
				'type'    => Controls_Manager::SELECT,
				'options' => $this->get_text_class_options_with_tags(),
				'default' => 'h2',
			]
		);

		$this->add_control(
			'use_font_family_heading',
			[
				'label'     => esc_html__( 'Use Font Family of Heading', 'orvian-addons' ),
				'type'      => Controls_Manager::SWITCHER,
				'condition' => [
					'heading_size!' => [ 'h1', 'h2', 'h3', 'h4', 'h5', 'h6' ],
				],
			]
		);

		$this->add_control(
			'use_color_heading',
			[
				'label'     => esc_html__( 'Use Color of Heading', 'orvian-addons' ),
				'type'      => Controls_Manager::SWITCHER,
				'condition' => [
					'heading_size!'            => [ 'h1', 'h2', 'h3', 'h4', 'h5', 'h6' ],
					'use_font_family_heading!' => 'yes',
				],
			]
		);

		$this->add_control(
			'hide_mobile_linebreaks',
			[
				'label'        => esc_html__( 'Disable line breaks on mobile', 'orvian-addons' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => esc_html__( 'Yes', 'orvian-addons' ),
				'label_off'    => esc_html__( 'No', 'orvian-addons' ),
				'return_value' => 'yes',
				'default'      => 'yes',
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'section_style_content',
			[
				'label' => esc_html__( 'Content', 'orvian-addons' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_responsive_control(
			'alignment',
			[
				'label'     => esc_html__( 'Alignment', 'orvian-addons' ),
				'type'      => Controls_Manager::CHOOSE,
				'options'   => [
					'left'   => [
						'title' => esc_html__( 'Left', 'orvian-addons' ),
						'icon'  => 'eicon-text-align-left',
					],
					'center' => [
						'title' => esc_html__( 'Center', 'orvian-addons' ),
						'icon'  => 'eicon-text-align-center',
					],
					'right'  => [
						'title' => esc_html__( 'Right', 'orvian-addons' ),
						'icon'  => 'eicon-text-align-right',
					],
				],
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .orvian-heading' => 'text-align: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'typography',
				'selector' => '{{WRAPPER}} .orvian-heading',
			]
		);

		$this->add_control(
			'white_space',
			[
				'label'     => esc_html__( 'White Space', 'orvian-addons' ),
				'type'      => Controls_Manager::SELECT,
				'options'   => [
					'normal' => esc_html__( 'Normal', 'orvian-addons' ),
					'pre'    => esc_html__( 'Pre', 'orvian-addons' ),
					'nowrap' => esc_html__( 'No Wrap', 'orvian-addons' ),
				],
				'default'   => 'normal',
				'selectors' => [
					'{{WRAPPER}} .orvian-heading' => 'white-space: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'color',
			[
				'label'     => esc_html__( 'Color', 'orvian-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .orvian-heading' => 'color: {{VALUE}};',
				],
			]
		);

		$this->end_controls_section();
	}

	/**
	 * Render widget output
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();

		$heading = $settings['heading'];
		$this->add_render_attribute( 'heading', 'class', [ 'orvian-heading', 'my-0' ] );

		if ( 'yes' === $settings['use_font_family_heading'] ) {
			$this->add_render_attribute( 'heading', 'class', 'font-heading text-heading tracking-heading' );
		}

		if ( 'yes' === $settings['use_color_heading'] ) {
			$this->add_render_attribute( 'heading', 'class', 'text-heading' );
		}

		if ( 'yes' === $settings['hide_mobile_linebreaks'] ) {
			$this->add_render_attribute( 'heading', 'class', 'sm:no-br' );
		}

		if ( 'yes' === $settings['auto_detect'] ) {
			global $wp_query;
			$object  = $wp_query->get_queried_object();
			$heading = ! empty( $object->name ) ? $object->name : get_the_title( $wp_query->get_queried_object_id() );
			$heading = ! empty( $heading ) ? $heading : esc_html__( 'Page Heading', 'orvian-addons' );
		} else {
			$this->add_inline_editing_attributes( 'heading' );
		}

		$heading_tag = $this->resolve_text_tag( $settings['heading_size'], 'heading' );

		if ( empty( $heading ) ) {
			return;
		}

		?>
		<<?php echo esc_attr( $heading_tag ); ?> <?php $this->print_render_attribute_string( 'heading' ); ?>>
			<?php echo wp_kses_post( do_shortcode( nl2br( $heading ) ) ); ?>
		</<?php echo esc_attr( $heading_tag ); ?>>
		<?php
	}
}
