<?php
/**
 * Timeline Carousel Widget
 *
 * @package OrvianAddons
 */

namespace OrvianAddons\Elementor\Widgets;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use Elementor\Controls_Manager;
use Elementor\Repeater;
use Elementor\Group_Control_Image_Size;
use Elementor\Group_Control_Background;
use Elementor\Group_Control_Box_Shadow;
use OrvianAddons\Elementor\Elementor as OrvianAddons_Elementor;

/**
 * Timeline Carousel Widget Class
 */
class Timeline_Carousel extends Base\Carousel_Widget_Base {

	/**
	 * Get widget name
	 *
	 * @return string
	 */
	public function get_name() {
		return 'orvian-timeline-carousel';
	}

	/**
	 * Get widget title
	 *
	 * @return string
	 */
	public function get_title() {
		return esc_html__( 'Timeline Carousel', 'orvian-addons' );
	}

	/**
	 * Get widget icon
	 *
	 * @return string
	 */
	public function get_icon() {
		return 'eicon-carousel ' . OrvianAddons_Elementor::CLASS_WIDGET;
	}

	/**
	 * Get widget categories
	 *
	 * @return array
	 */
	public function get_categories() {
		return [ OrvianAddons_Elementor::CATEGORY ];
	}

	/**
	 * Get widget keywords
	 *
	 * @return array
	 */
	public function get_keywords() {
		return [ 'orvian', 'timeline', 'carousel' ];
	}

	/**
	 * Get carousel controls
	 *
	 * @return array
	 */
	protected function get_carousel_controls(): array {
		return [
			'slides_per_view' => [
				'desktop' => 2.3,
				'tablet'  => 2,
				'mobile'  => 1,
			],
			'space_between'   => [
				'desktop' => 84.5,
				'tablet'  => 30,
				'mobile'  => 15,
			],
			'effect'          => 'slide',
			'centered_slides' => 'yes',
		];
	}

	/**
	 * Register widget controls
	 */
	protected function register_controls() {
		$this->start_controls_section(
			'content_section',
			[
				'label' => esc_html__( 'Timeline', 'orvian-addons' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);

		$repeater = new Repeater();

		$repeater->add_control(
			'year',
			[
				'label'   => esc_html__( 'Year', 'orvian-addons' ),
				'type'    => Controls_Manager::TEXT,
				'dynamic' => [
					'active' => true,
				],
			]
		);

		$repeater->add_control(
			'card_heading',
			[
				'label'     => esc_html__( 'Card Content', 'orvian-addons' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$repeater->add_control(
			'card_gallery',
			[
				'label'      => esc_html__( 'Add Images', 'orvian-addons' ),
				'type'       => Controls_Manager::GALLERY,
				'show_label' => false,
				'dynamic'    => [
					'active' => true,
				],
			]
		);

		$repeater->add_control(
			'card_title',
			[
				'label'       => esc_html__( 'Title', 'orvian-addons' ),
				'type'        => Controls_Manager::TEXT,
				'default'     => esc_html__( 'Card Title', 'orvian-addons' ),
				'label_block' => true,
				'dynamic'     => [
					'active' => true,
				],
			]
		);

		$repeater->add_control(
			'card_tags',
			[
				'label' => esc_html__( 'Tags', 'orvian-addons' ),
				'type'  => 'orvian-tags',
			]
		);

		$this->add_control(
			'timeline',
			[
				'label'       => esc_html__( 'Timeline', 'orvian-addons' ),
				'type'        => Controls_Manager::REPEATER,
				'fields'      => $repeater->get_controls(),
				'default'     => [
					[
						'year' => '2021',
					],
					[
						'year' => '2023',
					],
					[
						'year' => '2025',
					],
				],
				'title_field' => '{{{ year }}}',
			]
		);

		$this->add_control(
			'enable_edge_fade',
			[
				'label'     => esc_html__( 'Enable Edge Fade Mask', 'orvian-addons' ),
				'type'      => Controls_Manager::SWITCHER,
				'label_on'  => esc_html__( 'Show', 'orvian-addons' ),
				'label_off' => esc_html__( 'Hide', 'orvian-addons' ),
				'selectors' => [
					'{{WRAPPER}} .swiper' => '
						-webkit-mask-image: linear-gradient(
							to right,
							transparent 0%,
							black 12%,
							black 88%,
							transparent 100%
						);
						mask-image: linear-gradient(
							to right,
							transparent 0%,
							black 12%,
							black 88%,
							transparent 100%
						);
					',
				],
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'carousel_settings_section',
			[
				'label' => esc_html__( 'Carousel Settings', 'orvian-addons' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->register_carousel_controls();

		$this->end_controls_section();

		$this->start_controls_section(
			'timeline_style_section',
			[
				'label' => esc_html__( 'Timeline', 'orvian-addons' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'year_heading',
			[
				'label'     => esc_html__( 'Year', 'orvian-addons' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_control(
			'year_color',
			[
				'label'     => esc_html__( 'Color', 'orvian-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .orvian-timeline-carousel__year span' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'year_background_color',
			[
				'label'     => esc_html__( 'Background Color', 'orvian-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .orvian-timeline-carousel__year span' => 'background-color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'year_box_shadow',
				'selector' => '{{WRAPPER}} .orvian-timeline-carousel__year span',
			]
		);

		$this->add_responsive_control(
			'year_border_radius',
			[
				'label'      => esc_html__( 'Border Radius', 'orvian-addons' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .orvian-timeline-carousel__year span' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'card_heading',
			[
				'label'     => esc_html__( 'Card', 'orvian-addons' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_responsive_control(
			'card__border_radius',
			[
				'label'      => esc_html__( 'Border Radius', 'orvian-addons' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .orvian-timeline-carousel__card' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->start_controls_tabs(
			'card_style_tabs'
		);

			$this->start_controls_tab(
				'card_style_normal_tab',
				[
					'label' => esc_html__( 'Normal', 'orvian-addons' ),
				]
			);

				$this->add_group_control(
					Group_Control_Background::get_type(),
					[
						'name'     => 'card_background',
						'selector' => '{{WRAPPER}} .orvian-timeline-carousel__card::before',
					]
				);

				$this->add_control(
					'card_border_color',
					[
						'label'     => esc_html__( 'Border Color', 'orvian-addons' ),
						'type'      => Controls_Manager::COLOR,
						'selectors' => [
							'{{WRAPPER}} .orvian-timeline-carousel__card' => 'border-color: {{VALUE}};',
						],
					]
				);

			$this->end_controls_tab();

			$this->start_controls_tab(
				'card_style_active_tab',
				[
					'label' => esc_html__( 'Active', 'orvian-addons' ),
				]
			);

				$this->add_group_control(
					Group_Control_Background::get_type(),
					[
						'name'     => 'card_background_active',
						'selector' => '{{WRAPPER}} .swiper-slide-active .orvian-timeline-carousel__card::before',
					]
				);

				$this->add_control(
					'card_border_color_active',
					[
						'label'     => esc_html__( 'Border Color', 'orvian-addons' ),
						'type'      => Controls_Manager::COLOR,
						'selectors' => [
							'{{WRAPPER}} .swiper-slide-active .orvian-timeline-carousel__card' => 'border-color: {{VALUE}};',
						],
					]
				);

			$this->end_controls_tab();

		$this->end_controls_tabs();

		$this->end_controls_section();

		$this->start_controls_section(
			'content_style_section',
			[
				'label' => esc_html__( 'Content', 'orvian-addons' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'gallery_heading',
			[
				'label' => esc_html__( 'Gallery', 'orvian-addons' ),
				'type'  => Controls_Manager::HEADING,
			]
		);

		$this->add_group_control(
			Group_Control_Image_Size::get_type(),
			[
				'name'    => 'thumbnail',
				'default' => 'full',
			]
		);

		$this->add_control(
			'image_border_radius',
			[
				'label'      => esc_html__( 'Border Radius', 'orvian-addons' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .orvian-timeline-carousel__gallery img' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'title_heading',
			[
				'label'     => esc_html__( 'Title', 'orvian-addons' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_control(
			'title_color',
			[
				'label'     => esc_html__( 'Title Color', 'orvian-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .orvian-timeline-carousel__title' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'title_color_active',
			[
				'label'     => esc_html__( 'Title Color Active', 'orvian-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .swiper-slide-active .orvian-timeline-carousel__title' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'tag_heading',
			[
				'label'     => esc_html__( 'Tag', 'orvian-addons' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->start_controls_tabs(
			'tag_style_tabs'
		);

			$this->start_controls_tab(
				'tag_style_normal_tab',
				[
					'label' => esc_html__( 'Normal', 'orvian-addons' ),
				]
			);

				$this->add_control(
					'tag_color',
					[
						'label'     => esc_html__( 'Color', 'orvian-addons' ),
						'type'      => Controls_Manager::COLOR,
						'selectors' => [
							'{{WRAPPER}} .orvian-timeline-carousel__tag' => 'color: {{VALUE}};',
						],
					]
				);

				$this->add_control(
					'tag_border_color',
					[
						'label'     => esc_html__( 'Border Color', 'orvian-addons' ),
						'type'      => Controls_Manager::COLOR,
						'selectors' => [
							'{{WRAPPER}} .orvian-timeline-carousel__tag' => 'border-color: {{VALUE}};',
						],
					]
				);

				$this->add_control(
					'tag_background_color',
					[
						'label'     => esc_html__( 'Background Color', 'orvian-addons' ),
						'type'      => Controls_Manager::COLOR,
						'selectors' => [
							'{{WRAPPER}} .orvian-timeline-carousel__tag' => 'background-color: {{VALUE}};',
						],
					]
				);

			$this->end_controls_tab();

			$this->start_controls_tab(
				'tag_style_hover_tab',
				[
					'label' => esc_html__( 'Hover', 'orvian-addons' ),
				]
			);

				$this->add_control(
					'tag_color_hover',
					[
						'label'     => esc_html__( 'Color', 'orvian-addons' ),
						'type'      => Controls_Manager::COLOR,
						'selectors' => [
							'{{WRAPPER}} .orvian-timeline-carousel__tag:hover' => 'color: {{VALUE}};',
						],
					]
				);

				$this->add_control(
					'tag_border_color_hover',
					[
						'label'     => esc_html__( 'Border Color', 'orvian-addons' ),
						'type'      => Controls_Manager::COLOR,
						'selectors' => [
							'{{WRAPPER}} .orvian-timeline-carousel__tag:hover' => 'border-color: {{VALUE}};',
						],
					]
				);

				$this->add_control(
					'tag_background_color_hover',
					[
						'label'     => esc_html__( 'Background Color', 'orvian-addons' ),
						'type'      => Controls_Manager::COLOR,
						'selectors' => [
							'{{WRAPPER}} .orvian-timeline-carousel__tag:hover' => 'background-color: {{VALUE}};',
						],
					]
				);

			$this->end_controls_tab();

			$this->start_controls_tab(
				'tag_style_active_tab',
				[
					'label' => esc_html__( 'Active', 'orvian-addons' ),
				]
			);

				$this->add_control(
					'tag_color_active',
					[
						'label'     => esc_html__( 'Color', 'orvian-addons' ),
						'type'      => Controls_Manager::COLOR,
						'selectors' => [
							'{{WRAPPER}} .swiper-slide-active .orvian-timeline-carousel__tag' => 'color: {{VALUE}};',
						],
					]
				);

				$this->add_control(
					'tag_border_color_active',
					[
						'label'     => esc_html__( 'Border Color', 'orvian-addons' ),
						'type'      => Controls_Manager::COLOR,
						'selectors' => [
							'{{WRAPPER}} .swiper-slide-active .orvian-timeline-carousel__tag' => 'border-color: {{VALUE}};',
						],
					]
				);

				$this->add_control(
					'tag_background_color_active',
					[
						'label'     => esc_html__( 'Background Color', 'orvian-addons' ),
						'type'      => Controls_Manager::COLOR,
						'selectors' => [
							'{{WRAPPER}} .swiper-slide-active .orvian-timeline-carousel__tag' => 'background-color: {{VALUE}};',
						],
					]
				);

			$this->end_controls_tab();

		$this->end_controls_tabs();

		$this->end_controls_section();

		$this->start_controls_section(
			'carousel_style_content',
			[
				'label' => esc_html__( 'Carousel Style', 'orvian-addons' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->register_carousel_style_controls();

		$this->end_controls_section();
	}

	/**
	 * Render widget output
	 */
	protected function render() {
		if ( empty( $this->get_settings_for_display()['timeline'] ) ) {
			return;
		}

		$this->render_carousel();
	}

	/**
	 * Render items carousel.
	 */
	protected function render_items_carousel() {
		$settings = $this->get_settings_for_display();

		foreach ( $settings['timeline'] as $index => $item ) :
			$ids = wp_list_pluck( $item['card_gallery'], 'id' );
			?>
			<div class="orvian-timeline-carousel__item swiper-slide swiper-slide--stretch text-center theme-dark">
			<?php if ( ! empty( $item['year'] ) ) : ?>
					<div class="orvian-timeline-carousel__year">
						<span class="inline-block text-white circle font-heading font-sm font-medium uppercase">
							<?php echo esc_html( $item['year'] ); ?>
						</span>
					</div>
				<?php endif; ?>
			<?php if ( ! empty( $ids ) || ! empty( $item['card_title'] ) || ! empty( $item['card_tags'] ) ) : ?>
					<div class="orvian-timeline-carousel__card relative flex flex-col">
						<?php if ( ! empty( $ids ) ) : ?>
							<div class="orvian-timeline-carousel__gallery flex flex-wrap justify-center items-center gap-10px">
								<?php
								foreach ( $ids as $id ) {
									$settings['thumbnail'] = [
										'id'  => $id,
										'url' => wp_get_attachment_url( $id ),
									];

									// phpcs:ignore
									echo Group_Control_Image_Size::get_attachment_image_html( $settings, 'thumbnail', 'thumbnail' );
								}
								?>
							</div>
						<?php endif; ?>
						<?php if ( ! empty( $item['card_title'] ) ) : ?>
							<h3 class="orvian-timeline-carousel__title m-0 text-white">
								<?php echo esc_html( nl2br( $item['card_title'] ) ); ?>
							</h3>
						<?php endif; ?>
						<?php if ( ! empty( $item['card_tags'] ) && is_array( $item['card_tags'] ) ) : ?>
							<div class="orvian-timeline-carousel__tags orvian-tags flex flex-wrap justify-center items-center gap-8px">
								<?php foreach ( $item['card_tags'] as $tag ) : ?>
									<span class="orvian-timeline-carousel__tag orvian-tag">
										<?php echo esc_html( $tag ); ?>
									</span>
								<?php endforeach; ?>
							</div>
						<?php endif; ?>
					</div>
				<?php endif; ?>
			</div>
			<?php
		endforeach;
	}

	/**
	 * Get classes swiper.
	 *
	 * @return array
	 */
	protected function get_classes_swiper(): array {
		return [ 'orvian-timeline-carousel' ];
	}
}
