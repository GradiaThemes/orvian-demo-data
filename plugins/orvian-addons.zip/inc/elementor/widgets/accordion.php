<?php
/**
 * Accordion Widget
 *
 * @package OrvianAddons
 */

namespace OrvianAddons\Elementor\Widgets;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Repeater;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;
use OrvianAddons\Helper;
use OrvianAddons\Elementor\Elementor as OrvianAddons_Elementor;

/**
 * Accordion Widget Class
 */
class Accordion extends Widget_Base {

	use Base\Text_Class;

	/**
	 * Get widget name
	 *
	 * @return string
	 */
	public function get_name() {
		return 'orvian-accordion';
	}

	/**
	 * Get widget title
	 *
	 * @return string
	 */
	public function get_title() {
		return esc_html__( 'Accordion', 'orvian-addons' );
	}

	/**
	 * Get widget icon
	 *
	 * @return string
	 */
	public function get_icon() {
		return 'eicon-accordion ' . OrvianAddons_Elementor::CLASS_WIDGET;
	}

	/**
	 * Get widget categories
	 *
	 * @return array
	 */
	public function get_categories() {
		return [ OrvianAddons_Elementor::CATEGORY ];
	}

	/**
	 * Get widget keywords
	 *
	 * @return array
	 */
	public function get_keywords() {
		return [ 'orvian', 'accordion', 'faq', 'toggle' ];
	}

	/**
	 * Register widget controls
	 */
	protected function register_controls() {
		$this->start_controls_section(
			'content_section',
			[
				'label' => esc_html__( 'Accordion', 'orvian-addons' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'type',
			[
				'label'   => esc_html__( 'Type', 'orvian-addons' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'default',
				'options' => [
					'default' => esc_html__( 'Default', 'orvian-addons' ),
					'step'    => esc_html__( 'Step', 'orvian-addons' ),
				],
			]
		);

		$repeater = new Repeater();

		$repeater->add_control(
			'index',
			[
				'label'       => esc_html__( 'Index', 'orvian-addons' ),
				'description' => esc_html__( 'The index of the accordion item. Use type "step" to set the index.', 'orvian-addons' ),
				'type'        => Controls_Manager::TEXT,
				'dynamic'     => [
					'active' => true,
				],
			]
		);

		$repeater->add_control(
			'title',
			[
				'label'   => esc_html__( 'Title', 'orvian-addons' ),
				'type'    => Controls_Manager::TEXT,
				'dynamic' => [
					'active' => true,
				],
			]
		);

		$repeater->add_control(
			'content',
			[
				'label'   => esc_html__( 'Content', 'orvian-addons' ),
				'type'    => Controls_Manager::WYSIWYG,
				'dynamic' => [
					'active' => true,
				],
			]
		);

		$repeater->add_control(
			'expanded',
			[
				'label'        => esc_html__( 'Expanded', 'orvian-addons' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => esc_html__( 'Yes', 'orvian-addons' ),
				'label_off'    => esc_html__( 'No', 'orvian-addons' ),
				'return_value' => 'open',
			]
		);

		$repeater->add_control(
			'custom_hover_cursor_text',
			[
				'label'       => esc_html__( 'Custom Hover Cursor Text', 'orvian-addons' ),
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
				'separator'   => 'before',
			]
		);

		$this->add_control(
			'accordion_items',
			[
				'label'       => esc_html__( 'Accordion Items', 'orvian-addons' ),
				'type'        => Controls_Manager::REPEATER,
				'fields'      => $repeater->get_controls(),
				'default'     => [
					[
						'title'   => esc_html__( 'Accordion Item #1', 'orvian-addons' ),
						'content' => esc_html__( 'Accordion Item Content #1', 'orvian-addons' ),
					],
					[
						'title'   => esc_html__( 'Accordion Item #2', 'orvian-addons' ),
						'content' => esc_html__( 'Accordion Item Content #2', 'orvian-addons' ),
					],
				],
				'title_field' => '{{{ title }}}',
			]
		);

		$this->add_control(
			'title_html_tag',
			[
				'label'     => esc_html__( 'Title HTML Tag', 'orvian-addons' ),
				'type'      => Controls_Manager::SELECT,
				'options'   => $this->get_text_class_options_with_tags(),
				'default'   => 'h3',
				'separator' => 'before',
			]
		);

		$this->add_control(
			'icon_align',
			[
				'label'     => esc_html__( 'Icon Alignment', 'orvian-addons' ),
				'type'      => Controls_Manager::CHOOSE,
				'options'   => [
					'row-reverse' => [
						'title' => esc_html__( 'Start', 'orvian-addons' ),
						'icon'  => 'eicon-h-align-left',
					],
					'row'         => [
						'title' => esc_html__( 'End', 'orvian-addons' ),
						'icon'  => 'eicon-h-align-right',
					],
				],
				'selectors' => [
					'{{WRAPPER}} .orvian-accordion' => '--flex-direction: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'faq_schema',
			[
				'label'     => esc_html__( 'FAQ Schema', 'orvian-addons' ),
				'type'      => Controls_Manager::SWITCHER,
				'separator' => 'before',
			]
		);

		$this->add_control(
			'hover_cursor',
			[
				'label' => esc_html__( 'Hover Cursor', 'orvian-addons' ),
				'type'  => Controls_Manager::SWITCHER,
			]
		);

		$this->add_control(
			'hover_cursor_text',
			[
				'label'     => esc_html__( 'Hover Cursor Text', 'orvian-addons' ),
				'type'      => Controls_Manager::TEXT,
				'default'   => esc_html__( 'Hover Me', 'orvian-addons' ),
				'condition' => [
					'hover_cursor' => 'yes',
				],
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'section_style',
			[
				'label' => esc_html__( 'Accordion Item', 'orvian-addons' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_responsive_control(
			'space_between',
			[
				'label'     => esc_html__( 'Space Between Items', 'orvian-addons' ),
				'type'      => Controls_Manager::SLIDER,
				'range'     => [
					'px' => [
						'min' => 0,
						'max' => 200,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .orvian-accordion__item' => 'margin-bottom: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'item_padding',
			[
				'label'      => esc_html__( 'Padding', 'orvian-addons' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .orvian-accordion__item' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'item_border_radius',
			[
				'label'      => esc_html__( 'Border Radius', 'orvian-addons' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .orvian-accordion__item' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'     => 'item_border',
				'label'    => esc_html__( 'Border', 'orvian-addons' ),
				'selector' => '{{WRAPPER}} .orvian-accordion__item',
			]
		);

		$this->start_controls_tabs(
			'item_tabs'
		);

			$this->start_controls_tab(
				'item_normal_tab',
				[
					'label' => esc_html__( 'Normal', 'orvian-addons' ),
				]
			);

				$this->add_control(
					'item_background_color',
					[
						'label'     => esc_html__( 'Background Color', 'orvian-addons' ),
						'type'      => Controls_Manager::COLOR,
						'default'   => '',
						'selectors' => [
							'{{WRAPPER}} .orvian-accordion__item' => 'background-color: {{VALUE}};',
						],
					]
				);

				$this->add_group_control(
					Group_Control_Box_Shadow::get_type(),
					[
						'name'     => 'item_box_shadow',
						'selector' => '{{WRAPPER}} .orvian-accordion__item',
					]
				);

			$this->end_controls_tab();

			$this->start_controls_tab(
				'item_hover_tab',
				[
					'label' => esc_html__( 'Hover', 'orvian-addons' ),
				]
			);

				$this->add_control(
					'item_background_color_hover',
					[
						'label'     => esc_html__( 'Background Color Hover', 'orvian-addons' ),
						'type'      => Controls_Manager::COLOR,
						'default'   => '',
						'selectors' => [
							'{{WRAPPER}} .orvian-accordion__item:hover' => 'background-color: {{VALUE}};',
						],
					]
				);

				$this->add_control(
					'item_border_color_hover',
					[
						'label'     => esc_html__( 'Border Color Hover', 'orvian-addons' ),
						'type'      => Controls_Manager::COLOR,
						'default'   => '',
						'selectors' => [
							'{{WRAPPER}} .orvian-accordion__item:hover' => 'border-color: {{VALUE}};',
						],
					]
				);

				$this->add_group_control(
					Group_Control_Box_Shadow::get_type(),
					[
						'name'     => 'item_box_shadow_hover',
						'selector' => '{{WRAPPER}} .orvian-accordion__item:hover',
					]
				);

			$this->end_controls_tab();

			$this->start_controls_tab(
				'item_open_tab',
				[
					'label' => esc_html__( 'Open', 'orvian-addons' ),
				]
			);

				$this->add_control(
					'item_background_color_open',
					[
						'label'     => esc_html__( 'Background Color Open', 'orvian-addons' ),
						'type'      => Controls_Manager::COLOR,
						'default'   => '',
						'selectors' => [
							'{{WRAPPER}} .orvian-accordion__item.open' => 'background-color: {{VALUE}};',
						],
					]
				);

				$this->add_control(
					'item_border_color_open',
					[
						'label'     => esc_html__( 'Border Color Open', 'orvian-addons' ),
						'type'      => Controls_Manager::COLOR,
						'default'   => '',
						'selectors' => [
							'{{WRAPPER}} .orvian-accordion__item.open' => 'border-color: {{VALUE}};',
						],
					]
				);

				$this->add_group_control(
					Group_Control_Box_Shadow::get_type(),
					[
						'name'     => 'item_box_shadow_open',
						'selector' => '{{WRAPPER}} .orvian-accordion__item.open',
					]
				);

			$this->end_controls_tab();

		$this->end_controls_tabs();

		$this->end_controls_section();

		$this->start_controls_section(
			'section_heading_style',
			[
				'label' => esc_html__( 'Heading', 'orvian-addons' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_responsive_control(
			'icon_size',
			[
				'label'     => esc_html__( 'Icon Size', 'orvian-addons' ),
				'type'      => Controls_Manager::SLIDER,
				'range'     => [
					'px' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .orvian-accordion__toggle' => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'icon_color',
			[
				'label'     => esc_html__( 'Icon Color', 'orvian-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .orvian-accordion__toggle' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'icon_color_hover',
			[
				'label'     => esc_html__( 'Icon Color Hover', 'orvian-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .orvian-accordion__item:hover .orvian-accordion__toggle' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'icon_color_open',
			[
				'label'     => esc_html__( 'Icon Color Open', 'orvian-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .orvian-accordion__item.open .orvian-accordion__toggle' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_responsive_control(
			'icon_spacing',
			[
				'label'     => esc_html__( 'Icon Spacing', 'orvian-addons' ),
				'type'      => Controls_Manager::SLIDER,
				'range'     => [
					'px' => [
						'min' => 0,
						'max' => 300,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .orvian-accordion__item' => 'gap: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'title_heading',
			[
				'label'     => esc_html__( 'Title', 'orvian-addons' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'title_typography',
				'selector' => '{{WRAPPER}} .orvian-accordion__title',
			]
		);

		$this->add_control(
			'title_color',
			[
				'label'     => esc_html__( 'Title Color', 'orvian-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .orvian-accordion__title' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'title_color_hover',
			[
				'label'     => esc_html__( 'Title Color Hover', 'orvian-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .orvian-accordion__item:hover .orvian-accordion__title' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'title_color_open',
			[
				'label'     => esc_html__( 'Title Color Open', 'orvian-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .orvian-accordion__item.open .orvian-accordion__title' => 'color: {{VALUE}};',
				],
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'section_content_style',
			[
				'label' => esc_html__( 'Content', 'orvian-addons' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'content_typography',
				'selector' => '{{WRAPPER}} .orvian-accordion__content',
			]
		);

		$this->add_control(
			'content_color',
			[
				'label'     => esc_html__( 'Content Color', 'orvian-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .orvian-accordion__content' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'content_color_hover',
			[
				'label'     => esc_html__( 'Content Color Hover', 'orvian-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .orvian-accordion__item:hover .orvian-accordion__content' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'content_color_open',
			[
				'label'     => esc_html__( 'Content Color Open', 'orvian-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .orvian-accordion__item.open .orvian-accordion__content' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_responsive_control(
			'content_spacing_top',
			[
				'label'     => esc_html__( 'Content Spacing Top', 'orvian-addons' ),
				'type'      => Controls_Manager::SLIDER,
				'range'     => [
					'px' => [
						'min' => 0,
						'max' => 200,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .orvian-accordion__content' => 'margin-top: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();
	}

	/**
	 * Render widget output
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();

		if ( empty( $settings['accordion_items'] ) ) {
			return;
		}

		$this->add_render_attribute( 'wrapper', 'class', [ 'orvian-accordion', 'orvian-accordion--' . esc_attr( $settings['type'] ) ] );
		$this->add_render_attribute( 'header', 'class', [ 'orvian-accordion__header', 'flex', 'gap-2', 'items-center', 'justify-between' ] );
		$this->add_render_attribute( 'title', 'class', [ 'orvian-accordion__title', 'm-0', 'font-base', 'font-medium' ] );

		$title_tag = $this->resolve_text_tag( $settings['title_html_tag'], 'title' );

		$this->add_inline_editing_attributes( 'title' );

		?>
		<div <?php $this->print_render_attribute_string( 'wrapper' ); ?>>
			<?php foreach ( $settings['accordion_items'] as $index => $item ) : ?>
				<?php
				$this->add_render_attribute( 'item_' . $index, 'class', [ 'orvian-accordion__item', 'border' ] );

				if ( 'open' === $item['expanded'] ) {
					$this->add_render_attribute( 'item_' . $index, 'class', esc_attr( $item['expanded'] ) );
				}

				if ( ! empty( $settings['hover_cursor'] ) ) {
					if ( ! empty( $item['custom_hover_cursor_text'] ) ) {
						$this->add_render_attribute( 'item_' . $index, 'hover-cursor' );
						$this->add_render_attribute( 'item_' . $index, 'hover-cursor-type', 'button_text' );
						$this->add_render_attribute( 'item_' . $index, 'hover-cursor-text', esc_html( $item['custom_hover_cursor_text'] ) );
					} else {
						if ( ! empty( $settings['hover_cursor_text'] ) ) {
							$this->add_render_attribute( 'item_' . $index, 'hover-cursor' );
							$this->add_render_attribute( 'item_' . $index, 'hover-cursor-type', 'button_text' );
							$this->add_render_attribute( 'item_' . $index, 'hover-cursor-text', esc_html( $settings['hover_cursor_text'] ) );
						}
					}
				}

				?>
				<?php $this->add_render_attribute( 'content_' . $index, 'class', [ 'orvian-accordion__content', 'font-sm', 'font-medium', 'open' === $item['expanded'] ? '' : 'hidden' ] ); ?>
				<div <?php $this->print_render_attribute_string( 'item_' . $index ); ?>>
					<div <?php $this->print_render_attribute_string( 'header' ); ?>>
						<?php if ( 'step' === $settings['type'] ) : ?>
							<span class="flex items-center gap-20px">
								<span class="orvian-accordion__index inline-flex items-center justify-center shrink-0 circle caption leading-none bg-primary text-white font-heading font-2xl font-semibold"><?php echo ! empty( $item['index'] ) ? esc_html( $item['index'] ) : esc_html( str_pad( $index + 1, 2, '0', STR_PAD_LEFT ) ); ?></span>
								<<?php echo esc_attr( $title_tag ); ?> <?php $this->print_render_attribute_string( 'title' ); ?>><?php echo wp_kses_post( $item['title'] ); ?></<?php echo esc_attr( $title_tag ); ?>>
							</span>
							<button class="orvian-accordion__toggle button-icon shrink-0">
								<?php echo Helper::get_svg( 'arrow-up' ); // phpcs:ignore ?>
							</button>
						<?php else : ?>
							<<?php echo esc_attr( $title_tag ); ?> <?php $this->print_render_attribute_string( 'title' ); ?>><?php echo wp_kses_post( $item['title'] ); ?></<?php echo esc_attr( $title_tag ); ?>>
							<button class="orvian-accordion__toggle button--no-style shrink-0"></button>
						<?php endif; ?>
					</div>
					<div <?php $this->print_render_attribute_string( 'content_' . $index ); ?>><?php echo wp_kses_post( $item['content'] ); ?></div>
				</div>
			<?php endforeach; ?>
			<?php
			if ( isset( $settings['faq_schema'] ) && 'yes' === $settings['faq_schema'] ) {
				$json = [
					'@context'   => 'https://schema.org',
					'@type'      => 'FAQPage',
					'mainEntity' => [],
				];

				foreach ( $settings['accordion_items'] as $index => $item ) {
					$json['mainEntity'][] = [
						'@type'          => 'Question',
						'name'           => wp_strip_all_tags( $item['title'] ),
						'acceptedAnswer' => [
							'@type' => 'Answer',
							'text'  => $this->parse_text_editor( $item['content'] ),
						],
					];
				}
				?>
				<script type="application/ld+json"><?php echo wp_json_encode( $json ); ?></script>
			<?php } ?>
		</div>
		<?php
	}
}
