<?php
/**
 * Award List Widget
 *
 * @package OrvianAddons
 */

namespace OrvianAddons\Elementor\Widgets;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Repeater;
use OrvianAddons\Elementor\Elementor as OrvianAddons_Elementor;

/**
 * Award List Widget Class
 */
class Award_List extends Widget_Base {

	/**
	 * Get widget name
	 *
	 * @return string
	 */
	public function get_name() {
		return 'orvian-award-list';
	}

	/**
	 * Get widget title
	 *
	 * @return string
	 */
	public function get_title() {
		return esc_html__( 'Award List', 'orvian-addons' );
	}

	/**
	 * Get widget icon
	 *
	 * @return string
	 */
	public function get_icon() {
		return 'eicon-editor-list-ol ' . OrvianAddons_Elementor::CLASS_WIDGET;
	}

	/**
	 * Get widget categories
	 *
	 * @return array
	 */
	public function get_categories() {
		return [ OrvianAddons_Elementor::CATEGORY ];
	}

	/**
	 * Get widget keywords
	 *
	 * @return array
	 */
	public function get_keywords() {
		return [ 'orvian', 'award', 'list', 'text' ];
	}

	/**
	 * Register widget controls.
	 *
	 * @access protected
	 */
	protected function register_controls() {

		$this->start_controls_section(
			'award_list_section',
			[
				'label' => esc_html__( 'Award List', 'orvian-addons' ),
			]
		);

		$repeater = new Repeater();

		$repeater->add_control(
			'award_body',
			[
				'label'       => esc_html__( 'Award Body', 'orvian-addons' ),
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
			]
		);

		$repeater->add_control(
			'award_title',
			[
				'label'       => esc_html__( 'Award Title', 'orvian-addons' ),
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
			]
		);

		$repeater->add_control(
			'award_project',
			[
				'label'       => esc_html__( 'Award Project', 'orvian-addons' ),
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
			]
		);

		$repeater->add_control(
			'award_image',
			[
				'label' => esc_html__( 'Award Image', 'orvian-addons' ),
				'type'  => Controls_Manager::MEDIA,
			]
		);

		$this->add_control(
			'award_list',
			[
				'label'       => esc_html__( 'Awards', 'orvian-addons' ),
				'type'        => Controls_Manager::REPEATER,
				'fields'      => $repeater->get_controls(),
				'default'     => [
					[
						'award_body'    => esc_html__( 'Awwwards', 'orvian-addons' ),
						'award_title'   => esc_html__( 'SOTY 2023 — 1st Winner', 'orvian-addons' ),
						'award_project' => esc_html__( 'Archin', 'orvian-addons' ),
					],
					[
						'award_body'    => esc_html__( 'Awwwards', 'orvian-addons' ),
						'award_title'   => esc_html__( 'SOTY 2023 — 1st Winner', 'orvian-addons' ),
						'award_project' => esc_html__( 'Archin', 'orvian-addons' ),
					],
				],
				'title_field' => '{{{ award_body }}} — {{{ award_title }}}',
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'award_body_style',
			[
				'label' => esc_html__( 'Award', 'orvian-addons' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_responsive_control(
			'padding',
			[
				'label'      => esc_html__( 'Padding', 'orvian-addons' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'rem', 'em', 'custom' ],
				'selectors'  => [
					'{{WRAPPER}} .orvian-award-list__item' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'border_color',
			[
				'label'     => esc_html__( 'Border Color', 'orvian-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .orvian-award-list__item' => 'border-color: {{VALUE}};',
				],
				'separator' => 'before',
			]
		);

		$this->add_control(
			'border_color_hover',
			[
				'label'     => esc_html__( 'Border Color Hover', 'orvian-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .orvian-award-list__item:hover' => 'border-color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'body_color',
			[
				'label'     => esc_html__( 'Body Color', 'orvian-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .orvian-award-list__body' => 'color: {{VALUE}};',
				],
				'separator' => 'before',
			]
		);

		$this->add_control(
			'body_color_hover',
			[
				'label'     => esc_html__( 'Body Color Hover', 'orvian-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .orvian-award-list__item:hover .orvian-award-list__body' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'title_color',
			[
				'label'     => esc_html__( 'Title Color', 'orvian-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .orvian-award-list__title' => 'color: {{VALUE}};',
				],
				'separator' => 'before',
			]
		);

		$this->add_control(
			'title_color_hover',
			[
				'label'     => esc_html__( 'Title Color Hover', 'orvian-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .orvian-award-list__item:hover .orvian-award-list__title' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'project_color',
			[
				'label'     => esc_html__( 'Project Color', 'orvian-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .orvian-award-list__project' => 'color: {{VALUE}};',
				],
				'separator' => 'before',
			]
		);

		$this->add_control(
			'project_color_hover',
			[
				'label'     => esc_html__( 'Project Color Hover', 'orvian-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .orvian-award-list__item:hover .orvian-award-list__project' => 'color: {{VALUE}};',
				],
			]
		);

		$this->end_controls_section();
	}

	/**
	 * Render widget output on the frontend.
	 *
	 * @access protected
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();

		if ( empty( $settings['award_list'] ) ) {
			return;
		}
		?>
		<div class="orvian-award-list">
			<?php foreach ( $settings['award_list'] as $item ) : ?>
				<div class="orvian-award-list__item flex items-center justify-between gap-4 border-bottom" hover-cursor hover-cursor-type="image">
					<span class="orvian-award-list__body shrink-0 pointer-events-none text-left text-body-3 font-medium transition"><?php echo wp_kses_post( $item['award_body'] ); ?></span>
					<span class="orvian-award-list__title flex-1 pointer-events-none text-center text-body-1 uppercase transition"><?php echo wp_kses_post( nl2br( $item['award_title'] ) ); ?></span>
					<span class="orvian-award-list__project shrink-0 pointer-events-none text-right text-body-3 font-medium transition"><?php echo wp_kses_post( $item['award_project'] ); ?></span>
					<?php if ( ! empty( $item['award_image']['url'] ) ) : ?>
					<template hover-cursor-image>
						<div class="orvian-award-list__image rounded-md overflow-hidden ratio-image">
							<?php if ( ! empty( $item['award_image']['id'] ) ) : ?>
								<?php echo wp_get_attachment_image( $item['award_image']['id'], 'full' ); // phpcs:ignore ?>
							<?php elseif ( ! empty( $item['award_image']['url'] ) ) : ?>
								<img src="<?php echo esc_url( $item['award_image']['url'] ); ?>">
							<?php endif; ?>
						</div>
					</template>
					<?php endif; ?>
				</div>
			<?php endforeach; ?>
		</div>
		<?php
	}
}
