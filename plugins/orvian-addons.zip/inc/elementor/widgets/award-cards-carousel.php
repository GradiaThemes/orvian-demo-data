<?php
/**
 * Award Cards Carousel Widget
 *
 * @package OrvianAddons
 */

namespace OrvianAddons\Elementor\Widgets;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use Elementor\Controls_Manager;
use Elementor\Repeater;
use Elementor\Icons_Manager;
use OrvianAddons\Helper;
use OrvianAddons\Elementor\Elementor as OrvianAddons_Elementor;

/**
 * Award Cards Carousel Widget Class
 */
class Award_Cards_Carousel extends Base\Carousel_Widget_Base {

	/**
	 * Get widget name
	 *
	 * @return string
	 */
	public function get_name() {
		return 'orvian-award-cards-carousel';
	}

	/**
	 * Get widget title
	 *
	 * @return string
	 */
	public function get_title() {
		return esc_html__( 'Award Cards Carousel', 'orvian-addons' );
	}

	/**
	 * Get widget icon
	 *
	 * @return string
	 */
	public function get_icon() {
		return 'eicon-carousel ' . OrvianAddons_Elementor::CLASS_WIDGET;
	}

	/**
	 * Get widget categories
	 *
	 * @return array
	 */
	public function get_categories() {
		return [ OrvianAddons_Elementor::CATEGORY ];
	}

	/**
	 * Get widget keywords
	 *
	 * @return array
	 */
	public function get_keywords() {
		return [ 'orvian', 'award', 'cards', 'carousel' ];
	}

	/**
	 * Get carousel controls
	 *
	 * @return array
	 */
	protected function get_carousel_controls(): array {
		return [
			'slides_per_view' => [
				'desktop' => 3,
				'tablet'  => 2,
				'mobile'  => 1,
			],
			'effect'          => 'coverflow',
			'centered_slides' => 'yes',
		];
	}

	/**
	 * Register widget controls
	 */
	protected function register_controls() {
		$this->start_controls_section(
			'content_section',
			[
				'label' => esc_html__( 'Award Cards', 'orvian-addons' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);

		$repeater = new Repeater();

		$repeater->add_control(
			'text_header',
			[
				'label'   => esc_html__( 'Text Header', 'orvian-addons' ),
				'type'    => Controls_Manager::TEXT,
				'dynamic' => [
					'active' => true,
				],
			]
		);

		$repeater->add_control(
			'type',
			[
				'label'   => esc_html__( 'Type', 'orvian-addons' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'icon',
				'options' => [
					'icon'  => esc_html__( 'Icon', 'orvian-addons' ),
					'image' => esc_html__( 'Image', 'orvian-addons' ),
				],
			]
		);

		$repeater->add_control(
			'icon',
			[
				'label'     => esc_html__( 'Icon', 'orvian-addons' ),
				'type'      => Controls_Manager::ICONS,
				'default'   => [
					'value'   => 'fas fa-star',
					'library' => 'fa-solid',
				],
				'condition' => [
					'type' => 'icon',
				],
			]
		);

		$repeater->add_control(
			'image',
			[
				'label'     => esc_html__( 'Image', 'orvian-addons' ),
				'type'      => Controls_Manager::MEDIA,
				'dynamic'   => [
					'active' => true,
				],
				'condition' => [
					'type' => 'image',
				],
			]
		);

		$repeater->add_control(
			'text_footer',
			[
				'label'   => esc_html__( 'Text Footer', 'orvian-addons' ),
				'type'    => Controls_Manager::TEXT,
				'dynamic' => [
					'active' => true,
				],
			]
		);

		$this->add_control(
			'award_cards',
			[
				'label'       => esc_html__( 'Award Cards', 'orvian-addons' ),
				'type'        => Controls_Manager::REPEATER,
				'fields'      => $repeater->get_controls(),
				'default'     => [
					[
						'text_header' => esc_html__( 'Award Card 1', 'orvian-addons' ),
					],
					[
						'text_header' => esc_html__( 'Award Card 2', 'orvian-addons' ),
					],
					[
						'text_header' => esc_html__( 'Award Card 3', 'orvian-addons' ),
					],
				],
				'title_field' => '{{{ text_header }}}',
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'carousel_settings_section',
			[
				'label' => esc_html__( 'Carousel Settings', 'orvian-addons' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->register_carousel_controls();

		$this->end_controls_section();

		$this->start_controls_section(
			'card_style_section',
			[
				'label' => esc_html__( 'Award Cards', 'orvian-addons' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'card_background_color',
			[
				'label'     => esc_html__( 'Background Color', 'orvian-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .orvian-award-card' => 'background-color: {{VALUE}};',
				],
			]
		);

		$this->add_responsive_control(
			'card_backdrop_filter',
			[
				'label'     => esc_html__( 'Backdrop Filter', 'orvian-addons' ),
				'type'      => Controls_Manager::NUMBER,
				'selectors' => [
					'{{WRAPPER}} .orvian-award-card' => 'backdrop-filter: blur({{VALUE}}px);',
				],
			]
		);

		$this->add_responsive_control(
			'card_border_radius',
			[
				'label'      => esc_html__( 'Border Radius', 'orvian-addons' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .orvian-award-card' => 'Border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'card_dots_color',
			[
				'label'     => esc_html__( 'Dots Color', 'orvian-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .orvian-award-card__dot' => 'color: {{VALUE}};',
				],
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'content_style_section',
			[
				'label' => esc_html__( 'Content', 'orvian-addons' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'card_text_top_color',
			[
				'label'     => esc_html__( 'Text at the top Color', 'orvian-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .orvian-award-card__header .orvian-award-card__text' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'card_text_bottom_color',
			[
				'label'     => esc_html__( 'Text at the bottom Color', 'orvian-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .orvian-award-card__footer .orvian-award-card__text' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'card_icon_color',
			[
				'label'     => esc_html__( 'Icon Color', 'orvian-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .orvian-award-card__body .orvian-svg-icon' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_responsive_control(
			'card_icon_size',
			[
				'label'      => esc_html__( 'Icon Size', 'orvian-addons' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', 'em', 'rem' ],
				'range'      => [
					'px' => [
						'min' => 0,
						'max' => 1000,
					],
				],
				'selectors'  => [
					'{{WRAPPER}} .orvian-award-card__body .orvian-svg-icon' => 'font-size: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'card_image_heading',
			[
				'label' => esc_html__( 'Image', 'orvian-addons' ),
				'type'  => Controls_Manager::HEADING,
			]
		);

		$this->add_responsive_control(
			'card_image_width',
			[
				'label'      => esc_html__( 'Max Width', 'orvian-addons' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', 'em', 'rem', '%' ],
				'range'      => [
					'px' => [
						'min' => 0,
						'max' => 1000,
					],
				],
				'selectors'  => [
					'{{WRAPPER}} .orvian-award-card__body img' => 'max-width: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'carousel_style_content',
			[
				'label' => esc_html__( 'Carousel Style', 'orvian-addons' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->register_carousel_style_controls();

		$this->end_controls_section();
	}

	/**
	 * Render widget output
	 */
	protected function render() {
		if ( empty( $this->get_settings_for_display()['award_cards'] ) ) {
			return;
		}

		$this->render_carousel();
	}

	/**
	 * Render items carousel.
	 */
	protected function render_items_carousel() {
		$settings = $this->get_settings_for_display();

		foreach ( $settings['award_cards'] as $index => $item ) :
			$this->add_render_attribute( 'card', 'class', [ 'swiper-slide', 'swiper-slide--stretch', 'orvian-award-card', 'text-center', 'flex', 'flex-col', 'items-center', 'justify-between' ] );

			?>
				<div <?php $this->print_render_attribute_string( 'card' ); ?>>
					<div class="orvian-award-card__header flex justify-between items-center gap-2 w-full">
						<?php echo Helper::get_svg( 'dot', 'ui', [ 'class' => 'orvian-award-card__dot' ] ); // phpcs:ignore ?>
						<?php if ( ! empty( $item['text_header'] ) ) : ?>
							<div class="orvian-award-card__text flex text-white font-heading font-semibold">
								<?php echo wp_kses_post( nl2br( $item['text_header'] ) ); ?>
							</div>
						<?php endif; ?>
						<?php echo Helper::get_svg( 'dot', 'ui', [ 'class' => 'orvian-award-card__dot' ] ); // phpcs:ignore ?>
					</div>
					<div class="orvian-award-card__body w-full text-white">
						<?php if ( 'image' === $item['type'] ) : ?>
							<?php if ( ! empty( $item['image']['id'] ) ) : ?>
								<?php echo wp_get_attachment_image( $item['image']['id'], 'full' ); // phpcs:ignore ?>
							<?php elseif ( ! empty( $item['image']['url'] ) ) : ?>
								<img src="<?php echo esc_url( $item['image']['url'] ); ?>">
							<?php endif; ?>
						<?php endif; ?>
						<?php if ( 'icon' === $item['type'] && ! empty( $item['icon'] ) ) : ?>
							<span class="orvian-svg-icon">
								<?php
								Icons_Manager::render_icon(
									$item['icon'],
									[
										'aria-hidden' => 'true',
										'fill'        => 'currentColor',
									]
								);
								?>
							</span>
						<?php endif; ?>
					</div>
					<div class="orvian-award-card__footer flex justify-between items-center gap-2 w-full">
						<?php echo Helper::get_svg( 'dot', 'ui', [ 'class' => 'orvian-award-card__dot' ] ); // phpcs:ignore ?>
						<?php if ( ! empty( $item['text_footer'] ) ) : ?>
							<div class="orvian-award-card__text flex text-white font-heading font-semibold">
								<?php echo wp_kses_post( nl2br( $item['text_footer'] ) ); ?>
							</div>
						<?php endif; ?>
						<?php echo Helper::get_svg( 'dot', 'ui', [ 'class' => 'orvian-award-card__dot' ] ); // phpcs:ignore ?>
					</div>
				</div>
			<?php
		endforeach;
	}
}
