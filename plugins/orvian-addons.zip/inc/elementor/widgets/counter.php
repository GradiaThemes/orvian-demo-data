<?php
/**
 * Counter Widget
 *
 * @package OrvianAddons
 */

namespace OrvianAddons\Elementor\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Icons_Manager;
use OrvianAddons\Elementor\Elementor as OrvianAddons_Elementor;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Counter Widget
 */
class Counter extends Widget_Base {

	/**
	 * Get widget name
	 *
	 * @return string
	 */
	public function get_name() {
		return 'orvian-counter';
	}

	/**
	 * Get widget title
	 *
	 * @return string
	 */
	public function get_title() {
		return esc_html__( 'Counter', 'orvian-addons' );
	}

	/**
	 * Get widget icon
	 *
	 * @return string
	 */
	public function get_icon() {
		return 'eicon-counter ' . OrvianAddons_Elementor::CLASS_WIDGET;
	}

	/**
	 * Get widget categories
	 *
	 * @return array
	 */
	public function get_categories() {
		return [ OrvianAddons_Elementor::CATEGORY ];
	}

	/**
	 * Get widget keywords
	 *
	 * @return array
	 */
	/**
	 * Get widget keywords
	 *
	 * @return array
	 */
	public function get_keywords() {
		return [ 'counter', 'number', 'animate' ];
	}

	/**
	 * Register widget controls
	 *
	 * @return void
	 */
	protected function register_controls() {
		$this->start_controls_section(
			'section_card',
			[
				'label' => esc_html__( 'Card', 'orvian-addons' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'counter_number',
			[
				'label'   => esc_html__( 'Number', 'orvian-addons' ),
				'type'    => Controls_Manager::NUMBER,
				'default' => 100,
				'min'     => 0,
			]
		);

		$this->add_control(
			'counter_prefix',
			[
				'label'       => esc_html__( 'Prefix', 'orvian-addons' ),
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
			]
		);

		$this->add_control(
			'counter_suffix',
			[
				'label'       => esc_html__( 'Suffix', 'orvian-addons' ),
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
			]
		);

		$this->add_control(
			'counter_duration',
			[
				'label'   => esc_html__( 'Animation Duration (s)', 'orvian-addons' ),
				'type'    => Controls_Manager::SLIDER,
				'range'   => [
					's' => [
						'min'  => 0.5,
						'max'  => 5,
						'step' => 0.5,
					],
				],
				'default' => [
					'size' => 2,
				],
			]
		);

		$this->add_control(
			'bottom_heading',
			[
				'label'     => esc_html__( 'Bottom Content', 'orvian-addons' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_control(
			'text_bottom',
			[
				'label'       => esc_html__( 'Bottom Text', 'orvian-addons' ),
				'type'        => Controls_Manager::TEXTAREA,
				'default'     => esc_html__( 'This is a description', 'orvian-addons' ),
				'placeholder' => esc_html__( 'Enter text here', 'orvian-addons' ),
				'label_block' => true,
			]
		);

		$this->add_responsive_control(
			'alignment',
			[
				'label'     => esc_html__( 'Alignment', 'orvian-addons' ),
				'type'      => Controls_Manager::CHOOSE,
				'options'   => [
					'left'   => [
						'title' => esc_html__( 'Left', 'orvian-addons' ),
						'icon'  => 'eicon-text-align-left',
					],
					'center' => [
						'title' => esc_html__( 'Center', 'orvian-addons' ),
						'icon'  => 'eicon-text-align-center',
					],
					'right'  => [
						'title' => esc_html__( 'Right', 'orvian-addons' ),
						'icon'  => 'eicon-text-align-right',
					],
				],
				'selectors' => [
					'{{WRAPPER}} .orvian-counter' => 'text-align: {{VALUE}};',
				],
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'section_style_counter',
			[
				'label' => esc_html__( 'Counter', 'orvian-addons' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'counter_color',
			[
				'label'     => esc_html__( 'Color', 'orvian-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .orvian-counter__number' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'counter_typography',
				'selector' => '{{WRAPPER}} .orvian-counter__number',
			]
		);

		$this->add_control(
			'prefix_suffix_heading',
			[
				'label'     => esc_html__( 'Prefix & Suffix', 'orvian-addons' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_control(
			'prefix_suffix_color',
			[
				'label'     => esc_html__( 'Color', 'orvian-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .orvian-counter__prefix' => 'color: {{VALUE}};',
					'{{WRAPPER}} .orvian-counter__suffix' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'prefix_suffix_typography',
				'selector' => '{{WRAPPER}} .orvian-counter__prefix, {{WRAPPER}} .orvian-counter__suffix',
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'section_style_text_bottom',
			[
				'label' => esc_html__( 'Bottom Text', 'orvian-addons' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'text_bottom_color',
			[
				'label'     => esc_html__( 'Color', 'orvian-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .orvian-counter__text-bottom' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'text_bottom_typography',
				'selector' => '{{WRAPPER}} .orvian-counter__text-bottom',
			]
		);

		$this->add_responsive_control(
			'counter_spacing',
			[
				'label'      => esc_html__( 'Spacing Top', 'orvian-addons' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', 'em', 'rem', 'custom' ],
				'selectors'  => [
					'{{WRAPPER}} .orvian-counter__text-bottom' => 'margin-top: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();
	}

	/**
	 * Render widget output
	 *
	 * @return void
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();

		$this->add_render_attribute( 'wrapper', 'class', 'orvian-counter overflow-hidden relative' );
		$this->add_render_attribute( 'counter', 'class', 'orvian-counter__counter text-display-2 text-heading inline-flex items-center' );
		$this->add_render_attribute( 'text_bottom', 'class', 'orvian-counter__text-bottom mt-2 text-body-3' );

		?>
		<div <?php $this->print_render_attribute_string( 'wrapper' ); ?>>
			<?php if ( ! empty( $settings['counter_number'] ) ) : ?>
				<?php
					$this->add_render_attribute( 'counter', 'data-counter-value', esc_attr( $settings['counter_number'] ) );
					$this->add_render_attribute( 'counter', 'data-counter-duration', esc_attr( $settings['counter_duration']['size'] ?? 2 ) );
				?>
				<div <?php $this->print_render_attribute_string( 'counter' ); ?>>
					<?php if ( ! empty( $settings['counter_prefix'] ) ) : ?>
						<span class="orvian-counter__prefix"><?php echo esc_html( $settings['counter_prefix'] ); ?></span>
					<?php endif; ?>

					<span class="orvian-counter__number">0</span>

					<?php if ( ! empty( $settings['counter_suffix'] ) ) : ?>
						<span class="orvian-counter__suffix"><?php echo esc_html( $settings['counter_suffix'] ); ?></span>
					<?php endif; ?>
				</div>
			<?php endif; ?>

			<?php if ( ! empty( $settings['text_bottom'] ) ) : ?>
				<div <?php $this->print_render_attribute_string( 'text_bottom' ); ?>>
					<?php echo wp_kses_post( nl2br( $settings['text_bottom'] ) ); ?>
				</div>
			<?php endif; ?>
		</div>
		<?php
	}
}
