<?php
/**
 * Marquee Widget
 *
 * @package OrvianAddons
 */

namespace OrvianAddons\Elementor\Widgets;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Repeater;
use Elementor\Icons_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Background;
use Elementor\Group_Control_Css_Filter;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;
use OrvianAddons\Elementor\Elementor as OrvianAddons_Elementor;

/**
 * Marquee Widget Class
 */
class Marquee extends Widget_Base {

	use Base\Text_Class;
	use Base\Hover_Cursor_Base;

	/**
	 * Get widget name
	 *
	 * @return string
	 */
	public function get_name() {
		return 'orvian-marquee';
	}

	/**
	 * Get widget title
	 *
	 * @return string
	 */
	public function get_title() {
		return esc_html__( 'Marquee', 'orvian-addons' );
	}

	/**
	 * Get widget icon
	 *
	 * @return string
	 */
	public function get_icon() {
		return 'eicon-animation ' . OrvianAddons_Elementor::CLASS_WIDGET;
	}

	/**
	 * Get widget categories
	 *
	 * @return array
	 */
	public function get_categories() {
		return [ OrvianAddons_Elementor::CATEGORY ];
	}

	/**
	 * Get widget keywords
	 *
	 * @return array
	 */
	public function get_keywords() {
		return [ 'orvian', 'marquee', 'slider', 'text' ];
	}

	/**
	 * Register heading widget controls.
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @access protected
	 */
	protected function register_controls() {
		$this->start_controls_section(
			'section_content',
			[
				'label' => esc_html__( 'Marquee Primary', 'orvian-addons' ),
			]
		);

		$repeater = new Repeater();

		$repeater->add_control(
			'type',
			[
				'label'   => esc_html__( 'Type', 'orvian-addons' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'icon',
				'options' => [
					'icon'  => esc_html__( 'Icon', 'orvian-addons' ),
					'image' => esc_html__( 'Image', 'orvian-addons' ),
					'none'  => esc_html__( 'None', 'orvian-addons' ),
				],
			]
		);

		$repeater->add_control(
			'icon',
			[
				'label'      => esc_html__( 'Icon', 'orvian-addons' ),
				'type'       => Controls_Manager::ICONS,
				'default'    => [
					'value'   => 'fa fa-star',
					'library' => 'fa-solid',
				],
				'conditions' => [
					'terms' => [
						[
							'name'  => 'type',
							'value' => 'icon',
						],
					],
				],
			]
		);

		$repeater->add_control(
			'image',
			[
				'label'      => esc_html__( 'Image', 'orvian-addons' ),
				'type'       => Controls_Manager::MEDIA,
				'conditions' => [
					'terms' => [
						[
							'name'  => 'type',
							'value' => 'image',
						],
					],
				],
			]
		);

		$repeater->add_control(
			'text',
			[
				'label' => esc_html__( 'Text', 'orvian-addons' ),
				'type'  => Controls_Manager::TEXTAREA,
			]
		);

		$this->add_control(
			'items',
			[
				'label'   => esc_html__( 'Items', 'orvian-addons' ),
				'type'    => Controls_Manager::REPEATER,
				'fields'  => $repeater->get_controls(),
				'default' => [
					[
						'text' => esc_html__( 'Orvian', 'orvian-addons' ),
					],
					[
						'text' => esc_html__( 'Orvian', 'orvian-addons' ),
					],
				],
			]
		);

		$this->add_control(
			'speed',
			[
				'label'              => esc_html__( 'Speed', 'orvian-addons' ),
				'type'               => Controls_Manager::NUMBER,
				'default'            => '0.3',
				'min'                => 0.1,
				'max'                => 0.9,
				'step'               => 0.1,
				'frontend_available' => true,
			]
		);

		$this->add_control(
			'primary_direction',
			[
				'label'   => esc_html__( 'Direction', 'orvian-addons' ),
				'type'    => Controls_Manager::SELECT,
				'options' => [
					'marquee' => esc_html__( 'Right to Left', 'orvian-addons' ),
					'reverse' => esc_html__( 'Left to Right', 'orvian-addons' ),
				],
				'default' => 'marquee',
			]
		);

		$this->add_control(
			'text_size',
			[
				'label'   => esc_html__( 'HTML Tag', 'orvian-addons' ),
				'type'    => Controls_Manager::SELECT,
				'options' => $this->get_text_class_options_with_tags(),
				'default' => 'div',
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'section_content_secondary',
			[
				'label' => esc_html__( 'Marquee Secondary', 'orvian-addons' ),
			]
		);

		$repeater = new Repeater();

		$repeater->add_control(
			'secondary_type',
			[
				'label'   => esc_html__( 'Type', 'orvian-addons' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'icon',
				'options' => [
					'icon'  => esc_html__( 'Icon', 'orvian-addons' ),
					'image' => esc_html__( 'Image', 'orvian-addons' ),
					'none'  => esc_html__( 'None', 'orvian-addons' ),
				],
			]
		);

		$repeater->add_control(
			'secondary_icon',
			[
				'label'      => esc_html__( 'Icon', 'orvian-addons' ),
				'type'       => Controls_Manager::ICONS,
				'default'    => [
					'value'   => 'fa fa-star',
					'library' => 'fa-solid',
				],
				'conditions' => [
					'terms' => [
						[
							'name'  => 'secondary_type',
							'value' => 'icon',
						],
					],
				],
			]
		);

		$repeater->add_control(
			'secondary_image',
			[
				'label'      => esc_html__( 'Image', 'orvian-addons' ),
				'type'       => Controls_Manager::MEDIA,
				'conditions' => [
					'terms' => [
						[
							'name'  => 'secondary_type',
							'value' => 'image',
						],
					],
				],
			]
		);

		$repeater->add_control(
			'secondary_text',
			[
				'label' => esc_html__( 'Text', 'orvian-addons' ),
				'type'  => Controls_Manager::TEXTAREA,
			]
		);

		$this->add_control(
			'secondary_items',
			[
				'label'         => esc_html__( 'Items', 'orvian-addons' ),
				'type'          => Controls_Manager::REPEATER,
				'fields'        => $repeater->get_controls(),
				'prevent_empty' => false,
				'default'       => [],
			]
		);

		$this->add_control(
			'secondary_speed',
			[
				'label'              => esc_html__( 'Speed', 'orvian-addons' ),
				'type'               => Controls_Manager::NUMBER,
				'default'            => '0.3',
				'min'                => 0.1,
				'max'                => 0.9,
				'step'               => 0.1,
				'frontend_available' => true,
				'separator'          => 'before',
			]
		);

		$this->add_control(
			'secondary_direction',
			[
				'label'   => esc_html__( 'Direction', 'orvian-addons' ),
				'type'    => Controls_Manager::SELECT,
				'options' => [
					'marquee' => esc_html__( 'Right to Left', 'orvian-addons' ),
					'reverse' => esc_html__( 'Left to Right', 'orvian-addons' ),
				],
				'default' => 'reverse',
			]
		);

		$this->add_control(
			'secondary_text_size',
			[
				'label'   => esc_html__( 'HTML Tag', 'orvian-addons' ),
				'type'    => Controls_Manager::SELECT,
				'options' => $this->get_text_class_options_with_tags(),
				'default' => 'div',
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'hover_cursor_controls',
			[
				'label' => esc_html__( 'Hover Cursor', 'orvian-addons' ),
			]
		);

		$this->register_hover_cursor_controls();

		$this->end_controls_section();

		$this->start_controls_section(
			'section_style',
			[
				'label' => esc_html__( 'Content', 'orvian-addons' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'hover_pause',
			[
				'label'     => esc_html__( 'Hover stop', 'orvian-addons' ),
				'type'      => Controls_Manager::SWITCHER,
				'label_on'  => esc_html__( 'Yes', 'orvian-addons' ),
				'label_off' => esc_html__( 'No', 'orvian-addons' ),
				'default'   => 'yes',
			]
		);

		$this->add_control(
			'alert',
			[
				'type'       => Controls_Manager::ALERT,
				'alert_type' => 'info',
				'content'    => esc_html__( 'The following options are applied only when both Primary and Secondary marquees are enabled.', 'orvian-addons' ),
				'separator'  => 'before',
			]
		);

		$this->add_control(
			'marquee_type',
			[
				'label'   => esc_html__( 'Type', 'orvian-addons' ),
				'type'    => Controls_Manager::CHOOSE,
				'options' => [
					'default' => [
						'title' => esc_html__( 'Default', 'orvian-addons' ),
						'icon'  => 'eicon-handle',
					],
					'cross'   => [
						'title' => esc_html__( 'Cross', 'orvian-addons' ),
						'icon'  => 'eicon-close',
					],
				],
				'default' => 'default',
			]
		);

		$this->add_responsive_control(
			'marquees_height',
			[
				'label'      => esc_html__( 'Height', 'orvian-addons' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%', 'em', 'vw' ],
				'range'      => [
					'px' => [
						'min' => 0,
						'max' => 2000,
					],
				],
				'selectors'  => [
					'{{WRAPPER}} .orvian-marquees' => 'height: {{SIZE}}{{UNIT}};',
				],
				'condition'  => [
					'marquee_type' => 'cross',
				],
			]
		);

		$this->add_control(
			'backdrop_heading',
			[
				'label'     => esc_html__( 'Backdrop', 'orvian-addons' ),
				'type'      => Controls_Manager::HEADING,
				'condition' => [
					'marquee_type' => 'cross',
				],
			]
		);

		$this->add_responsive_control(
			'backdrop_width',
			[
				'label'      => esc_html__( 'Width', 'orvian-addons' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%', 'em', 'vw' ],
				'range'      => [
					'px' => [
						'min' => 0,
						'max' => 2000,
					],
				],
				'selectors'  => [
					'{{WRAPPER}} .orvian-marquee__backdrop' => 'width: {{SIZE}}{{UNIT}};',
				],
				'condition'  => [
					'marquee_type' => 'cross',
				],
			]
		);

		$this->add_responsive_control(
			'backdrop_height',
			[
				'label'      => esc_html__( 'Height', 'orvian-addons' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%', 'em', 'vw' ],
				'range'      => [
					'px' => [
						'min' => 0,
						'max' => 2000,
					],
				],
				'selectors'  => [
					'{{WRAPPER}} .orvian-marquee__backdrop' => 'height: {{SIZE}}{{UNIT}};',
				],
				'condition'  => [
					'marquee_type' => 'cross',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'      => 'backdrop_background',
				'types'     => [ 'classic', 'gradient' ],
				'selector'  => '{{WRAPPER}} .orvian-marquee__backdrop',
				'condition' => [
					'marquee_type' => 'cross',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Css_Filter::get_type(),
			[
				'name'      => 'backdrop_css_filters',
				'selector'  => '{{WRAPPER}} .orvian-marquee__backdrop',
				'condition' => [
					'marquee_type' => 'cross',
				],
			]
		);

		$this->add_responsive_control(
			'backdrop_opacity',
			[
				'label'     => esc_html__( 'Opacity', 'orvian-addons' ),
				'type'      => Controls_Manager::SLIDER,
				'range'     => [
					'px' => [
						'min'  => 0,
						'max'  => 1,
						'step' => 0.01,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .orvian-marquee__backdrop' => 'opacity: {{SIZE}};',
				],
				'condition' => [
					'marquee_type' => 'cross',
				],
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'section_primary_style',
			[
				'label' => esc_html__( 'Marquee Primary', 'orvian-addons' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'opacity',
			[
				'label'     => esc_html__( 'Opacity', 'orvian-addons' ),
				'type'      => Controls_Manager::SLIDER,
				'range'     => [
					'px' => [
						'min'  => 0,
						'max'  => 1,
						'step' => 0.01,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .orvian-marquee__primary' => 'opacity: {{SIZE}};',
				],
			]
		);

		$this->add_responsive_control(
			'padding',
			[
				'label'      => esc_html__( 'Padding', 'orvian-addons' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors'  => [
					'{{WRAPPER}} .orvian-marquee__primary' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'margin',
			[
				'label'      => esc_html__( 'Margin', 'orvian-addons' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors'  => [
					'{{WRAPPER}} .orvian-marquee__primary' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'gap',
			[
				'label'      => esc_html__( 'Gap', 'orvian-addons' ),
				'type'       => Controls_Manager::SLIDER,
				'range'      => [
					'px' => [
						'min' => 0,
						'max' => 200,
					],
				],
				'size_units' => [ 'px' ],
				'selectors'  => [
					'{{WRAPPER}} .orvian-marquee__primary .orvian-marquee__items' => 'gap: {{SIZE}}{{UNIT}}; margin-inline-end: {{SIZE}}{{UNIT}};',
					'.rtl {{WRAPPER}} .orvian-marquee__primary .orvian-marquee__items' => 'gap: {{SIZE}}{{UNIT}}; margin-inline-start: {{SIZE}}{{UNIT}}; margin-inline-end: 0;',
				],
			]
		);

		$this->add_control(
			'background_color',
			[
				'label'     => esc_html__( 'Background Color', 'orvian-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .orvian-marquee__primary' => 'background-color: {{VALUE}}',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'box_shadow',
				'selector' => '{{WRAPPER}} .orvian-marquee__primary',
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'     => 'border',
				'selector' => '{{WRAPPER}} .orvian-marquee__primary',
			]
		);

		$this->add_control(
			'item_heading',
			[
				'label'     => esc_html__( 'Item', 'orvian-addons' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_responsive_control(
			'item_width',
			[
				'label'      => esc_html__( 'Width', 'orvian-addons' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%', 'em', 'rem' ],
				'selectors'  => [
					'{{WRAPPER}} .orvian-marquee__primary .orvian-marquee__item' => 'width: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'item_height',
			[
				'label'      => esc_html__( 'Height', 'orvian-addons' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%', 'em', 'rem' ],
				'selectors'  => [
					'{{WRAPPER}} .orvian-marquee__primary .orvian-marquee__item' => 'height: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'item_align',
			[
				'label'     => esc_html__( 'Alignment', 'orvian-addons' ),
				'type'      => Controls_Manager::CHOOSE,
				'options'   => [
					'left'   => [
						'title' => esc_html__( 'Left', 'orvian-addons' ),
						'icon'  => 'eicon-text-align-left',
					],
					'center' => [
						'title' => esc_html__( 'Center', 'orvian-addons' ),
						'icon'  => 'eicon-text-align-center',
					],
					'right'  => [
						'title' => esc_html__( 'Right', 'orvian-addons' ),
						'icon'  => 'eicon-text-align-right',
					],
				],
				'selectors' => [
					'{{WRAPPER}} .orvian-marquee__primary .orvian-marquee__item' => 'text-align: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'item_background_color',
			[
				'label'     => esc_html__( 'Background Color', 'orvian-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .orvian-marquee__primary .orvian-marquee__item' => 'background-color: {{VALUE}}',
				],
			]
		);

		$this->add_responsive_control(
			'item_backdrop_filter',
			[
				'label'     => esc_html__( 'Backdrop Filter', 'orvian-addons' ),
				'type'      => Controls_Manager::SLIDER,
				'range'     => [
					'px' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .orvian-marquee__primary .orvian-marquee__item' => 'backdrop-filter: blur({{SIZE}}px)',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'     => 'item_border',
				'selector' => '{{WRAPPER}} .orvian-marquee__primary .orvian-marquee__item',
			]
		);

		$this->add_responsive_control(
			'item_padding',
			[
				'label'      => esc_html__( 'Padding', 'orvian-addons' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors'  => [
					'{{WRAPPER}} .orvian-marquee__primary .orvian-marquee__item' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'item_border_radius',
			[
				'label'      => esc_html__( 'Border Radius', 'orvian-addons' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors'  => [
					'{{WRAPPER}} .orvian-marquee__primary .orvian-marquee__item' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'image_heading',
			[
				'label'     => esc_html__( 'Image', 'orvian-addons' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_responsive_control(
			'image_width',
			[
				'label'      => esc_html__( 'Width', 'orvian-addons' ),
				'type'       => Controls_Manager::SLIDER,
				'range'      => [
					'px' => [
						'min' => 0,
						'max' => 200,
					],
				],
				'size_units' => [ 'px' ],
				'selectors'  => [
					'{{WRAPPER}} .orvian-marquee__primary .orvian-marquee__image' => 'width: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'image_border_radius',
			[
				'label'      => esc_html__( 'Border Radius', 'orvian-addons' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors'  => [
					'{{WRAPPER}} .orvian-marquee__primary .orvian-marquee__image' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'icon_heading',
			[
				'label'     => esc_html__( 'Icon', 'orvian-addons' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_responsive_control(
			'icon_size',
			[
				'label'      => esc_html__( 'Size', 'orvian-addons' ),
				'type'       => Controls_Manager::SLIDER,
				'range'      => [
					'px' => [
						'min' => 0,
						'max' => 200,
					],
				],
				'size_units' => [ 'px' ],
				'selectors'  => [
					'{{WRAPPER}} .orvian-marquee__primary .orvian-marquee__icon' => 'font-size: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'icon_color',
			[
				'label'     => esc_html__( 'Color', 'orvian-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .orvian-marquee__primary .orvian-marquee__icon' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_responsive_control(
			'spacing',
			[
				'label'      => esc_html__( 'Spacing', 'orvian-addons' ),
				'type'       => Controls_Manager::SLIDER,
				'range'      => [
					'px' => [
						'min' => 0,
						'max' => 200,
					],
				],
				'size_units' => [ 'px' ],
				'selectors'  => [
					'{{WRAPPER}} .orvian-marquee__primary .orvian-marquee__item' => 'gap: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'text_heading',
			[
				'label'     => esc_html__( 'Text', 'orvian-addons' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'text_typography',
				'selector' => '{{WRAPPER}} .orvian-marquee__primary .orvian-marquee__text',
			]
		);

		$this->add_control(
			'text_color',
			[
				'label'     => esc_html__( 'Color', 'orvian-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .orvian-marquee__primary .orvian-marquee__text' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_control(
			'text_background_color',
			[
				'label'     => esc_html__( 'Background Color', 'orvian-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .orvian-marquee__primary .orvian-marquee__text' => 'background-color: {{VALUE}}',
				],
			]
		);

		$this->add_responsive_control(
			'text_padding',
			[
				'label'      => esc_html__( 'Padding', 'orvian-addons' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors'  => [
					'{{WRAPPER}} .orvian-marquee__primary .orvian-marquee__text' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'text_border_radius',
			[
				'label'      => esc_html__( 'Border Radius', 'orvian-addons' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors'  => [
					'{{WRAPPER}} .orvian-marquee__primary .orvian-marquee__text' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'section_secondary_style',
			[
				'label' => esc_html__( 'Marquee Secondary', 'orvian-addons' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'secondary_opacity',
			[
				'label'     => esc_html__( 'Opacity', 'orvian-addons' ),
				'type'      => Controls_Manager::SLIDER,
				'range'     => [
					'px' => [
						'min'  => 0,
						'max'  => 1,
						'step' => 0.01,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .orvian-marquee__secondary' => 'opacity: {{SIZE}};',
				],
			]
		);

		$this->add_responsive_control(
			'secondary_padding',
			[
				'label'      => esc_html__( 'Padding', 'orvian-addons' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors'  => [
					'{{WRAPPER}} .orvian-marquee__secondary' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'secondary_margin',
			[
				'label'      => esc_html__( 'Margin', 'orvian-addons' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors'  => [
					'{{WRAPPER}} .orvian-marquee__secondary' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'secondary_gap',
			[
				'label'      => esc_html__( 'Gap', 'orvian-addons' ),
				'type'       => Controls_Manager::SLIDER,
				'range'      => [
					'px' => [
						'min' => 0,
						'max' => 200,
					],
				],
				'size_units' => [ 'px' ],
				'selectors'  => [
					'{{WRAPPER}} .orvian-marquee__secondary .orvian-marquee__items' => 'gap: {{SIZE}}{{UNIT}}; margin-inline-end: {{SIZE}}{{UNIT}};',
					'.rtl {{WRAPPER}} .orvian-marquee__secondary .orvian-marquee__items' => 'gap: {{SIZE}}{{UNIT}}; margin-inline-start: {{SIZE}}{{UNIT}}; margin-inline-end: 0;',
				],
			]
		);

		$this->add_control(
			'secondary_background_color',
			[
				'label'     => esc_html__( 'Background Color', 'orvian-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .orvian-marquee__secondary' => 'background-color: {{VALUE}}',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'secondary_box_shadow',
				'selector' => '{{WRAPPER}} .orvian-marquee__secondary',
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'     => 'secondary_border',
				'selector' => '{{WRAPPER}} .orvian-marquee__secondary',
			]
		);

		$this->add_control(
			'secondary_item_heading',
			[
				'label'     => esc_html__( 'Item', 'orvian-addons' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_responsive_control(
			'secondary_item_width',
			[
				'label'      => esc_html__( 'Width', 'orvian-addons' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%', 'em', 'rem' ],
				'selectors'  => [
					'{{WRAPPER}} .orvian-marquee__secondary .orvian-marquee__item' => 'width: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'secondary_item_height',
			[
				'label'      => esc_html__( 'Height', 'orvian-addons' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%', 'em', 'rem' ],
				'selectors'  => [
					'{{WRAPPER}} .orvian-marquee__secondary .orvian-marquee__item' => 'height: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'secondary_item_align',
			[
				'label'     => esc_html__( 'Alignment', 'orvian-addons' ),
				'type'      => Controls_Manager::CHOOSE,
				'options'   => [
					'left'   => [
						'title' => esc_html__( 'Left', 'orvian-addons' ),
						'icon'  => 'eicon-text-align-left',
					],
					'center' => [
						'title' => esc_html__( 'Center', 'orvian-addons' ),
						'icon'  => 'eicon-text-align-center',
					],
					'right'  => [
						'title' => esc_html__( 'Right', 'orvian-addons' ),
						'icon'  => 'eicon-text-align-right',
					],
				],
				'selectors' => [
					'{{WRAPPER}} .orvian-marquee__secondary .orvian-marquee__item' => 'text-align: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'secondary_item_background_color',
			[
				'label'     => esc_html__( 'Background Color', 'orvian-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .orvian-marquee__secondary .orvian-marquee__item' => 'background-color: {{VALUE}}',
				],
			]
		);

		$this->add_responsive_control(
			'secondary_item_backdrop_filter',
			[
				'label'     => esc_html__( 'Backdrop Filter', 'orvian-addons' ),
				'type'      => Controls_Manager::SLIDER,
				'range'     => [
					'px' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .orvian-marquee__secondary .orvian-marquee__item' => 'backdrop-filter: blur({{SIZE}}px)',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'     => 'secondary_item_border',
				'selector' => '{{WRAPPER}} .orvian-marquee__secondary .orvian-marquee__item',
			]
		);

		$this->add_responsive_control(
			'secondary_item_padding',
			[
				'label'      => esc_html__( 'Padding', 'orvian-addons' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors'  => [
					'{{WRAPPER}} .orvian-marquee__secondary .orvian-marquee__item' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'secondary_item_border_radius',
			[
				'label'      => esc_html__( 'Border Radius', 'orvian-addons' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors'  => [
					'{{WRAPPER}} .orvian-marquee__secondary .orvian-marquee__item' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'secondary_image_heading',
			[
				'label'     => esc_html__( 'Image', 'orvian-addons' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_responsive_control(
			'secondary_image_width',
			[
				'label'      => esc_html__( 'Width', 'orvian-addons' ),
				'type'       => Controls_Manager::SLIDER,
				'range'      => [
					'px' => [
						'min' => 0,
						'max' => 200,
					],
				],
				'size_units' => [ 'px' ],
				'selectors'  => [
					'{{WRAPPER}} .orvian-marquee__secondary .orvian-marquee__image' => 'width: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'secondary_image_border_radius',
			[
				'label'      => esc_html__( 'Border Radius', 'orvian-addons' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors'  => [
					'{{WRAPPER}} .orvian-marquee__secondary .orvian-marquee__image' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'secondary_icon_heading',
			[
				'label'     => esc_html__( 'Icon', 'orvian-addons' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_responsive_control(
			'secondary_icon_size',
			[
				'label'      => esc_html__( 'Size', 'orvian-addons' ),
				'type'       => Controls_Manager::SLIDER,
				'range'      => [
					'px' => [
						'min' => 0,
						'max' => 200,
					],
				],
				'size_units' => [ 'px' ],
				'selectors'  => [
					'{{WRAPPER}} .orvian-marquee__secondary .orvian-marquee__icon' => 'font-size: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'secondary_icon_color',
			[
				'label'     => esc_html__( 'Color', 'orvian-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .orvian-marquee__secondary .orvian-marquee__icon' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_responsive_control(
			'secondary_spacing',
			[
				'label'      => esc_html__( 'Spacing', 'orvian-addons' ),
				'type'       => Controls_Manager::SLIDER,
				'range'      => [
					'px' => [
						'min' => 0,
						'max' => 200,
					],
				],
				'size_units' => [ 'px' ],
				'selectors'  => [
					'{{WRAPPER}} .orvian-marquee__secondary .orvian-marquee__item' => 'gap: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'secondary_text_heading',
			[
				'label'     => esc_html__( 'Text', 'orvian-addons' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'secondary_text_typography',
				'selector' => '{{WRAPPER}} .orvian-marquee__secondary .orvian-marquee__text',
			]
		);

		$this->add_control(
			'secondary_text_color',
			[
				'label'     => esc_html__( 'Color', 'orvian-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .orvian-marquee__secondary .orvian-marquee__text' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_control(
			'secondary_text_background_color',
			[
				'label'     => esc_html__( 'Background Color', 'orvian-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .orvian-marquee__secondary .orvian-marquee__text' => 'background-color: {{VALUE}}',
				],
			]
		);

		$this->add_responsive_control(
			'secondary_text_padding',
			[
				'label'      => esc_html__( 'Padding', 'orvian-addons' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors'  => [
					'{{WRAPPER}} .orvian-marquee__secondary .orvian-marquee__text' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'secondary_text_border_radius',
			[
				'label'      => esc_html__( 'Border Radius', 'orvian-addons' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors'  => [
					'{{WRAPPER}} .orvian-marquee__secondary .orvian-marquee__text' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'hover_cursor_controls_style',
			[
				'label' => esc_html__( 'Hover Cursor', 'orvian-addons' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->register_hover_cursor_controls_style();

		$this->end_controls_section();
	}

	/**
	 * Render heading widget output on the frontend.
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @access protected
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();

		$classes = [
			'orvian-marquee',
			'orvian-marquee__primary',
			'orvian-elementor--marquee',
			'yes' === $settings['hover_pause'] ? 'hover-stop' : '',
			'marquee--' . $settings['primary_direction'],
		];

		if ( ! empty( $settings['secondary_items'] ) && 'cross' === $settings['marquee_type'] ) {
			?>
			<div class="orvian-marquee__backdrop"></div>
			<div class="orvian-marquees relative">
			<?php
		}

		$this->add_render_attribute( 'wrapper', 'class', $classes );
		$this->add_render_attribute( 'inner', 'class', [ 'orvian-marquee__inner', 'orvian-marquee--inner', 'relative', 'items-center' ] );
		$this->add_render_attribute( 'items', 'class', [ 'orvian-marquee__items', 'orvian-marquee--items', 'orvian-marquee--original', 'items-center' ] );
		$this->add_render_attribute( 'image', 'class', [ 'orvian-marquee__image' ] );
		$this->add_render_attribute( 'icon', 'class', [ 'orvian-marquee__icon', 'orvian-svg-icon', 'text-white' ] );
		$this->add_render_attribute( 'text', 'class', [ 'orvian-marquee__text', 'uppercase', 'font-semibold', 'text-white', 'm-0' ] );

		$text_tag = $this->resolve_text_tag( $settings['text_size'], 'text' );
		?>
		<div <?php $this->print_render_attribute_string( 'wrapper' ); ?> <?php $this->render_hover_cursor_attributes(); ?>>
			<div <?php $this->print_render_attribute_string( 'inner' ); ?>>
				<div <?php $this->print_render_attribute_string( 'items' ); ?>>
					<?php foreach ( $settings['items'] as $index => $item ) : ?>
						<?php
							$item_key = $this->get_repeater_setting_key( 'item', 'elementor-marquee', $index );
							$this->add_render_attribute( $item_key, 'class', [ 'orvian-marquee__item', 'flex', 'items-center', 'justify-center', 'elementor-repeater-item-' . esc_attr( $item['_id'] ) ] );
						?>
						<div <?php $this->print_render_attribute_string( $item_key ); ?>>
							<?php if ( 'image' === $item['type'] ) : ?>
								<?php if ( ! empty( $item['image']['url'] ) ) : ?>
									<div <?php $this->print_render_attribute_string( 'image' ); ?>>
										<?php if ( ! empty( $item['image']['id'] ) ) : ?>
											<?php echo wp_get_attachment_image( $item['image']['id'], 'full' ); ?>
										<?php elseif ( ! empty( $item['image']['url'] ) ) : ?>
											<img src="<?php echo esc_url( $item['image']['url'] ); ?>"/>
										<?php endif; ?>
									</div>
								<?php endif; ?>
							<?php endif; ?>
							<?php if ( 'icon' === $item['type'] ) : ?>
								<?php if ( ! empty( $item['icon'] ) && ! empty( $item['icon']['value'] ) ) : ?>
									<span <?php $this->print_render_attribute_string( 'icon' ); ?>>
										<?php Icons_Manager::render_icon( $item['icon'], [ 'aria-hidden' => 'true' ] ); ?>
									</span>
								<?php endif; ?>
							<?php endif; ?>
							<?php if ( ! empty( $item['text'] ) ) : ?>
								<<?php echo esc_attr( $text_tag ); ?> <?php $this->print_render_attribute_string( 'text' ); ?>>
									<?php echo wp_kses_post( $item['text'] ); ?>
								</<?php echo esc_attr( $text_tag ); ?>>
							<?php endif; ?>
						</div>
					<?php endforeach; ?>
				</div>
			</div>
			<?php $this->render_hover_cursor_template(); ?>
		</div>
		<?php

		if ( ! empty( $settings['secondary_items'] ) ) {
			$this->marquee_secondary( $settings );
			if ( 'cross' === $settings['marquee_type'] ) {
				?>
				</div>
				<?php
			}
		}
	}

	/**
	 * Render heading widget output on the frontend.
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @param array $settings Widget settings.
	 * @access protected
	 */
	protected function marquee_secondary( $settings ) {
		$classes = [
			'orvian-marquee',
			'orvian-marquee__secondary',
			'orvian-elementor--marquee',
			'yes' === $settings['hover_pause'] ? 'hover-stop' : '',
			'marquee--' . $settings['secondary_direction'],
		];

		$this->add_render_attribute( 'secondary_wrapper', 'class', $classes );
		$this->add_render_attribute( 'secondary_inner', 'class', [ 'orvian-marquee__inner', 'orvian-marquee--inner', 'relative', 'items-center' ] );
		$this->add_render_attribute( 'secondary_items', 'class', [ 'orvian-marquee__items', 'orvian-marquee--items', 'orvian-marquee--original', 'items-center' ] );
		$this->add_render_attribute( 'secondary_image', 'class', [ 'orvian-marquee__image' ] );
		$this->add_render_attribute( 'secondary_icon', 'class', [ 'orvian-marquee__icon', 'orvian-svg-icon', 'text-white' ] );
		$this->add_render_attribute( 'secondary_text', 'class', [ 'orvian-marquee__text', 'uppercase', 'font-semibold', 'text-white', 'm-0' ] );

		$secondary_text_tag = $this->resolve_text_tag( $settings['secondary_text_size'], 'secondary_text' );
		?>
		<div <?php $this->print_render_attribute_string( 'secondary_wrapper' ); ?> <?php $this->render_hover_cursor_attributes(); ?>>
			<div <?php $this->print_render_attribute_string( 'secondary_inner' ); ?>>
				<div <?php $this->print_render_attribute_string( 'secondary_items' ); ?>>
					<?php foreach ( $settings['secondary_items'] as $index => $item ) : ?>
						<?php
							$item_key = $this->get_repeater_setting_key( 'secondary_item', 'elementor-marquee', $index );
							$this->add_render_attribute( $item_key, 'class', [ 'orvian-marquee__item', 'flex', 'items-center', 'justify-center', 'elementor-repeater-item-' . esc_attr( $item['_id'] ) ] );
						?>
						<div <?php $this->print_render_attribute_string( $item_key ); ?>>
							<?php if ( 'image' === $item['secondary_type'] ) : ?>
								<?php if ( ! empty( $item['secondary_image']['url'] ) ) : ?>
									<div <?php $this->print_render_attribute_string( 'secondary_image' ); ?>>
										<?php if ( ! empty( $item['secondary_image']['id'] ) ) : ?>
											<?php echo wp_get_attachment_image( $item['secondary_image']['id'], 'full' ); ?>
										<?php elseif ( ! empty( $item['secondary_image']['url'] ) ) : ?>
											<img src="<?php echo esc_url( $item['secondary_image']['url'] ); ?>"/>
										<?php endif; ?>
									</div>
								<?php endif; ?>
							<?php endif; ?>
							<?php if ( 'icon' === $item['secondary_type'] ) : ?>
								<?php if ( ! empty( $item['secondary_icon'] ) && ! empty( $item['secondary_icon']['value'] ) ) : ?>
									<span <?php $this->print_render_attribute_string( 'secondary_icon' ); ?>>
										<?php Icons_Manager::render_icon( $item['secondary_icon'], [ 'aria-hidden' => 'true' ] ); ?>
									</span>
								<?php endif; ?>
							<?php endif; ?>
							<?php if ( ! empty( $item['secondary_text'] ) ) : ?>
								<<?php echo esc_attr( $secondary_text_tag ); ?> <?php $this->print_render_attribute_string( 'secondary_text' ); ?>>
									<?php echo wp_kses_post( $item['secondary_text'] ); ?>
								</<?php echo esc_attr( $secondary_text_tag ); ?>>
							<?php endif; ?>
						</div>
					<?php endforeach; ?>
				</div>
			</div>
			<?php $this->render_hover_cursor_template(); ?>
		</div>
		<?php
	}
}
