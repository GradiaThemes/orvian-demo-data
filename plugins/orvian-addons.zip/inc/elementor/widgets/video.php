<?php
/**
 * Video Widget
 *
 * @package OrvianAddons
 */

namespace OrvianAddons\Elementor\Widgets;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Modules\DynamicTags\Module as TagsModule;
use Elementor\Plugin;
use Elementor\Embed;
use Elementor\Utils;
use Elementor\Icons_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Image_Size;
use Elementor\Group_Control_Css_Filter;
use Elementor\Group_Control_Text_Shadow;

/**
 * Video Widget Class
 */
class Video extends Widget_Base {
	use Base\Hover_Cursor_Base;
	use Base\Text_Class;

	/**
	 * Get widget name
	 *
	 * @return string
	 */
	public function get_name() {
		return 'orvian-video';
	}

	/**
	 * Get HTML wrapper class.
	 *
	 * Retrieve the widget container class. Can be used to override the
	 * container class for specific widgets.
	 */
	protected function get_html_wrapper_class() {
		return 'elementor-widget-video elementor-widget-' . $this->get_name();
	}

	/**
	 * Get widget title
	 *
	 * @return string
	 */
	public function get_title() {
		return esc_html__( 'Video', 'orvian-addons' );
	}

	/**
	 * Get widget icon
	 *
	 * @return string
	 */
	public function get_icon() {
		return 'eicon-e-youtube ' . \OrvianAddons\Elementor\Elementor::CLASS_WIDGET;
	}

	/**
	 * Get widget categories
	 *
	 * @return array
	 */
	public function get_categories() {
		return [ \OrvianAddons\Elementor\Elementor::CATEGORY ];
	}

	/**
	 * Get widget keywords
	 *
	 * @return array
	 */
	public function get_keywords() {
		return [ 'orvian', 'video', 'player' ];
	}

	/**
	 * Get style dependencies.
	 *
	 * Retrieve the list of style dependencies the widget requires.
	 *
	 * @return array Widget style dependencies.
	 */
	public function get_style_depends(): array {
		return [ 'widget-video' ];
	}

	/**
	 * Check if widget has inner wrapper
	 *
	 * @return bool
	 */
	public function has_widget_inner_wrapper(): bool {
		return ! Plugin::$instance->experiments->is_feature_active( 'e_optimized_markup' );
	}

	/**
	 * Register widget controls
	 */
	protected function register_controls() {
		$this->start_controls_section(
			'section_video',
			[
				'label' => esc_html__( 'Video', 'orvian-addons' ),
			]
		);

		$this->add_control(
			'video_type',
			[
				'label'              => esc_html__( 'Source', 'orvian-addons' ),
				'type'               => Controls_Manager::SELECT,
				'default'            => 'youtube',
				'options'            => [
					'youtube'     => esc_html__( 'YouTube', 'orvian-addons' ),
					'vimeo'       => esc_html__( 'Vimeo', 'orvian-addons' ),
					'dailymotion' => esc_html__( 'Dailymotion', 'orvian-addons' ),
					'videopress'  => esc_html__( 'VideoPress', 'orvian-addons' ),
					'hosted'      => esc_html__( 'Self Hosted', 'orvian-addons' ),
				],
				'frontend_available' => true,
			]
		);

		$this->add_control(
			'youtube_url',
			[
				'label'              => esc_html__( 'Link', 'orvian-addons' ),
				'type'               => Controls_Manager::TEXT,
				'dynamic'            => [
					'active'     => true,
					'categories' => [
						TagsModule::POST_META_CATEGORY,
						TagsModule::URL_CATEGORY,
					],
				],
				'placeholder'        => esc_html__( 'Enter your URL', 'orvian-addons' ) . ' (YouTube)',
				'default'            => 'https://www.youtube.com/watch?v=XHOmBV4js_E',
				'label_block'        => true,
				'condition'          => [
					'video_type' => 'youtube',
				],
				'ai'                 => [
					'active' => false,
				],
				'frontend_available' => true,
			]
		);

		$this->add_control(
			'vimeo_url',
			[
				'label'       => esc_html__( 'Link', 'orvian-addons' ),
				'type'        => Controls_Manager::TEXT,
				'dynamic'     => [
					'active'     => true,
					'categories' => [
						TagsModule::POST_META_CATEGORY,
						TagsModule::URL_CATEGORY,
					],
				],
				'placeholder' => esc_html__( 'Enter your URL', 'orvian-addons' ) . ' (Vimeo)',
				'default'     => 'https://vimeo.com/235215203',
				'label_block' => true,
				'condition'   => [
					'video_type' => 'vimeo',
				],
				'ai'          => [
					'active' => false,
				],
			]
		);

		$this->add_control(
			'dailymotion_url',
			[
				'label'       => esc_html__( 'Link', 'orvian-addons' ),
				'type'        => Controls_Manager::TEXT,
				'dynamic'     => [
					'active'     => true,
					'categories' => [
						TagsModule::POST_META_CATEGORY,
						TagsModule::URL_CATEGORY,
					],
				],
				'placeholder' => esc_html__( 'Enter your URL', 'orvian-addons' ) . ' (Dailymotion)',
				'default'     => 'https://www.dailymotion.com/video/x6tqhqb',
				'label_block' => true,
				'condition'   => [
					'video_type' => 'dailymotion',
				],
				'ai'          => [
					'active' => false,
				],
			]
		);

		$this->add_control(
			'insert_url',
			[
				'label'     => esc_html__( 'External URL', 'orvian-addons' ),
				'type'      => Controls_Manager::SWITCHER,
				'condition' => [
					'video_type' => [ 'hosted', 'videopress' ],
				],
			]
		);

		$this->add_control(
			'hosted_url',
			[
				'label'       => esc_html__( 'Choose Video File', 'orvian-addons' ),
				'type'        => Controls_Manager::MEDIA,
				'dynamic'     => [
					'active'     => true,
					'categories' => [
						TagsModule::MEDIA_CATEGORY,
					],
				],
				'media_types' => [
					'video',
				],
				'condition'   => [
					'video_type' => [ 'hosted', 'videopress' ],
					'insert_url' => '',
				],
			]
		);

		$this->add_control(
			'external_url',
			[
				'label'        => esc_html__( 'URL', 'orvian-addons' ),
				'type'         => Controls_Manager::URL,
				'autocomplete' => false,
				'options'      => false,
				'label_block'  => true,
				'show_label'   => false,
				'dynamic'      => [
					'active'     => true,
					'categories' => [
						TagsModule::POST_META_CATEGORY,
						TagsModule::URL_CATEGORY,
					],
				],
				'placeholder'  => esc_html__( 'Enter your URL', 'orvian-addons' ),
				'condition'    => [
					'video_type' => 'hosted',
					'insert_url' => 'yes',
				],
			]
		);

		$this->add_control(
			'videopress_url',
			[
				'label'       => esc_html__( 'URL', 'orvian-addons' ),
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
				'show_label'  => false,
				'default'     => 'https://videopress.com/v/ZCAOzTNk',
				'dynamic'     => [
					'active'     => true,
					'categories' => [
						TagsModule::POST_META_CATEGORY,
						TagsModule::URL_CATEGORY,
					],
				],
				'placeholder' => esc_html__( 'VideoPress URL', 'orvian-addons' ),
				'ai'          => [
					'active' => false,
				],
				'condition'   => [
					'video_type' => 'videopress',
					'insert_url' => 'yes',
				],

			]
		);

		$this->add_control(
			'start',
			[
				'label'              => esc_html__( 'Start Time', 'orvian-addons' ),
				'type'               => Controls_Manager::NUMBER,
				'description'        => esc_html__( 'Specify a start time (in seconds)', 'orvian-addons' ),
				'frontend_available' => true,
				'separator'          => 'before',
			]
		);

		$this->add_control(
			'end',
			[
				'label'              => esc_html__( 'End Time', 'orvian-addons' ),
				'type'               => Controls_Manager::NUMBER,
				'description'        => esc_html__( 'Specify an end time (in seconds)', 'orvian-addons' ),
				'condition'          => [
					'video_type' => [ 'youtube', 'hosted' ],
				],
				'frontend_available' => true,
			]
		);

		$this->add_control(
			'video_options',
			[
				'label'     => esc_html__( 'Video Options', 'orvian-addons' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_control(
			'autoplay',
			[
				'label'              => esc_html__( 'Autoplay', 'orvian-addons' ),
				'description'        => sprintf(
					/* translators: 1: `<a>` opening tag, 2: `</a>` closing tag. */
					esc_html__( 'Note: Autoplay is affected by %1$s Google’s Autoplay policy %2$s on Chrome browsers.', 'orvian-addons' ),
					'<a href="https://developers.google.com/web/updates/2017/09/autoplay-policy-changes" target="_blank">',
					'</a>'
				),
				'type'               => Controls_Manager::SWITCHER,
				'frontend_available' => true,
			]
		);

		$this->add_control(
			'play_on_mobile',
			[
				'label'              => esc_html__( 'Play On Mobile', 'orvian-addons' ),
				'type'               => Controls_Manager::SWITCHER,
				'condition'          => [
					'autoplay' => 'yes',
				],
				'frontend_available' => true,
			]
		);

		$this->add_control(
			'mute',
			[
				'label'              => esc_html__( 'Mute', 'orvian-addons' ),
				'type'               => Controls_Manager::SWITCHER,
				'frontend_available' => true,
			]
		);

		$this->add_control(
			'loop',
			[
				'label'              => esc_html__( 'Loop', 'orvian-addons' ),
				'type'               => Controls_Manager::SWITCHER,
				'condition'          => [
					'video_type!' => 'dailymotion',
				],
				'frontend_available' => true,
			]
		);

		$this->add_control(
			'controls',
			[
				'label'              => esc_html__( 'Player Controls', 'orvian-addons' ),
				'type'               => Controls_Manager::SWITCHER,
				'label_off'          => esc_html__( 'Hide', 'orvian-addons' ),
				'label_on'           => esc_html__( 'Show', 'orvian-addons' ),
				'default'            => 'yes',
				'condition'          => [
					'video_type!' => 'vimeo',
				],
				'frontend_available' => true,
			]
		);

		$this->add_control(
			'showinfo',
			[
				'label'     => esc_html__( 'Video Info', 'orvian-addons' ),
				'type'      => Controls_Manager::SWITCHER,
				'label_off' => esc_html__( 'Hide', 'orvian-addons' ),
				'label_on'  => esc_html__( 'Show', 'orvian-addons' ),
				'default'   => 'yes',
				'condition' => [
					'video_type' => [ 'dailymotion' ],
				],
			]
		);

		$this->add_control(
			'cc_load_policy',
			[
				'label'              => esc_html__( 'Captions', 'orvian-addons' ),
				'type'               => Controls_Manager::SWITCHER,
				'condition'          => [
					'video_type' => [ 'youtube' ],
					'controls'   => 'yes',
				],
				'frontend_available' => true,
			]
		);

		$this->add_control(
			'logo',
			[
				'label'     => esc_html__( 'Logo', 'orvian-addons' ),
				'type'      => Controls_Manager::SWITCHER,
				'label_off' => esc_html__( 'Hide', 'orvian-addons' ),
				'label_on'  => esc_html__( 'Show', 'orvian-addons' ),
				'default'   => 'yes',
				'condition' => [
					'video_type' => [ 'dailymotion' ],
				],
			]
		);

		// YouTube.
		$this->add_control(
			'yt_privacy',
			[
				'label'              => esc_html__( 'Privacy Mode', 'orvian-addons' ),
				'type'               => Controls_Manager::SWITCHER,
				'description'        => esc_html__( 'When you turn on privacy mode, YouTube/Vimeo won\'t store information about visitors on your website unless they play the video.', 'orvian-addons' ),
				'condition'          => [
					'video_type' => [ 'youtube', 'vimeo' ],
				],
				'frontend_available' => true,
			]
		);

		$this->add_control(
			'lazy_load',
			[
				'label'              => esc_html__( 'Lazy Load', 'orvian-addons' ),
				'type'               => Controls_Manager::SWITCHER,
				'conditions'         => [
					'relation' => 'or',
					'terms'    => [
						[
							'name'     => 'video_type',
							'operator' => '===',
							'value'    => 'youtube',
						],
						[
							'relation' => 'and',
							'terms'    => [
								[
									'name'     => 'show_image_overlay',
									'operator' => '===',
									'value'    => 'yes',
								],
								[
									'name'     => 'video_type',
									'operator' => '!==',
									'value'    => 'hosted',
								],
							],
						],
					],
				],
				'frontend_available' => true,
			]
		);

		$this->add_control(
			'rel',
			[
				'label'     => esc_html__( 'Suggested Videos', 'orvian-addons' ),
				'type'      => Controls_Manager::SELECT,
				'options'   => [
					''    => esc_html__( 'Current Video Channel', 'orvian-addons' ),
					'yes' => esc_html__( 'Any Video', 'orvian-addons' ),
				],
				'condition' => [
					'video_type' => 'youtube',
				],
			]
		);

		// Vimeo.
		$this->add_control(
			'vimeo_title',
			[
				'label'     => esc_html__( 'Intro Title', 'orvian-addons' ),
				'type'      => Controls_Manager::SWITCHER,
				'label_off' => esc_html__( 'Hide', 'orvian-addons' ),
				'label_on'  => esc_html__( 'Show', 'orvian-addons' ),
				'default'   => 'yes',
				'condition' => [
					'video_type' => 'vimeo',
				],
			]
		);

		$this->add_control(
			'vimeo_portrait',
			[
				'label'     => esc_html__( 'Intro Portrait', 'orvian-addons' ),
				'type'      => Controls_Manager::SWITCHER,
				'label_off' => esc_html__( 'Hide', 'orvian-addons' ),
				'label_on'  => esc_html__( 'Show', 'orvian-addons' ),
				'default'   => 'yes',
				'condition' => [
					'video_type' => 'vimeo',
				],
			]
		);

		$this->add_control(
			'vimeo_byline',
			[
				'label'     => esc_html__( 'Intro Byline', 'orvian-addons' ),
				'type'      => Controls_Manager::SWITCHER,
				'label_off' => esc_html__( 'Hide', 'orvian-addons' ),
				'label_on'  => esc_html__( 'Show', 'orvian-addons' ),
				'default'   => 'yes',
				'condition' => [
					'video_type' => 'vimeo',
				],
			]
		);

		$this->add_control(
			'color',
			[
				'label'     => esc_html__( 'Controls Color', 'orvian-addons' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'condition' => [
					'video_type' => [ 'vimeo', 'dailymotion' ],
				],
			]
		);

		$this->add_control(
			'download_button',
			[
				'label'     => esc_html__( 'Download Button', 'orvian-addons' ),
				'type'      => Controls_Manager::SWITCHER,
				'label_off' => esc_html__( 'Hide', 'orvian-addons' ),
				'label_on'  => esc_html__( 'Show', 'orvian-addons' ),
				'condition' => [
					'video_type' => 'hosted',
				],
			]
		);

		$this->add_control(
			'preload',
			[
				'label'       => esc_html__( 'Preload', 'orvian-addons' ),
				'type'        => Controls_Manager::SELECT,
				'options'     => [
					'metadata' => esc_html__( 'Metadata', 'orvian-addons' ),
					'auto'     => esc_html__( 'Auto', 'orvian-addons' ),
					'none'     => esc_html__( 'None', 'orvian-addons' ),
				],
				'description' => sprintf(
					'%1$s <a target="_blank" href="https://go.elementor.com/preload-video/">%2$s</a>',
					esc_html__( 'Preload attribute lets you specify how the video should be loaded when the page loads.', 'orvian-addons' ),
					esc_html__( 'Learn more', 'orvian-addons' ),
				),
				'default'     => 'metadata',
				'condition'   => [
					'video_type' => 'hosted',
					'autoplay'   => '',
				],
			]
		);

		$this->add_control(
			'poster',
			[
				'label'     => esc_html__( 'Poster', 'orvian-addons' ),
				'type'      => Controls_Manager::MEDIA,
				'dynamic'   => [
					'active' => true,
				],
				'condition' => [
					'video_type' => 'hosted',
				],
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'section_image_overlay',
			[
				'label' => esc_html__( 'Image Overlay', 'orvian-addons' ),
			]
		);

		$this->add_control(
			'show_image_overlay',
			[
				'label'              => esc_html__( 'Image Overlay', 'orvian-addons' ),
				'type'               => Controls_Manager::SWITCHER,
				'label_off'          => esc_html__( 'Hide', 'orvian-addons' ),
				'label_on'           => esc_html__( 'Show', 'orvian-addons' ),
				'frontend_available' => true,
			]
		);

		$this->add_control(
			'image_overlay',
			[
				'label'              => esc_html__( 'Choose Image', 'orvian-addons' ),
				'type'               => Controls_Manager::MEDIA,
				'default'            => [
					'url' => Utils::get_placeholder_image_src(),
				],
				'dynamic'            => [
					'active' => true,
				],
				'condition'          => [
					'show_image_overlay' => 'yes',
				],
				'frontend_available' => true,
			]
		);

		$this->add_group_control(
			Group_Control_Image_Size::get_type(),
			[
				'name'      => 'image_overlay',
				'default'   => 'full',
				'condition' => [
					'show_image_overlay' => 'yes',
				],
			]
		);

		$this->add_control(
			'show_play_icon',
			[
				'label'     => esc_html__( 'Play Icon', 'orvian-addons' ),
				'type'      => Controls_Manager::SWITCHER,
				'default'   => 'yes',
				'label_off' => esc_html__( 'Hide', 'orvian-addons' ),
				'label_on'  => esc_html__( 'Show', 'orvian-addons' ),
				'separator' => 'before',
				'condition' => [
					'show_image_overlay'  => 'yes',
					'image_overlay[url]!' => '',
				],
			]
		);

		$this->add_control(
			'play_icon',
			[
				'label'            => esc_html__( 'Icon', 'orvian-addons' ),
				'type'             => Controls_Manager::ICONS,
				'fa4compatibility' => 'icon',
				'skin'             => 'inline',
				'label_block'      => false,
				'skin_settings'    => [
					'inline' => [
						'none' => [
							'label' => 'Default',
							'icon'  => 'eicon-play',
						],
						'icon' => [
							'icon' => 'eicon-star',
						],
					],
				],
				'recommended'      => [
					'fa-regular' => [
						'play-circle',
					],
					'fa-solid'   => [
						'play',
						'play-circle',
					],
				],
				'condition'        => [
					'show_image_overlay' => 'yes',
					'show_play_icon!'    => '',
				],
			]
		);

		$this->add_control(
			'play_icon_text',
			[
				'label'     => esc_html__( 'Icon Text', 'orvian-addons' ),
				'type'      => Controls_Manager::TEXT,
				'condition' => [
					'show_image_overlay' => 'yes',
					'show_play_icon!'    => '',
				],
			]
		);

		$this->add_control(
			'play_icon_text_size',
			[
				'label'     => esc_html__( 'HTML Tag', 'orvian-addons' ),
				'type'      => Controls_Manager::SELECT,
				'options'   => $this->get_text_class_options_with_tags(),
				'default'   => 'div',
				'condition' => [
					'show_image_overlay' => 'yes',
					'show_play_icon!'    => '',
				],
			]
		);

		$this->add_control(
			'play_icon_use_font_family_heading',
			[
				'label'     => esc_html__( 'Use Font Family of Heading', 'orvian-addons' ),
				'type'      => Controls_Manager::SWITCHER,
				'condition' => [
					'show_image_overlay' => 'yes',
					'show_play_icon!'    => '',
				],
			]
		);

		$this->register_hover_cursor_controls( '', [], [ 'show_play_icon' => '' ] );

		$this->add_control(
			'lightbox',
			[
				'label'              => esc_html__( 'Lightbox', 'orvian-addons' ),
				'type'               => Controls_Manager::SWITCHER,
				'frontend_available' => true,
				'label_off'          => esc_html__( 'Off', 'orvian-addons' ),
				'label_on'           => esc_html__( 'On', 'orvian-addons' ),
				'condition'          => [
					'show_image_overlay'  => 'yes',
					'image_overlay[url]!' => '',
				],
				'separator'          => 'before',
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'section_video_style',
			[
				'label' => esc_html__( 'Video', 'orvian-addons' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'aspect_ratio',
			[
				'label'                => esc_html__( 'Aspect Ratio', 'orvian-addons' ),
				'type'                 => Controls_Manager::SELECT,
				'options'              => [
					'169'    => '16:9',
					'219'    => '21:9',
					'43'     => '4:3',
					'32'     => '3:2',
					'11'     => '1:1',
					'916'    => '9:16',
					'custom' => esc_html__( 'Custom', 'orvian-addons' ),
				],
				'selectors_dictionary' => [
					'169'    => '1.77777', // 16 / 9
					'219'    => '2.33333', // 21 / 9
					'43'     => '1.33333', // 4 / 3
					'32'     => '1.5', // 3 / 2
					'11'     => '1', // 1 / 1
					'916'    => '0.5625', // 9 / 16
					'custom' => '',
				],
				'default'              => '169',
				'selectors'            => [
					'{{WRAPPER}} .elementor-wrapper' => '--video-aspect-ratio: {{VALUE}}',
				],
			]
		);

		$this->add_control(
			'aspect_ratio_custom',
			[
				'label'       => esc_html__( 'Custom Aspect Ratio (width / height)', 'orvian-addons' ),
				'type'        => Controls_Manager::TEXT,
				'placeholder' => '4/3',
				'condition'   => [
					'aspect_ratio' => 'custom',
				],
				'selectors'   => [
					'{{WRAPPER}} .elementor-wrapper' => '--video-aspect-ratio: {{VALUE}}',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Css_Filter::get_type(),
			[
				'name'     => 'css_filters',
				'selector' => '{{WRAPPER}} .elementor-wrapper',
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'section_image_overlay_style',
			[
				'label'     => esc_html__( 'Image Overlay', 'orvian-addons' ),
				'tab'       => Controls_Manager::TAB_STYLE,
				'condition' => [
					'show_image_overlay' => 'yes',
					'show_play_icon'     => 'yes',
				],
			]
		);

		$this->add_responsive_control(
			'play_icon_gap',
			[
				'label'      => esc_html__( 'Gap', 'orvian-addons' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', 'em', 'rem', 'custom' ],
				'selectors'  => [
					'{{WRAPPER}} .elementor-custom-embed-play' => 'gap: {{SIZE}}{{UNIT}}',
				],
				'condition'  => [
					'show_image_overlay' => 'yes',
					'show_play_icon'     => 'yes',
				],
			]
		);

		$this->add_control(
			'play_icon_title',
			[
				'label'     => esc_html__( 'Play Icon', 'orvian-addons' ),
				'type'      => Controls_Manager::HEADING,
				'condition' => [
					'show_image_overlay' => 'yes',
					'show_play_icon'     => 'yes',
				],
			]
		);

		$this->add_control(
			'play_icon_color',
			[
				'label'     => esc_html__( 'Color', 'orvian-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .elementor-custom-embed-play i' => 'color: {{VALUE}}',
					'{{WRAPPER}} .elementor-custom-embed-play .orvian-svg-icon' => 'color: {{VALUE}}',
					'{{WRAPPER}} .elementor-custom-embed-play > svg' => 'fill: {{VALUE}}',
				],
				'condition' => [
					'show_image_overlay' => 'yes',
					'show_play_icon'     => 'yes',
				],
			]
		);

		$this->add_responsive_control(
			'play_icon_size',
			[
				'label'      => esc_html__( 'Size', 'orvian-addons' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', 'em', 'rem', 'custom' ],
				'range'      => [
					'px' => [
						'min' => 10,
						'max' => 300,
					],
				],
				'selectors'  => [
					// Not using a CSS vars because the default size value is coming from a global scss file.
					'{{WRAPPER}} .elementor-custom-embed-play i' => 'font-size: {{SIZE}}{{UNIT}}',
					'{{WRAPPER}} .elementor-custom-embed-play .orvian-svg-icon' => '--svg-size: {{SIZE}}{{UNIT}}',
					'{{WRAPPER}} .elementor-custom-embed-play > svg' => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}};',
				],
				'condition'  => [
					'show_image_overlay' => 'yes',
					'show_play_icon'     => 'yes',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Text_Shadow::get_type(),
			[
				'name'           => 'play_icon_text_shadow',
				'selector'       => '{{WRAPPER}} .elementor-custom-embed-play i',
				'fields_options' => [
					'text_shadow_type' => [
						'label' => esc_html__( 'Shadow', 'orvian-addons' ),
					],
				],
				'condition'      => [
					'show_image_overlay'  => 'yes',
					'show_play_icon'      => 'yes',
					'play_icon[library]!' => 'svg',
				],
			]
		);

		$this->add_control(
			'play_icon_text_heading',
			[
				'label'     => esc_html__( 'Play Text', 'orvian-addons' ),
				'type'      => Controls_Manager::HEADING,
				'condition' => [
					'show_image_overlay' => 'yes',
					'show_play_icon'     => 'yes',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'      => 'play_icon_text_typography',
				'selector'  => '{{WRAPPER}} .elementor-custom-embed-play .play-icon__text',
				'condition' => [
					'show_image_overlay' => 'yes',
					'show_play_icon'     => 'yes',
				],
			]
		);

		$this->add_control(
			'play_icon_text_color',
			[
				'label'     => esc_html__( 'Color', 'orvian-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .elementor-custom-embed-play .play-icon__text' => 'color: {{VALUE}}',
				],
				'condition' => [
					'show_image_overlay' => 'yes',
					'show_play_icon'     => 'yes',
				],
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'section_lightbox_style',
			[
				'label'     => esc_html__( 'Lightbox', 'orvian-addons' ),
				'tab'       => Controls_Manager::TAB_STYLE,
				'condition' => [
					'show_image_overlay'  => 'yes',
					'image_overlay[url]!' => '',
					'lightbox'            => 'yes',
				],
			]
		);

		$this->add_control(
			'lightbox_color',
			[
				'label'     => esc_html__( 'Background Color', 'orvian-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'#elementor-lightbox-{{ID}}' => 'background-color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'lightbox_ui_color',
			[
				'label'     => esc_html__( 'UI Color', 'orvian-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'#elementor-lightbox-{{ID}} .dialog-lightbox-close-button' => 'color: {{VALUE}}',
					'#elementor-lightbox-{{ID}} .dialog-lightbox-close-button svg' => 'fill: {{VALUE}}',
				],
			]
		);

		$this->add_control(
			'lightbox_ui_color_hover',
			[
				'label'     => esc_html__( 'UI Hover Color', 'orvian-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'#elementor-lightbox-{{ID}} .dialog-lightbox-close-button:hover' => 'color: {{VALUE}}',
					'#elementor-lightbox-{{ID}} .dialog-lightbox-close-button:hover svg' => 'fill: {{VALUE}}',
				],
			]
		);

		$this->add_responsive_control(
			'lightbox_content_animation',
			[
				'label'              => esc_html__( 'Entrance Animation', 'orvian-addons' ),
				'type'               => Controls_Manager::ANIMATION,
				'frontend_available' => true,
				'separator'          => 'before',
			]
		);

		$this->add_control(
			'deprecation_warning',
			[
				'type'       => Controls_Manager::ALERT,
				'alert_type' => 'danger',
				'content'    => esc_html__( 'Note: These controls have been deprecated and are only visible if they were previously in use. The video’s width and position are now set based on its aspect ratio.', 'orvian-addons' ),
				'separator'  => 'before',
				'condition'  => [
					'lightbox_video_width!'      => '',
					'lightbox_content_position!' => '',
				],
			]
		);

		$this->add_control(
			'lightbox_video_width',
			[
				'label'      => esc_html__( 'Content Width', 'orvian-addons' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%', 'em', 'rem', 'vw', 'custom' ],
				'default'    => [
					'unit' => '%',
				],
				'condition'  => [
					'lightbox_video_width!'      => '',
					'lightbox_content_position!' => '',
				],
			]
		);

		$this->add_control(
			'lightbox_content_position',
			[
				'label'                => esc_html__( 'Content Position', 'orvian-addons' ),
				'type'                 => Controls_Manager::SELECT,
				'frontend_available'   => true,
				'options'              => [
					''    => esc_html__( 'Center', 'orvian-addons' ),
					'top' => esc_html__( 'Top', 'orvian-addons' ),
				],
				'selectors_dictionary' => [
					'top' => 'top: 60px',
				],
				'condition'            => [
					'lightbox_video_width!'      => '',
					'lightbox_content_position!' => '',
				],
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'hover_cursor_controls_style',
			[
				'label'     => esc_html__( 'Hover Cursor', 'orvian-addons' ),
				'tab'       => Controls_Manager::TAB_STYLE,
				'condition' => [
					'show_play_icon' => '',
				],
			]
		);

		$this->register_hover_cursor_controls_style( '', [ 'show_play_icon' => '' ] );

		$this->end_controls_section();
	}

	/**
	 * Print a11y text
	 *
	 * @param array $image_overlay Image overlay.
	 */
	public function print_a11y_text( $image_overlay ) {
		if ( empty( $image_overlay['alt'] ) ) {
			echo esc_html__( 'Play Video', 'orvian-addons' );
		} else {
			echo esc_html__( 'Play Video about', 'orvian-addons' ) . ' ' . esc_attr( $image_overlay['alt'] );
		}
	}

	/**
	 * Render widget output
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();

		$video_url = $settings[ $settings['video_type'] . '_url' ];

		if ( 'hosted' === $settings['video_type'] ) {
			$video_url = $this->get_hosted_video_url();
		} else {
			if ( 'videopress' === $settings['video_type'] ) {
				$video_url = $this->get_videopress_video_url();
			}

			$embed_params  = $this->get_embed_params();
			$embed_options = $this->get_embed_options();
		}

		if ( empty( $video_url ) ) {
			return;
		}

		if ( 'youtube' === $settings['video_type'] ) {
			$video_html = '<div class="elementor-video orvian-video"></div>';
		}

		if ( 'hosted' === $settings['video_type'] ) {
			$this->add_render_attribute( 'video-wrapper', 'class', 'e-hosted-video' );

			ob_start();

			$this->render_hosted_video();

			$video_html = ob_get_clean();
		} else {
			$is_static_render_mode = Plugin::$instance->frontend->is_static_render_mode();
			$post_id               = get_queried_object_id();

			if ( $is_static_render_mode ) {
				$video_html = Embed::get_embed_thumbnail_html( $video_url, $post_id );
			} elseif ( 'youtube' !== $settings['video_type'] ) {
				$video_html = Embed::get_embed_html( $video_url, $embed_params, $embed_options );
			}
		}

		if ( empty( $video_html ) ) {
			echo esc_url( $video_url );

			return;
		}

		$this->add_render_attribute( 'video-wrapper', 'class', [ 'elementor-wrapper', 'orvian-video-elementor', 'yes' === $settings['show_play_icon'] ? 'elementor-has-playicon' : '' ] );
		if ( ! empty( $settings['play_icon_text_size'] ) ) {
			$this->add_render_attribute( 'play_icon_text', 'class', [ 'play-icon__text' ] );
			$play_icon_text_size = $this->resolve_text_tag( $settings['play_icon_text_size'], 'play_icon_text' );
		}

		if ( 'yes' === $settings['play_icon_use_font_family_heading'] ) {
			$this->add_render_attribute( 'play_icon_text', 'class', 'font-heading text-heading tracking-heading' );
		}

		$this->add_render_attribute( 'video-wrapper', 'class', 'elementor-open-' . ( $settings['lightbox'] ? 'lightbox' : 'inline' ) );
		?>
		<div <?php $this->print_render_attribute_string( 'video-wrapper' ); ?> <?php $this->render_hover_cursor_attributes(); ?>>
			<?php
			if ( ! $settings['lightbox'] ) {
				Utils::print_unescaped_internal_string( $video_html ); // XSS ok.
			}

			if ( $this->has_image_overlay() ) {
				$this->add_render_attribute( 'image-overlay', 'class', 'elementor-custom-embed-image-overlay' );

				if ( $settings['lightbox'] ) {
					if ( 'hosted' === $settings['video_type'] ) {
						$lightbox_url = $video_url;
					} else {
						$lightbox_url = Embed::get_embed_url( $video_url, $embed_params, $embed_options );
					}

					$lightbox_options = [
						'type'         => 'video',
						'videoType'    => $settings['video_type'],
						'url'          => $lightbox_url,
						'autoplay'     => $settings['autoplay'],
						'modalOptions' => [
							'id'                       => 'elementor-lightbox-' . $this->get_id(),
							'entranceAnimation'        => $settings['lightbox_content_animation'],
							'entranceAnimation_tablet' => $settings['lightbox_content_animation_tablet'],
							'entranceAnimation_mobile' => $settings['lightbox_content_animation_mobile'],
							'videoAspectRatio'         => $settings['aspect_ratio'] ?? '169',
						],
					];

					if ( 'hosted' === $settings['video_type'] ) {
						$lightbox_options['videoParams'] = $this->get_hosted_params();
					}

					$this->add_render_attribute(
						'image-overlay',
						[
							'data-elementor-open-lightbox' => 'yes',
							'data-elementor-lightbox'      => wp_json_encode( $lightbox_options ),
							'data-e-action-hash'           => Plugin::instance()->frontend->create_action_hash( 'lightbox', $lightbox_options ),
						]
					);

					if ( Plugin::$instance->editor->is_edit_mode() ) {
						$this->add_render_attribute(
							'image-overlay',
							[
								'class' => 'elementor-clickable',
							]
						);
					}
				} else {
					if ( empty( $settings['image_overlay']['id'] && ! empty( $settings['image_overlay']['url'] ) ) ) {
						$image_url = $settings['image_overlay']['url'];
					} else {
						$image_url = Group_Control_Image_Size::get_attachment_image_src( $settings['image_overlay']['id'], 'image_overlay', $settings );
					}

					$this->add_render_attribute( 'image-overlay', 'style', 'background-image: url(' . $image_url . ');' );
				}
				?>
				<div <?php $this->print_render_attribute_string( 'image-overlay' ); ?>>
					<?php if ( $settings['lightbox'] ) : ?>
						<?php Group_Control_Image_Size::print_attachment_image_html( $settings, 'image_overlay' ); ?>
					<?php endif; ?>
					<?php if ( 'yes' === $settings['show_play_icon'] ) : ?>
						<div class="elementor-custom-embed-play inline-flex items-center gap-2" role="button" aria-label="<?php $this->print_a11y_text( $settings['image_overlay'] ); ?>" tabindex="0">
							<?php
							if ( empty( $settings['play_icon']['value'] ) ) {
								// phpcs:ignore WordPress.Security.EscapeOutput
								echo \OrvianAddons\Helper::get_svg( 'play', 'ui', [ 'class' => 'button-play--default' ] );
							} else {
								Icons_Manager::render_icon( $settings['play_icon'], [ 'aria-hidden' => 'true' ] );
							}

							if ( ! empty( $settings['play_icon_text'] ) ) {
								?>
								<<?php echo esc_attr( $play_icon_text_size ); ?> <?php $this->print_render_attribute_string( 'play_icon_text' ); ?> >
									<?php echo wp_kses_post( $settings['play_icon_text'] ); // phpcs:ignore WordPress.Security.EscapeOutput ?>
								</<?php echo esc_attr( $play_icon_text_size ); ?>>
								<?php
							}
							?>
						</div>
					<?php endif; ?>
				</div>
			<?php } ?>
		</div>
		<?php
		$this->render_hover_cursor_template();
	}

	/**
	 * Render video widget as plain content.
	 *
	 * Override the default behavior, by printing the video URL instead of rendering it.
	 */
	public function render_plain_content() {
		$settings = $this->get_settings_for_display();

		if ( 'hosted' !== $settings['video_type'] ) {
			$url = $settings[ $settings['video_type'] . '_url' ];
		} else {
			$url = $this->get_hosted_video_url();
		}

		echo esc_url( $url );
	}

	/**
	 * Get embed params.
	 *
	 * Retrieve video widget embed parameters.
	 *
	 * @return array Video embed parameters.
	 */
	public function get_embed_params() {
		$settings = $this->get_settings_for_display();

		$params = [];

		if ( $settings['autoplay'] && ! $this->has_image_overlay() ) {
			$params['autoplay'] = '1';

			if ( $settings['play_on_mobile'] ) {
				$params['playsinline'] = '1';
			}
		}

		$params_dictionary = [];

		if ( 'youtube' === $settings['video_type'] ) {
			$params_dictionary = [
				'loop',
				'controls',
				'mute',
				'rel',
				'cc_load_policy',
			];

			if ( $settings['loop'] ) {
				$video_properties = Embed::get_video_properties( $settings['youtube_url'] );

				$params['playlist'] = $video_properties['video_id'];
			}

			$params['start'] = $settings['start'];

			$params['end'] = $settings['end'];

			$params['wmode'] = 'opaque';
		} elseif ( 'vimeo' === $settings['video_type'] ) {
			$params_dictionary = [
				'loop',
				'mute'           => 'muted',
				'vimeo_title'    => 'title',
				'vimeo_portrait' => 'portrait',
				'vimeo_byline'   => 'byline',
			];

			$params['color'] = str_replace( '#', '', $settings['color'] );

			$params['autopause'] = '0';

			if ( ! empty( $settings['yt_privacy'] ) ) {
				$params['dnt'] = 'true';
			}
		} elseif ( 'dailymotion' === $settings['video_type'] ) {
			$params_dictionary = [
				'controls',
				'mute',
				'showinfo' => 'ui-start-screen-info',
				'logo'     => 'ui-logo',
			];

			$params['ui-highlight'] = str_replace( '#', '', $settings['color'] );

			$params['start'] = $settings['start'];

			$params['endscreen-enable'] = '0';
		} elseif ( 'videopress' === $settings['video_type'] ) {
			$params_dictionary = $this->get_params_dictionary_for_videopress();

			$params['at'] = $settings['start'];
		}

		foreach ( $params_dictionary as $key => $param_name ) {
			$setting_name = $param_name;

			if ( is_string( $key ) ) {
				$setting_name = $key;
			}

			$setting_value = $settings[ $setting_name ] ? '1' : '0';

			$params[ $param_name ] = $setting_value;
		}

		return $params;
	}

	/**
	 * Whether the video widget has an overlay image or not.
	 *
	 * Used to determine whether an overlay image was set for the video.
	 *
	 * @return bool Whether an image overlay was set for the video.
	 */
	protected function has_image_overlay() {
		$settings = $this->get_settings_for_display();

		return ! empty( $settings['image_overlay']['url'] ) && 'yes' === $settings['show_image_overlay'];
	}

	/**
	 * Get embed options.
	 */
	private function get_embed_options() {
		$settings = $this->get_settings_for_display();

		$embed_options = [];

		if ( 'youtube' === $settings['video_type'] ) {
			$embed_options['privacy'] = $settings['yt_privacy'];
		} elseif ( 'vimeo' === $settings['video_type'] ) {
			$embed_options['start'] = $settings['start'];
		}

		$embed_options['lazy_load'] = ! empty( $settings['lazy_load'] );

		return $embed_options;
	}

	/**
	 * Get the hosted video parameters.
	 */
	private function get_hosted_params() {
		$settings = $this->get_settings_for_display();

		$video_params = [];

		foreach ( [ 'autoplay', 'loop', 'controls' ] as $option_name ) {
			if ( $settings[ $option_name ] ) {
				$video_params[ $option_name ] = '';
			}
		}

		if ( $settings['preload'] ) {
			$video_params['preload'] = $settings['preload'];
		}

		if ( $settings['mute'] ) {
			$video_params['muted'] = 'muted';
		}

		if ( $settings['play_on_mobile'] ) {
			$video_params['playsinline'] = '';
		}

		if ( ! $settings['download_button'] ) {
			$video_params['controlsList'] = 'nodownload';
		}

		if ( $settings['poster']['url'] ) {
			$video_params['poster'] = $settings['poster']['url'];
		}

		return $video_params;
	}

	/**
	 * Get the hosted video URL from the current selected settings.
	 */
	private function get_hosted_video_url() {
		$settings = $this->get_settings_for_display();

		if ( ! empty( $settings['insert_url'] ) ) {
			$video_url = $settings['external_url']['url'];
		} else {
			$video_url = $settings['hosted_url']['url'];
		}

		if ( empty( $video_url ) ) {
			return '';
		}

		if ( $settings['start'] || $settings['end'] ) {
			$video_url .= '#t=';
		}

		if ( $settings['start'] ) {
			$video_url .= $settings['start'];
		}

		if ( $settings['end'] ) {
			$video_url .= ',' . $settings['end'];
		}

		return $video_url;
	}

	/**
	 * Get the VideoPress video URL from the current selected settings.
	 *
	 * @return string
	 */
	private function get_videopress_video_url() {
		$settings = $this->get_settings_for_display();

		if ( ! empty( $settings['insert_url'] ) ) {
			return $settings['videopress_url'];
		}

		return $settings['hosted_url']['url'];
	}

	/**
	 * Get the params dictionary for VideoPress videos.
	 *
	 * @return array
	 */
	private function get_params_dictionary_for_videopress() {
		return [
			'controls',
			'autoplay'       => 'autoPlay',
			'mute'           => 'muted',
			'loop',
			'play_on_mobile' => 'playsinline',
		];
	}

	/**
	 * Render the hosted video.
	 */
	private function render_hosted_video() {
		$video_url = $this->get_hosted_video_url();
		if ( empty( $video_url ) ) {
			return;
		}

		$video_params = $this->get_hosted_params();
		?>
		<video class="elementor-video orvian-video" src="<?php echo esc_attr( $video_url ); ?>" <?php Utils::print_html_attributes( $video_params ); ?>></video>
		<?php
	}
}
