<?php
/**
 * Shortcode OrvianAddons
 *
 * @package OrvianAddons
 */

namespace OrvianAddons;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Shortcode
 */
class Shortcode {

	/**
	 * Instance
	 *
	 * @var $instance
	 */
	private static $instance;

	/**
	 * Initiator
	 *
	 * @return object
	 */
	public static function instance() {
		if ( ! isset( self::$instance ) ) {
			self::$instance = new self();
		}

		return self::$instance;
	}

	/**
	 * Instantiate the object.
	 *
	 * @return void
	 */
	public function __construct() {
		add_shortcode( 'orvian_year', [ __CLASS__, 'year' ] );
	}

	/**
	 * Display current year
	 */
	public static function year() {
		return gmdate( 'Y' );
	}
}
